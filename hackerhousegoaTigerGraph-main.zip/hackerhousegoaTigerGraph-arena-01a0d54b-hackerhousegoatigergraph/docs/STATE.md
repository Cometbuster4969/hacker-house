# Investigation State Machine

The authoritative definition of `InvestigationState`, the 16 nodes, their contracts, transitions, budgets, and the trace/replay format.

The state schema is a plain `TypedDict` plus reducer functions. LangGraph drives it; **nothing in the schema depends on LangGraph**, so a hand-rolled state machine is a drop-in replacement.

---

## 1. State schema

```python
class InvestigationState(TypedDict):
    # ─── identity — immutable after intake ───────────────────────────────
    case_id: str
    trigger_type: Literal["risk_score", "customer_report", "analyst_request"]
    trigger_text: str
    flagged_txn_id: str
    card_id: str
    customer_id: str
    risk_score: float | None
    as_of: datetime                  # = case.opened_at. BINDS EVERY GRAPH READ.

    # ─── episode ─────────────────────────────────────────────────────────
    candidate_txn_ids: list[str]
    episode_txn_ids: list[str]
    first_suspicious_txn_id: str
    connected_card_ids: list[str]
    connected_device_profiles: list[str]
    connected_regions: list[str]
    exposure_usd: float

    # ─── hypotheses and plan ─────────────────────────────────────────────
    hypotheses: list[Hypothesis]
    plan: list[ToolCall]
    rejected_tools: list[RejectedTool]   # considered, not run, WITH reason

    # ─── evidence ────────────────────────────────────────────────────────
    evidence: list[Evidence]

    # ─── memory ──────────────────────────────────────────────────────────
    similar_prior_cases: list[str]
    retrieved_docs: list[DocRef]

    # ─── assessment ──────────────────────────────────────────────────────
    features: dict[str, float]
    p_det: float
    p_llm: float
    fraud_probability: float
    verdict: Literal["fraud", "legitimate", "uncertain"]
    pattern: Pattern
    pattern_description: str
    n_independent_signals: int
    signal_axes: list[str]
    confidence_low: float
    confidence_high: float
    sensitivity: str                 # "what would change my mind"

    # ─── flags the policy engine reads ───────────────────────────────────
    flags: PolicyFlags

    # ─── evidence requests ───────────────────────────────────────────────
    evidence_requests: list[EvidenceRequest]
    responses: list[SimulatedResponse]

    # ─── decision ────────────────────────────────────────────────────────
    initial_actions: list[ActionRef]
    final_actions: list[ActionRef]
    what_changed: str
    sar: SAR | None

    # ─── control ─────────────────────────────────────────────────────────
    step: int
    tool_calls: int
    tokens: int
    started_at: float
    latency_s: float
    round: int
    stop_reason: str
    status: Literal["open", "closed_fraud", "closed_legitimate", "escalated"]
    graph_case_id: str
    errors: list[str]
    trace: list[TraceEvent]
```

### Supporting types

```python
@dataclass
class Hypothesis:
    pattern: Pattern
    rationale: str
    probes: list[str]                # query names this hypothesis needs

@dataclass
class ToolCall:
    query: str                       # "device_neighbors"
    params: dict                     # MUST include as_of
    for_hypothesis: Pattern

@dataclass
class RejectedTool:
    query: str
    reason: str                      # "device degree < 3"
    # ★ this is the strongest evidence of agency in the whole trace

@dataclass
class Evidence:
    claim: str
    source: Literal["graph", "document", "customer", "external"]
    ref: str                         # "query:card_window(card_id=…, hours=48)"
    entity_ids: list[str]            # all must exist in the dataset
    axis: str                        # for independence counting
    weight: float = 1.0

@dataclass
class PolicyFlags:
    channel: Literal["online", "in_person"]
    response: Literal["none", "denied", "confirmed", "no_reply"]
    shared_origin: bool
    shared_element: str
    in_ring: bool
    ring_size: int
    is_recurring: bool
    cross_customer: bool
    conflicting_evidence: bool
    cards_confirmed_fraud: int
    credentials_compromised: bool
    max_cleared_purchase: float
    disputed: bool

@dataclass
class ActionRef:
    action: str                      # one of the 14
    route: Literal["auto", "L1", "L2"]
    reason: str                      # MUST cite a rule: "R5: testing sequence…"
```

---

## 2. Node contracts

| # | Node | Reads | Writes | Tools | Failure behaviour |
|---|---|---|---|---|---|
| 1 | `intake` | case_pack row | identity fields | 0 | Raise. No case without a valid trigger. |
| 2 | `as_of_bind` | `opened_at` | `as_of` | 0 | Raise. `as_of` is mandatory. |
| 3 | `episode_construct` | identity, `as_of` | `candidate_txn_ids` | Q1, Q2, Q3, Q17 | Degrade to `[flagged_txn_id]`, record in `errors` |
| 4 | `hypothesize` ★LLM | evidence so far | `hypotheses`, `plan`, `rejected_tools` | 0 | Fall back to all five patterns as hypotheses |
| 5 | `gather_evidence` | `plan` | `evidence`, `flags.*` | ≤ 20 (Q4, Q7, Q10, Q12, Q16, Q18) | Record per-query error; continue with what landed |
| 6 | `recall_memory` | `features`, episode | `similar_prior_cases`, `retrieved_docs` | Q13, Q14, Q15 | Empty lists; do not block |
| 7 | `assess` | `evidence`, `features` | `p_det`, `verdict`, `pattern`, `n_independent_signals`, `sensitivity` | 0 | Needs ≥ 1 evidence item, else verdict `uncertain` |
| 8 | `hypothesis_llm` ★LLM | evidence brief | `p_llm`, `pattern_description` | 0 | Skip fusion, use `p_det` alone |
| 9 | `stop_or_continue` | `p`, `flags`, evidence | `stop_reason` or routes to 10 | 0 | Conservative: stop if VOI cannot be computed |
| 10 | `request_evidence` | `sensitivity` | `evidence_requests`, `responses` | 0 | Fixed response policy; never tuned |
| 11 | `reassess` | `p`, `responses` | `fraud_probability`, `verdict` | 0 | Keep previous `p` |
| 12 | `policy_resolve` ★ | `p`, `flags`, `exposure_usd` | `initial_actions` / `final_actions` | 0 | **Must never fail.** A case with no actions is invalid. |
| 13 | `rank_actions` | actions, `p`, `exposure_usd` | reordered actions | 0 | Keep policy order |
| 14 | `case_writeback` | full state | `graph_case_id` | `add_nodes`, `add_edges` | Record error, set `written_to_graph=False` |
| 15 | `explain` ★LLM | evidence list | `summary`, `sar.narrative`, `what_changed` | 0 | Template fallback (`--no-llm`) |
| 16 | `validate` | assembled answer | report | 0 | Repair once, then fail loudly |

★LLM = one of exactly two LLM nodes.
★ = deterministic and independently testable.

---

## 3. Transitions

```
intake → as_of_bind → episode_construct → hypothesize → gather_evidence
  → recall_memory → assess → hypothesis_llm → stop_or_continue

stop_or_continue:
  ├── hard stop      → policy_resolve                       (see §4)
  ├── VOI > 0 and round < BUDGET_MAX_ROUNDS
  │                  → request_evidence → reassess → stop_or_continue
  └── VOI == 0       → policy_resolve                       ("nothing can change the decision")

policy_resolve → rank_actions → case_writeback → explain → validate → emit
```

**No cycles except the evidence loop**, which is bounded by `BUDGET_MAX_ROUNDS = 2`.

---

## 4. Stopping

Checked in this order at `stop_or_continue`.

### 4.1 Hard stops (policy §6)

```python
if p >= 0.85 and n_independent_signals >= 2:      # §6 "at or above 0.85"
    stop("Fraud probability 0.85+ supported by N independent signals.")
if p <= 0.15 and n_independent_signals >= 2:      # §6 "at or below 0.15"
    stop("Probability below 0.15 on N independent signals.")
if flags.response in ("denied", "confirmed"):
    stop("Customer response settles the question.")
if round >= BUDGET_MAX_ROUNDS:
    stop("Evidence-request budget exhausted.")
if tool_calls >= BUDGET_TOOL_CALLS or elapsed >= BUDGET_WALL_S:
    stop("Investigation budget exhausted.")
```

### 4.2 Independence counting

Two evidence items are independent iff their `axis` values differ. Axes:

`velocity` · `amount` · `device` · `geography` · `channel` · `model_residual` · `graph` · `memory`

`n_independent_signals = len({e.axis for e in evidence if e.weight > 0})`

Without this, five variations of "the amount is unusual" count as five signals.

### 4.3 Value of information

```python
def voi(state) -> float:
    A_now = policy.resolve(state)
    best = 0.0
    for request in candidate_requests(state):
        flip = 0.0
        for response, p_response in RESPONSE_PRIORS[request.type].items():
            s2 = apply(state, request, response)
            A2 = policy.resolve(s2)
            if A2 != A_now:
                flip += p_response
        best = max(best, flip * abs(expected_cost(A_now) - expected_cost(A2))
                        - COST_OF_ASKING[request.type])
    return best
```

`stop_or_continue` proceeds iff `voi > 0`. `stop_reason` must name the number:

> "No response can change the action set (VOI = 0.00). At p = 0.44 the legal actions are MONITOR_CARD and VERIFY_WITH_CUSTOMER regardless of whether the customer confirms or denies."

---

## 5. Budgets

| Budget | Value | Enforced in | On breach |
|---|---|---|---|
| `BUDGET_TOOL_CALLS` | 30 | `graph/mcp_client.py` | `BudgetExceeded` → stop, record in `errors` |
| `BUDGET_WALL_S` | 60 | `agent/graph.py` | Stop at the next node boundary |
| `BUDGET_MAX_ROUNDS` | 2 | `stop_or_continue` | Hard stop |
| `MAX_HYPOTHESES` | 4 | `hypothesize` | Truncate to top 4 by prior |
| `MAX_EVIDENCE_ITEMS` | 25 | `gather_evidence` | Keep highest-weight |

Budgets are **not** tuned per case. A case that hits its budget produces a thinner, honest answer — never a special-cased one.

---

## 6. Trace format

`traces/<case_id>.json`. This file powers the UI timeline, the demo replay, and the `tool_calls` / `tokens` / `latency_s` answer fields.

```json
{
  "case_id": "HHG-010",
  "as_of": "2016-12-02T18:18:27",
  "events": [
    {
      "seq": 7,
      "node": "gather_evidence",
      "kind": "tool_call",
      "tool": "tigergraph__run_installed_query",
      "query": "device_neighbors",
      "params": {"as_of": "2016-12-02T18:18:27", "device_id": "D000731", "days": 30},
      "for_hypothesis": "card_not_present_new_device",
      "latency_ms": 214,
      "result_digest": {"n_cards": 4, "n_txns": 11},
      "concluded": "Device seen on 3 other cards this month; prior closed case CC-0141"
    },
    {
      "seq": 8,
      "node": "gather_evidence",
      "kind": "tool_rejected",
      "query": "ring_components",
      "reason": "device degree 1 < 3; ring sweep not informative",
      "concluded": null
    },
    {
      "seq": 19,
      "node": "assess",
      "kind": "assessment",
      "p_det": 0.41, "p_llm": 0.55, "fused": 0.44,
      "n_independent_signals": 2,
      "sensitivity": "A customer denial would move p to ~0.8 and unblock BLOCK_CARD"
    }
  ],
  "final": { "tool_calls": 11, "tokens": 12480, "latency_s": 18.7 }
}
```

**`tool_rejected` events are not optional.** They are the clearest evidence that the agent is choosing, not executing a fixed script.

---

## 7. Replay contract

`ui/replay.py` renders a frozen trace as if live. **The demo is recorded from replay, never from a live run** — see [`ROADMAP.md` G11](../ROADMAP.md).

Contract:

1. The UI reads **only** `traces/*.json` and `cases/*.json`. Never the graph, never the LLM, never the network.
2. Replaying a trace must render identically, every time, offline.
3. A trace is complete: it contains every value the UI needs. No recomputation at render time.

Test: `tests/test_replay.py` — render all 20 traces with the network disabled and assert no exceptions and stable output hashes.

---

## 8. Persistence and determinism

- One `InvestigationState` per case, no shared mutable state between cases.
- Cases run **sequentially in `case_pack` order** so memory accumulates (case 12 can cite case 3). Documented in the blog.
- `policy.resolve()` is pure ⇒ `initial_actions` and `final_actions` are reproducible from the state alone.
- `NFR-10`: same case, same seed, same answer modulo LLM prose. Prose differences are confined to `summary`, `narrative`, `what_changed`, `pattern_description`.
