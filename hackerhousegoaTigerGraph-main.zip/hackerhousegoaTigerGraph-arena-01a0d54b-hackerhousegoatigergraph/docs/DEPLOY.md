# Deployment & Submission Runbook

**Deadline: 24 Sept 2026, 23:59 IST. Read §0 first — it tells you what to skip.**

---

## 0. Read this first (2 minutes)

### The situation

This repo contains a complete fraud-investigation agent, but everything committed so far ran on **synthetic data**.
Tonight you will produce the real submission: **20 answer files generated from the real dataset**,
plus a demo video, a blog post, a social post, and the submission form.

### The track for tonight: real CSVs + memory adapter

There are two ways to run the agent:

| Track | Command | Needs |
|---|---|---|
| **Memory (tonight)** | `anvesh run --all --data-dir data/HHGOA_IEEE` | Just the downloaded CSVs. No TigerGraph, no API keys. |
| Full graph (not tonight) | `... --adapter tigergraph` | Savanna instance + 708 MB upload + finished loading job + 10 query installs |

**Use the memory track.** It reads the same real CSVs, runs the same investigator, and produces
real answer files that pass the same 15 checks. The full graph track is the better system and most
of it is built (`graph/*.gsql`, the MCP adapter), but the loading job only loads vertices so far —
edge loading was never finished — and Savanna provisioning plus a 708 MB upload plus GSQL debugging
does not fit in the hours left. A complete honest submission beats an unfinished ambitious one.
Say exactly that in the blog (§7); judges reward honesty about scope cuts.

### Golden rules

1. **Start the dataset download FIRST** (§1). It is the longest pole. Everything else happens while it runs.
2. **The form goes in before 23:59 no matter what** (§9). A form with 4 links beats no form.
3. If you fall behind, drop things in this order (last resort first): social post → blog length
   (shorter is fine) → demo polish (unedited is fine) → backtest numbers → **never** drop the
   20 validated files or the form.
4. **Never download or consult the public IEEE-CIS / Kaggle fraud files.** The challenge data was
   transformed so outcomes cannot be looked up; using the public files is **disqualification**.
   Touch only the `HHGOA_IEEE` folder from the challenge Drive link.

### What "done" looks like (8 artifacts)

- [ ] `cases/HHG-001.json` … `cases/HHG-020.json` on `main`, generated from real data, `validate` green
- [ ] `traces/` + `benchmark/backtest.json` committed alongside
- [ ] README results table filled with your backtest numbers
- [ ] Demo video uploaded (unlisted is fine), link in hand
- [ ] Blog post published, link in hand
- [ ] Social post live, tagging **@TigerGraphDB**, link in hand
- [ ] Repo is **public**
- [ ] Form submitted + confirmation screenshot: `https://forms.gle/yxXzqSULGgZ9VUF56`

---

## 1. Start the dataset download (do this NOW — it runs in the background)

**Goal:** a folder `data/HHGOA_IEEE/` containing 5 files. Time: 15–45 min depending on your connection.
Start it, then move to §2 while it downloads.

**Method A — command line (recommended):**

```bash
pip install gdown
mkdir -p data
gdown --folder "https://drive.google.com/drive/folders/1YDJUW1fiE7Jx8R9KqknC4IcsED9zll2A" -O data/
```

**Method B — browser (fallback):** open the link above, select all files, download.
If Drive refuses to zip the big file, download `transactions.csv` individually.

**Verify when it finishes** — you must see all four CSVs (names must match exactly):

```bash
ls -la data/HHGOA_IEEE/
# README.md  transactions.csv  identity.csv  closed_cases_history.csv  case_pack.csv
```

Row-count sanity check (`transactions.csv` must have **590,742** data rows):

```bash
# macOS / Linux:
wc -l data/HHGOA_IEEE/*.csv
# Windows PowerShell:
(Get-Content data\HHGOA_IEEE\transactions.csv | Measure-Object -Line).Lines
```

`wc -l` counts the header line too, so expect 590,743 lines for `transactions.csv`.

> ⏭️ **Skip this section** if `data/HHGOA_IEEE/` already has all four CSVs with the right row counts.

---

## 2. Get the code running (while the download runs)

**Goal:** the `anvesh` command works and the pipeline runs on synthetic data. Time: ~10 min.

```bash
# 1. Clone and enter the repo
git clone https://github.com/nickkerDroid/hackerhousegoaTigerGraph.git
cd hackerhousegoaTigerGraph
git log --oneline -1   # you should be on main, past the "MCP-backed ..." commit

# 2. Check Python (need 3.10 or newer)
python3 --version

# 3. Create and activate a virtual environment
python3 -m venv .venv
source .venv/bin/activate            # macOS / Linux
# .venv\Scripts\activate             # Windows PowerShell instead

# 4. Install (small: pydantic, numpy, pandas, scikit-learn, pytest)
pip install -e ".[dev]"

# 5. Smoke test — one synthetic case, then validate all 20 shipped files
anvesh run --case HHG-002            # expect: "1/1 cases passed validation"
anvesh validate                      # expect: "20/20 files passed"
```

**Expected:** two green confirmations. If `anvesh` is "command not found", your venv isn't
activated (repeat step 3), or use the fallback `python -m anvesh.cli ...` instead of `anvesh ...`.

**Config:** copy the example env file. **Leave everything blank — that is correct for tonight**
(no TigerGraph needed; no LLM key needed — the agent falls back to deterministic templates):

```bash
cp .env.example .env
```

(The code reads `.env` only for connection details; blank values select the offline path.
`.env` is gitignored — never commit it.)

> ⏭️ **Skip this section** if `anvesh validate` already prints `20/20 files passed`.

---

## 3. Skim `data/README.md` (10 minutes, while things run)

**Goal:** know the answer format and the policy at a high level, so the blog (§7) is accurate.
Open `data/HHGOA_IEEE/README.md` and read it once. You do **not** need to memorise it —
`anvesh validate` enforces the format mechanically. Pay attention to anything marked as a rule
or a disqualifier.

---

## 4. Run the pipeline on real data (after the download finishes)

**Goal:** 20 real answer files + validation + backtest numbers. Time: ~10–20 min.

```bash
# Make sure the venv is still activated (you should see (.venv) in your prompt)

# 1. Investigate all 20 real cases (this overwrites cases/ and traces/ with REAL output)
anvesh run --all --data-dir data/HHGOA_IEEE
```

**Expected output** (numbers on the first line are the tell that real data loaded):

```
[data] data/HHGOA_IEEE: pack=20 closed=5565
[data] 590,742 transactions in memory
  PASS  HHG-001  p=0.81 ...
  ...
20/20 cases passed validation
```

```bash
# 2. Validate the real answer files (the 15 submission checks)
anvesh validate --data-dir data/HHGOA_IEEE
# Expected: 20/20 files passed
```

If any file says FAIL, **do not hand-edit it** — read the ERROR lines, and:
- a column-mapping complaint → the loader couldn't match a CSV header (see Appendix A);
- anything else → fix forward in code, or ask for help (Appendix A tells you what to paste).

```bash
# 3. Backtest on real data (gives you the numbers for the README + blog)
anvesh backtest --data-dir data/HHGOA_IEEE --fit-limit 2000
```

**Expected:** a table like this (your numbers will differ — that is fine and expected):

```
  arm              n     accuracy   brier    auc
  onset (upper)    ...   ...        ...      ...
  random (honest)  ...   ...        ...      ...
written to benchmark/backtest.json
```

Copy these numbers into the README table (§5). **Episode IoU is not printed by the backtest** —
leave that column as `not measured` (see §5). Report both arms honestly, even if `random` is
much worse than `onset` — the gap is a finding, not an embarrassment (see `docs/BACKTEST.md`).

> ⏭️ **Running out of time?** Step 3 (backtest) is droppable — README can say "backtest pending".
> Steps 1–2 are not.

---

## 5. Fill the README table, commit, push (15 min)

**Goal:** real results on `main`, visible on GitHub. The shipped table looks like this:

```markdown
| | Verdict accuracy | Episode IoU | AUC | Brier |
|---|---|---|---|---|
| Onset trigger (upper bound) | — | — | — | — |
| **Random trigger (honest)** | — | — | — | — |
```

Replace it with your §4 numbers (example values — use YOURS):

```markdown
| | Verdict accuracy | Episode IoU | AUC | Brier |
|---|---|---|---|---|
| Onset trigger (upper bound) | 0.917 | not measured | 1.0 | 0.141 |
| **Random trigger (honest)** | 0.929 | not measured | 1.0 | 0.120 |
```

Then commit and push **only the submission artifacts** (never `data/` or `.env` —
both are gitignored, and pushing 708 MB will fail anyway):

```bash
git add cases/ traces/ benchmark/ README.md
git status --short        # MUST NOT list data/ or .env — if it does, stop and unstage them
git commit -m "Real-data submission: 20 answer files, traces, backtest"
git push origin main
```

Verify on `github.com/nickkerDroid/hackerhousegoaTigerGraph`: `cases/` shows 20 files,
README shows your numbers.

---

## 6. Record and upload the demo (25 min — START THE UPLOAD EARLY)

**Goal:** a 3-minute unedited screen capture, uploaded unlisted, link in hand.
**Record from replay, never from a live run.** The replay UI reads only the frozen
`cases/` + `traces/` you just committed, so it cannot break mid-recording.

```bash
anvesh serve
# replay served on http://0.0.0.0:8000/index.html
```

Open `http://localhost:8000/index.html` in your browser. Click through it once to rehearse,
then record (starts the clock — keep it under 4 minutes):

| Time | Say | Do |
|---|---|---|
| 0:00 | "An alert fires. The bank's model scored this transaction 0.90 — and nine times out of ten, that's a false alarm." | Show the case queue |
| 0:30 | "The agent binds everything to the case's open time. It cannot see the future." | Show the timeline / as_of |
| 1:00 | "It builds the episode, forms hypotheses, and picks which evidence to pull." | Show evidence / hypotheses |
| 1:45 | "Two signals, not enough to block — so it asks. Only a denial changes the answer." | Show uncertainty + the question |
| 2:15 | "The response moves the probability and the action panel changes with it — with the approval route." | Show actions + approve button |
| 2:45 | "Case written up, report filed, next case." | Show the finished case file |

**Recording tools:** Windows `Win+G` (Xbox Game Bar) · macOS `Cmd+Shift+5` · Linux OBS/SimpleScreenRecorder ·
any phone filming the screen also works. Cursor visible, narrate the *decision*, not the buttons.
Raw and unedited is acceptable. Missing is not.

**Upload immediately** to YouTube as **Unlisted**, copy the link. Upload + processing takes
5–15 min — start it, then write the blog (§7) while it processes.

---

## 7. Publish the blog (30 min)

**Goal:** a published post covering the brief's six required topics. Tonight, ~900 words beats
2,000 missing words. Publish on **dev.to** (GitHub login, paste markdown, Publish — no review queue).

Outline (steal the section drafts from `docs/CONTENT.md` §1 and cut ruthlessly):

1. **What we built** — one paragraph + the thesis: *the graph supplies the facts, the model
   supplies the probability, the policy engine makes the call, the LLM writes it down.*
   Lead with your real numbers (20 alerts → N cases, M SARs, backtest accuracy).
2. **Architecture** — the four layers; the one rule (**the LLM never picks the action**).
3. **How TigerGraph is used** — be precise and honest: 10 installed parameterised queries, all
   `as_of`-bounded; single-source ring walk; MCP as the only graph path; case write-back.
   Then one honest paragraph: the graph path is built and tested, but tonight's 20 files ran on
   the memory adapter over the real CSVs because Savanna provisioning + the 708 MB load + GSQL
   install did not fit the remaining hours. Link `graph/` in the repo.
4. **Agentic capabilities** — hypotheses pick the queries; it asks only when an answer could
   change the actions; show one probability move from a real trace.
5. **The numbers** — your backtest table, both arms, plus the honest findings (prior shift,
   onset-vs-random gap).
6. **Learned / would improve** — 3 bullets each (candidates in `docs/CONTENT.md`).

Link the repo and the demo video. Hit Publish, copy the link.

---

## 8. Post on social (10 min)

**Goal:** a post tagging **@TigerGraphDB** with a link to the blog or demo.
Copy the X thread draft from `docs/CONTENT.md` §3 (or the LinkedIn single-post version),
**swap in your real numbers**, post it, copy the link, screenshot it.

Checklist: tags @TigerGraphDB · links blog or demo (both if space allows) · posted before the deadline.

---

## 9. Make the repo public + submit the form (10 min — BEFORE 23:59)

**1. Push anything left**, then make the repo public** (submission requirement — it is currently private).
On github.com: repo page → **Settings** → scroll to **Danger Zone** → **Change visibility** →
**Make public** → type the repo name to confirm. (Or: `gh repo edit --visibility public`.)

**2. Fill the form:** `https://forms.gle/yxXzqSULGgZ9VUF56`

Have these 5 links ready before you open it: repo URL · demo URL · blog URL · social URL ·
your contact email. If a link is missing at 23:50, submit anyway with what you have —
a form with the repo + demo beats no form. **Screenshot the confirmation page.**

**3. Breathe.** Verify each link opens in an incognito window (catches private-video / draft-post mistakes).

---

## Appendix A. Troubleshooting

| Symptom | Fix |
|---|---|
| `anvesh: command not found` | venv not activated: `source .venv/bin/activate` (or `.venv\Scripts\activate` on Windows). Fallback: `python -m anvesh.cli ...` |
| `pip install` fails | Upgrade pip first: `pip install -U pip setuptools wheel`. Need Python ≥ 3.10 (`python3 --version`). |
| `gdown --folder` fails / quota error | Use browser download (§1 Method B). If `transactions.csv` stalls, retry — Drive resumes. |
| `run` says data dir / file not found | Folder must be exactly `data/HHGOA_IEEE/` with the four CSV names from §1. Case-sensitive on macOS/Linux. |
| `run` dies with a loader error about columns | A real CSV header didn't match the loader's aliases. Open the CSV header + `src/anvesh/data/loader.py` aliases, or set the `*_FROM` overrides in `.env` (see `LoadConfig.from_env`). |
| `validate` FAILs on real files | Read the ERROR lines — they name the check. Never hand-edit answer files; fix the code and re-run. |
| `run` is slow / machine struggles | Close the browser during the run (590k rows live in RAM). It should still finish in minutes. |
| `anvesh serve` page is empty | `cases/` + `traces/` must exist — re-run §4 step 1 first. |
| YouTube still processing at 23:50 | Submit the form with the video link anyway — processing usually finishes within minutes; verify after. |
| **Anything else** | Paste the *full terminal output* (command + all lines + error) to your AI assistant along with which § step you were on. The exact text matters more than your summary of it. |

## Appendix B. The full graph track (for after the deadline)

Honestly scoped, for learning/follow-up — **not tonight**:

1. Finish `graph/loading_job.gsql`: it currently loads only `Transaction` + `ClosedCase` vertices.
   Edge `LOAD` statements (`MADE`, `NEXT`, `FROM_DEVICE`, …) must be written against the real CSV headers.
2. Provision Savanna (`https://savanna.tgcloud.io`), enable auto-start, create the secret.
3. Install schema + loading job + 10 queries (paste each `graph/*.gsql` file through GraphStudio
   or `conn.gsql(...)` via pyTigerGraph — `pip install -e ".[tigergraph]"`), fix GSQL compile errors.
4. Upload CSVs in ≤ 16 MB chunks, run the loading job, confirm 590,742 / 5,565 counts.
   (Automated loader script available: `python scripts/graph_load.py --data-dir data/HHGOA_IEEE` or `--subset`.)
5. Fill `.env` with `TG_*`, run `anvesh verify --data-dir data/HHGOA_IEEE`,
   then `anvesh run --all --data-dir data/HHGOA_IEEE --adapter tigergraph`.

## Appendix C. Command cheat sheet (tonight, in order)

```bash
# §1 download (first!)
pip install gdown && mkdir -p data
gdown --folder "https://drive.google.com/drive/folders/1YDJUW1fiE7Jx8R9KqknC4IcsED9zll2A" -O data/

# §2 install + smoke test
git clone https://github.com/nickkerDroid/hackerhousegoaTigerGraph.git && cd hackerhousegoaTigerGraph
python3 -m venv .venv && source .venv/bin/activate && pip install -e ".[dev]"
anvesh run --case HHG-002 && anvesh validate && cp .env.example .env

# §4 real run (after download finishes)
anvesh run --all --data-dir data/HHGOA_IEEE
anvesh validate --data-dir data/HHGOA_IEEE
anvesh backtest --data-dir data/HHGOA_IEEE --fit-limit 2000

# §5 commit real results (fill README table first)
git add cases/ traces/ benchmark/ README.md && git commit -m "Real-data submission" && git push origin main

# §6 demo
anvesh serve   # then open http://localhost:8000/index.html and record
```
