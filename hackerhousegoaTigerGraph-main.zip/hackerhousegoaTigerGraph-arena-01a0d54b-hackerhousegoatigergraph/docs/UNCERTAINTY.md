# Uncertainty Model

How `fraud_probability` is produced. This field is **scored for calibration**, and it drives R1, the case-opening threshold, the stop rule and the SAR decision.

---

## 1. The corrected model

```
logit(p) = logit(π₀)                                          # explicit assumption, documented
         + γ · Σᵢ wᵢ · log LRᵢ                                # LRs from closed cases
         + [ log(π_target/(1−π_target)) − log(π_train/(1−π_train)) ]   # ← the G3 correction

p = α · p_det + (1 − α) · p_llm                               # fusion, α fitted on held-out split
```

`γ ∈ (0,1]` is a shrinkage exponent: the evidence axes are **not** independent, so raw log-LR summation over-confidences. Fit `γ`, `wᵢ` and `α` on the held-out split only.

---

## 2. ⚠️ The prior cannot be learned from the closed cases

This is the most important correction in the document set. See [`ROADMAP.md` G3](../ROADMAP.md).

**The problem.** `closed_cases_history.csv` contains cases the bank already chose to open: 4,665 confirmed, 900 cleared — an **83.9% fraud rate**. The 20 benchmark cases are *alerts*, and the dataset README says roughly half are legitimate, and that above 0.7 *most* flagged transactions turn out legitimate.

A model fitted on an 84%-fraud population and applied to a ~50%-fraud population over-predicts fraud. Since `fraud_probability` drives R1, the stop rule and the case threshold, that means **systematic over-blocking — which the policy calls a breach.**

**It is also not computable as originally specified.** The closed-case file has **no `trigger_type` column**. Its columns are `case_id, customer_id, card_id, opened_at, closed_at, outcome, pattern, first_fraud_txn_id, txn_ids, n_txns, exposure_usd, connected_card_ids, actions_taken, report_filed, analyst_notes`. A prior conditioned on trigger type cannot be learned from it.

### The fix

**Split the problem.**

| Component | Source | Valid? |
|---|---|---|
| **Likelihood ratios** — how evidence shifts belief | Closed cases | ✅ Yes. `P(f \| confirmed) / P(f \| cleared)` is a *within-population* ratio; its ordering survives outcome-dependent selection |
| **Prior** — base rate before evidence | **Explicit assumption, documented** | ⚠️ Must be stated, not fitted |
| **Level correction** | The G3 shift below | ✅ Directionally correct; magnitude approximate |

### Documented priors (`π_target`)

| Trigger | Risk band | `π₀` | Rationale |
|---|---|---|---|
| `risk_score` | < 0.50 | 0.20 | Low model score |
| `risk_score` | 0.50 – 0.70 | 0.30 | Mid |
| `risk_score` | 0.70 – 0.90 | 0.40 | *"Above 0.7, most flagged transactions turn out to be legitimate"* |
| `risk_score` | > 0.90 | 0.45 | Highest band, still below even |
| `customer_report` | — | 0.50 | Disputes are often recurring charges the customer forgot — R7 exists for exactly this |
| `analyst_request` | — | 0.50 | Pre-filtered by a human |

These are **assumptions, not measurements.** They are printed in the blog, in the README, and in the answer-file provenance. If you disagree with one, change it in `config.py` — but change it *deliberately and in the open*.

### The correction

```python
PI_TRAIN = 4665 / 5565          # 0.8383 — the closed-case base rate

def correct_prior(p_model: float, pi_target: float) -> float:
    shift = logit(pi_target) - logit(PI_TRAIN)
    return sigmoid(logit(p_model) + shift)
```

Worked example: `π_target = 0.40`, `π_train = 0.838`.
`shift = logit(0.40) − logit(0.838) = (−0.405) − (1.644) = −2.049`.
A model output of `0.85` becomes `0.42`.

That is a large shift, and it is **correct**: you are moving from a population that is 84% fraud to one that is 40% fraud.

**Honest caveat, to be stated in the blog:** the standard case-control correction assumes selection on the outcome. Here selection is by an upstream triage rule that *correlates* with the outcome. The correction is therefore first-order — directionally right, magnitude approximate. This is why we report **AUC** (valid under selection) alongside Brier (valid only given the assumed `π_target`).

---

## 3. Feature vector

Identical construction for closed cases and benchmark cases — this is what makes the model transferable. All computed **as of `opened_at`**.

| Axis | Features |
|---|---|
| `velocity` | n txns in 1 h / 24 h / 7 d; burst ratio; inter-arrival entropy |
| `amount` | z-score vs cardholder baseline; max/mean ratio; count of sub-$5 authorizations |
| `device` | device new to account (`id_15`); distinct cards on device in window; proxy flag (`id_23`); profile age |
| `geography` | distinct regions in 24 h; max geo-velocity; foreign-country share |
| `channel` | online/in-person mix shift; count of anomalous `M1`–`M9` flags |
| `model_residual` | `v_anom` (IsolationForest / PCA reconstruction error over `V1`–`V339`) |
| `graph` | ring membership; shared-origin degree; connected-card count |
| `memory` | max similarity to a prior confirmed case; similarity to a prior cleared case |

**Novelty features are always relative to `cardholder_baseline`** over `[as_of − days, as_of]`. Never over the full six months.

---

## 4. Likelihood ratios

For each axis, over the closed cases:

```
LRᵢ = P(featureᵢ | confirmed_fraud) / P(featureᵢ | cleared)
```

Computed on binned features, with Laplace smoothing, on the **training split only**. Combine in logit space with the fitted shrinkage `γ`.

Closed cases are also the source of the behavioural fingerprint vectors (`ClosedCase.fp`) used for kNN memory and for the undocumented-pattern residual scan.

---

## 5. Fusion and update

```python
p = alpha * p_det + (1 - alpha) * p_llm        # alpha fitted on held-out split
```

The LLM sees the structured evidence brief and returns an independent probability **and** a pattern label. If `p_llm` proves unstable, set `α = 1` and say so in the blog — that is a finding, not a failure.

**Bayesian update on the simulated response:**

```python
P_UPDATE = {
    "denied":    LR_denied,     # learned from closed cases where analyst_notes record the answer
    "confirmed": LR_confirmed,
    "no_reply":  LR_no_reply,
}
p_after = sigmoid(logit(p_before) + log(LR[response]))
```

Report calibration **before and after** in the blog.

---

## 6. Fingerprint vectors

Used for memory retrieval and the residual scan. **Not** an embedding — a hand-built behavioural vector, so it is cheap, interpretable and stable across embedding models.

```
fp = [ amount_z, log1p(exposure), n_txns_in_48h, device_novelty, region_novelty,
       product_novelty, channel_mix_shift, geo_velocity_max, hour_of_day_sin,
       hour_of_day_cos, v_anom, ring_size ]
```

~12 floats. Normalised. Stored on `ClosedCase.fp` and `InvestigationCase.fp`.

---

## 7. Calibration and metrics

Isotonic or Platt calibration fitted on a **separate** slice from the LR estimation, to avoid double-dipping.

Report:

| Metric | Target | Valid under selection? |
|---|---|---|
| AUC (held-out closed cases) | ≥ 0.75 | ✅ Yes |
| Brier (after prior correction) | ≤ 0.15 | ⚠️ Given `π_target` |
| Reliability, 0.8 bucket | actual rate 0.65–0.95 | ⚠️ Given `π_target` |
| Backtest verdict accuracy (random trigger) | ≥ 0.80 | See [`BACKTEST.md`](./BACKTEST.md) |

**Report the ranking metric as the headline and the level metric with its caveat.** Publishing a confident Brier score built on an assumed prior would be the same mistake in a different place.

---

## 8. Interpretive gaps we had to close

The policy leaves several terms undefined. Each is closed by an explicit, documented decision in `config.py`. **Every one of these is a HYPOTHESIS — flagging them in the blog is cheap credibility.**

| Policy term | Our resolution |
|---|---|
| "fraud is **strongly suspected**" (§3a SAR) | `p >= 0.70` |
| "a **single signal**" (R1) | `n_independent_signals == 1` |
| "**independent** pieces of evidence" (§6) | distinct `Evidence.axis` |
| "**several** cards" (R6) | `>= 2` cards sharing an element |
| "in **one window**" (R6) | 7 days |
| "**materially larger** purchase" (R5) | `>= 5×` the mean of the small authorizations, or above the card's amount baseline |
| "small" authorizations (R5) | `< $5` |
| "**no reply** within 24 hours" (R4) | simulated at 24 h |
| "**monthly**" recurring (R7) | cadence 25–35 days |
| "same **merchant**" (R7) | `ProductCode` — **no merchant column exists** |
| "**coordinated or repeated** abuse" (R9) | ≥ 3 clustered episodes sharing an entity |
| "**ongoing** monitoring" | 72 hours (per `MONITOR_CARD`) |

---

## 9. What not to do

- **Do not** treat `risk_score` as a probability. It is an input. *"A score is a reason to look, never a verdict."*
- **Do not** fit the prior on the closed-case base rate and call it calibrated.
- **Do not** emit `0.0` or `1.0`. Clamp to `[0.01, 0.99]`.
- **Do not** tune the simulated customer response to reach a verdict.
- **Do not** report a metric tuned on the evaluation split.
