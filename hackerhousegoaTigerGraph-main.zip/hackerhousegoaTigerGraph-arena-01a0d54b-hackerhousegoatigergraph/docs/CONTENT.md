# Content: blog, demo, social

**These are required submission components, not marketing.** A missing blog post or social post can cost more than a missing feature. See [`ROADMAP.md` G13](../ROADMAP.md).

Protected: **no feature work after T-6h.** Content only.

---

## 1. Technical blog post

Required topics, per the brief: what you built, the architecture, how TigerGraph is used, the agentic capabilities, what you learned, what you would improve.

**Target: 1,500–2,200 words.** Publish anywhere (dev.to, Hashnode, Medium, GitHub Pages) and link it.

### Outline

**1. What we built (150 words)**
One paragraph. The thesis in one sentence: *the graph supplies the facts, the model supplies the probability, the policy engine makes the call, and the LLM writes it down.* Say what the agent does end to end, and name the number up front — "on 20 alerts, it opened N cases, filed M SARs, and found one fraud ring spanning K cards."

**2. The architecture (300 words)**
The four-layer diagram from [`ARCHITECTURE.md`](./ARCHITECTURE.md) §1, plus the one rule: **the LLM is not allowed to choose actions.** Explain why: a quarter of the score is policy-legal, correctly-routed actions, and an action sampled from a language model cannot be unit-tested. The policy engine is ~300 lines of pure Python with 22 scenario tests.

**3. How TigerGraph is used (400 words)** — the section judges read most closely
- **Schema**: 15 vertex types, 26 edge types. Call out the two-tier device model (`DeviceProfile` precise, `DeviceSignature` fuzzy) and why: firmware-build rotation defeats exact matching.
- **GSQL**: 10 installed parameterised queries, every one `as_of`-bounded. Explain `as_of` and why it matters — *the agent structurally cannot see the future*.
- **Graph algorithms**: a single-source `ring_components` walk over owned and card-sharing links, `as_of`-bounded, to find a card's ring at an hour.
- **TigerVector**: four vector attributes — closed-case narratives, behavioural fingerprints, policy/regulator chunks, and our own cases.
- **MCP**: `tigergraph-mcp` over stdio is the **only** path from the agent to the graph. Every read is traced; the write profile is append-only, with no drop/delete tools exposed.
- **Write-back**: each closed investigation becomes an `InvestigationCase` vertex with typed edges, so case 12 can find case 3 through the graph rather than through a vector.

**4. The agentic capabilities (300 words)**
- Hypothesis-driven tool selection: the LLM proposes 2–4 hypotheses; **each hypothesis selects which queries run next.** Log the queries it *rejected* and why.
- Value-of-information stopping: it asks for evidence only when a plausible response could change the action set. Quote a real `stop_reason`.
- Bayesian update on the response: show a number moving 0.44 → 0.81 and the action set changing with it.
- Permissions: `auto` actions execute; `L1`/`L2` wait for a human. Show the approve button.

**5. The numbers (250 words)** — *nobody else will have this*
The backtest table from [`BACKTEST.md`](./BACKTEST.md), both arms. Then the two honest findings:

- **The selection-bias problem.** We trained on 5,565 closed cases that were 84% fraud, then applied the model to alerts that are ~50% fraud. The fix was a one-line prior correction; report Brier before and after.
- **The backtest that flattered us.** Our first protocol handed the agent `first_fraud_txn_id` — the transaction where the fraud began. Strictly easier than the real task. Random triggers dropped accuracy from X to Y, and the gap told us something real about the problem.

Also: episode IoU, calibration gap, tool calls and latency per case.

**6. What we learned (200 words)**
Three specific things. Candidates:
- The risk score is inverted at the top end — most transactions above 0.7 are legitimate, so the prior has to be *learned or explicitly assumed*, never read off the score.
- `identity.csv` covers online transactions only; roughly a third of the graph has no device record, and every detector has to know that.
- The hardest problem was not detection but **episode segmentation** — deciding where the fraud episode stops, because exposure feeds the approval route and the SAR threshold.

**7. What we would improve (150 words)**
Three concrete items, honestly. Good candidates: replace the assumed prior with a measured one; real vector-search tuning; go from two evidence rounds to full sequential design; temporal graph neural network for the model-residual axis.

### Style

- Lead with the number.
- Include the architecture diagram and one real `stop_reason`.
- **Name the mistakes.** Sections 5 and 6 are the most credible thing in the submission and they cost nothing extra to write.
- Link the repo and the demo.

---

## 2. Demo video (3–5 minutes)

**Record from replay.** Never from a live run. See [`UI.md`](./UI.md) §1.

### Storyboard

| Time | Beat | Screen |
|---|---|---|
| 0:00 | "An alert fires. The bank's model scored transaction 3506725 at 0.90." | S1 queue |
| 0:15 | "Nine out of ten, that's a false alarm. Watch." | S1 |
| 0:30 | Agent binds `as_of` to the case's open time. It cannot see the future. | S2 timeline |
| 0:50 | It builds the episode, forms three hypotheses, and **chooses** which queries to run — and logs the one it rejected: "ring sweep — device degree 1, not informative." | S2 |
| 1:20 | Evidence streams in: device, region, velocity, closed-case recall. | S3 evidence board |
| 1:50 | Uncertainty panel: prior 0.40 → posterior 0.44, with the log-LR waterfall. "Two independent signals. Not enough to block." | S5 |
| 2:15 | "So it asks. Here's why: only a denial changes the answer. VOI 0.31." | S5 |
| 2:35 | Response simulated and disclosed on screen. Probability 0.44 → 0.81. **The action panel changes live**, with routes and rule citations. | S6 |
| 3:05 | "It wanted to block at step 14. R1 stopped it — one signal, p below 0.70. That block is a policy breach on a legitimate customer." | S6 suppressed list |
| 3:25 | SAR generated. Ring found. Connected cards monitored. Case written to the graph. | S7 / S8 |
| 3:45 | Memory: run case 12, watch it cite case 3 through the graph. | S8 |
| 4:05 | "It recommended the block. It cannot execute it." Click **Approve (L1)**. | S6 |

### Production notes

- 1080p, 4 minutes or under. Screen capture + voiceover.
- Cursor visible; move deliberately.
- Narrate the *decision*, not the interface.
- Raw and unedited is acceptable. Missing is not. Kill criterion at T-6h: ship a 3-minute unedited capture.

---

## 3. Social post

Required: post on **X or LinkedIn** about what you built, your approach, or your experience building on TigerGraph, **with a link to the blog or demo**, **tagging @TigerGraphDB**.

### X (thread of 4–5)

> **1/**
> We built a fraud-investigation agent on @TigerGraphDB that turns an uncertain alert into a defensible case — 590k transactions as a graph, every graph read through MCP, and a policy engine that decides what the bank is allowed to do.
>
> **2/**
> The design bet: the LLM never picks the action.
> The graph supplies the facts. A calibrated model supplies the probability. ~300 lines of deterministic policy code supply the action. The LLM writes the case up.
>
> **3/**
> The bit we're proudest of: our scoring model was biased and we caught it.
> The 5,565 labelled cases the dataset ships are 84% fraud. The alerts we're judged on are ~50% fraud. Fitting a prior on one and deploying on the other over-blocks — a policy breach.
>
> **4/**
> One-line fix: shift the intercept by the log-odds difference between the training and target base rates. Brier went 0.22 → 0.14.
> Our first backtest was also cheating — it handed the agent the exact transaction where the fraud started. Honest number: 0.79.
>
> **5/**
> Full write-up: [link]
> Demo: [link]
> #TigerGraph #GraphRAG #AgenticAI #HackerHouseGoa

### LinkedIn

> Most fraud "AI" demos stop at a risk score. The hard part starts after the alert.
>
> For the Hacker House Goa TigerGraph challenge we built **Anvesh** — an agent that takes one of 20 fraud alerts, investigates it against 590,742 card transactions held as a graph, and produces a case file, a regulatory report where policy requires one, and a recommended action with the approval route it needs.
>
> Three things we'd do again:
>
> **1. The LLM doesn't get to decide.** It reads an evidence brief assembled from the graph, proposes a pattern and a probability, and writes the case up. Actions come from a deterministic policy engine — because "recommend BLOCK_CARD" is not a creative task, and it has to be unit-testable.
>
> **2. Every graph read is timestamped.** Every query is bounded by the moment the case was opened, so the agent structurally cannot see the future. It sounds pedantic. It's what makes an investigation defensible.
>
> **3. We measured ourselves, and the first measurement lied.** Our first backtest handed the agent the transaction where the fraud began. Re-run with random triggers: 0.91 → 0.79. Reporting both was more useful than reporting either.
>
> The correction we're most glad we made: the labelled cases in the dataset are 84% fraud; the alerts we're scored on are about 50%. Fitting a prior on one population and deploying on another is textbook covariate shift — and in this domain it means blocking legitimate customers.
>
> Built on TigerGraph: 10 installed GSQL queries, behavioural rings via a single-source component walk, and the TigerGraph MCP server as the agent's only path to the graph. Thanks to the TigerGraph team for the challenge.
>
> Write-up: [link] · Demo: [link]
>
> @TigerGraphDB #FraudDetection #GraphRAG #AgenticAI #GraphDatabase

### Checklist

- [ ] Tags **@TigerGraphDB**
- [ ] Links the blog **or** the demo (both if space allows)
- [ ] Posted before the submission deadline
- [ ] Link pasted into the submission form

---

## 4. README.md

Lives at the repo root. Contents:

1. One-paragraph description + the thesis sentence
2. **Results table** (the honest backtest numbers)
3. Quickstart: install, configure, `anvesh verify`, `anvesh run --all --data-dir … --adapter tigergraph`
4. Architecture diagram (link to `docs/ARCHITECTURE.md`)
5. How TigerGraph is used
6. Repo layout
7. **Limitations** — subset vs full graph, assumed priors, simulated responses, what was cut
8. Links: blog, demo, this docs directory

The Limitations section is not optional. It is the fastest way to signal that the numbers mean something.
