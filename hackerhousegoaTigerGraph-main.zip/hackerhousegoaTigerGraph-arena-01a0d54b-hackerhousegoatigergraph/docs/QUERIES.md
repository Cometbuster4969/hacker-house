# GSQL Query Catalogue

The agent's complete tool surface. Installed with `tigergraph__install_query`, invoked with `tigergraph__run_installed_query`, wrapped by `src/anvesh/graph/tools.py`.

**Eight core queries** (build these first). The remaining ten are stretch.

---

## 0. The `as_of` contract

Every query takes `as_of DATETIME` as its **first** parameter.

> A transaction is visible to a query iff `txn.ts <= as_of`.

This is not a filter applied at the end. It is applied at the first hop of every traversal. A query that ignores `as_of` is a bug, not a shortcut.

Enforced by:
- `tests/test_graph_queries.py::test_no_future_leakage` — `as_of = 2016-07-01` ⇒ every query returns empty
- `AGENTS.md` rule R2
- code review: `params` must contain `as_of`

---

## 1. Core queries (build first)

### Q1 `txn_context`

```gsql
CREATE QUERY txn_context(DATETIME as_of, STRING txn_id) FOR GRAPH Anvesh
```

One hop in every direction from a transaction: card, customer, device profile, device signature, billing region, country, product, purchaser and recipient email.

**Returns:** the transaction, its card, its customer, `DeviceProfile` (null if in-person), `DeviceSignature`, `BillingRegion`, `BillingCountry`, `ProductCode`, email domains, and the card's transaction count.

**Used by:** `episode_construct` — always the first call.

---

### Q2 `card_window`

```gsql
CREATE QUERY card_window(DATETIME as_of, STRING card_id, INT hours) FOR GRAPH Anvesh
```

All transactions on a card in the window ending at `as_of`, ordered by `ts`, with inter-arrival gaps.

**Returns:** `[{txn_id, ts, amount, product_cd, channel, risk_score, region, device_id, gap_minutes}]`

**Used by:** `episode_construct`, every velocity detector.

---

### Q3 `cardholder_baseline`

```gsql
CREATE QUERY cardholder_baseline(DATETIME as_of, STRING card_id, INT days) FOR GRAPH Anvesh
```

Distributional baseline for the card over the preceding `days`: amount mean/σ, product-code frequency, region frequency, device frequency, typical hour-of-day, typical channel mix.

**Returns:** `{amount_mean, amount_std, product_hist, region_hist, device_hist, hour_hist, channel_hist, n_txns}`

**Used by:** every novelty detector. Amount z-scores, product novelty and region novelty are all relative to this.

> Baseline must be computed over `[as_of - days, as_of]` only — never over the whole six months.

---

### Q4 `device_neighbors`

```gsql
CREATE QUERY device_neighbors(DATETIME as_of, STRING device_id, INT days) FOR GRAPH Anvesh
```

Every card and transaction that touched this device profile within the window.

**Returns:** `{cards: [{card_id, n_txns, first_seen, last_seen}], txns: [...], closed_cases: [case_id]}`

**Used by:** hypothesis `card_not_present_new_device`; R6 shared-origin detection; HHG-014 (the ring case).

**Guard:** returns empty for in-person transactions. Callers must check `channel` first and record the absence, not infer a device.

---

### Q7 `geo_velocity`

```gsql
CREATE QUERY geo_velocity(DATETIME as_of, STRING card_id, INT hours) FOR GRAPH Anvesh
```

Walks `NEXT` within the window and joins `BILLED_IN`, producing consecutive transactions in different billing regions with the elapsed time between them.

**Returns:** `[{from_txn, to_txn, from_region, to_region, minutes_elapsed}]`

**Used by:** `out_of_region_use`. Impossible travel is the strongest single signal for a cloned card.

**Subtlety:** several days of purchases in one new region is a **trip, not a clone**. This query returns raw pairs; the *detector* applies the duration and simultaneity test. Do not encode "different region ⇒ fraud" in the query.

---

### Q10 `testing_sequence`

```gsql
CREATE QUERY testing_sequence(DATETIME as_of, STRING card_id, INT hours) FOR GRAPH Anvesh
```

Finds ≥ 3 small online authorizations within the window followed by a materially larger purchase on the same card.

**Returns:** `{fired: BOOL, small_txns: [...], large_txn: txn_id, large_amount: DOUBLE, gap_minutes: INT}`

**Used by:** R5. Threshold: small < $5, larger purchase materially above the card's baseline.

**Boundary:** the policy block triggers when "a purchase over $100 has already cleared" — strictly `> 100`. Return `large_amount` and let the policy engine compare.

---

### Q12 `recurring_check`

```gsql
CREATE QUERY recurring_check(DATETIME as_of, STRING card_id, INT days) FOR GRAPH Anvesh
```

Looks for a charge matching the cardholder's own recurring pattern: same `ProductCode`, amount within ±2%, on a roughly monthly cadence.

**Returns:** `{is_recurring: BOOL, matched_txns: [...], cadence_days: FLOAT}`

**Used by:** R7. Note that the policy says "same merchant" — **there is no merchant column in this dataset.** `ProductCode` is the closest available proxy. Document this mapping in the evidence claim.

---

### Q17 `episode_expand`

```gsql
CREATE QUERY episode_expand(DATETIME as_of, SET<STRING> seed_txn_ids, INT hops) FOR GRAPH Anvesh
```

Grows a candidate set from seeds via device, region, email and `NEXT`-chain adjacency, bounded by `as_of` and `hops`.

**Returns:** `[{txn_id, ts, amount, via: STRING, distance: INT}]` where `via` ∈ {`next`, `device`, `region`, `email`}

**Used by:** `episode_construct`. Candidate generation only — scoring and boundary selection happen in `evidence/episode.py`.

---

## 2. Stretch queries (build after the eight)

> **Shipped status:** of these, only Q16 `shared_origin` became an installed query
> (the shipped ten are the §1 eight plus `ring_components` and `shared_origin`).
> The rest were cut — the agent never calls them. Kept as specified future work.

| # | Query | Signature | Purpose |
|---|---|---|---|
| Q5 | `device_signature_neighbors` | `(as_of, sig_id, days)` | Fuzzy device linkage across firmware builds |
| Q6 | `region_window` | `(as_of, region_id, days)` | Activity in a billing region |
| Q8 | `email_cluster` | `(as_of, domain, days)` | Cards sharing a purchaser/recipient email |
| Q9 | `ring_components` | `(seed_txn, as_of, window_h, ...)` | **Shipped** as a single-source walk (see §3) |
| Q11 | `burst_detect` | `(as_of, card_id, hours)` | 2–4 online transactions within 48 h |
| Q13 | `prior_cases` | `(vec, k, as_of)` | TigerVector over `ClosedCase.emb`, then graph expansion |
| Q14 | `similar_agent_cases` | `(vec, k)` | Same over `InvestigationCase.emb` — the memory loop |
| Q15 | `policy_search` | `(vec, k)` | `DocChunk` retrieval, returns linked `Pattern` vertices |
| Q16 | `shared_origin` | `(as_of, element, id, days)` | **Shipped.** R6: every card sharing a device / region / email |
| Q18 | `counterfactual_exposure` | `(as_of, card_ids, hours)` | Forward exposure if we do not act → cost model |

---

## 3. Ring detection (Q9)

**Shipped as a single-source walk, not GDS.** The GDS library's `tg_wcc` computes
components for the whole graph and cannot be scoped to one card at one hour —
the agent's question is always "this card's ring at this `as_of`". So
`ring_components(seed_txn, as_of, window_h, ...)` walks owned and card-sharing
links from the seed with a visited-set, per-vertex degree caps, and `as_of`
filtering on every hop. Cost scales with the ring, not the graph.

Procedure (shipped):

1. Seed at the flagged transaction; walk `MADE` / `FROM_DEVICE` / `RESOLVES_TO` / email edges in both directions, `ts <= as_of` on every hop.
2. Track visited vertices; cap expansion per vertex (degree caps keep adversarial hubs cheap).
3. Keep cards with `>= min_cards` (default 3) distinct cards in the component.

Budget: ~0.3 s per call. Cost scales with the ring, not the graph — no global
WCC, no materialised projection to keep fresh.

---

## 4. Query conventions

1. **`as_of` is parameter 1, always.**
2. **Installed, not interpreted** — for speed and auditability. Interpreted `tigergraph__run_query` is the fallback when `INSTALL QUERY` is fighting you.
3. **Detectors do not call the graph.** Queries return data; `evidence/detectors.py` interprets it. This keeps detectors unit-testable without a database.
4. **Return IDs, not prose.** Every returned entity carries the ID used in answer files.
5. **Bound every result set.** Add `LIMIT` — a shared device can touch thousands of cards.
6. **Nulls, not guesses.** An in-person transaction returns `device_id = null`, never a default.
7. **Every query carries a comment** naming the pattern or rule it serves.

---

## 5. Testing

```
tests/test_graph_queries.py
  ::test_no_future_leakage          as_of = 2016-07-01 ⇒ all queries empty
  ::test_as_of_boundary             a txn exactly at as_of is visible; one second later is not
  ::test_in_person_has_no_device    Q1/Q4 on a ProductCD=W txn ⇒ device is null
  ::test_card_window_ordering       Q2 returns ascending ts, gaps consistent
  ::test_baseline_window            Q3 never includes txns after as_of
  ::test_episode_expand_bounded     Q17 returns no txn with ts > as_of
  ::test_ring_components_deterministic
```

Hand-verify the first five results of each query against pandas before trusting it. Generation is cheap; a wrong query produces confidently wrong evidence.
