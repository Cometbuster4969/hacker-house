# Analyst Workstation

Static single-file replay (`ui/index.html`, served by `anvesh serve`). **Replay-first: the UI reads only frozen artifacts.**

> **The UI never touches the graph, the LLM, or the network.** It renders `traces/*.json` and `cases/*.json`.
> See [`ROADMAP.md` G11](../ROADMAP.md) — this is what makes the demo recordable without a live database.

---

## 1. Replay contract

```python
# src/anvesh/ui/replay.py

def render(trace_path: Path, answer_path: Path) -> None:
    """Renders a frozen trace as if live. Deterministic. Offline. Repeatable."""
```

1. Inputs are **only** `traces/<case_id>.json` and `cases/<case_id>.json`.
2. A trace is **complete** — it contains every value the UI needs. No recomputation at render time.
3. Rendering is **deterministic** — same inputs, same screen, every time.
4. Test: `tests/test_replay.py` renders all 20 traces with networking disabled and asserts no exceptions and stable output hashes.

---

## 2. Screens

### S1 — Case queue

The 20 cases as a table: `case_id`, trigger type, risk score, status, verdict, `fraud_probability`, exposure.

Sortable and filterable. Colour-code verdict. This is the demo's opening shot — a wall of alerts, then the agent works one.

### S2 — Investigation timeline ★

Every step, in order, from the trace:

```
07  gather_evidence   device_neighbors(D000731, 30d)          214ms
                      → 3 other cards on this device; closed case CC-0141
08  gather_evidence   ✗ ring_components — device degree 1 < 3, not informative
09  recall_memory     prior_cases → CC-0141 (0.87), CC-2210 (0.71)
10  assess            p_det 0.41 ⊕ p_llm 0.55 → 0.44 · 2 independent signals
                      "A customer denial would move p to ~0.81 and unblock BLOCK_CARD"
11  stop_or_continue  VOI 0.31 → ask the customer
12  request_evidence  customer_validation → assumed: "I did not make this purchase"
13  reassess          0.44 → 0.81
14  policy_resolve    BLOCK_CARD(L1) · CREATE_CASE(auto) · FILE_REPORT(L2)
                      ⊘ BLOCK_CARD was suppressed at step 14 by R1 (p < 0.70, 1 signal)
```

**This screen carries the 15% for agentic design.** Show `tool_rejected` and `suppressed` events prominently — they are the proof that the agent chooses and is constrained, rather than executing a script.

### S3 — Evidence board

Claims grouped by hypothesis. Each shows its `source` chip (`graph` / `document` / `customer` / `external`), its `ref` (the query and parameters), and entity ID chips.

Clicking a `ref` shows the raw parameters including `as_of` — visible proof of temporal isolation.

### S4 — Graph explorer

The episode subgraph: `Customer → Card → Transaction → DeviceProfile / BillingRegion / EmailDomain`.

- affected transactions highlighted
- ring components in a distinct colour
- connected cards called out
- nodes greyed if `ts > as_of`, with a visible "not yet visible to the agent" legend

Shipped as a pre-rendered static layout: one static SVG/PNG of the subgraph per case, no graph library in the browser.

### S5 — Uncertainty panel ★

- **Prior → posterior** gauge: `π₀` → `p_det` → fused `p`
- **Log-LR waterfall** per evidence axis — which evidence moved the number, and by how much
- confidence band
- **"What would change my mind"** — the `sensitivity` field, rendered verbatim

This screen is the clearest demonstration of the 25% next-best-action criterion, because it shows the reasoning that produces the action.

### S6 — Action panel ★

`initial` and `final` side by side, with routes and rule citations, plus:

- expected-cost comparison across the legal alternatives
- the **suppressed** list: "BLOCK_CARD withheld at step 14 — R1: single signal, p < 0.70"
- **Approve (L1)** and **Approve (L2)** buttons

The buttons are the human-in-the-loop beat. Clicking records the approval against the action and executes it **in the simulator only**. The agent could not execute it alone. That is the demo's closing shot.

### S7 — Case file and SAR

The rendered answer JSON, plus the SAR narrative with a completeness checklist: **who / what / when / where / how / why** — one tick per element. Export as JSON.

### S8 — Memory

- similar prior cases retrieved, with similarity and outcome
- the graph path that connected them ("CC-0141 shares device profile D000731")
- this case's own contribution back to memory (`CASE_*` edges, `graph_case_id`)

### S9 — Policy trace

Which rules fired, on which predicate, in which order — and which were considered and did not fire.

---

## 3. Screen priority

| Priority | Screens | Rationale |
|---|---|---|
| **Must** | S2 timeline, S5 uncertainty, S6 actions | Direct rubric evidence: agentic 15%, NBA 25% |
| **Should** | S1 queue, S3 evidence, S7 case + SAR | Explainability 10% |
| **Could** | S4 graph explorer, S8 memory, S9 policy trace | TigerGraph depth, Innovation |

**If time collapses:** S2 + S5 + S6 in a single scrolling page. Nine screens can degrade to three; the demo cannot degrade to zero.

---

## 4. Data contracts

```python
# traces/<case_id>.json — see docs/STATE.md §6
# cases/<case_id>.json  — see docs/ANSWER_SCHEMA.md
```

The UI imports `domain.models` for typing and nothing else from `src/anvesh`. **No imports from `graph/`, `policy/`, `reasoning/` or `llm/`.** Enforce with an import check in `tests/test_replay.py` — a UI that can call the graph cannot be guaranteed replayable.

---

## 5. Running

```bash
anvesh serve            # Streamlit on 0.0.0.0:8501
anvesh serve --replay   # explicit replay-only mode (default)
```

Bind `0.0.0.0`, not `127.0.0.1`, so the live preview is reachable.
