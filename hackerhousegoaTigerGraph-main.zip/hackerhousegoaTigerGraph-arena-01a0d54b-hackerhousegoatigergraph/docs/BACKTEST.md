# Backtest Protocol

How we measure ourselves before seeing the answer key.

The dataset ships **5,565 labelled closed cases**. That is a held-out set we are given for free. Most teams will not use it; we will publish a number, and the number will be honest.

---

## 1. ⚠️ Why the original protocol was wrong

[`ROADMAP.md` G4](../ROADMAP.md). The first draft reconstructed each closed case's trigger from `first_fraud_txn_id`.

That is **contaminated**, for two reasons:

1. **It hands the agent the answer.** `first_fraud_txn_id` is the transaction where the analyst determined the fraud began. The real task gives an arbitrary flagged transaction — *"it is not necessarily where the fraud started, and it may not be fraud at all."* A backtest built on the onset is strictly easier than the exam.
2. **The two arms use different constructs.** For cleared cases there is no `first_fraud_txn_id`, so the draft fell back to "first transaction in `txn_ids`" — the earliest of a set that turned out benign. That is a different task, and averaging the two produces a meaningless number.

---

## 2. Corrected protocol

### 2.1 Splits

- **80 / 20**, stratified on `outcome` × `pattern`.
- Three disjoint slices:
  - **TRAIN** (60%) — fit LRs, `γ`, `wᵢ`, `α`
  - **CAL** (20%) — fit the isotonic/Platt calibrator
  - **EVAL** (20%) — reported. Touched only for final measurement.
- The `undocumented` and `none` pattern strata are small; stratify on them explicitly or the split will drop them.

### 2.2 Trigger reconstruction

| Arm | Trigger selection |
|---|---|
| **Honest (headline)** | Sample the flagged transaction **uniformly at random** from `txn_ids` |
| **Onset (upper bound)** | Use `first_fraud_txn_id` |
| **Cleared** | Sample uniformly from `txn_ids`, matched on risk-score band to the confirmed triggers |

`as_of = closed_case.opened_at`, always. The agent never sees beyond it.

### 2.3 What we measure

| Metric | Definition |
|---|---|
| **Verdict accuracy** | `verdict ∈ {fraud, legitimate}` correct vs `outcome` |
| **Episode IoU** | \|predicted ∩ `txn_ids`\| / \|predicted ∪ `txn_ids`\| |
| **Exposure error** | \|predicted `exposure_usd` − actual\| / actual |
| **AUC** | Ranking quality. Valid under outcome-dependent selection |
| **Brier** | After the G3 prior correction. Report **with the caveat** |
| **Reliability** | Predicted vs actual by decile |
| **Policy-legality** | Fraction of action sets passing the validator |
| **Calibration gap** | Brier before vs after correction |

### 2.4 Report both arms

```
                     Verdict acc.   Episode IoU    AUC     Brier
Onset trigger            0.91          0.74        0.86    0.11      ← upper bound
Random trigger           0.79          0.61        0.83    0.14      ← honest
```

**The gap is itself a finding.** If onset-triggered accuracy is 0.91 and random-triggered is 0.79, the agent is much better at confirming a known fraud than at finding one from an arbitrary alert — which is exactly the skill the benchmark tests. Put that in the blog.

---

## 3. Commands

```bash
anvesh backtest --split eval --trigger random --out benchmark/random.json
anvesh backtest --split eval --trigger onset  --out benchmark/onset.json
anvesh backtest --report                       # renders both, side by side
```

Output lands in `benchmark/`. The results table goes into `README.md` and the blog verbatim.

---

## 4. Discipline

1. **Tune only on TRAIN + CAL.** If you look at EVAL to make a decision, that decision is contaminated.
2. **Re-run the backtest after every change to detectors, features or the scorer.** It is the regression suite.
3. **Never tune the simulated customer response policy on EVAL.** It is fixed and disclosed.
4. **Publish the honest arm as the headline**, with the upper bound visible beside it.
5. **Publish the calibration gap.** "Brier 0.22 before correction, 0.14 after" is a stronger sentence than "Brier 0.14".

---

## 5. Using closed cases for supervised episode tuning

Separate from the probability backtest, and cheaper:

`closed_cases_history.csv` gives `txn_ids` for every case — **5,565 labelled episodes.** Use them to tune the segmentation threshold and `λ` in `evidence/episode.py` by maximising IoU directly.

This is free supervision for the single hardest unsupervised problem in the build. Use TRAIN only.

---

## 6. What the backtest cannot tell us

State these plainly in the blog:

- The 20 benchmark cases come from **November–December**; closed cases are **July–October**. There may be seasonal drift.
- The benchmark cases include `customer_report` and `analyst_request` triggers, which have **no analogue** in the closed-case file (no `trigger_type` column). The backtest exercises `risk_score`-like triggers only.
- Episode labels reflect what *one analyst* recorded, not ground truth.
- Everything rests on the assumed `π_target`. Say so.
