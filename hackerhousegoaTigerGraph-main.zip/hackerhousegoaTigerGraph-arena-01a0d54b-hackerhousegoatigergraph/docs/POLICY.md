# Policy Engine Specification

**This document governs 25% of the score.** It is the highest-value-per-hour artifact in the build.

Fraud Policy v1.0, encoded as deterministic Python. Source of truth: the dataset `README.md`, reproduced here verbatim where it matters.

**The engine is pure.** `resolve(state) -> Decision`. No I/O, no LLM, no network. Same state in, same decision out. That is what makes a quarter of the score unit-testable.

---

## 1. Actions (14)

| Action | Effect | Customer impact | Friction weight |
|---|---|---|---|
| `ALLOW_TRANSACTION` | Let the flagged transaction stand | None | 0 |
| `DECLINE_TRANSACTION` | Decline the flagged authorization only. Card stays active | Low | 1 |
| `MONITOR_CARD` | Card stays active; raise monitoring sensitivity for 72 h | None | 0 |
| `MONITOR_CONNECTED_CARDS` | Put linked cards (device / region cluster / ring) under monitoring | None | 0 |
| `WARN_CUSTOMER` | Send an informational message | None | 0 |
| `VERIFY_WITH_CUSTOMER` | Ask the cardholder. Card stays active pending reply | Low | 1 |
| `STEP_UP_AUTH` | Require OTP or app confirmation before further activity | Low | 2 |
| `BLOCK_CARD` | Block this card and reissue | High | 6 |
| `BLOCK_ALL_CARDS` | Block every card the customer holds | Very high | 15 |
| `GENERATE_REPORT` | Write up the investigation without opening a case | None | 0 |
| `CREATE_CASE` | Open an internal fraud case, write it to the graph | None | 0 |
| `FILE_REPORT` | File a SAR with the regulator | None | 0 |
| `ESCALATE_TO_ANALYST` | Hand the case to a human analyst | None | 0 |
| `CLOSE_NO_FRAUD` | Close the alert as legitimate | None | 0 |

An agent may recommend several actions for one case. **Order them by what happens first.**

## 2. Approval routing

```python
AUTO = {
    "ALLOW_TRANSACTION", "MONITOR_CARD", "MONITOR_CONNECTED_CARDS",
    "WARN_CUSTOMER", "VERIFY_WITH_CUSTOMER", "STEP_UP_AUTH",
    "GENERATE_REPORT", "CREATE_CASE", "ESCALATE_TO_ANALYST", "CLOSE_NO_FRAUD",
}

def route(action: str, exposure_usd: float) -> Literal["auto", "L1", "L2"]:
    if action == "BLOCK_CARD":
        return "L1" if exposure_usd <= 2500 else "L2"   # "exposure ≤ $2,500" / "> $2,500"
    if action in ("BLOCK_ALL_CARDS", "FILE_REPORT"):
        return "L2"                                      # "always"
    if action == "DECLINE_TRANSACTION":
        return "L1"
    if action in AUTO:
        return "auto"
    raise ValueError(f"unknown action: {action}")
```

Only `auto` actions may be **executed** by the agent. `L1` (team lead) and `L2` (fraud manager) are recommended with the route stated and wait for a human.

**The route is computed, never generated.** An LLM never supplies a route.

---

## 3. Exact comparison operators

Copy these literally. `>` vs `>=` is never a judgement call.

| Condition | Operator | Policy wording |
|---|---|---|
| Open a case | `p >= 0.30` | §3a "fraud probability **reaches** 0.30" |
| R1 verify before block | `p < 0.70` | "your assessed fraud probability is **below 0.70**" |
| R2 SAR | `exposure > 1_000` | "exposure **exceeds** $1,000" |
| R4 escalate | `exposure > 500` | "Escalate if exposure **exceeds** $500" |
| R5 block after cleared purchase | `max_cleared > 100` | "a purchase **over $100** has already cleared" |
| R8 escalate | `exposure > 500` | "exposure **exceeds** $500" |
| Stop — high | `p >= 0.85` | §6 "at or **above** 0.85" |
| Stop — low | `p <= 0.15` | §6 "at or **below** 0.15" |
| `BLOCK_CARD` → L1 | `exposure <= 2_500` | "exposure **≤ $2,500**" |
| `BLOCK_CARD` → L2 | `exposure > 2_500` | "exposure **> $2,500**" |

Every threshold in `src/anvesh/config.py` carries a comment quoting the policy line.

---

## 4. Rules R1–R10 as predicates

`state.flags` is `PolicyFlags` (see [`STATE.md`](./STATE.md) §1). Each rule appends actions and can **suppress** actions emitted by earlier rules.

### R1 — Verify before you block on a weak signal

```python
if state.n_independent_signals == 1 and state.fraud_probability < 0.70:
    emit(VERIFY_WITH_CUSTOMER)          # or STEP_UP_AUTH
    suppress(BLOCK_CARD, BLOCK_ALL_CARDS, DECLINE_TRANSACTION)
```

> *"If the case rests on a single signal (including a risk score alone) and your assessed fraud probability is below 0.70, recommend VERIFY_WITH_CUSTOMER or STEP_UP_AUTH before any block. Blocking a legitimate customer on one signal is a policy breach."*

**Note:** `risk_score` alone is always one signal. A risk-score trigger with no corroboration can never block.

### R2 — Customer denies

```python
if flags.response == "denied":
    emit(BLOCK_CARD)
    emit(CREATE_CASE)
    if exposure > 1_000 or flags.shared_origin or flags.cross_customer:
        emit(FILE_REPORT)
```

### R3 — Customer confirms

```python
if flags.response == "confirmed":
    emit(CLOSE_NO_FRAUD)
    verdict = "legitimate"              # record the confirmation in the case file
```

### R4 — No reply within 24 hours

```python
if flags.response == "no_reply":
    emit(MONITOR_CARD)
    emit(DECLINE_TRANSACTION)           # for pending authorizations
    if exposure > 500:
        emit(ESCALATE_TO_ANALYST)
```

### R5 — Card testing

```python
if pattern == "card_testing":
    emit(DECLINE_TRANSACTION)
    emit(STEP_UP_AUTH)
    if flags.max_cleared_purchase > 100:
        emit(BLOCK_CARD)
    unsuppress()                        # R5 OVERRIDES R1's suppression
```

> *"Three or more small online authorizations on one card within an hour, followed by a larger purchase: recommend DECLINE_TRANSACTION and STEP_UP_AUTH. If a purchase over $100 has already cleared, recommend BLOCK_CARD."*

**R5 overrides R1** because the testing sequence is itself multiple corroborating signals, not one.

### R6 — Shared origin

```python
if flags.shared_origin:                 # device | region | recipient email, ≥2 cards, one window
    evidence.add(f"shared {flags.shared_element} across N cards")
    emit(CREATE_CASE)
    emit(FILE_REPORT)
    emit(MONITOR_CONNECTED_CARDS)       # for every card that shares it
```

> *"Name the shared element."* Do not emit a bare `MONITOR_CONNECTED_CARDS` — the shared element must be named in the evidence.

### R7 — Disputed but legitimate

```python
if flags.disputed and flags.is_recurring:
    emit(CREATE_CASE)
    emit(VERIFY_WITH_CUSTOMER)
    emit(WARN_CUSTOMER)
    suppress(BLOCK_CARD, BLOCK_ALL_CARDS, DECLINE_TRANSACTION)
```

> *"When the customer disputes a charge that matches their own recurring pattern (same merchant, same amount, monthly)… Do not block."*

**No merchant column exists.** `ProductCode` is the proxy. State this in the evidence claim.

### R8 — Escalate when uncertain and exposed

```python
if (verdict == "uncertain" and exposure > 500) or flags.conflicting_evidence:
    emit(ESCALATE_TO_ANALYST)
```

### R9 — Undocumented patterns

```python
if pattern == "undocumented" and flags.cross_customer:
    emit(CREATE_CASE)
    emit(FILE_REPORT)
    emit(ESCALATE_TO_ANALYST)
    require(pattern_description)        # 2–3 sentences: what, who, how found
    forbid_known_pattern_labels()
```

> *"Do not force it into a known category."*

### R10 — `BLOCK_ALL_CARDS` guard (veto, checked last)

```python
if "BLOCK_ALL_CARDS" in actions:
    if not (flags.cards_confirmed_fraud >= 2 or flags.credentials_compromised):
        remove("BLOCK_ALL_CARDS")
        record("R10: BLOCK_ALL_CARDS withheld — fewer than 2 confirmed-fraud cards")
```

R10 is a **veto**, evaluated after all other rules. Nothing overrides it.

### Default

```python
if not actions:
    emit(ALLOW_TRANSACTION if verdict == "legitimate" else MONITOR_CARD)
```

**A case with no actions is invalid.** The engine must never return an empty list.

---

## 5. Case vs report (§3a)

Two different things. Getting the distinction right is part of the next-best-action score.

### Open a case (`CREATE_CASE`) when any of:

- `p >= 0.30`, **or**
- the agent requests evidence, **or**
- the customer disputes a charge

### File a report (`FILE_REPORT`) when **all** of:

- fraud is confirmed **or strongly suspected**, **and**
- at least one of:
  - `exposure > 1_000`
  - the activity connects to a shared device profile, a shared region cluster, or another customer's fraud
  - the pattern is coordinated or undocumented (R9)

> *"A report always has a case behind it. Most cases never need a report."*

**Invariant:** `FILE_REPORT ∈ final_actions` ⟺ `sar.file == true`. Validator check #4.

---

## 6. Stopping (§6)

```python
def should_stop(state) -> tuple[bool, str]:
    p, n = state.fraud_probability, state.n_independent_signals
    if p >= 0.85 and n >= 2:   return True, "Probability ≥ 0.85 on N independent signals."
    if p <= 0.15 and n >= 2:   return True, "Probability ≤ 0.15 on N independent signals."
    if flags.response in ("denied", "confirmed"):
                               return True, "Customer response settles the question."
    if voi(state) <= 0:        return True, f"No response can change the action set (VOI={voi:.2f})."
    if state.round >= 2:       return True, "Evidence-request budget exhausted."
    return False, ""
```

Independence = distinct `Evidence.axis`. Axes: `velocity`, `amount`, `device`, `geography`, `channel`, `model_residual`, `graph`, `memory`. Without this, five restatements of "the amount is odd" count as five signals.

---

## 7. Expected-cost ranking

Within the policy-legal set, order actions by expected cost:

```
Cost(A) = p · L_unavoided(A)                 # fraud loss we failed to stop
        + (1 − p) · F(A)                     # customer friction
        + R_missing_filing(A)                # regulatory cost of a SAR we should have filed
        + λ · O(A)                           # operational cost
```

`F` uses the friction weights from §1. `R_missing_filing` is large and applies only when §5 says a report was required and `A` omits `FILE_REPORT`.

**This is why the system recommends `MONITOR_CARD` over `BLOCK_CARD` at p = 0.4** — not because a rule says so, but because the arithmetic does, and R1 agrees. The rule citation is still required (§7 of the policy).

---

## 8. Explanation requirement (§7)

> *"Every recommendation must state what evidence was used, why more evidence was requested if it was, and why the chosen actions follow from this policy. Cite the rule number."*

Every `ActionRef.reason` **must** contain a rule identifier. `enforce_citations()` raises if any action lacks one.

Good: `"R5: testing sequence observed, $259 purchase already cleared"`
Bad: `"The evidence suggests blocking is appropriate"`

---

## 9. Test matrix

`tests/test_policy.py`. One synthetic `PolicyFlags` + probability + exposure per row. **Deterministic — no graph, no LLM, no dataset.**

| # | Scenario | Expected actions | Route |
|---|---|---|---|
| 1 | p=0.45, 1 signal | `VERIFY_WITH_CUSTOMER` or `STEP_UP_AUTH`; **no block** | auto |
| 2 | denied, exposure $900, no shared origin | `BLOCK_CARD`, `CREATE_CASE`; **no SAR** | L1, auto |
| 3 | denied, exposure $1,200 | + `FILE_REPORT` | L2 |
| 4 | denied, exposure $800, shared device | + `FILE_REPORT` | L2 |
| 5 | confirmed | `CLOSE_NO_FRAUD`, verdict `legitimate` | auto |
| 6 | no reply, exposure $300 | `MONITOR_CARD`, `DECLINE_TRANSACTION` | auto, L1 |
| 7 | no reply, exposure $900 | + `ESCALATE_TO_ANALYST` | auto |
| 8 | card testing, nothing cleared | `DECLINE_TRANSACTION`, `STEP_UP_AUTH` | L1, auto |
| 9 | card testing, $150 cleared | + `BLOCK_CARD` | L1 |
| 10 | shared device across 4 cards | `CREATE_CASE`, `FILE_REPORT`, `MONITOR_CONNECTED_CARDS` | auto, L2, auto |
| 11 | disputed, matches monthly recurring | `CREATE_CASE`, `VERIFY_WITH_CUSTOMER`, `WARN_CUSTOMER`; **no block** | auto |
| 12 | uncertain, exposure $700 | `ESCALATE_TO_ANALYST` | auto |
| 13 | undocumented, cross-customer | `CREATE_CASE`, `FILE_REPORT`, `ESCALATE_TO_ANALYST` + description | auto, L2, auto |
| 14 | 1 card confirmed fraud | **no** `BLOCK_ALL_CARDS` | — |
| 15 | 2 cards confirmed fraud | `BLOCK_ALL_CARDS` permitted | L2 |
| 16 | block, exposure **$2,500.00** | `BLOCK_CARD` → **L1** | L1 |
| 17 | block, exposure **$2,500.01** | `BLOCK_CARD` → **L2** | L2 |
| 18 | p = 0.30 exactly | case opens | — |
| 19 | p = 0.29 | case does **not** open (absent other triggers) | — |
| 20 | exposure **$1,000.00**, denied | **no** SAR (must *exceed*) | — |
| 21 | no rules fire, legitimate | `ALLOW_TRANSACTION` | auto |
| 22 | `BLOCK_ALL_CARDS` requested, 1 card | removed by R10 | — |

Rows 16, 17, 18, 19, 20 are the boundary rows. **Do not skip them.**

---

## 10. Interface

```python
# src/anvesh/policy/engine.py — the ONLY writer of next_best_actions

def resolve(state: InvestigationState) -> Decision:
    """Pure. Deterministic. No I/O. Never returns an empty action list.
    Every returned ActionRef carries a rule citation."""

@dataclass
class Decision:
    actions: list[ActionRef]
    open_case: bool
    file_sar: bool
    stop_reason: str
    verdict: Verdict
    suppressed: list[str]        # actions considered and withheld, with the rule
```

`suppressed` is logged to the trace. "Considered BLOCK_CARD, suppressed by R1" is exactly the kind of line that demonstrates the controls to a judge.
