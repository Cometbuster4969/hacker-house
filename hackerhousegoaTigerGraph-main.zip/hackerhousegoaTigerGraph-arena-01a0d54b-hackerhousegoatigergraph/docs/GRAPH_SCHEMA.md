# TigerGraph Schema

Vertices, edges, attributes, vector stores, loading order and estimated cardinalities.
Code lives in `graph/schema.gsql` and `graph/loading_jobs.gsql`; the loader is `src/anvesh/graph/build.py`.

> **Treat the DDL below as a sketch.** Verify syntax against your TigerGraph version.
> Add vector attributes with the MCP tool `tigergraph__add_vector_attribute` rather than by hand — the syntax varies between releases.

---

## 1. Vertices

| Vertex | Primary ID | Attributes | Est. count |
|---|---|---|---|
| `Customer` | `customer_id` STRING | — | ~13,500 |
| `Card` | `card_id` STRING | `card4` STRING (network), `card6` STRING (credit/debit) | ~20,000 |
| `Transaction` | `txn_id` STRING | `ts` DATETIME, `amount` DOUBLE, `product_cd` STRING, `channel` STRING, `risk_score` DOUBLE, `addr1` STRING, `addr2` STRING, `p_email` STRING, `r_email` STRING, `v_anom` DOUBLE, `c_sum` INT, `d_days` INT, `m_flags` INT | 590,742 |
| `DeviceProfile` | `device_id` STRING | `device_info` STRING, `device_type` STRING, `os` STRING, `browser` STRING, `screen` STRING | ~50,000 |
| `DeviceSignature` | `sig_id` STRING | `device_type` STRING, `os` STRING, `browser` STRING | ~2,000 |
| `EmailDomain` | `domain` STRING | `kind` STRING (`P` \| `R`) | ~60 |
| `BillingRegion` | `region_id` STRING | — | ~350 |
| `BillingCountry` | `country_id` STRING | — | ~70 |
| `ProductCode` | `code` STRING | — | 5 |
| `ClosedCase` | `case_id` STRING | `opened_at` DATETIME, `closed_at` DATETIME, `outcome` STRING, `pattern` STRING, `n_txns` INT, `exposure_usd` DOUBLE, `analyst_notes` STRING, **`emb`** VECTOR, **`fp`** VECTOR | 5,565 |
| `InvestigationCase` | `case_id` STRING | `opened_at` DATETIME, `verdict` STRING, `fraud_probability` DOUBLE, `pattern` STRING, `exposure_usd` DOUBLE, **`emb`** VECTOR, **`fp`** VECTOR | 20 + monitor |
| `CaseEvent` | `event_id` STRING | `seq` INT, `step` INT, `kind` STRING, `payload` STRING (JSON), `at` DATETIME | append-only |
| `Pattern` | `name` STRING | `kind` STRING (`known` \| `discovered`), `description` STRING | 5 + discovered |
| `DocChunk` | `chunk_id` STRING | `source` STRING, `section` STRING, `text` STRING, **`emb`** VECTOR | ~300 |
| `Cluster` | `cluster_id` STRING | `window_days` INT, `kind` STRING, `size` INT | varies |

Only the `V`/`C`/`D`/`M` features that detectors actually use are loaded onto `Transaction`. Do **not** load all 339 `V` columns — it triples load time for no benefit. Precompute `v_anom` (anomaly score), `c_sum`, `d_days` and `m_flags` during ingestion.

### `DeviceProfile` vs `DeviceSignature`

Two granularities, deliberately.

- **`DeviceProfile`** = `DeviceInfo + id_30 (OS) + id_31 (browser) + id_33 (screen)`. Precise. The README's suggested definition.
- **`DeviceSignature`** = `DeviceType + id_30 + id_31`. Coarse. Catches rings that rotate firmware builds — `SAMSUNG SM-G892A Build/NRD90M` and `...Build/NRD90U` are different `DeviceInfo` strings and the same phone.

A ring that rotates builds defeats exact matching. Two tiers give both precision and recall.

---

## 2. Edges

```
Customer          ──OWNS──▶                Card
Card              ──MADE──▶                Transaction
Transaction       ──FROM_DEVICE──▶         DeviceProfile          (ONLINE ONLY)
Transaction       ──RESOLVES_TO──▶         DeviceSignature        (ONLINE ONLY)
Transaction       ──PURCHASER_EMAIL──▶     EmailDomain
Transaction       ──RECIPIENT_EMAIL──▶     EmailDomain            (sparse — 76% null)
Transaction       ──BILLED_IN──▶           BillingRegion
Transaction       ──IN_COUNTRY──▶          BillingCountry
Transaction       ──OF_PRODUCT──▶          ProductCode
Transaction       ──NEXT──▶                Transaction            (per card, by ts)

ClosedCase        ──INVOLVES──▶            Transaction
ClosedCase        ──ON_CARD──▶             Card
ClosedCase        ──CONNECTED_TO──▶        Card
ClosedCase        ──HAS_PATTERN──▶         Pattern

InvestigationCase ──CASE_TXN──▶            Transaction
InvestigationCase ──CASE_CARD──▶           Card
InvestigationCase ──CASE_DEVICE──▶         DeviceProfile
InvestigationCase ──CASE_REGION──▶         BillingRegion
InvestigationCase ──CASE_PATTERN──▶        Pattern
InvestigationCase ──CASE_CITES──▶          ClosedCase | DocChunk
InvestigationCase ──HAS_EVENT──▶           CaseEvent

DocChunk          ──DESCRIBES──▶           Pattern
Cluster           ──CONTAINS──▶            Card
```

Materialised card-to-card projections (performance, optional):

```
Card ──SHARES_DEVICE──▶ Card   (window_days, first_seen, last_seen)
Card ──SHARES_REGION──▶ Card
Card ──SHARES_EMAIL──▶  Card
```

Undirected. Built per window. They exist so a future global algorithm could run on a small projection instead of traversing 590k transactions at read time. **Not built by the shipped loader** — `ring_components` walks from the seed, so no projection is needed.

### Estimated edge counts

| Edge | Count |
|---|---|
| `MADE` | 590,742 |
| `NEXT` | ~570,000 |
| `FROM_DEVICE` / `RESOLVES_TO` | 144,432 each |
| `PURCHASER_EMAIL` | ~570,000 |
| `RECIPIENT_EMAIL` | ~135,000 |
| `BILLED_IN` / `IN_COUNTRY` / `OF_PRODUCT` | 590,742 each |
| `OWNS` | ~20,000 |
| `INVOLVES` | ~35,000 (Σ `n_txns` over closed cases) |
| `SHARES_*` | computed, sparse |

---

## 3. ⚠️ The identity gap

**`identity.csv` covers online transactions only.** `ProductCD = W` ⇒ `channel = in_person` ⇒ **no device record exists**.

Every detector must branch on `channel`. Every device claim must be gated:

```python
if txn.channel == "in_person":
    # No DeviceProfile. No DeviceSignature. Do not emit device evidence.
```

Test: `tests/test_detectors.py::test_no_device_claim_for_in_person` — for every in-person transaction in a sample, assert no evidence object with `axis == "device"` is produced.

This is a top-three source of silent bugs in this dataset. It will not raise an error; it will just quietly produce wrong findings on roughly a third of the transactions.

---

## 4. DDL sketch

```sql
-- Vertices
CREATE VERTEX Customer (PRIMARY_ID customer_id STRING)
  WITH primary_id_as_attribute="true"

CREATE VERTEX Card (PRIMARY_ID card_id STRING, card4 STRING, card6 STRING)
  WITH primary_id_as_attribute="true"

CREATE VERTEX Transaction (
  PRIMARY_ID txn_id STRING,
  ts DATETIME, amount DOUBLE, product_cd STRING, channel STRING,
  risk_score DOUBLE, addr1 STRING, addr2 STRING,
  p_email STRING, r_email STRING,
  v_anom DOUBLE, c_sum INT, d_days INT, m_flags INT
) WITH primary_id_as_attribute="true"

CREATE VERTEX DeviceProfile (
  PRIMARY_ID device_id STRING,
  device_info STRING, device_type STRING, os STRING, browser STRING, screen STRING
) WITH primary_id_as_attribute="true"

CREATE VERTEX DeviceSignature (
  PRIMARY_ID sig_id STRING, device_type STRING, os STRING, browser STRING
) WITH primary_id_as_attribute="true"

CREATE VERTEX EmailDomain (PRIMARY_ID domain STRING, kind STRING)
  WITH primary_id_as_attribute="true"

CREATE VERTEX BillingRegion (PRIMARY_ID region_id STRING)
  WITH primary_id_as_attribute="true"

CREATE VERTEX BillingCountry (PRIMARY_ID country_id STRING)
  WITH primary_id_as_attribute="true"

CREATE VERTEX ProductCode (PRIMARY_ID code STRING)
  WITH primary_id_as_attribute="true"

CREATE VERTEX ClosedCase (
  PRIMARY_ID case_id STRING,
  opened_at DATETIME, closed_at DATETIME, outcome STRING, pattern STRING,
  n_txns INT, exposure_usd DOUBLE, analyst_notes STRING
) WITH primary_id_as_attribute="true"

CREATE VERTEX InvestigationCase (
  PRIMARY_ID case_id STRING,
  opened_at DATETIME, verdict STRING, fraud_probability DOUBLE,
  pattern STRING, exposure_usd DOUBLE
) WITH primary_id_as_attribute="true"

CREATE VERTEX CaseEvent (
  PRIMARY_ID event_id STRING,
  seq INT, step INT, kind STRING, payload STRING, at DATETIME
) WITH primary_id_as_attribute="true"

CREATE VERTEX Pattern (PRIMARY_ID name STRING, kind STRING, description STRING)
  WITH primary_id_as_attribute="true"

CREATE VERTEX DocChunk (
  PRIMARY_ID chunk_id STRING, source STRING, section STRING, text STRING
) WITH primary_id_as_attribute="true"

CREATE VERTEX Cluster (
  PRIMARY_ID cluster_id STRING, window_days INT, kind STRING, size INT
) WITH primary_id_as_attribute="true"

-- Edges
--
-- Association edges are UNDIRECTED on purpose: every traversal walks them in
-- both directions (card -> txn -> device -> txn -> card), and a directed edge
-- traversed backwards matches nothing. These are link tables, not flows.
CREATE UNDIRECTED EDGE OWNS             (FROM Customer,          TO Card)
CREATE UNDIRECTED EDGE MADE             (FROM Card,              TO Transaction)
CREATE UNDIRECTED EDGE NEXT             (FROM Transaction,       TO Transaction)
CREATE UNDIRECTED EDGE FROM_DEVICE      (FROM Transaction,       TO DeviceProfile)
CREATE UNDIRECTED EDGE RESOLVES_TO      (FROM Transaction,       TO DeviceSignature)
CREATE UNDIRECTED EDGE PURCHASER_EMAIL  (FROM Transaction,       TO EmailDomain)
CREATE UNDIRECTED EDGE RECIPIENT_EMAIL  (FROM Transaction,       TO EmailDomain)
CREATE UNDIRECTED EDGE BILLED_IN        (FROM Transaction,       TO BillingRegion)
CREATE UNDIRECTED EDGE IN_COUNTRY       (FROM Transaction,       TO BillingCountry)
CREATE UNDIRECTED EDGE OF_PRODUCT       (FROM Transaction,       TO ProductCode)
CREATE DIRECTED EDGE INVOLVES           (FROM ClosedCase,        TO Transaction)
CREATE DIRECTED EDGE ON_CARD            (FROM ClosedCase,        TO Card)
CREATE DIRECTED EDGE CONNECTED_TO       (FROM ClosedCase,        TO Card)
CREATE DIRECTED EDGE HAS_PATTERN        (FROM ClosedCase,        TO Pattern)
CREATE DIRECTED EDGE CASE_TXN           (FROM InvestigationCase, TO Transaction)
CREATE DIRECTED EDGE CASE_CARD          (FROM InvestigationCase, TO Card)
CREATE DIRECTED EDGE CASE_DEVICE        (FROM InvestigationCase, TO DeviceProfile)
CREATE DIRECTED EDGE CASE_REGION        (FROM InvestigationCase, TO BillingRegion)
CREATE DIRECTED EDGE CASE_PATTERN       (FROM InvestigationCase, TO Pattern)
CREATE DIRECTED EDGE CASE_CITES         (FROM InvestigationCase, TO ClosedCase)
CREATE DIRECTED EDGE HAS_EVENT          (FROM InvestigationCase, TO CaseEvent)
CREATE DIRECTED EDGE DESCRIBES          (FROM DocChunk,          TO Pattern)
CREATE DIRECTED EDGE CONTAINS           (FROM Cluster,           TO Card)
CREATE UNDIRECTED EDGE SHARES_DEVICE    (FROM Card, TO Card, window_days INT, first_seen DATETIME, last_seen DATETIME)
CREATE UNDIRECTED EDGE SHARES_REGION    (FROM Card, TO Card, window_days INT, first_seen DATETIME, last_seen DATETIME)
CREATE UNDIRECTED EDGE SHARES_EMAIL     (FROM Card, TO Card, window_days INT, first_seen DATETIME, last_seen DATETIME)

CREATE GRAPH Anvesh (*)
```

> `CASE_CITES` is declared to `ClosedCase`. Where a citation targets a `DocChunk`, use the `payload` on a `CaseEvent` rather than adding a second edge type — keep the schema small.

### Vector attributes

Add via MCP, not by hand:

```
tigergraph__add_vector_attribute  vertex_type=ClosedCase          attribute=emb  dimension=<d>  metric=COSINE  index_type=HNSW
tigergraph__add_vector_attribute  vertex_type=ClosedCase          attribute=fp   dimension=<fp> metric=COSINE  index_type=HNSW
tigergraph__add_vector_attribute  vertex_type=DocChunk            attribute=emb  dimension=<d>  metric=COSINE  index_type=HNSW
tigergraph__add_vector_attribute  vertex_type=InvestigationCase   attribute=emb  dimension=<d>  metric=COSINE  index_type=HNSW
tigergraph__add_vector_attribute  vertex_type=InvestigationCase   attribute=fp   dimension=<fp> metric=COSINE  index_type=HNSW
```

`d` = embedding dimension (e.g. 384 for a local `all-MiniLM` model). `fp` = behavioural fingerprint dimension (see [`UNCERTAINTY.md`](./UNCERTAINTY.md) §6 — typically 12–20 floats, **not** an embedding).

---

## 5. Loading

Via the loading job in `graph/loading_job.gsql` (emitted by
`src/anvesh/graph/gsql.py`, installed with `anvesh gsql-out`). There is no
`build-graph` command: schema install, loading-job install and the load run
are separate deliberate steps (a one-command graph rebuild is a footgun on a
shared Savanna instance). Verify with `anvesh verify` afterwards.

### 5.1 Order (dependencies matter)

1. Schema + graph creation
2. Dimension vertices: `BillingRegion`, `BillingCountry`, `ProductCode`, `EmailDomain`, `DeviceProfile`, `DeviceSignature`, `Pattern`
3. `Customer`, then `Card`, then `OWNS`
4. `Transaction`, then `MADE`
5. `NEXT` (per card, ordered by `ts`)
6. Identity-derived edges: `FROM_DEVICE`, `RESOLVES_TO`, `PURCHASER_EMAIL`, `RECIPIENT_EMAIL`, `BILLED_IN`, `IN_COUNTRY`, `OF_PRODUCT`
7. `ClosedCase` + `INVOLVES` / `ON_CARD` / `CONNECTED_TO` / `HAS_PATTERN`
8. Vector attributes, then `upsert_vectors`
9. `DocChunk` + `DESCRIBES`
10. `SHARES_*` projections (full graph only)

### 5.2 Chunking

REST loading in **≤ 16 MB parts**, so the same code path works on Savanna and CE. `tigergraph__run_loading_job_with_file` takes a `size_limit` parameter — respect it.

### 5.3 Subset first, full second

**Load a subset before the full graph.** The agent can be built and tested against ~100k rows while 590k load in the background.

Subset definition:

- all transactions for the 20 flagged cards
- all cards belonging to those cards' customers
- all identity rows for the loaded transactions
- **all 5,565 closed cases and every transaction they involve** (needed for memory and for supervised tuning — do not subset this)
- all dimension vertices

Rebuild the full graph once the background job finishes. Re-run the affected tests.

### 5.4 Idempotency

Loading jobs must be safe to re-run. Upsert semantics everywhere; no `DROP` by default.

---

## 6. Ingestion preprocessing

Done once, in `src/anvesh/graph/build.py`, before loading:

| Derived field | Rule |
|---|---|
| `channel` | `ProductCD == "W"` → `in_person`, else `online` |
| `device_id` | hash of `DeviceInfo + id_30 + id_31 + id_33` |
| `sig_id` | hash of `DeviceType + id_30 + id_31` |
| `v_anom` | anomaly score over `V1`–`V339` (IsolationForest or PCA reconstruction error). **Computed offline, not at query time.** |
| `c_sum` | sum of `C1`–`C14` counts |
| `d_days` | first non-null of `D1`–`D15` |
| `m_flags` | count of anomalous `M1`–`M9` values |

`TransactionID`, `card1`, `TransactionDT` and `TransactionAmt` were transformed by the dataset authors so answers cannot be looked up in the public file. Never attempt to reverse that.

---

## 7. Verification queries

Run after loading, before anything else:

```
tigergraph__show_graph_details
get_vertex_count(Transaction)   → expect 590,742 (full) or the subset count
get_vertex_count(ClosedCase)    → expect 5,565
get_edge_count(MADE)            → expect = get_vertex_count(Transaction)
get_edge_count(FROM_DEVICE)     → expect ≤ 144,432 and == number of online txns with identity
```

Then the leakage test: every query with `as_of = 2016-07-01` must return empty.
