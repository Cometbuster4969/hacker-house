# Answer File Contract

`cases/HHG-001.json` … `cases/HHG-020.json`. **This is the submission artifact.**

One file per case in `case_pack.csv`. Twenty cases, twenty files, in `cases/`.

> *"Same structure for every case. Missing fields score zero for that part."*
> *"IDs must be the ones in the dataset. Made-up IDs score zero."*

---

## 1. Top level

| Field | Type | Meaning |
|---|---|---|
| `case_id` | string | From `case_pack.csv` |
| `case` | object | Part 1 — the internal investigation record |
| `evidence_requests` | list | Each: `type`, `asked_after_step`, `assumed_response`. Empty if none |
| `next_best_actions` | object | Part 3 |
| `sar` | object | Part 2 |
| `stop_reason` | string | Why the investigation ended here |
| `tool_calls` | int | Graph and retrieval calls made |
| `tokens` | int | LLM tokens consumed |
| `latency_s` | number | Wall-clock seconds |

## 2. Part 1 — `case`

| Field | Type | Notes |
|---|---|---|
| `status` | `open` \| `closed_fraud` \| `closed_legitimate` \| `escalated` | `open` = evidence still pending |
| `verdict` | `fraud` \| `legitimate` \| `uncertain` | `uncertain` is valid and earns full credit on ambiguous cases, provided actions follow R1 and R8 |
| `fraud_probability` | number 0–1 | **Scored for calibration.** Never 0 or 1 |
| `pattern` | enum | `card_testing` · `card_not_present_fraud` · `card_not_present_new_device` · `out_of_region_use` · `account_takeover` · `undocumented` · `none` |
| `pattern_description` | string | Required iff `pattern == "undocumented"`, else `""` |
| `affected_txn_ids` | list[str] | The episode, including the flagged transaction. Empty if legitimate |
| `first_suspicious_txn_id` | string or `""` | Where it started |
| `connected_card_ids` | list[str] | Other cards in the same compromise, ring or device |
| `connected_device_profiles` | list[str] | `DeviceInfo \| OS \| browser \| screen` |
| `exposure_usd` | number | **Must equal** Σ\|amount\| of `affected_txn_ids` |
| `evidence` | list[object] | `claim`, `source` (`graph`\|`document`\|`customer`\|`external`), `ref`, `entity_ids` |
| `similar_prior_cases` | list[str] | Closed-case IDs retrieved as memory, e.g. `["CC-0141"]`. Empty if none |
| `summary` | string | **2–6 sentences** an analyst could read |
| `written_to_graph` | bool | Whether the case was stored in TigerGraph |
| `graph_case_id` | string or `""` | The case vertex ID |

## 3. Part 2 — `sar`

| Field | Type | Notes |
|---|---|---|
| `file` | bool | **Must agree** with whether `FILE_REPORT` is in the final actions |
| `reason` | string | Cite the policy rule |
| `narrative` | string | Required iff `file`. **6–12 sentences.** Who / what / when / where / how / why |
| `subjects` | list[str] | Customers, cards, devices named in the narrative |
| `total_amount_usd` | number | Total of the suspicious activity |
| `activity_dates` | list[str, str] | First and last date, `YYYY-MM-DD` |

If `file` is false: `narrative = ""`, `subjects = []`, `total_amount_usd = 0`, `activity_dates = []`.

## 4. Part 3 — `next_best_actions`

| Field | Type | Notes |
|---|---|---|
| `initial` | list[object] | Recommended **before** requested evidence came back |
| `final` | list[object] | Recommended **after** the assumed responses. Equals `initial` if nothing was requested |
| `what_changed` | string | 1–2 sentences, or `"nothing"` |

Each action object: `{action, route, reason}` — `reason` must cite a rule.

## 5. `evidence_requests`

Each: `{type, asked_after_step, assumed_response}` where `type` ∈ `customer_validation` | `step_up_auth` | `analyst_info`.

> *"Customer and analyst replies are not provided. Simulate them in your own system and state the assumption you made."*

The simulation policy is **fixed, disclosed and order-independent**. It is never tuned to reach a preferred verdict.

---

## 6. Consistency invariants

| # | Invariant |
|---|---|
| I1 | `verdict == "legitimate"` ⇒ `affected_txn_ids == []`, `exposure_usd == 0`, `sar.file == false` |
| I2 | `exposure_usd == sum(abs(amount) for txn in affected_txn_ids)` **to the cent** |
| I3 | `sar.file == true` ⟺ `FILE_REPORT ∈ [a.action for a in next_best_actions.final]` |
| I4 | `sar.file == false` ⇒ `narrative == ""`, `subjects == []`, `total_amount_usd == 0`, `activity_dates == []` |
| I5 | `pattern == "undocumented"` ⇒ `pattern_description != ""`; otherwise `pattern_description == ""` |
| I6 | `next_best_actions.final == initial` ⟺ `evidence_requests == []` |
| I7 | Every action ∈ the 14 legal actions; every route matches the routing table |
| I8 | Every ID in the file exists in the provided dataset |

---

## 7. The 15 validator checks

`src/anvesh/validate/checks.py`. Run with `anvesh validate`. **Errors block the freeze.**

| # | Check | Severity |
|---|---|---|
| 1 | JSON parses against the answer schema | error |
| 2 | **Every ID exists in the dataset** | error |
| 3 | `exposure_usd` == Σ\|amount\| to the cent | error |
| 4 | `sar.file` ⟺ `FILE_REPORT` ∈ final actions | error |
| 5 | `sar.file == false` ⇒ narrative/subjects/amount/dates all empty | error |
| 6 | Legitimate verdict ⇒ empty episode, zero exposure, no SAR | error |
| 7 | `pattern == undocumented` ⟺ description non-empty | error |
| 8 | Every action ∈ the 14 legal actions | error |
| 9 | Every route matches the (action, exposure) routing table | error |
| 10 | Every action carries a rule citation | error |
| 11 | `summary` is 2–6 sentences | warning |
| 12 | `narrative` is 6–12 sentences (when filed) | warning |
| 13 | Every evidence object has `source` and `ref` | error |
| 14 | `initial` and `final` present; `what_changed` non-empty | error |
| 15 | `tool_calls` / `tokens` / `latency_s` populated | warning |

Check 2 is the hard one: every ID — transactions, cards, customers, devices, closed cases — must be present in the loaded dataset. Build an `IdRegistry` at graph-build time and look IDs up against it. **Never compose an ID from a pattern.**

---

## 8. Minimal skeleton

```json
{
  "case_id": "HHG-001",
  "case": {
    "status": "closed_legitimate",
    "verdict": "legitimate",
    "fraud_probability": 0.31,
    "pattern": "none",
    "pattern_description": "",
    "affected_txn_ids": [],
    "first_suspicious_txn_id": "",
    "connected_card_ids": [],
    "connected_device_profiles": [],
    "exposure_usd": 0,
    "evidence": [
      {
        "claim": "Card has 14 in-person purchases in region 444 over 90 days; this one is 3.1 miles from the median location",
        "source": "graph",
        "ref": "query:geo_velocity(card_id=C12382-K1, hours=48)",
        "entity_ids": ["3514030"]
      }
    ],
    "similar_prior_cases": ["CC-2210"],
    "summary": "Two to six sentences. An analyst could read this and know what happened.",
    "written_to_graph": true,
    "graph_case_id": "CASE-2016-0001"
  },
  "evidence_requests": [
    {
      "type": "customer_validation",
      "asked_after_step": 4,
      "assumed_response": "Customer confirms the purchase; it was a gift bought in person."
    }
  ],
  "next_best_actions": {
    "initial": [
      { "action": "VERIFY_WITH_CUSTOMER", "route": "auto",
        "reason": "R1: single signal, probability 0.28 below 0.70" }
    ],
    "final": [
      { "action": "CLOSE_NO_FRAUD", "route": "auto",
        "reason": "R3: customer confirmed the transaction" }
    ],
    "what_changed": "Customer confirmation under R3 closes the alert; the block that R1 had suppressed is no longer relevant."
  },
  "sar": {
    "file": false,
    "reason": "Not fraud. R3 applies; no §3a trigger met.",
    "narrative": "",
    "subjects": [],
    "total_amount_usd": 0,
    "activity_dates": []
  },
  "stop_reason": "Customer confirmation settles the question under §6.",
  "tool_calls": 7,
  "tokens": 6420,
  "latency_s": 11.3
}
```

---

## 9. Prose rules

- **`summary`** — 2–6 sentences. *"Keep summary short. The evidence list carries the detail."*
- **`narrative`** — 6–12 sentences, complete: who, what, when, where, how, why suspicious. *"The SAR narrative is the one place to be complete."* It must **stand on its own** — a regulator reads only this.
- **`stop_reason`** — name the actual reason, including the VOI number when VOI was the cause.
- **`what_changed`** — name what moved and by how much. "Customer denial raised probability from 0.44 to 0.81, which unblocks BLOCK_CARD under R2 and triggers a report under §3a because the device is shared."

The LLM writes exactly four fields: `summary`, `narrative`, `what_changed`, `pattern_description`. Everything else is code.
