# Setup

---

## 1. Dataset

Get the **HHGOA_IEEE** folder from the Google Drive link in the challenge brief:

`https://drive.google.com/drive/folders/1YDJUW1fiE7Jx8R9KqknC4IcsED9zll2A`

Place in `data/`:

| File | Size |
|---|---|
| `README.md` | — |
| `transactions.csv` | ~708 MB |
| `identity.csv` | — |
| `closed_cases_history.csv` | — |
| `case_pack.csv` | — |

**Start the download first.** It is the longest pole in the build and nothing can proceed without it.

> **Read `data/README.md` in full before anything else.** It defines the policy, the answer format and the 20 cases. Every other document in this repository derives from it.
>
> **Never download or consult the public IEEE-CIS / Kaggle files.** IDs, times and amounts were transformed so outcomes cannot be looked up. Using them is disqualification.

---

## 2. TigerGraph

### Savanna (recommended)

1. Sign up at `https://savanna.tgcloud.io`, create a workspace.
2. **Free tier enforces auto-stop and it cannot be disabled.** Enable auto-start. Assume the workspace will sleep between sessions and budget for cold start.
3. Create a database **secret** — not a raw password.
4. Note the host and graph name.

### Community Edition (fallback)

Docker install from `https://dl.tigergraph.com`. No auto-stop, but you own the resources. Use it if Savanna is flaky or if you need guaranteed availability near the deadline.

**Recommendation: Savanna for the submission, CE as a local fallback.** The graph must be real TigerGraph either way — it is a required component.

---

## 3. Environment

```bash
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
```

Core dependencies:

```
pyTigerGraph>=2.0.4      # TigerGraph SDK
tigergraph-mcp           # the MCP server (the only path to the graph)
langgraph>=0.2           # orchestration
pydantic>=2.0            # domain models and structured LLM output
pandas numpy scikit-learn
sentence-transformers    # local embeddings — no API cost, no rate limits
(The replay UI is dependency-free static HTML — no UI packages needed.)
pytest pytest-asyncio
```

Optional: `uvicorn starlette` (if you serve MCP over HTTP instead of stdio).

### `.env`

```bash
# TigerGraph (Savanna)
TG_HOST=https://<instance>.i.tgcloud.io
TG_GRAPHNAME=Anvesh
TG_SECRET=<database secret>
TG_TGCLOUD=true

# LLM
LLM_PROVIDER=gemini          # or openai / anthropic
LLM_MODEL=gemini-2.5-flash
LLM_API_KEY=<key>

# Embeddings (local — recommended)
EMBED_MODEL=sentence-transformers/all-MiniLM-L6-v2
EMBED_DIM=384

# Budgets (defaults from src/anvesh/config.py)
# ANVESH_BUDGET_TOOL_CALLS=30
# ANVESH_BUDGET_WALL_S=60
```

`.env` is gitignored. Commit `.env.example` only. **Never commit a secret.**

---

## 4. MCP

`anvesh` spawns `tigergraph-mcp` as a **stdio subprocess** and owns its pipes. It is never started by hand in normal operation.

Smoke test:

```bash
echo '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-06-18","capabilities":{},"clientInfo":{"name":"manual","version":"1"}}}' | tigergraph-mcp
```

Enable tool-call logging during development:

```bash
TG_LOG_TOOL_CALLS=true
```

**The agent's MCP client exposes a read + append-only tool profile.** The subprocess starts with `--allowed-tools` limited to the query tools (bare names like `run_installed_query`), the read-only and discovery tools, and nothing else — `drop_graph`, `clear_graph_data`, `delete_node(s)`, `delete_edge(s)` and `drop_query` are never reachable. See `src/anvesh/graph/mcp_client.py`.

---

## 5. Commands

```bash
# Emit schema / loading job / queries, then install in GraphStudio (flow below)
anvesh gsql-out                       # refreshes graph/*.gsql (check the diff)

# Investigate (memory adapter; synthetic data unless --data-dir is given)
anvesh run --case HHG-002             # one case
anvesh run --all                      # all 20, in case_pack order (memory accumulates)
anvesh run --all --data-dir data/HHGOA_IEEE                        # real CSVs, in memory
anvesh run --all --data-dir data/HHGOA_IEEE --adapter tigergraph   # live graph via MCP

# Validate the answer files
anvesh validate                       # the 15 checks; errors block the freeze
anvesh validate --data-dir data/HHGOA_IEEE --adapter tigergraph

# Verify a live instance (§7, executable)
anvesh verify --data-dir data/HHGOA_IEEE

# Measure (memory-only by design — it measures the model, not the transport)
anvesh backtest
anvesh backtest --data-dir data/HHGOA_IEEE --fit-limit 2000

# UI
anvesh serve                          # static replay server on 0.0.0.0:8000 (no graph/LLM/network)
```

---

## 6. Repo hygiene

`.gitignore`:

```
data/                 # 708 MB
.env
.venv/
__pycache__/
*.pyc
.pytest_cache/
.DS_Store
```

**Committed:** `cases/` (the submission), `traces/` (the demo source), `benchmark/`, `monitor/`, `graph/`, `src/`, `tests/`, `docs/`, `PRD.md`, `ROADMAP.md`, `AGENTS.md`, `README.md`.

---

## 7. Verification order

Before trusting anything downstream:

1. `anvesh verify --data-dir data/HHGOA_IEEE` passes — it checks graph reachability, all 10 installed queries, the Transaction (590,742) and ClosedCase (5,565) counts, and `as_of` isolation on a real card
2. MCP answers from inside the agent process (`TG_LOG_TOOL_CALLS=true` shows tool-call logs)
3. `anvesh run --case HHG-002 --data-dir data/HHGOA_IEEE --adapter tigergraph` produces an answer file that `anvesh validate` accepts

---

## 8. Before submitting

- [ ] Repo is **public**
- [ ] Working tree clean, no secrets committed
- [ ] `cases/` contains exactly 20 files, `HHG-001.json` … `HHG-020.json`
- [ ] `anvesh validate` green on all 20
- [ ] `README.md` has run instructions, the results table and a Limitations section
- [ ] Blog published; social post live, tagging **@TigerGraphDB**
- [ ] Demo video uploaded (unlisted is fine)
- [ ] Form submitted: `https://forms.gle/yxXzqSULGgZ9VUF56` — **by 24 Sept 2026, 23:59 IST**
- [ ] Savanna auto-start enabled (and a cold-start buffer in the schedule)
