# Architecture

**Module layout, component interfaces, and data flow.** The implementable form of [`PRD.md` §9](../PRD.md).

---

## 1. The thesis

Four layers, one job each, hard boundaries between them.

| Layer | Owns | Nature | Fails if |
|---|---|---|---|
| **L1 Evidence** | TigerGraph — GSQL, graph algorithms, TigerVector | Deterministic, replayable, citeable | Hallucinated facts |
| **L2 Judgement** | Calibrated model ⊕ LLM synthesis | Probabilistic | Confident nonsense; miscalibrated probability |
| **L3 Decision** | Policy engine — R1–R10 as code | Deterministic, auditable, permissioned | Illegal or unapproved actions |
| **L4 Explanation** | LLM, constrained by the evidence list | Generative | Unsourced claims |

> **The graph supplies the facts. The model supplies the probability. The policy engine makes the call. The LLM writes it down.**

The one rule that matters more than any other: **the LLM cannot write to L3.**

---

## 2. System diagram

```
                    case_pack.csv (20 alerts)
                              │
                    ┌─────────▼──────────┐
                    │   anvesh CLI       │  gsql-out | run | validate | backtest | verify | serve
                    └─────────┬──────────┘
                              │
      ┌───────────────────────▼────────────────────────┐
      │  ORCHESTRATOR   src/anvesh/agent/graph.py      │
      │  LangGraph state machine over InvestigationState│
      │  16 nodes · 2 LLM nodes · budgeted · traced     │
      └───┬──────────┬──────────┬──────────┬───────────┘
          │          │          │          │
   ┌──────▼───┐ ┌────▼────┐ ┌───▼─────┐ ┌──▼──────────┐
   │ EVIDENCE │ │JUDGEMENT│ │ DECISION│ │ EXPLANATION │
   │ graph/   │ │reasoning│ │ policy/ │ │ llm/        │
   │ evidence/│ │         │ │         │ │             │
   └──────┬───┘ └────┬────┘ └───┬─────┘ └──┬──────────┘
          │          │          │          │
          │      ┌───▼──────────▼───┐      │
          │      │  retrieval/      │      │
          │      │  GraphRAG hybrid │      │
          │      └───┬──────────────┘      │
          │          │                     │
   ┌──────▼──────────▼─────────────────────▼──────────┐
   │  TIGERGRAPH   (Savanna or CE 4.2+)               │
   │  ┌───────────────────┐  ┌──────────────────────┐ │
   │  │ Graph             │  │ TigerVector          │ │
   │  │ ~800k V, ~5M E    │  │ DocChunk.emb         │ │
   │  │ 10 installed q's  │  │ ClosedCase.emb | .fp │ │
   │  │ ring walk         │  │ InvestigationCase.*  │ │
   │  └───────────────────┘  └──────────────────────┘ │
   └────────────────────┬─────────────────────────────┘
                        │  write-back (append-only)
              ┌─────────▼──────────┐
              │ InvestigationCase  │
              │ + CaseEvent        │
              └────────────────────┘

   ┌──────────────┐   ┌──────────────┐   ┌──────────────┐
   │ policy/engine│   │ validate/    │   │ ui/ (replay) │
   │ (R1–R10)     │   │ 15 checks    │   │ static HTML  │
   └──────────────┘   └──────────────┘   └──────────────┘
```

**Everything touching the graph goes through `graph/mcp_client.py`.** No module may open a second path (`pyTigerGraph` direct, REST, GSQL shell). One path means one place to trace, one place to rate-limit, one place to enforce `as_of`.

---

## 3. Repository layout

```
anvesh/
├── AGENTS.md                    # rules for coding agents — read first
├── PRD.md  ·  ROADMAP.md
├── README.md
├── docs/                        # this directory
├── pyproject.toml  ·  .env.example  ·  .gitignore
│
├── data/                        # GITIGNORED — 708 MB of raw CSV
├── cases/                       # HHG-001.json … HHG-020.json   ← SUBMISSION ARTIFACT
├── traces/                      # per-case traces                ← DEMO SOURCE
├── monitor/                     # optional autonomous investigations (Innovation)
├── benchmark/                   # backtest output
│
├── graph/
│   ├── schema.gsql
│   ├── loading_jobs.gsql
│   └── queries/                 # Q1 … Q18, one .gsql file each
│
└── src/anvesh/
    ├── cli.py                   # anvesh gsql-out|run|validate|backtest|verify|serve
    ├── config.py                # env, budgets, thresholds — single source of truth
    │
    ├── domain/
    │   ├── enums.py             # Pattern, Verdict, Action, Route, TriggerType
    │   ├── models.py            # Evidence, EvidenceRequest, ActionRef, SAR
    │   └── answer.py            # AnswerFile — the submission shape
    │
    ├── graph/
    │   ├── mcp_client.py        # ★ THE ONLY PATH TO TIGERGRAPH
    │   ├── tools.py             # typed wrappers: ctx_window(), device_neighbors()…
    │   ├── build.py             # schema → load → install
    │   └── writeback.py         # case memory
    │
    ├── agent/
    │   ├── state.py             # InvestigationState TypedDict
    │   ├── graph.py             # LangGraph wiring
    │   ├── nodes/               # one module per node
    │   ├── hypotheses.py        # hypothesis → query selection
    │   └── prompts/*.md         # versioned, never inline
    │
    ├── evidence/
    │   ├── detectors.py         # the 5 pattern detectors
    │   ├── episode.py           # segmentation
    │   └── features.py          # the feature vector (shared with the scorer)
    │
    ├── reasoning/
    │   ├── priors.py            # documented priors + the G3 correction
    │   ├── likelihood.py        # LRs from closed cases
    │   ├── scorer.py            # calibrated episode scorer
    │   └── voi.py               # value of information
    │
    ├── policy/
    │   ├── actions.py           # 14 actions + routing table
    │   ├── rules.py             # R1–R10 as predicates
    │   ├── engine.py            # ★ THE ONLY WRITER OF next_best_actions
    │   └── cost.py              # expected-cost ranking
    │
    ├── retrieval/
    │   ├── embed.py
    │   ├── docs.py              # DocChunk corpus build
    │   └── hybrid.py            # vector → graph expand → rerank
    │
    ├── llm/
    │   ├── client.py            # provider-agnostic, temp 0
    │   └── structured.py        # schema-constrained calls + repair
    │
    ├── validate/
    │   ├── checks.py            # the 15 checks
    │   └── run.py
    │
    ├── ui/
    │   ├── index.html           # static replay (no deps)
    │   └── replay.py            # render a frozen trace as if live
    │
    └── util/
        ├── time.py              # as_of helpers
        └── ids.py               # ID existence registry
```

---

## 4. Component interfaces

Interfaces are contracts. Implement them exactly; other modules call them by these signatures.

### 4.1 `graph/mcp_client.py` — the only path to TigerGraph

```python
class GraphClient:
    """Every graph operation in the system goes through this class.

    Guarantees:
      * every read is as_of-bounded
      * every call is appended to the trace
      * tool-call budget is enforced (raises BudgetExceeded)
      * destructive tools are not exposed
    """
    def __init__(self, profile: str, state: "InvestigationState"): ...

    async def installed_query(self, name: str, params: dict) -> dict:
        """tigergraph__run_installed_query. params MUST include 'as_of'."""

    async def vector_search(self, vertex_type: str, attribute: str,
                            query_vector: list[float], top_k: int) -> list[dict]:
        """tigergraph__search_top_k_similarity."""

    async def add_nodes(self, vtype: str, nodes: list[dict]) -> None: ...
    async def add_edges(self, etype: str, edges: list[dict]) -> None: ...
```

Not exposed, by design: `drop_graph`, `clear_graph_data`, `delete_node(s)`, `delete_edge(s)`, `drop_query`.
The agent may **read and append**. It may not destroy.

### 4.2 `evidence/detectors.py`

```python
@dataclass
class DetectorResult:
    pattern: Pattern
    fired: bool
    confidence: float            # 0–1, not a fraud probability
    txn_ids: list[str]           # must all exist in the dataset
    why: str                     # one sentence, human-readable
    ref: str                     # "query:testing_sequence(card_id=..., hours=1)"

def detect(pattern: Pattern, ctx: "EvidenceContext") -> DetectorResult:
    """ctx is as_of-bounded and carries channel. Never inspects the future."""
```

All five detectors share the signature. `EvidenceContext` carries `as_of`, `card_id`, `channel`, and the query results already gathered — detectors do **not** call the graph themselves.

### 4.3 `evidence/episode.py`

```python
def segment(ctx: "EvidenceContext",
            seed_txn_ids: list[str],
            scores: dict[str, float],
            max_span_hours: int = 72,
            lam: float = 0.15) -> Episode:

@dataclass
class Episode:
    txn_ids: list[str]           # contiguous, capped at as_of
    first_suspicious_txn_id: str
    exposure_usd: float          # == sum(|amount| for txn in txn_ids), exact
```

Boundary objective: maximise `Σ score − λ · span_hours`. Tune `lam` and the inclusion threshold on IoU against closed-case `txn_ids` (free labels — see [`BACKTEST.md`](./BACKTEST.md)).

### 4.4 `reasoning/scorer.py` — the probability

```python
def score_episode(features: dict[str, float]) -> float:
    """Calibrated P(fraud | features, as_of evidence). Applies the G3 prior correction.
    See docs/UNCERTAINTY.md. Returns a value in (0, 1), never 0 or 1."""

def fuse(p_det: float, p_llm: float, alpha: float) -> float:
    """alpha fitted on the held-out closed-case split."""

def update_on_response(p: float, response: ResponseKind) -> float:
    """Bayesian update using LRs learned from closed-case analyst_notes."""
```

### 4.5 `policy/engine.py` — ★ the only writer of actions

```python
def resolve(state: "InvestigationState") -> Decision:

@dataclass
class Decision:
    actions: list[ActionRef]     # each: action, route, reason (rule citation)
    open_case: bool
    file_sar: bool
    stop_reason: str
    verdict: Verdict
```

`resolve()` is **pure**: same state in, same decision out. No I/O, no LLM, no network. This is what makes the 25% testable.

### 4.6 `validate/checks.py`

```python
CHECKS: list[Check] = [ ... 15 checks ... ]

def validate(answer: dict, id_registry: "IdRegistry") -> Report:
    """Report has .passed, .errors, .warnings. Errors block the freeze."""
```

### 4.7 `llm/structured.py`

```python
def call(prompt: str, schema: type[T], *, temperature: float = 0.0) -> T:
    """Schema-constrained. Retries once with the validation error appended,
    then raises. Never returns a partially-valid object."""
```

---

## 5. Data flow for one case

```
case_pack row
  → intake            : resolve entities, set as_of = opened_at
  → episode_construct : Q1, Q2, Q3, Q17 → candidate episode
  → hypothesize (LLM) : 2–4 hypotheses → query plan (+ rejected queries, with reasons)
  → gather_evidence   : Q4, Q7, Q10, Q12, Q16 … budget-capped, traced
  → recall_memory     : vector seeds → graph expand → rerank → similar_prior_cases
  → assess            : features → p_det → fuse with p_llm → verdict, pattern, sensitivity
  → stop_or_continue  : hard stops, then VOI
  → request_evidence  : simulated, disclosed, fixed policy
  → reassess          : Bayesian update
  → policy_resolve    : R1–R10 → actions + routes      ★ deterministic
  → rank_actions      : expected cost within the legal set
  → case_writeback    : InvestigationCase + CaseEvent + CASE_* edges
  → explain (LLM)     : summary, SAR narrative, what_changed — evidence-constrained
  → validate          : 15 checks
  → emit              : cases/HHG-0NN.json  +  traces/HHG-0NN.json
```

**Two LLM nodes only:** `hypothesize` and `explain`. Everything else is code.

---

## 6. Key design decisions

| Decision | Chosen | Rejected alternative | Why |
|---|---|---|---|
| Tool surface | 10 installed parameterised GSQL queries | LLM writes GSQL at runtime (`generate_gsql`) | Installed queries are fast, auditable, replayable. Runtime generation is slow and non-deterministic. `generate_gsql` is an **offline authoring aid only**. |
| Action ownership | Deterministic policy engine | LLM proposes actions | 25% of the score must be verifiable. Rules in a prompt cannot be unit-tested. |
| Ring detection | Single-source walk in `ring_components` | Global GDS `tg_wcc` | The agent asks for one card's ring at one hour; a whole-graph WCC cannot be `as_of`-scoped per call. Cost scales with the ring. |
| Memory | Graph vertices + edges, seeded by vector | Vector store of case texts | Retrieval must answer "what else touched this device?" — unanswerable with vectors alone. |
| Retrieval | Hybrid: vector → 1–2 hop expansion → rerank | Pure vector top-k | Same reason. |
| Orchestration | LangGraph over a plain `TypedDict` state | Custom state machine | LangGraph gives tracing and checkpointing free; the state schema is framework-agnostic, so a custom machine is a drop-in replacement. |
| Probability | Calibrated model ⊕ LLM, fused | LLM self-reported confidence | LLMs are badly calibrated and the answer format scores calibration. |
| Stopping | Value of information | Fixed probability threshold | §6's "further steps are unlikely to change the decision" is a decision-theoretic claim, not a threshold. |
| Execution | Simulated, recorded, permissioned | Real integrations | Required by the brief; also the only safe option. |

---

## 7. Dependency graph and build order

```
        W2 policy ──────────────┐  (needs nothing)
                                │
W1 graph ──▶ W3 queries ──▶ W4 detectors/episode ──▶ W6 uncertainty
                     │                                      │
                     └──────────▶ W5 orchestrator ◀─────────┤
                                        │                   │
                                        ▼                   │
                                  W7 validator ◀────────────┘
                                        │
                                        ▼
                              W8 memory ──▶ W9 UI ──▶ W10 demo ──▶ W11 content
                                                                        │
                                                                   W12 extras
```

**W2 and W7 have no upstream dependencies. Build them first.** W1 is wall-clock bound (708 MB download, 590k row load) — start it at hour zero and build W2 while it runs.

---

## 8. Non-functional requirements

| ID | Requirement |
|---|---|
| NFR-1 | Held-out Brier score ≤ 0.15 |
| NFR-2 | Predicted 0.8 bucket ⇒ actual fraud rate 0.65–0.95 |
| NFR-3 | 20/20 answer files pass schema validation |
| NFR-4 | 100% of IDs exist in the dataset |
| NFR-5 | 100% of evidence claims carry `source` + `ref` |
| NFR-6 | `sar.file` ⟺ `FILE_REPORT` ∈ final actions |
| NFR-7 | `exposure_usd` == Σ|amount| to the cent |
| NFR-8 | Legitimate ⇒ empty episode, zero exposure, `sar.file` false |
| NFR-9 | 100% of GSQL queries are `as_of`-bounded |
| NFR-10 | Same case + same seed ⇒ identical answer modulo LLM prose |
| NFR-11 | ≤ 30 tool calls, ≤ 60 s wall clock per case |
| NFR-12 | 20/20 cases written to the graph |

---

## 9. Configuration

All thresholds live in `src/anvesh/config.py`. **No magic numbers anywhere else.**

```python
BUDGET_TOOL_CALLS   = 30
BUDGET_WALL_S       = 60
BUDGET_MAX_ROUNDS   = 2      # evidence-request rounds
MAX_HYPOTHESES      = 4

P_CASE_OPEN         = 0.30   # §3a "fraud probability reaches 0.30"
P_VERIFY_BELOW      = 0.70   # R1 "below 0.70"
P_STOP_HIGH         = 0.85   # §6 "at or above 0.85"
P_STOP_LOW          = 0.15   # §6 "at or below 0.15"

EXPOSURE_SAR        = 1000   # R2 / §3a "exceeds $1,000"
EXPOSURE_ESCALATE   = 500    # R4 / R8 "exceeds $500"
PURCHASE_BLOCK      = 100    # R5 "a purchase over $100"
BLOCK_ROUTE_L1_MAX  = 2500   # "exposure ≤ $2,500"
```

Every one of these is quoted from the policy text. Changing one is a policy change, not a tuning change.
