#!/usr/bin/env python3
"""Run the post-load datetime fixup query on TigerGraph.

Copies Transaction.ts_raw -> Transaction.ts using to_datetime().
Run ONCE after --steps load completes:

    python scripts/fixup_timestamps.py
"""

from __future__ import annotations

import sys
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO / "scripts"))

from graph_load import connect, load_env, run_gsql


def main() -> None:
    env = load_env()
    conn, graph = connect(env)
    fixup_file = REPO / "graph" / "zz_fixup.gsql"
    if not fixup_file.exists():
        sys.exit(f"{fixup_file} not found.")

    text = fixup_file.read_text(encoding="utf-8")
    print("[fixup] dropping existing zz_fixup query (best effort)...")
    try:
        conn.gsql(f"USE GRAPH {graph}\nDROP QUERY zz_fixup", graphname=graph)
    except Exception:
        pass

    print("[fixup] creating zz_fixup query...")
    run_gsql(conn, f"USE GRAPH {graph}\n{text}", "CREATE QUERY zz_fixup", graph)

    print("[fixup] installing zz_fixup query (compiling, be patient)...")
    run_gsql(conn, f"USE GRAPH {graph}\nINSTALL QUERY zz_fixup", "INSTALL QUERY zz_fixup", graph)

    print("[fixup] executing zz_fixup() to backfill Transaction.ts...")
    out = conn.runInstalledQuery("zz_fixup")
    print(f"[ok] zz_fixup completed: {out}")


if __name__ == "__main__":
    main()
