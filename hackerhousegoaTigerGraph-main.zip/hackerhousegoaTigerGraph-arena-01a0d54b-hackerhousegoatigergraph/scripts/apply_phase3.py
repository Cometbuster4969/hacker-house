#!/usr/bin/env python3
"""One-shot: apply the tested loader patch (card grouping + channel + device fix).

Run from anywhere:  python3 scripts/apply_loader_patch.py
Safe to re-run: already-applied edits are skipped. If an anchor does not
match, NOTHING is written and the failure names the exact spot.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
os.chdir(REPO)
TARGET = "src/anvesh/data/loader.py"


MARKERS = {
    # (stage, pair-index) -> short stable string proving the pair applied.
    # Needed only where a LATER pair refines the same region (the full
    # `new` text is then legitimately absent from the final file).
    ("core", 1): "def build_card_map(",
    ("core", 3): '            card_ids = chunk[cols["txn_id"]].astype(str).map(',
    ("core", 5): "    card_map = None",
}


def patch(pairs: list[tuple[str, str]], stage: str) -> None:
    p = Path(TARGET)
    t = p.read_text(encoding="utf-8")
    applied, skipped = 0, 0
    for i, (old, new) in enumerate(pairs):
        if (MARKERS.get((stage, i)) or new) in t:
            skipped += 1
            continue
        assert t.count(old) == 1, (
            f"anchor FAILED ({stage}): {old[:70]!r} found x{t.count(old)}. "
            f"Your {TARGET} differs from the expected version — STOP and "
            f"report this line.")
        t = t.replace(old, new)
        applied += 1
    p.write_text(t, encoding="utf-8")
    print(f"[{stage}] applied={applied} skipped={skipped}")


CARD_MAP_FN = '''

# ------------------------------------------------- card identity (challenge)
_CARD_MAP_CACHE: dict[str, dict[str, str]] = {}

CARD_TUPLE_COLS = ["card1", "card2", "card3", "card4", "card5", "card6"]


def build_card_map(data_dir: Path) -> dict[str, str]:
    """TransactionID -> card_id under the challenge scheme.

    Groups transactions by (customer_id + full card1..6 tuple); K-numbers go
    by first-seen order within each customer; anchored groups take their true
    pack/closed C-ID. Raises LOUDLY on any contradiction — a wrong grouping
    must never silently mislabel cards.
    """
    key = str(data_dir)
    if key in _CARD_MAP_CACHE:
        return _CARD_MAP_CACHE[key]
    txn_path = Path(data_dir) / "transactions.csv"
    headers = list(pd.read_csv(txn_path, nrows=0).columns)
    norm = {_norm(h): h for h in headers}

    def need(logical: str) -> str:
        if _norm(logical) not in norm:
            raise LoaderError(
                f"card grouping needs column {logical}; headers include: "
                f"{headers[:12]}...")
        return norm[_norm(logical)]

    tid_c = need("TransactionID")
    cust_c = need("customer_id")
    tup_c = [need(c) for c in CARD_TUPLE_COLS]
    use = [tid_c, cust_c, *tup_c]
    cust_seen: dict[str, int] = {}
    group_cid: dict[str, str] = {}
    tid_group: dict[str, str] = {}
    for chunk in pd.read_csv(txn_path, usecols=use, chunksize=200_000,
                             dtype=str):
        chunk = chunk.fillna("")
        cols = [chunk[c].astype(str) for c in use]
        for vals in zip(*cols):
            tid, cust = str(vals[0]), str(vals[1])
            g = cust + "||" + "|".join(str(x) for x in vals[2:])
            if g not in group_cid:
                cust_seen[cust] = cust_seen.get(cust, 0) + 1
                group_cid[g] = f"{cust}-K{cust_seen[cust]}"
            tid_group[tid] = g
    anchors: dict[str, str] = {}
    for r in load_pack(Path(data_dir) / "case_pack.csv"):
        anchors[str(r.flagged_txn_id)] = str(r.card_id)
    for c in load_closed_cases(Path(data_dir) / "closed_cases_history.csv"):
        ids = [str(x) for x in c.txn_ids]
        if c.first_fraud_txn_id:
            ids.append(str(c.first_fraud_txn_id))
        for t in ids:
            if t in anchors and anchors[t] != str(c.card_id):
                raise LoaderError(
                    f"anchor txn {t} claimed by two cards: {anchors[t]} and "
                    f"{c.card_id} — data contradiction, report it")
            anchors[t] = str(c.card_id)
    alias: dict[str, str] = {}
    for tid, cid in anchors.items():
        g = tid_group.get(tid)
        if g is None:
            raise LoaderError(f"anchor txn {tid} (card {cid}) not in "
                              f"transactions.csv")
        if g in alias and alias[g] != cid:
            raise LoaderError(
                f"card grouping collision: one card-tuple claimed by {alias[g]} "
                f"and {cid} — the (customer + card-tuple) grouping is wrong")
        alias[g] = cid
    out = {tid: alias.get(g, group_cid[g]) for tid, g in tid_group.items()}
    _CARD_MAP_CACHE[key] = out
    return out
'''


def main() -> None:
    if not Path(TARGET).exists():
        sys.exit(f"{TARGET} not found — run from the repo root.")
    patch([
        ('    "risk": ["risk_score", "riskscore", "score", "model_score"],\n}',
         '    "risk": ["risk_score", "riskscore", "score", "model_score"],\n    "channel": ["channel", "txn_channel"],\n}'),
        ('    return df[comp].astype(str).agg("-".join, axis=1)\n\n\n# ------------------------------------------------------------------ v_anom',
         '    return df[comp].astype(str).agg("-".join, axis=1)\n' + CARD_MAP_FN + '\n\n# ------------------------------------------------------------------ v_anom'),
        ('    opt = {k: resolve(headers, k) for k in\n           ("addr1", "addr2", "p_email", "r_email", "risk")}',
         '    opt = {k: resolve(headers, k) for k in\n           ("addr1", "addr2", "p_email", "r_email", "risk", "channel")}'),
        ('        card_ids = _id_series(chunk, headers, cfg.card_id_from, "card", "card", 6)',
         '''        if cfg.card_id_from or resolve(headers, "card"):
            card_ids = _id_series(chunk, headers, cfg.card_id_from, "card",
                                  "card", 6)
        else:
            card_ids = chunk[cols["txn_id"]].astype(str).map(
                build_card_map(cfg.data_dir))
            if card_ids.isna().any():
                raise LoaderError("card map missed transactions — report it")
            card_ids = card_ids.astype(str)'''),
        ('            product = str(row[cols["product"]])\n            online = product != "W"          # ProductCD W = in-person (documented)',
         '''            product = str(row[cols["product"]])
            if opt["channel"]:
                online = str(row[opt["channel"]]).strip().lower() == "online"
            else:
                online = product != "W"      # ProductCD W = in-person'''),
        ('''    for c in (card_col, cust_col):
        if c and c not in use:
            use.append(c)''',
         '''    for c in (card_col, cust_col):
        if c and c not in use:
            use.append(c)
    card_map = None
    if not card_col and not cfg.card_id_from:
        card_map = build_card_map(cfg.data_dir)'''),
        ('''        if card_col:
            reg.add_card(*chunk[card_col].astype(str).tolist())''',
         '''        if card_col:
            reg.add_card(*chunk[card_col].astype(str).tolist())
        elif card_map is not None:
            reg.add_card(*chunk[cols["txn_id"]].astype(str).map(card_map)
                         .dropna().astype(str).tolist())'''),
    ], "core")
    patch([
        ("""    normed = {_norm(h): h for h in df.columns}
    use = [normed[c] for c in DEVICE_COLS if c in normed]""",
         """    normed = {_norm(h): h for h in df.columns}
    use, _seen = [], set()          # NOTE: DEVICE_COLS must match normalized
    for c in DEVICE_COLS:           # ("id_30" never equals normalized "id30")
        if _norm(c) in normed and normed[_norm(c)] not in _seen:
            _seen.add(normed[_norm(c)])
            use.append(normed[_norm(c)])"""),
    ], "device-fix")
    patch([
        ("\n\n# ------------------------------------------------- card identity (challenge)",
         '''

def _challenge_cols_present(headers: list[str]) -> bool:
    """True when the challenge card-grouping columns exist."""
    norm = {_norm(h) for h in headers}
    return _norm("customer_id") in norm and all(
        _norm(c) in norm for c in CARD_TUPLE_COLS)

# ------------------------------------------------- card identity (challenge)'''),
        ('''        if cfg.card_id_from or resolve(headers, "card"):
            card_ids = _id_series(chunk, headers, cfg.card_id_from, "card",
                                  "card", 6)
        else:''',
         '''        if cfg.card_id_from or resolve(headers, "card") or \\
                not _challenge_cols_present(headers):
            # explicit cols, a direct card column, or a generic CSV without
            # the challenge grouping columns -> legacy composite derivation
            card_ids = _id_series(chunk, headers, cfg.card_id_from, "card",
                                  "card", 6)
        else:'''),
        ('''    if not card_col and not cfg.card_id_from:
        card_map = build_card_map(cfg.data_dir)''',
         '''    if not card_col and not cfg.card_id_from and _challenge_cols_present(
            headers):
        card_map = build_card_map(cfg.data_dir)'''),
    ], "fallback")
    print("ALL PATCHES APPLIED")



# ---------------------------------------------------------------------------
# Phase 3 payload stages (bundled base64 blobs; written + verified on run).
# ---------------------------------------------------------------------------
import base64
import hashlib
import py_compile

PREP_MD5 = "b7acf7512ea30e24bb728e1d400c1386"
JOB_MD5 = "d8981348e48e7e89e2d37526b30fef0e"
PREP_B64 = """IyEvdXNyL2Jpbi9lbnYgcHl0aG9uMwoiIiJCdWlsZCBncmFwaCBzaWRlLWZpbGVzICsgZW5yaWNo
ZWQgdHJhbnNhY3Rpb25zIGZyb20gdGhlIHJlYWwgSEhHT0FfSUVFRSBDU1ZzLgoKUnVuIG9uY2Ug
KEFGVEVSIHRoZSBsb2FkZXIgSUQgcGF0Y2ggaXMgYXBwbGllZCDigJQgcHJlcCBjb25zdW1lcyBU
eG4gb2JqZWN0cywKc28gZ3JhcGggSURzIGFyZSBiaXQtaWRlbnRpY2FsIHRvIG1lbW9yeS1tb2Rl
IElEcyBieSBjb25zdHJ1Y3Rpb24pOgoKICAgIHB5dGhvbiBzY3JpcHRzL3ByZXBfZ3JhcGgucHkK
ClJlYWRzIGRhdGEvSEhHT0FfSUVFRS8qLmNzdiwgd3JpdGVzIGludG8gZGF0YS9ISEdPQV9JRUVF
L2dyYXBoX3ByZXAvOgogICAgdHJhbnNhY3Rpb25zX2VucmljaGVkLmNzdiAgcmF3ICsgYXBwZW5k
ZWQgdl9hbm9tLCBtX2ZsYWdzCiAgICB0eG5fa2V5cy5jc3YgICAgICAgICAgICAgICBUcmFuc2Fj
dGlvbklELGNhcmRfaWQsY3VzdG9tZXJfaWQsY2FyZDQsY2FyZDYKICAgIHR4bl9kZXZpY2VzLmNz
diAgICAgICAgICAgIFRyYW5zYWN0aW9uSUQsZGV2aWNlX2lkLGRldmljZV9pbmZvLGRldmljZV90
eXBlLAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3MsYnJvd3NlcixzY3JlZW4sc2ln
X2lkLHNpZ19kZXZpY2VfdHlwZSxzaWdfb3Msc2lnX2Jyb3dzZXIKICAgIG5leHRfZWRnZXMuY3N2
ICAgICAgICAgICAgIHNyY190eG4sZHN0X3R4biAocGVyLWNhcmQgdGltZSBvcmRlcikKICAgIGNh
c2VfdHhuX2VkZ2VzLmNzdiAgICAgICAgIGNhc2VfaWQsdHhuX2lkCiAgICBjYXNlX2Nvbm5fZWRn
ZXMuY3N2ICAgICAgICBjYXNlX2lkLGNhcmRfaWQKICAgIGNhc2VfY2FyZF9lZGdlcy5jc3YgICAg
ICAgIGNhc2VfaWQsY2FyZF9pZCAoT05fQ0FSRCwgdmVyaWZpZWQpCgpBbmNob3IgdmVyaWZpY2F0
aW9uOiBldmVyeSBwYWNrL2Nsb3NlZCBjYXJkK2N1c3RvbWVyIElEIGlzIGNoZWNrZWQgYWdhaW5z
dCB0aGUKSUQgZGVyaXZlZCBmb3IgaXRzIGFuY2hvciB0cmFuc2FjdGlvbi4gQW55IG1pc21hdGNo
IGFib3J0cyBMT1VETFkg4oCUIGEgd3JvbmcKZGVyaXZhdGlvbiBtdXN0IG5ldmVyIHNpbGVudGx5
IHByb2R1Y2UgemVyby1tYXRjaCBpbnZlc3RpZ2F0aW9ucy4KIiIiCgpmcm9tIF9fZnV0dXJlX18g
aW1wb3J0IGFubm90YXRpb25zCgppbXBvcnQgYXJncGFyc2UKaW1wb3J0IGNzdgppbXBvcnQgc3lz
CmZyb20gcGF0aGxpYiBpbXBvcnQgUGF0aAoKUkVQTyA9IFBhdGgoX19maWxlX18pLnJlc29sdmUo
KS5wYXJlbnQucGFyZW50CnN5cy5wYXRoLmluc2VydCgwLCBzdHIoUkVQTyAvICJzcmMiKSkKCgpk
ZWYgbWFpbigpIC0+IE5vbmU6CiAgICBhcCA9IGFyZ3BhcnNlLkFyZ3VtZW50UGFyc2VyKCkKICAg
IGFwLmFkZF9hcmd1bWVudCgiLS1kYXRhLWRpciIsIHR5cGU9UGF0aCwgZGVmYXVsdD1SRVBPIC8g
ImRhdGEiIC8gIkhIR09BX0lFRUUiKQogICAgYXJncyA9IGFwLnBhcnNlX2FyZ3MoKQogICAgZnJv
bSBhbnZlc2guZGF0YS5sb2FkZXIgaW1wb3J0IChMb2FkQ29uZmlnLCBsb2FkX2Nsb3NlZF9jYXNl
cywgbG9hZF9wYWNrLAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsb2FkX3Ry
YW5zYWN0aW9ucywgX3JlYWRfaWRlbnRpdHkpCiAgICBpbXBvcnQgcGFuZGFzIGFzIHBkCgogICAg
ZDogUGF0aCA9IGFyZ3MuZGF0YV9kaXIKICAgIHByZXAgPSBkIC8gImdyYXBoX3ByZXAiCiAgICBw
cmVwLm1rZGlyKGV4aXN0X29rPVRydWUpCiAgICBjZmcgPSBMb2FkQ29uZmlnKGQpCgogICAgcHJp
bnQoIltwcmVwXSBwYXNzIDA6IGNhcmQ0L2NhcmQ2ICsgYW5jaG9ycy4uLiIpCiAgICBjNDY6IGRp
Y3Rbc3RyLCB0dXBsZVtzdHIsIHN0cl1dID0ge30KICAgIGZvciBjaHVuayBpbiBwZC5yZWFkX2Nz
dihkIC8gInRyYW5zYWN0aW9ucy5jc3YiLAogICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVz
ZWNvbHM9WyJUcmFuc2FjdGlvbklEIiwgImNhcmQ0IiwgImNhcmQ2Il0sCiAgICAgICAgICAgICAg
ICAgICAgICAgICAgICAgY2h1bmtzaXplPTIwMF8wMDAsIGR0eXBlPXN0cik6CiAgICAgICAgY2h1
bmsgPSBjaHVuay5maWxsbmEoIiIpCiAgICAgICAgZm9yIHRpZCwgYzQsIGM2IGluIHppcChjaHVu
a1siVHJhbnNhY3Rpb25JRCJdLCBjaHVua1siY2FyZDQiXSwKICAgICAgICAgICAgICAgICAgICAg
ICAgICAgICAgIGNodW5rWyJjYXJkNiJdKToKICAgICAgICAgICAgYzQ2W3N0cih0aWQpXSA9IChz
dHIoYzQpLCBzdHIoYzYpKQogICAgcGFjayA9IHtyLmZsYWdnZWRfdHhuX2lkOiAoci5jYXJkX2lk
LCByLmN1c3RvbWVyX2lkKQogICAgICAgICAgICBmb3IgciBpbiBsb2FkX3BhY2soZCAvICJjYXNl
X3BhY2suY3N2Iil9CiAgICBjbG9zZWQgPSBsb2FkX2Nsb3NlZF9jYXNlcyhkIC8gImNsb3NlZF9j
YXNlc19oaXN0b3J5LmNzdiIpCiAgICBhbmNob3JfbmVlZDogc2V0W3N0cl0gPSBzZXQocGFjaykK
ICAgIGNsb3NlZF9ieV90eG46IGRpY3Rbc3RyLCBsaXN0W3R1cGxlW3N0ciwgc3RyXV1dID0ge30K
ICAgIGZvciBjIGluIGNsb3NlZDoKICAgICAgICBmb3IgdCBpbiBjLnR4bl9pZHM6CiAgICAgICAg
ICAgIGNsb3NlZF9ieV90eG4uc2V0ZGVmYXVsdChzdHIodCksIFtdKS5hcHBlbmQoKGMuY2FyZF9p
ZCwKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg
ICAgYy5jdXN0b21lcl9pZCkpCiAgICAgICAgICAgIGFuY2hvcl9uZWVkLmFkZChzdHIodCkpCiAg
ICAgICAgaWYgYy5maXJzdF9mcmF1ZF90eG5faWQ6CiAgICAgICAgICAgIGFuY2hvcl9uZWVkLmFk
ZChzdHIoYy5maXJzdF9mcmF1ZF90eG5faWQpKQoKICAgIGlkZW50aXR5ID0gX3JlYWRfaWRlbnRp
dHkoZCAvICJpZGVudGl0eS5jc3YiKQoKICAgIGRlZiBwYXJ0cyh0aWQ6IHN0cikgLT4gdHVwbGVb
c3RyLCBzdHIsIHN0ciwgc3RyLCBzdHJdOgogICAgICAgIGRldiA9IGlkZW50aXR5LmdldChzdHIo
dGlkKSwge30pCiAgICAgICAgcmV0dXJuIChkZXYuZ2V0KCJEZXZpY2VJbmZvIiwgIiIpLCBkZXYu
Z2V0KCJEZXZpY2VUeXBlIiwgIiIpLAogICAgICAgICAgICAgICAgZGV2LmdldCgiaWRfMzAiLCAi
IiksIGRldi5nZXQoImlkXzMxIiwgIiIpLAogICAgICAgICAgICAgICAgZGV2LmdldCgiaWRfMzMi
LCAiIikpCgogICAgcHJpbnQoIltwcmVwXSBwYXNzIDE6IHRyYW5zYWN0aW9ucyAtPiBlbnJpY2hl
ZC9rZXlzL2RldmljZXMuLi4iKQogICAgZl9lbnIgPSBvcGVuKHByZXAgLyAidHJhbnNhY3Rpb25z
X2VucmljaGVkLmNzdiIsICJ3IiwgbmV3bGluZT0iIiwgZW5jb2Rpbmc9InV0Zi04IikKICAgIGZf
a2V5cyA9IG9wZW4ocHJlcCAvICJ0eG5fa2V5cy5jc3YiLCAidyIsIG5ld2xpbmU9IiIsIGVuY29k
aW5nPSJ1dGYtOCIpCiAgICBmX2RldiA9IG9wZW4ocHJlcCAvICJ0eG5fZGV2aWNlcy5jc3YiLCAi
dyIsIG5ld2xpbmU9IiIsIGVuY29kaW5nPSJ1dGYtOCIpCiAgICB3X2tleXMgPSBjc3Yud3JpdGVy
KGZfa2V5cykKICAgIHdfZGV2ID0gY3N2LndyaXRlcihmX2RldikKICAgIHdfa2V5cy53cml0ZXJv
dyhbIlRyYW5zYWN0aW9uSUQiLCAiY2FyZF9pZCIsICJjdXN0b21lcl9pZCIsICJjYXJkNCIsCiAg
ICAgICAgICAgICAgICAgICAgICJjYXJkNiJdKQogICAgd19kZXYud3JpdGVyb3coWyJUcmFuc2Fj
dGlvbklEIiwgImRldmljZV9pZCIsICJkZXZpY2VfaW5mbyIsICJkZXZpY2VfdHlwZSIsCiAgICAg
ICAgICAgICAgICAgICAgIm9zIiwgImJyb3dzZXIiLCAic2NyZWVuIiwgInNpZ19pZCIsICJzaWdf
ZGV2aWNlX3R5cGUiLAogICAgICAgICAgICAgICAgICAgICJzaWdfb3MiLCAic2lnX2Jyb3dzZXIi
XSkKICAgIHJhdyA9IG9wZW4oZCAvICJ0cmFuc2FjdGlvbnMuY3N2IiwgInIiLCBuZXdsaW5lPSIi
LCBlbmNvZGluZz0idXRmLTgiKQogICAgZl9lbnIud3JpdGUocmF3LnJlYWRsaW5lKCkucnN0cmlw
KCJcclxuIikgKyAiLHZfYW5vbSxtX2ZsYWdzXG4iKQogICAgb3JkZXI6IGxpc3RbdHVwbGVbc3Ry
LCBvYmplY3QsIHN0cl1dID0gW10KICAgIHRpZHM6IHNldFtzdHJdID0gc2V0KCkKICAgIGNhcmRz
OiBzZXRbc3RyXSA9IHNldCgpCiAgICBhbmNob3Jfc2VlbjogZGljdFtzdHIsIHR1cGxlW3N0ciwg
c3RyXV0gPSB7fQogICAgbl9kZXYgPSBuX3NpZyA9IDAKICAgIGZvciBiYXRjaCBpbiBsb2FkX3Ry
YW5zYWN0aW9ucyhjZmcpOgogICAgICAgIGZvciB0IGluIGJhdGNoOgogICAgICAgICAgICBsaW5l
ID0gcmF3LnJlYWRsaW5lKCkKICAgICAgICAgICAgaWYgbm90IGxpbmU6CiAgICAgICAgICAgICAg
ICByYWlzZSBSdW50aW1lRXJyb3IoInJhdyBmaWxlIGVuZGVkIGJlZm9yZSB0eG4gc3RyZWFtIOKA
lCBjb3JydXB0PyIpCiAgICAgICAgICAgIGZfZW5yLndyaXRlKGxpbmUucnN0cmlwKCJcclxuIikg
KyBmIix7dC52X2Fub206LjRmfSx7dC5tX2ZsYWdzfVxuIikKICAgICAgICAgICAgYzQsIGM2ID0g
YzQ2LmdldCh0LnR4bl9pZCwgKCIiLCAiIikpCiAgICAgICAgICAgIHdfa2V5cy53cml0ZXJvdyhb
dC50eG5faWQsIHQuY2FyZF9pZCwgdC5jdXN0b21lcl9pZCwgYzQsIGM2XSkKICAgICAgICAgICAg
aWYgdC5kZXZpY2VfaWQ6CiAgICAgICAgICAgICAgICBpbmZvLCBkdHlwZSwgbywgYiwgcyA9IHBh
cnRzKHQudHhuX2lkKQogICAgICAgICAgICAgICAgc2lnID0gW3ggZm9yIHggaW4gKGR0eXBlLCBv
LCBiKSBpZiB4XQogICAgICAgICAgICAgICAgc2lnX2lkID0gIiB8ICIuam9pbihzaWcpCiAgICAg
ICAgICAgICAgICB3X2Rldi53cml0ZXJvdyhbdC50eG5faWQsIHQuZGV2aWNlX2lkLCBpbmZvLCBk
dHlwZSwgbywgYiwgcywKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaWdfaWQsIGR0
eXBlLCBvLCBiXSkKICAgICAgICAgICAgICAgIG5fZGV2ICs9IDEKICAgICAgICAgICAgICAgIG5f
c2lnICs9IGJvb2woc2lnX2lkKQogICAgICAgICAgICBvcmRlci5hcHBlbmQoKHQuY2FyZF9pZCwg
dC50cywgdC50eG5faWQpKQogICAgICAgICAgICB0aWRzLmFkZCh0LnR4bl9pZCkKICAgICAgICAg
ICAgY2FyZHMuYWRkKHQuY2FyZF9pZCkKICAgICAgICAgICAgaWYgdC50eG5faWQgaW4gYW5jaG9y
X25lZWQ6CiAgICAgICAgICAgICAgICBhbmNob3Jfc2Vlblt0LnR4bl9pZF0gPSAodC5jYXJkX2lk
LCB0LmN1c3RvbWVyX2lkKQogICAgaWYgcmF3LnJlYWRsaW5lKCkuc3RyaXAoKToKICAgICAgICBy
YWlzZSBSdW50aW1lRXJyb3IoInR4biBzdHJlYW0gZW5kZWQgYmVmb3JlIHJhdyBmaWxlIOKAlCBj
b3JydXB0PyIpCiAgICByYXcuY2xvc2UoKQogICAgZl9lbnIuY2xvc2UoKQogICAgZl9rZXlzLmNs
b3NlKCkKICAgIGZfZGV2LmNsb3NlKCkKICAgIHByaW50KGYiW3ByZXBdIHR4bnM9e2xlbih0aWRz
KTosfSBkZXZpY2VzPXtuX2RldjosfSBzaWdzPXtuX3NpZzosfSIpCgogICAgYmFkOiBsaXN0W3N0
cl0gPSBbXQogICAgZm9yIHRpZCwgd2FudCBpbiBwYWNrLml0ZW1zKCk6CiAgICAgICAgZ290ID0g
YW5jaG9yX3NlZW4uZ2V0KHN0cih0aWQpKQogICAgICAgIGlmIGdvdCBpcyBOb25lOgogICAgICAg
ICAgICBiYWQuYXBwZW5kKGYicGFjayB0eG4ge3RpZH0gTUlTU0lORyBmcm9tIHRyYW5zYWN0aW9u
cyIpCiAgICAgICAgZWxpZiBnb3QgIT0gd2FudDoKICAgICAgICAgICAgYmFkLmFwcGVuZChmInBh
Y2sgdHhuIHt0aWR9OiBmaWxlIHNheXMge3dhbnR9LCBkZXJpdmVkIHtnb3R9IikKICAgIGZvciB0
aWQsIHdhbnRzIGluIGNsb3NlZF9ieV90eG4uaXRlbXMoKToKICAgICAgICBnb3QgPSBhbmNob3Jf
c2Vlbi5nZXQoc3RyKHRpZCkpCiAgICAgICAgaWYgZ290IGlzIE5vbmU6CiAgICAgICAgICAgIGJh
ZC5hcHBlbmQoZiJjbG9zZWQgdHhuIHt0aWR9IE1JU1NJTkcgZnJvbSB0cmFuc2FjdGlvbnMiKQog
ICAgICAgICAgICBjb250aW51ZQogICAgICAgIGZvciB3YW50IGluIHdhbnRzOgogICAgICAgICAg
ICBpZiBnb3QgIT0gd2FudDoKICAgICAgICAgICAgICAgIGJhZC5hcHBlbmQoZiJjbG9zZWQgdHhu
IHt0aWR9OiBmaWxlIHNheXMge3dhbnR9LCBkZXJpdmVkIHtnb3R9IikKICAgIG1pc3NpbmcgPSBh
bmNob3JfbmVlZCAtIHNldChhbmNob3Jfc2VlbikKICAgIGlmIG1pc3Npbmc6CiAgICAgICAgYmFk
LmFwcGVuZChmIntsZW4obWlzc2luZyl9IGFuY2hvciB0eG5zIG1pc3NpbmcsIGUuZy4gIgogICAg
ICAgICAgICAgICAgICAgZiJ7c29ydGVkKG1pc3NpbmcpWzo1XX0iKQogICAgaWYgYmFkOgogICAg
ICAgIHByaW50KCJbcHJlcF0gQU5DSE9SIE1JU01BVENIIOKAlCBkZXJpdmF0aW9uIGRpc2FncmVl
cyB3aXRoIHBhY2svY2xvc2VkIElEczoiKQogICAgICAgIGZvciBiIGluIGJhZFs6MTVdOgogICAg
ICAgICAgICBwcmludCgiICAgIiwgYikKICAgICAgICByYWlzZSBTeXN0ZW1FeGl0KCJmaXggdGhl
IGNhcmQvY3VzdG9tZXIgZGVyaXZhdGlvbiAobG9hZGVyIHBhdGNoKSAiCiAgICAgICAgICAgICAg
ICAgICAgICAgICAiYW5kIHJlLXJ1biBwcmVwLiIpCiAgICBwcmludChmIltwcmVwXSBhbmNob3Jz
IHZlcmlmaWVkOiB7bGVuKGFuY2hvcl9zZWVuKTosfSBwYWNrL2Nsb3NlZCB0eG4gSURzICIKICAg
ICAgICAgIGYibWF0Y2ggZGVyaXZlZCBjYXJkL2N1c3RvbWVyIElEcy4iKQoKICAgIHByaW50KCJb
cHJlcF0gbmV4dCBlZGdlcy4uLiIpCiAgICBvcmRlci5zb3J0KGtleT1sYW1iZGEgcjogKHJbMF0s
IHJbMV0pKQogICAgbl9uZXh0ID0gMAogICAgd2l0aCBvcGVuKHByZXAgLyAibmV4dF9lZGdlcy5j
c3YiLCAidyIsIG5ld2xpbmU9IiIsIGVuY29kaW5nPSJ1dGYtOCIpIGFzIGZoOgogICAgICAgIHcg
PSBjc3Yud3JpdGVyKGZoKQogICAgICAgIHcud3JpdGVyb3coWyJzcmNfdHhuIiwgImRzdF90eG4i
XSkKICAgICAgICBmb3IgaSBpbiByYW5nZSgxLCBsZW4ob3JkZXIpKToKICAgICAgICAgICAgaWYg
b3JkZXJbaV1bMF0gPT0gb3JkZXJbaSAtIDFdWzBdOgogICAgICAgICAgICAgICAgdy53cml0ZXJv
dyhbb3JkZXJbaSAtIDFdWzJdLCBvcmRlcltpXVsyXV0pCiAgICAgICAgICAgICAgICBuX25leHQg
Kz0gMQogICAgcHJpbnQoZiJbcHJlcF0gbmV4dCBwYWlyczoge25fbmV4dDosfSIpCgogICAgcHJp
bnQoIltwcmVwXSBjYXNlIGVkZ2VzLi4uIikKICAgIHdpdGggb3BlbihwcmVwIC8gImNhc2VfdHhu
X2VkZ2VzLmNzdiIsICJ3IiwgbmV3bGluZT0iIiwgZW5jb2Rpbmc9InV0Zi04IikgYXMgZmgxLCBv
cGVuKAogICAgICAgICAgICBwcmVwIC8gImNhc2VfY29ubl9lZGdlcy5jc3YiLCAidyIsIG5ld2xp
bmU9IiIsIGVuY29kaW5nPSJ1dGYtOCIpIGFzIGZoMiwgb3BlbigKICAgICAgICAgICAgcHJlcCAv
ICJjYXNlX2NhcmRfZWRnZXMuY3N2IiwgInciLCBuZXdsaW5lPSIiLCBlbmNvZGluZz0idXRmLTgi
KSBhcyBmaDM6CiAgICAgICAgdzEsIHcyLCB3MyA9IGNzdi53cml0ZXIoZmgxKSwgY3N2LndyaXRl
cihmaDIpLCBjc3Yud3JpdGVyKGZoMykKICAgICAgICB3MS53cml0ZXJvdyhbImNhc2VfaWQiLCAi
dHhuX2lkIl0pCiAgICAgICAgdzIud3JpdGVyb3coWyJjYXNlX2lkIiwgImNhcmRfaWQiXSkKICAg
ICAgICB3My53cml0ZXJvdyhbImNhc2VfaWQiLCAiY2FyZF9pZCJdKQogICAgICAgIG4xID0gbjIg
PSBuMyA9IGRyb3AgPSBkcm9wYyA9IDAKICAgICAgICBmb3IgYyBpbiBjbG9zZWQ6CiAgICAgICAg
ICAgIGZvciB0IGluIGMudHhuX2lkczoKICAgICAgICAgICAgICAgIGlmIHN0cih0KSBpbiB0aWRz
OgogICAgICAgICAgICAgICAgICAgIHcxLndyaXRlcm93KFtjLmNhc2VfaWQsIHN0cih0KV0pCiAg
ICAgICAgICAgICAgICAgICAgbjEgKz0gMQogICAgICAgICAgICAgICAgZWxzZToKICAgICAgICAg
ICAgICAgICAgICBkcm9wICs9IDEKICAgICAgICAgICAgZm9yIGNjIGluIGMuY29ubmVjdGVkX2Nh
cmRfaWRzOgogICAgICAgICAgICAgICAgaWYgc3RyKGNjKSBpbiBjYXJkczoKICAgICAgICAgICAg
ICAgICAgICB3Mi53cml0ZXJvdyhbYy5jYXNlX2lkLCBzdHIoY2MpXSkKICAgICAgICAgICAgICAg
ICAgICBuMiArPSAxCiAgICAgICAgICAgICAgICBlbHNlOgogICAgICAgICAgICAgICAgICAgIGRy
b3BjICs9IDEKICAgICAgICAgICAgaWYgc3RyKGMuY2FyZF9pZCkgaW4gY2FyZHM6CiAgICAgICAg
ICAgICAgICB3My53cml0ZXJvdyhbYy5jYXNlX2lkLCBzdHIoYy5jYXJkX2lkKV0pCiAgICAgICAg
ICAgICAgICBuMyArPSAxCiAgICAgICAgICAgIGVsc2U6CiAgICAgICAgICAgICAgICBkcm9wYyAr
PSAxCiAgICBwcmludChmIltwcmVwXSBjYXNlX3R4bj17bjE6LH0gY2FzZV9jb25uPXtuMjosfSBj
YXNlX2NhcmQ9e24zOix9ICIKICAgICAgICAgIGYiZHJvcHBlZF91bmtub3duX3R4bj17ZHJvcH0g
ZHJvcHBlZF91bmtub3duX2NhcmQ9e2Ryb3BjfSIpCiAgICBwcmludCgiW3ByZXBdIERPTkUuIFNp
ZGUtZmlsZXMgaW4iLCBwcmVwKQoKCmlmIF9fbmFtZV9fID09ICJfX21haW5fXyI6CiAgICBtYWlu
KCkK
"""
JOB_B64 = """LS0gQW52ZXNoIGJ1bGsgbG9hZCBmb3IgdGhlIEhIR09BX0lFRUUgQ1NWcyAoKyBwcmVwIHNpZGUt
ZmlsZXMpLgotLSBSdW4gQUZURVI6ICBzY2hlbWEgaW5zdGFsbGVkLCBBTFRFUiBWRVJURVggVHJh
bnNhY3Rpb24gQUREIEFUVFJJQlVURSAodHNfcmF3IFNUUklORykuCi0tIEluc3RhbGwgd2l0aDog
IHB5dGhvbiBzY3JpcHRzL2dyYXBoX2xvYWQucHkgLS1zdGVwcyBqb2IKLS0gTG9hZCB3aXRoOiAg
ICAgcHl0aG9uIHNjcmlwdHMvZ3JhcGhfbG9hZC5weSAtLXN0ZXBzIGxvYWQgLS1tYXAgLi4uIChE
RVBMT1kubWQgwqc1KQotLQotLSBQT1NJVElPTkFMIHRva2VucyAoJDAuLiROKSBldmVyeXdoZXJl
OiBjaHVua3MgYXJlIHVwbG9hZGVkIGhlYWRlcmxlc3MsIHNvCi0tIG5hbWVkIHRva2VucyAoJCJj
b2wiKSB3b3VsZCBub3QgcmVzb2x2ZS4gSW5kZXggbWFwcyAoMC1iYXNlZCk6Ci0tICAgZl90eG4g
ICAgdHJhbnNhY3Rpb25zX2VucmljaGVkLmNzdiA9IHJhdyAzOTcgY29scyArIHZfYW5vbSwgbV9m
bGFncyBhcHBlbmRlZAotLSAgICAgICAgICAgIDAgVHJhbnNhY3Rpb25JRCwgMSBUcmFuc2FjdGlv
bkRULCAyIFRyYW5zYWN0aW9uQW10LCAzIFByb2R1Y3RDRCwKLS0gICAgICAgICAgICA0LTkgY2Fy
ZDEuLmNhcmQ2LCAxMCBhZGRyMSwgMTEgYWRkcjIsIDEyIGRpc3QxLCAxMyBkaXN0MiwKLS0gICAg
ICAgICAgICAxNCBQX2VtYWlsZG9tYWluLCAxNSBSX2VtYWlsZG9tYWluLCAxNi0yOSBDMS4uQzE0
LCAzMC00NCBEMS4uRDE1LAotLSAgICAgICAgICAgIDQ1LTUzIE0xLi5NOSwgNTQtMzkyIFYxLi5W
MzM5LAotLSAgICAgICAgICAgIDM5MyBjdXN0b21lcl9pZCwgMzk0IHRzICgiWVlZWS1NTS1ERCBI
SDpNTTpTUyIpLCAzOTUgY2hhbm5lbCwKLS0gICAgICAgICAgICAzOTYgcmlza19zY29yZSwgMzk3
IHZfYW5vbSwgMzk4IG1fZmxhZ3MKLS0gICBmX2tleXMgICB0eG5fa2V5cy5jc3YgICAgICAgMCBU
cmFuc2FjdGlvbklELCAxIGNhcmRfaWQsIDIgY3VzdG9tZXJfaWQsIDMgY2FyZDQsIDQgY2FyZDYK
LS0gICBmX2RldmljZXMgdHhuX2RldmljZXMuY3N2ICAgMCBUcmFuc2FjdGlvbklELCAxIGRldmlj
ZV9pZCwgMiBkZXZpY2VfaW5mbywKLS0gICAgICAgICAgICAzIGRldmljZV90eXBlLCA0IG9zLCA1
IGJyb3dzZXIsIDYgc2NyZWVuLCA3IHNpZ19pZCwKLS0gICAgICAgICAgICA4IHNpZ19kZXZpY2Vf
dHlwZSwgOSBzaWdfb3MsIDEwIHNpZ19icm93c2VyCi0tICAgZl9uZXh0ICAgbmV4dF9lZGdlcy5j
c3YgICAgIDAgc3JjX3R4biwgMSBkc3RfdHhuCi0tICAgZl9jYXNlcyAgY2xvc2VkX2Nhc2VzX2hp
c3RvcnkuY3N2Ci0tICAgICAgICAgICAgMCBjYXNlX2lkLCAxIGN1c3RvbWVyX2lkLCAyIGNhcmRf
aWQsIDMgb3BlbmVkX2F0LCA0IGNsb3NlZF9hdCwKLS0gICAgICAgICAgICA1IG91dGNvbWUsIDYg
cGF0dGVybiwgNyBmaXJzdF9mcmF1ZF90eG5faWQsIDggdHhuX2lkcywgOSBuX3R4bnMsCi0tICAg
ICAgICAgICAgMTAgZXhwb3N1cmVfdXNkLCAxMSBjb25uZWN0ZWRfY2FyZF9pZHMsIDEyIGFjdGlv
bnNfdGFrZW4sCi0tICAgICAgICAgICAgMTMgcmVwb3J0X2ZpbGVkLCAxNCBhbmFseXN0X25vdGVz
Ci0tICAgZl9jYXNlX3R4biAgY2FzZV90eG5fZWRnZXMuY3N2ICAgMCBjYXNlX2lkLCAxIHR4bl9p
ZAotLSAgIGZfY2FzZV9jb25uIGNhc2VfY29ubl9lZGdlcy5jc3YgIDAgY2FzZV9pZCwgMSBjYXJk
X2lkCi0tICAgZl9jYXNlX2NhcmQgY2FzZV9jYXJkX2VkZ2VzLmNzdiAgMCBjYXNlX2lkLCAxIGNh
cmRfaWQKLS0KLS0gdHMgaXMgTk9UIGxvYWRlZCBoZXJlOiBpdCBjb21lcyBmcm9tIHRoZSB6el9m
aXh1cCBxdWVyeQotLSAodG9fZGF0ZXRpbWUgb3ZlciB0c19yYXcpLiBOb3RoaW5nIHJlYWRzIGNf
c3VtL2RfZGF5cy9hbmFseXN0X25vdGVzL2tpbmQ6Ci0tIGNvbnN0YW50cywgbm90IGNvbHVtbnMu
CkNSRUFURSBMT0FESU5HIEpPQiBsb2FkX2FudmVzaCBGT1IgR1JBUEggQW52ZXNoIHsKICBERUZJ
TkUgRklMRU5BTUUgZl90eG47CiAgREVGSU5FIEZJTEVOQU1FIGZfa2V5czsKICBERUZJTkUgRklM
RU5BTUUgZl9kZXZpY2VzOwogIERFRklORSBGSUxFTkFNRSBmX25leHQ7CiAgREVGSU5FIEZJTEVO
QU1FIGZfY2FzZXM7CiAgREVGSU5FIEZJTEVOQU1FIGZfY2FzZV90eG47CiAgREVGSU5FIEZJTEVO
QU1FIGZfY2FzZV9jb25uOwogIERFRklORSBGSUxFTkFNRSBmX2Nhc2VfY2FyZDsKCiAgLS0gQmFz
ZSB0cmFuc2FjdGlvbiByb3dzICgxNSBUcmFuc2FjdGlvbiBhdHRycyBpbmNsLiBBTFRFUi1hZGRl
ZCB0c19yYXcpLgogIExPQUQgZl90eG4gVE8gVkVSVEVYIFRyYW5zYWN0aW9uIFZBTFVFUyAoCiAg
ICAkMCwgIjIwMTYtMDctMDEgMDA6MDA6MDAiLCAkMiwgJDMsCiAgICAkMzk1LCAkMzk2LCAkMTAs
ICQxMSwgJDE0LCAkMTUsCiAgICAkMzk3LCAwLCAwLCAkMzk4LCAkMzk0KQogIFVTSU5HIEhFQURF
Uj0iZmFsc2UiLCBTRVBBUkFUT1I9IiwiOwoKICAtLSBDYXJkcyArIGN1c3RvbWVycyArIGxpbmth
Z2UgKElEcyByZXNvbHZlZCBieSBzY3JpcHRzL3ByZXBfZ3JhcGgucHkpLgogIExPQUQgZl9rZXlz
IFRPIFZFUlRFWCBDYXJkIFZBTFVFUyAoJDEsICQzLCAkNCkKICBVU0lORyBIRUFERVI9ImZhbHNl
IiwgU0VQQVJBVE9SPSIsIjsKICBMT0FEIGZfa2V5cyBUTyBWRVJURVggQ3VzdG9tZXIgVkFMVUVT
ICgkMikKICBVU0lORyBIRUFERVI9ImZhbHNlIiwgU0VQQVJBVE9SPSIsIjsKICBMT0FEIGZfa2V5
cyBUTyBFREdFIE1BREUgVkFMVUVTICgkMSwgJDApCiAgVVNJTkcgSEVBREVSPSJmYWxzZSIsIFNF
UEFSQVRPUj0iLCI7CiAgTE9BRCBmX2tleXMgVE8gRURHRSBPV05TIFZBTFVFUyAoJDIsICQxKQog
IFVTSU5HIEhFQURFUj0iZmFsc2UiLCBTRVBBUkFUT1I9IiwiOwoKICAtLSBORVhUIChwZXItY2Fy
ZCB0aW1lIG9yZGVyLCBwcmVjb21wdXRlZCkuCiAgTE9BRCBmX25leHQgVE8gRURHRSBORVhUIFZB
TFVFUyAoJDAsICQxKQogIFVTSU5HIEhFQURFUj0iZmFsc2UiLCBTRVBBUkFUT1I9IiwiOwoKICAt
LSBEaW1lbnNpb25zIGZyb20gcmF3IHR4biBjb2x1bW5zLiBXSEVSRSBza2lwcyBlbXB0aWVzOiBh
biAiIiB2ZXJ0ZXgKICAtLSB3b3VsZCBsaW5rIGV2ZXJ5IG1pc3NpbmctdmFsdWUgdHJhbnNhY3Rp
b24gaW50byBvbmUgZ2FyYmFnZSBodWIuCiAgTE9BRCBmX3R4biBUTyBWRVJURVggQmlsbGluZ1Jl
Z2lvbiBWQUxVRVMgKCQxMCkKICBXSEVSRSAkMTAgIT0gIiIgVVNJTkcgSEVBREVSPSJmYWxzZSIs
IFNFUEFSQVRPUj0iLCI7CiAgTE9BRCBmX3R4biBUTyBFREdFIEJJTExFRF9JTiBWQUxVRVMgKCQw
LCAkMTApCiAgV0hFUkUgJDEwICE9ICIiIFVTSU5HIEhFQURFUj0iZmFsc2UiLCBTRVBBUkFUT1I9
IiwiOwogIExPQUQgZl90eG4gVE8gVkVSVEVYIEJpbGxpbmdDb3VudHJ5IFZBTFVFUyAoJDExKQog
IFdIRVJFICQxMSAhPSAiIiBVU0lORyBIRUFERVI9ImZhbHNlIiwgU0VQQVJBVE9SPSIsIjsKICBM
T0FEIGZfdHhuIFRPIEVER0UgSU5fQ09VTlRSWSBWQUxVRVMgKCQwLCAkMTEpCiAgV0hFUkUgJDEx
ICE9ICIiIFVTSU5HIEhFQURFUj0iZmFsc2UiLCBTRVBBUkFUT1I9IiwiOwogIExPQUQgZl90eG4g
VE8gVkVSVEVYIFByb2R1Y3RDb2RlIFZBTFVFUyAoJDMpCiAgV0hFUkUgJDMgIT0gIiIgVVNJTkcg
SEVBREVSPSJmYWxzZSIsIFNFUEFSQVRPUj0iLCI7CiAgTE9BRCBmX3R4biBUTyBFREdFIE9GX1BS
T0RVQ1QgVkFMVUVTICgkMCwgJDMpCiAgV0hFUkUgJDMgIT0gIiIgVVNJTkcgSEVBREVSPSJmYWxz
ZSIsIFNFUEFSQVRPUj0iLCI7CiAgTE9BRCBmX3R4biBUTyBWRVJURVggRW1haWxEb21haW4gVkFM
VUVTICgkMTQsICJwdXJjaGFzZXIiKQogIFdIRVJFICQxNCAhPSAiIiBVU0lORyBIRUFERVI9ImZh
bHNlIiwgU0VQQVJBVE9SPSIsIjsKICBMT0FEIGZfdHhuIFRPIEVER0UgUFVSQ0hBU0VSX0VNQUlM
IFZBTFVFUyAoJDAsICQxNCkKICBXSEVSRSAkMTQgIT0gIiIgVVNJTkcgSEVBREVSPSJmYWxzZSIs
IFNFUEFSQVRPUj0iLCI7CiAgTE9BRCBmX3R4biBUTyBWRVJURVggRW1haWxEb21haW4gVkFMVUVT
ICgkMTUsICJyZWNpcGllbnQiKQogIFdIRVJFICQxNSAhPSAiIiBVU0lORyBIRUFERVI9ImZhbHNl
IiwgU0VQQVJBVE9SPSIsIjsKICBMT0FEIGZfdHhuIFRPIEVER0UgUkVDSVBJRU5UX0VNQUlMIFZB
TFVFUyAoJDAsICQxNSkKICBXSEVSRSAkMTUgIT0gIiIgVVNJTkcgSEVBREVSPSJmYWxzZSIsIFNF
UEFSQVRPUj0iLCI7CiAgTE9BRCBmX3R4biBUTyBWRVJURVggQ3VzdG9tZXIgVkFMVUVTICgkMzkz
KQogIFdIRVJFICQzOTMgIT0gIiIgVVNJTkcgSEVBREVSPSJmYWxzZSIsIFNFUEFSQVRPUj0iLCI7
CgogIC0tIERldmljZXMgKGNvbXBvc2l0ZXMgcmVzb2x2ZWQgYnkgcHJlcDsgc2lnIHJvd3MgbWF5
IGJlIGFic2VudCkuCiAgTE9BRCBmX2RldmljZXMgVE8gVkVSVEVYIERldmljZVByb2ZpbGUgVkFM
VUVTICgkMSwgJDIsICQzLCAkNCwgJDUsICQ2KQogIFVTSU5HIEhFQURFUj0iZmFsc2UiLCBTRVBB
UkFUT1I9IiwiOwogIExPQUQgZl9kZXZpY2VzIFRPIFZFUlRFWCBEZXZpY2VTaWduYXR1cmUgVkFM
VUVTICgkNywgJDgsICQ5LCAkMTApCiAgV0hFUkUgJDcgIT0gIiIgVVNJTkcgSEVBREVSPSJmYWxz
ZSIsIFNFUEFSQVRPUj0iLCI7CiAgTE9BRCBmX2RldmljZXMgVE8gRURHRSBGUk9NX0RFVklDRSBW
QUxVRVMgKCQwLCAkMSkKICBVU0lORyBIRUFERVI9ImZhbHNlIiwgU0VQQVJBVE9SPSIsIjsKICBM
T0FEIGZfZGV2aWNlcyBUTyBFREdFIFJFU09MVkVTX1RPIFZBTFVFUyAoJDAsICQ3KQogIFdIRVJF
ICQ3ICE9ICIiIFVTSU5HIEhFQURFUj0iZmFsc2UiLCBTRVBBUkFUT1I9IiwiOwoKICAtLSBDbG9z
ZWQgY2FzZXMgKGRhdGV0aW1lcyBkdW1teTogbm90aGluZyByZWFkcyB0aGVtOyBub3RlcyBjb25z
dGFudDoKICAtLSBmcmVlIHRleHQgd2l0aCBjb21tYXMgd291bGQgcmlzayB0aGUgcGFyc2UgYW5k
IG5vdGhpbmcgcmVhZHMgaXQpLgogIExPQUQgZl9jYXNlcyBUTyBWRVJURVggQ2xvc2VkQ2FzZSBW
QUxVRVMgKAogICAgJDAsICIyMDE2LTA3LTAxIDAwOjAwOjAwIiwgIjIwMTYtMDctMDEgMDA6MDA6
MDAiLAogICAgJDUsICQ2LCAkOSwgJDEwLCAic2VlIENTViIpCiAgVVNJTkcgSEVBREVSPSJmYWxz
ZSIsIFNFUEFSQVRPUj0iLCI7CiAgTE9BRCBmX2Nhc2VzIFRPIFZFUlRFWCBQYXR0ZXJuIFZBTFVF
UyAoJDYsICJvYnNlcnZlZCIsICIiKQogIFdIRVJFICQ2ICE9ICIiIFVTSU5HIEhFQURFUj0iZmFs
c2UiLCBTRVBBUkFUT1I9IiwiOwogIExPQUQgZl9jYXNlX3R4biBUTyBFREdFIElOVk9MVkVTIFZB
TFVFUyAoJDAsICQxKQogIFVTSU5HIEhFQURFUj0iZmFsc2UiLCBTRVBBUkFUT1I9IiwiOwogIExP
QUQgZl9jYXNlX2NhcmQgVE8gRURHRSBPTl9DQVJEIFZBTFVFUyAoJDAsICQxKQogIFVTSU5HIEhF
QURFUj0iZmFsc2UiLCBTRVBBUkFUT1I9IiwiOwogIExPQUQgZl9jYXNlX2Nvbm4gVE8gRURHRSBD
T05ORUNURURfVE8gVkFMVUVTICgkMCwgJDEpCiAgVVNJTkcgSEVBREVSPSJmYWxzZSIsIFNFUEFS
QVRPUj0iLCI7CiAgTE9BRCBmX2Nhc2VzIFRPIEVER0UgSEFTX1BBVFRFUk4gVkFMVUVTICgkMCwg
JDYpCiAgV0hFUkUgJDYgIT0gIiIgVVNJTkcgSEVBREVSPSJmYWxzZSIsIFNFUEFSQVRPUj0iLCI7
Cn0K
"""


def _write_payload(rel, data):
    p = Path(rel)
    if p.exists() and p.read_bytes() == data:
        print(f"[payload] {rel}: unchanged")
        return
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(data)
    print(f"[payload] {rel}: wrote {len(data)} bytes")


def payload_stages():
    try:
        prep = base64.b64decode(PREP_B64)
        job = base64.b64decode(JOB_B64)
    except Exception as e:
        raise SystemExit(f"bundle payload would not decode ({e}) — re-copy scripts/apply_phase3.py from the viewer")
    assert hashlib.md5(prep).hexdigest() == PREP_MD5, "prep payload corrupted in transit — re-copy scripts/apply_phase3.py from the viewer"
    assert hashlib.md5(job).hexdigest() == JOB_MD5, "job payload corrupted in transit — re-copy scripts/apply_phase3.py from the viewer"
    _write_payload("scripts/prep_graph.py", prep)
    _write_payload("graph/loading_job.gsql", job)
    lt = Path(TARGET).read_text(encoding="utf-8")
    n_card = lt.count("def build_card_map(")
    n_chal = lt.count("def _challenge_cols_present(")
    n_loads = job.decode().count("LOAD f_")
    print(f"[verify] {TARGET}: {len(lt.splitlines())} lines, build_card_map x{n_card}, _challenge_cols_present x{n_chal}")
    assert n_card == 1 and n_chal == 1, "loader patch incomplete — report this line"
    print(f"[verify] scripts/prep_graph.py: {len(prep.decode().splitlines())} lines")
    print(f"[verify] graph/loading_job.gsql: {len(job.decode().splitlines())} lines, LOADs x{n_loads}")
    assert n_loads == 27, "job payload damaged — report this line"
    py_compile.compile(str(REPO / TARGET), doraise=True)
    py_compile.compile(str(REPO / "scripts" / "prep_graph.py"), doraise=True)
    print("[verify] py_compile loader + prep: OK")
    print("PHASE 3 FILES READY")


def bundle_main():
    main()
    payload_stages()


if __name__ == "__main__":
    bundle_main()
