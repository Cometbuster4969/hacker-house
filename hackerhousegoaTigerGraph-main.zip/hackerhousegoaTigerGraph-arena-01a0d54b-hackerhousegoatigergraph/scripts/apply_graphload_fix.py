#!/usr/bin/env python3
"""One-shot: fix scripts/graph_load.py for the GSQL statements endpoint.

1. run_gsql() strips full-line '--' comments before sending: the
   POST /gsql/v1/statements endpoint rejects them (parse error at the
   first dash). Files on disk keep their comments.
2. run_gsql() also treats GSQL parser failures ("Encountered ...",
   "semantic error", "syntax error") as errors, and prints [ok] only
   after the output passes the check (red is red, no silent fakes).
3. step_job() / step_queries() prefix "USE GRAPH <graph>": the statements
   endpoint runs each submission in a fresh session with no graph
   selected, and FOR GRAPH alone does not select it.
4. The error check additionally catches the silent-fake shapes seen live:
   terse "Semantic Check Fails: ..." (no "Failed ..." summary line),
   permission/privilege denials, "could not be created", "does not
   exist", "invalid syntax", "is not a valid".
5. step_queries() drops each query before creating it: CREATE QUERY fails
   if a query with that name already exists ("used by another object").
   DROP QUERY {n} runs silently via conn.gsql() (best-effort, ignoring
   errors when the query does not exist yet) with "USE GRAPH <graph>"
   so CREATE starts clean.

Expected counts:
  Fresh run on pristine graph_load.py:
    [gsql-fix] applied=2 skipped=0
    [use-graph] applied=3 skipped=0
    [error-patterns] applied=1 skipped=0
    [drop-before-create] applied=1 skipped=0
  Upgrade run (stages 1-3 already applied):
    [gsql-fix] applied=0 skipped=2
    [use-graph] applied=0 skipped=3
    [error-patterns] applied=0 skipped=1
    [drop-before-create] applied=1 skipped=0

Run from anywhere:  python scripts/apply_graphload_fix.py
Safe to re-run: already-applied edits are skipped. If an anchor does not
match, NOTHING is written and the failure names the exact spot.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
os.chdir(REPO)
TARGET = "scripts/graph_load.py"


MARKERS = {
    # (stage, pair-index) -> short stable string proving the pair applied.
    # gsql-fix pair 1's `new` is legitimately refined by error-patterns.
    ("gsql-fix", 1): '    print(f"[ok] {label}")\n    return out',
    ("error-patterns", 0): '"semantic check fails"',
    ("error-margin-clean", 0): 'if "query installation finished" in low and "failed: 0" in low:',
    ("drop-before-create", 0): 'DROP QUERY {n}',
}


def patch(pairs: list[tuple[str, str]], stage: str) -> None:
    p = Path(TARGET)
    t = p.read_text(encoding="utf-8")
    applied, skipped = 0, 0
    for i, (old, new) in enumerate(pairs):
        if (MARKERS.get((stage, i)) or new) in t:
            skipped += 1
            continue
        assert t.count(old) == 1, (
            f"anchor FAILED ({stage}): {old[:70]!r} found x{t.count(old)}. "
            f"Your {TARGET} differs from the expected version — STOP and "
            f"report this line.")
        t = t.replace(old, new)
        applied += 1
    p.write_text(t, encoding="utf-8")
    print(f"[{stage}] applied={applied} skipped={skipped}")


def main() -> None:
    if not Path(TARGET).exists():
        sys.exit(f"{TARGET} not found — run from the repo root.")
    patch([
        ('''def run_gsql(conn, text: str, label: str, graphname: str | None) -> str:
    try:
        out = conn.gsql(text, graphname=graphname)''',
         '''def run_gsql(conn, text: str, label: str, graphname: str | None) -> str:
    # The /gsql/v1/statements endpoint rejects '--' comment lines (parse
    # error at the first dash), so strip them client-side. On-disk files
    # keep their comments. (All non-ASCII bytes live in those comment
    # lines, so the stripped text is pure ASCII on every platform.)
    text = "\\n".join(
        ln for ln in text.splitlines() if not ln.lstrip().startswith("--"))
    try:
        out = conn.gsql(text, graphname=graphname)'''),
        ('''    out = out if isinstance(out, str) else str(out)
    print(f"[ok] {label}")
    low = out.lower()
    if "error" in low or "failed" in low:
        print(f"----- server output for {label} -----")
        print(out[:3000])
        print("----- end -----")
        raise RuntimeError(f"{label} reported an error (see above).")
    return out''',
         '''    out = out if isinstance(out, str) else str(out)
    low = out.lower()
    if any(p in low for p in ("error", "failed", "encountered",
                              "semantic error", "syntax error")):
        print(f"----- server output for {label} -----")
        print(out[:3000])
        print("----- end -----")
        raise RuntimeError(f"{label} reported an error (see above).")
    print(f"[ok] {label}")
    return out'''),
    ], "gsql-fix")
    patch([
        ('''def step_job(conn) -> tuple[str, list[str]]:
    text = (GRAPH / "loading_job.gsql").read_text()
    job, tags = parse_job(text)
    run_gsql(conn, text, f"loading job '{job}' (tags: {', '.join(tags)})", None)
    return job, tags''',
         '''def step_job(conn) -> tuple[str, list[str]]:
    text = (GRAPH / "loading_job.gsql").read_text()
    job, tags = parse_job(text)
    # CREATE LOADING JOB needs a selected graph even with FOR GRAPH: each
    # submission runs in a fresh session with nothing selected.
    gm = re.search(r"FOR GRAPH (\\w+)", text)
    assert gm, "no FOR GRAPH in loading_job.gsql — report this"
    text = f"USE GRAPH {gm.group(1)}\\n" + text
    run_gsql(conn, text, f"loading job '{job}' (tags: {', '.join(tags)})", None)
    return job, tags'''),
        ('''        run_gsql(conn, f.read_text(), f"CREATE QUERY {n}", graph)''',
         '''        run_gsql(conn, f"USE GRAPH {graph}\\n" + f.read_text(),
                 f"CREATE QUERY {n}", graph)'''),
        ('''            run_gsql(conn, f"INSTALL QUERY {n}", f"INSTALL QUERY {n}", graph)''',
         '''            run_gsql(conn, f"USE GRAPH {graph}\\nINSTALL QUERY {n}",
                     f"INSTALL QUERY {n}", graph)'''),
    ], "use-graph")
    patch([
        ('''    if any(p in low for p in ("error", "failed", "encountered",
                              "semantic error", "syntax error")):''',
         '''    if any(p in low for p in ("error", "failed", "encountered",
                              "semantic error", "semantic check fails",
                              "syntax error", "invalid syntax",
                              "permission", "privilege",
                              "could not be created", "does not exist",
                              "is not a valid")):'''),
    ], "error-patterns")
    patch([
        ('''    low = out.lower()
    if any(p in low for p in ("error", "failed", "encountered",
                              "semantic error", "semantic check fails",
                              "syntax error", "invalid syntax",
                              "permission", "privilege",
                              "could not be created", "does not exist",
                              "is not a valid")):''',
         '''    low = out.lower()
    # Query installation summary reports 'failed: 0' on success; do not false-positive on 'failed'.
    if "query installation finished" in low and "failed: 0" in low:
        print(f"[ok] {label}")
        return out
    # Query creation reports 'Successfully created queries: [...]' on success.
    if "successfully created queries" in low:
        print(f"[ok] {label}")
        return out
    chk = low.replace("error margin", "").replace("failed: 0", "")
    if any(p in chk for p in ("error", "failed", "encountered",
                              "semantic error", "semantic check fails",
                              "syntax error", "invalid syntax",
                              "permission", "privilege",
                              "could not be created", "does not exist",
                              "is not a valid")):'''),
    ], "error-margin-clean")
    patch([
        ('''        run_gsql(conn, f"USE GRAPH {graph}\\n" + f.read_text(),
                 f"CREATE QUERY {n}", graph)''',
         '''        try:
            conn.gsql(f"USE GRAPH {graph}\\nDROP QUERY {n}", graphname=graph)
        except Exception:
            pass
        run_gsql(conn, f"USE GRAPH {graph}\\n" + f.read_text(),
                 f"CREATE QUERY {n}", graph)'''),
    ], "drop-before-create")
    print("ALL PATCHES APPLIED")


if __name__ == "__main__":
    main()
