#!/usr/bin/env python3
"""Build graph side-files + enriched transactions from the real HHGOA_IEEE CSVs.

Run once (AFTER the loader ID patch is applied — prep consumes Txn objects,
so graph IDs are bit-identical to memory-mode IDs by construction):

    python scripts/prep_graph.py

Reads data/HHGOA_IEEE/*.csv, writes into data/HHGOA_IEEE/graph_prep/:
    transactions_enriched.csv  raw + appended v_anom, m_flags
    txn_keys.csv               TransactionID,card_id,customer_id,card4,card6
    txn_devices.csv            TransactionID,device_id,device_info,device_type,
                               os,browser,screen,sig_id,sig_device_type,sig_os,sig_browser
    next_edges.csv             src_txn,dst_txn (per-card time order)
    case_txn_edges.csv         case_id,txn_id
    case_conn_edges.csv        case_id,card_id
    case_card_edges.csv        case_id,card_id (ON_CARD, verified)

Anchor verification: every pack/closed card+customer ID is checked against the
ID derived for its anchor transaction. Any mismatch aborts LOUDLY — a wrong
derivation must never silently produce zero-match investigations.
"""

from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO / "src"))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", type=Path, default=REPO / "data" / "HHGOA_IEEE")
    args = ap.parse_args()
    from anvesh.data.loader import (LoadConfig, load_closed_cases, load_pack,
                                    load_transactions, _read_identity)
    import pandas as pd

    d: Path = args.data_dir
    prep = d / "graph_prep"
    prep.mkdir(exist_ok=True)
    cfg = LoadConfig(d)

    print("[prep] pass 0: card4/card6 + anchors...")
    c46: dict[str, tuple[str, str]] = {}
    for chunk in pd.read_csv(d / "transactions.csv",
                             usecols=["TransactionID", "card4", "card6"],
                             chunksize=200_000, dtype=str):
        chunk = chunk.fillna("")
        for tid, c4, c6 in zip(chunk["TransactionID"], chunk["card4"],
                               chunk["card6"]):
            c46[str(tid)] = (str(c4), str(c6))
    pack = {r.flagged_txn_id: (r.card_id, r.customer_id)
            for r in load_pack(d / "case_pack.csv")}
    closed = load_closed_cases(d / "closed_cases_history.csv")
    anchor_need: set[str] = set(pack)
    closed_by_txn: dict[str, list[tuple[str, str]]] = {}
    for c in closed:
        for t in c.txn_ids:
            closed_by_txn.setdefault(str(t), []).append((c.card_id,
                                                         c.customer_id))
            anchor_need.add(str(t))
        if c.first_fraud_txn_id:
            anchor_need.add(str(c.first_fraud_txn_id))

    identity = _read_identity(d / "identity.csv")

    def parts(tid: str) -> tuple[str, str, str, str, str]:
        dev = identity.get(str(tid), {})
        return (dev.get("DeviceInfo", ""), dev.get("DeviceType", ""),
                dev.get("id_30", ""), dev.get("id_31", ""),
                dev.get("id_33", ""))

    print("[prep] pass 1: transactions -> enriched/keys/devices...")
    f_enr = open(prep / "transactions_enriched.csv", "w", newline="", encoding="utf-8")
    f_keys = open(prep / "txn_keys.csv", "w", newline="", encoding="utf-8")
    f_dev = open(prep / "txn_devices.csv", "w", newline="", encoding="utf-8")
    w_keys = csv.writer(f_keys)
    w_dev = csv.writer(f_dev)
    w_keys.writerow(["TransactionID", "card_id", "customer_id", "card4",
                     "card6"])
    w_dev.writerow(["TransactionID", "device_id", "device_info", "device_type",
                    "os", "browser", "screen", "sig_id", "sig_device_type",
                    "sig_os", "sig_browser"])
    raw = open(d / "transactions.csv", "r", newline="", encoding="utf-8")
    f_enr.write(raw.readline().rstrip("\r\n") + ",v_anom,m_flags\n")
    order: list[tuple[str, object, str]] = []
    tids: set[str] = set()
    cards: set[str] = set()
    anchor_seen: dict[str, tuple[str, str]] = {}
    n_dev = n_sig = 0
    for batch in load_transactions(cfg):
        for t in batch:
            line = raw.readline()
            if not line:
                raise RuntimeError("raw file ended before txn stream — corrupt?")
            f_enr.write(line.rstrip("\r\n") + f",{t.v_anom:.4f},{t.m_flags}\n")
            c4, c6 = c46.get(t.txn_id, ("", ""))
            w_keys.writerow([t.txn_id, t.card_id, t.customer_id, c4, c6])
            if t.device_id:
                info, dtype, o, b, s = parts(t.txn_id)
                sig = [x for x in (dtype, o, b) if x]
                sig_id = " | ".join(sig)
                w_dev.writerow([t.txn_id, t.device_id, info, dtype, o, b, s,
                                sig_id, dtype, o, b])
                n_dev += 1
                n_sig += bool(sig_id)
            order.append((t.card_id, t.ts, t.txn_id))
            tids.add(t.txn_id)
            cards.add(t.card_id)
            if t.txn_id in anchor_need:
                anchor_seen[t.txn_id] = (t.card_id, t.customer_id)
    if raw.readline().strip():
        raise RuntimeError("txn stream ended before raw file — corrupt?")
    raw.close()
    f_enr.close()
    f_keys.close()
    f_dev.close()
    print(f"[prep] txns={len(tids):,} devices={n_dev:,} sigs={n_sig:,}")

    bad: list[str] = []
    for tid, want in pack.items():
        got = anchor_seen.get(str(tid))
        if got is None:
            bad.append(f"pack txn {tid} MISSING from transactions")
        elif got != want:
            bad.append(f"pack txn {tid}: file says {want}, derived {got}")
    for tid, wants in closed_by_txn.items():
        got = anchor_seen.get(str(tid))
        if got is None:
            bad.append(f"closed txn {tid} MISSING from transactions")
            continue
        for want in wants:
            if got != want:
                bad.append(f"closed txn {tid}: file says {want}, derived {got}")
    missing = anchor_need - set(anchor_seen)
    if missing:
        bad.append(f"{len(missing)} anchor txns missing, e.g. "
                   f"{sorted(missing)[:5]}")
    if bad:
        print("[prep] ANCHOR MISMATCH — derivation disagrees with pack/closed IDs:")
        for b in bad[:15]:
            print("   ", b)
        raise SystemExit("fix the card/customer derivation (loader patch) "
                         "and re-run prep.")
    print(f"[prep] anchors verified: {len(anchor_seen):,} pack/closed txn IDs "
          f"match derived card/customer IDs.")

    print("[prep] next edges...")
    order.sort(key=lambda r: (r[0], r[1]))
    n_next = 0
    with open(prep / "next_edges.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["src_txn", "dst_txn"])
        for i in range(1, len(order)):
            if order[i][0] == order[i - 1][0]:
                w.writerow([order[i - 1][2], order[i][2]])
                n_next += 1
    print(f"[prep] next pairs: {n_next:,}")

    print("[prep] case edges...")
    with open(prep / "case_txn_edges.csv", "w", newline="", encoding="utf-8") as fh1, open(
            prep / "case_conn_edges.csv", "w", newline="", encoding="utf-8") as fh2, open(
            prep / "case_card_edges.csv", "w", newline="", encoding="utf-8") as fh3:
        w1, w2, w3 = csv.writer(fh1), csv.writer(fh2), csv.writer(fh3)
        w1.writerow(["case_id", "txn_id"])
        w2.writerow(["case_id", "card_id"])
        w3.writerow(["case_id", "card_id"])
        n1 = n2 = n3 = drop = dropc = 0
        for c in closed:
            for t in c.txn_ids:
                if str(t) in tids:
                    w1.writerow([c.case_id, str(t)])
                    n1 += 1
                else:
                    drop += 1
            for cc in c.connected_card_ids:
                if str(cc) in cards:
                    w2.writerow([c.case_id, str(cc)])
                    n2 += 1
                else:
                    dropc += 1
            if str(c.card_id) in cards:
                w3.writerow([c.case_id, str(c.card_id)])
                n3 += 1
            else:
                dropc += 1
    print(f"[prep] case_txn={n1:,} case_conn={n2:,} case_card={n3:,} "
          f"dropped_unknown_txn={drop} dropped_unknown_card={dropc}")
    print("[prep] DONE. Side-files in", prep)


if __name__ == "__main__":
    main()
