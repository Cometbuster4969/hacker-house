#!/usr/bin/env python3
"""Provision the Anvesh graph on TigerGraph and bulk-load the challenge CSVs.

Resumable steps — run one at a time or `--steps all`:

    schema   install vertices/edges/graph from graph/schema.gsql (one call)
    job      create the loading job from graph/loading_job.gsql (one call)
    queries  CREATE + INSTALL each query in graph/q_*.gsql (slow: ~1-5 min each)
    load     split CSVs into headerless chunks, upload + run the job per chunk
    verify   vertex counts vs expected (Transaction 590,742 / ClosedCase 5,565)

Connection comes from `.env` (TG_HOST, TG_GRAPHNAME, TG_USERNAME, TG_PASSWORD
or TG_API_TOKEN, TG_TGCLOUD). `--map` binds a local CSV to a DEFINE FILENAME
tag in the loading job; repeat for every tag the job defines:

    python scripts/graph_load.py --steps schema,job
    python scripts/graph_load.py --steps queries
    python scripts/graph_load.py --steps load \\
        --map f_txn=transactions.csv --map f_cases=closed_cases_history.csv
    python scripts/graph_load.py --steps verify

Re-running a step is safe: schema/job CREATEs overwrite, INSTALL overwrites,
and `load` skips chunks listed in each tag's done.txt. See docs/DEPLOY.md §5.
"""

from __future__ import annotations

import argparse
import os
import re
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
GRAPH = REPO / "graph"

STEP_ORDER = ("schema", "job", "queries", "load", "verify")


# ------------------------------------------------------------------ env/auth
def load_env() -> dict[str, str]:
    env = dict(os.environ)
    dot = REPO / ".env"
    if dot.exists():
        for line in dot.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            env.setdefault(k.strip(), v.strip().strip("'\""))
    return env


def connect(env: dict[str, str]):
    try:
        import pyTigerGraph as tg
    except ImportError:
        sys.exit("pyTigerGraph is not installed — run: pip install -e \".[tigergraph]\"")
    host = env.get("TG_HOST", "")
    if not host:
        sys.exit("TG_HOST is not set — fill .env (docs/DEPLOY.md §3).")
    if "://" not in host:
        host = "https://" + host
    graph = env.get("TG_GRAPHNAME", "Anvesh")
    token = env.get("TG_API_TOKEN", "")
    kwargs: dict = dict(host=host.rstrip("/"), graphname=graph,
                        tgCloud=env.get("TG_TGCLOUD", "true").lower() == "true")
    if token:
        kwargs["apiToken"] = token
        auth = "api token"
    else:
        kwargs["username"] = env.get("TG_USERNAME", "tigergraph")
        kwargs["password"] = env.get("TG_PASSWORD", "")
        if not kwargs["password"]:
            sys.exit("Set TG_API_TOKEN or TG_PASSWORD in .env (docs/DEPLOY.md §3).")
        auth = f"password for user '{kwargs['username']}'"
    print(f"[connect] {host} graph={graph} tgCloud={kwargs['tgCloud']} auth={auth}")
    try:
        conn = tg.TigerGraphConnection(**kwargs)
    except Exception as e:
        sys.exit(f"connection failed: {e}\n"
                 "If the instance just woke up, wait 2-3 min and retry (docs/DEPLOY.md §A).")
    return conn, graph


# ------------------------------------------------------------------ gsql steps
def run_gsql(conn, text: str, label: str, graphname: str | None) -> str:
    # The /gsql/v1/statements endpoint rejects '--' comment lines (parse
    # error at the first dash), so strip them client-side. On-disk files
    # keep their comments. (All non-ASCII bytes live in those comment
    # lines, so the stripped text is pure ASCII on every platform.)
    text = "\n".join(
        ln for ln in text.splitlines() if not ln.lstrip().startswith("--"))
    try:
        out = conn.gsql(text, graphname=graphname)
    except Exception as e:
        raise RuntimeError(f"{label} FAILED:\n{e}")
    out = out if isinstance(out, str) else str(out)
    low = out.lower()
    # Query installation summary reports 'failed: 0' on success; do not false-positive on 'failed'.
    if "query installation finished" in low and "failed: 0" in low:
        print(f"[ok] {label}")
        return out
    # Query creation reports 'Successfully created queries: [...]' on success.
    if "successfully created queries" in low:
        print(f"[ok] {label}")
        return out
    chk = low.replace("error margin", "").replace("failed: 0", "")
    if any(p in chk for p in ("error", "failed", "encountered",
                              "semantic error", "semantic check fails",
                              "syntax error", "invalid syntax",
                              "permission", "privilege",
                              "could not be created", "does not exist",
                              "is not a valid")):
        print(f"----- server output for {label} -----")
        print(out[:3000])
        print("----- end -----")
        raise RuntimeError(f"{label} reported an error (see above).")
    print(f"[ok] {label}")
    return out


def step_schema(conn) -> None:
    run_gsql(conn, (GRAPH / "schema.gsql").read_text(),
             "schema (vertices + edges + CREATE GRAPH)", None)


def parse_job(text: str) -> tuple[str, list[str]]:
    m = re.search(r"CREATE\s+LOADING\s+JOB\s+(\w+)", text, re.I)
    if not m:
        sys.exit("No CREATE LOADING JOB found in graph/loading_job.gsql")
    tags = re.findall(r"DEFINE\s+FILENAME\s+(\w+)", text, re.I)
    return m.group(1), tags


def step_job(conn) -> tuple[str, list[str]]:
    text = (GRAPH / "loading_job.gsql").read_text()
    job, tags = parse_job(text)
    # CREATE LOADING JOB needs a selected graph even with FOR GRAPH: each
    # submission runs in a fresh session with nothing selected.
    gm = re.search(r"FOR GRAPH (\w+)", text)
    assert gm, "no FOR GRAPH in loading_job.gsql — report this"
    text = f"USE GRAPH {gm.group(1)}\n" + text
    run_gsql(conn, text, f"loading job '{job}' (tags: {', '.join(tags)})", None)
    return job, tags


def step_queries(conn, graph: str) -> None:
    core = (GRAPH / "core_queries.gsql").read_text()
    names = re.findall(r"CREATE\s+QUERY\s+(\w+)", core, re.I)
    if not names:
        sys.exit("No CREATE QUERY found in graph/core_queries.gsql")
    print(f"[queries] {len(names)} queries: {', '.join(names)}")
    for n in names:
        f = GRAPH / f"q_{n}.gsql"
        if not f.exists():
            sys.exit(f"graph/q_{n}.gsql is missing — run `anvesh gsql-out` first.")
        try:
            conn.gsql(f"USE GRAPH {graph}\nDROP QUERY {n}", graphname=graph)
        except Exception:
            pass
        run_gsql(conn, f"USE GRAPH {graph}\n" + f.read_text(),
                 f"CREATE QUERY {n}", graph)
    failed = []
    for n in names:
        print(f"[install] INSTALL QUERY {n} ... (compiling, be patient)")
        try:
            run_gsql(conn, f"USE GRAPH {graph}\nINSTALL QUERY {n}",
                     f"INSTALL QUERY {n}", graph)
        except RuntimeError as e:
            print(str(e))
            failed.append(n)
    if failed:
        raise SystemExit(f"INSTALL failed for: {', '.join(failed)}\n"
                         "Fix the GSQL, re-run --steps queries (it overwrites). "
                         "Paste the server output to your assistant (docs/DEPLOY.md §A).")


# ------------------------------------------------------------------ loading
def split_headerless(src: Path, dest_dir: Path, chunk_mb: int) -> tuple[list[Path], str]:
    """Split src into <=chunk_mb headerless parts. Returns (parts, eol)."""
    raw = src.read_bytes().replace(b"\r\n", b"\n")  # normalize: loader expects \n
    eol = "\\n"
    lines = raw.split(b"\n")
    if lines and not lines[-1].strip():
        lines.pop()
    header, rows = lines[0], lines[1:]
    if not any(c.isalpha() for c in header.decode("utf-8", "replace")):
        print("[warn] first line has no letters — keeping it as data, not a header.")
        rows = lines
    else:
        print(f"[split] header: {header.decode('utf-8', 'replace')[:160]}")
    dest_dir.mkdir(parents=True, exist_ok=True)
    limit = chunk_mb * 1024 * 1024
    parts, buf, size, idx, nrows = [], [], 0, 0, 0
    for ln in rows:
        ln = ln + b"\n"
        buf.append(ln)
        size += len(ln)
        nrows += 1
        if size >= limit:
            p = dest_dir / f"{src.stem}.part{idx:02d}.csv"
            p.write_bytes(b"".join(buf))
            parts.append(p)
            buf, size, idx = [], 0, idx + 1
    if buf:
        p = dest_dir / f"{src.stem}.part{idx:02d}.csv"
        p.write_bytes(b"".join(buf))
        parts.append(p)
    print(f"[split] {src.name}: {nrows:,} rows -> {len(parts)} headerless part(s) in {dest_dir}")
    return parts, eol


def step_load(conn, args, job: str, tags: list[str]) -> None:
    if not args.map:
        sys.exit("--steps load needs at least one --map TAG=file.csv "
                 f"(job '{job}' defines: {', '.join(tags)})")
    mapping = {}
    for item in args.map:
        if "=" not in item:
            sys.exit(f"bad --map '{item}' — want TAG=file.csv")
        tag, rel = item.split("=", 1)
        if tag not in tags:
            sys.exit(f"tag '{tag}' is not a DEFINE FILENAME in the job "
                     f"(have: {', '.join(tags)})")
        mapping[tag] = args.data_dir / rel
    failures: list[str] = []
    for tag, src in mapping.items():
        if not src.exists():
            sys.exit(f"{src} does not exist.")
        dest = args.data_dir / "chunks" / tag
        parts = sorted(dest.glob("*.part*.csv")) if dest.exists() else []
        if parts and not args.rechunk:
            eol = "\\n"
            print(f"[split] reusing {len(parts)} existing part(s) in {dest} "
                  "(--rechunk to redo)")
        else:
            parts, eol = split_headerless(src, dest, args.chunk_mb)
        done_file = dest / "done.txt"
        done = set(done_file.read_text().split()) if done_file.exists() else set()
        for p in parts:
            if p.name in done:
                print(f"[load] {tag}/{p.name} already loaded — skipping")
                continue
            print(f"[load] {tag}/{p.name} ({p.stat().st_size / 1e6:.1f} MB) ...")
            try:
                res = conn.runLoadingJobWithFile(str(p), tag, job,
                                                 timeout=args.timeout_ms)
                print(f"       -> {str(res)[:220]}")
            except Exception as e:
                print(f"       FAILED: {str(e)[:500]}")
                failures.append(f"{tag}/{p.name}")
                continue
            with done_file.open("a") as fh:
                fh.write(p.name + "\n")
    if failures:
        raise SystemExit("these parts FAILED (everything else is recorded in done.txt; "
                         "fix the cause and re-run --steps load):\n  " + "\n  ".join(failures))
    print("[load] all parts loaded.")


# ------------------------------------------------------------------ verify
EXPECT = (("Transaction", 590_742), ("ClosedCase", 5_565))


def step_verify(conn) -> None:
    try:
        counts = conn.getVertexCount(
            ["Transaction", "Card", "Customer", "ClosedCase", "DeviceProfile",
             "DeviceSignature", "EmailDomain", "BillingRegion", "BillingCountry",
             "ProductCode", "Pattern", "InvestigationCase"])
    except Exception as e:
        sys.exit(f"vertex counts failed: {e}")
    counts = counts if isinstance(counts, dict) else {"*": counts}
    bad = []
    for vtype, n in counts.items():
        mark = ""
        for want_type, want_n in EXPECT:
            if vtype == want_type and n != want_n:
                mark = f"  <-- expected {want_n:,}"
                bad.append(vtype)
        print(f"  {vtype:<18} {n:>10,}{mark}")
    if bad:
        raise SystemExit(f"count mismatch on {', '.join(bad)} — the load is incomplete. "
                         "Check done.txt files and loading-job errors, then re-run load.")
    print("[verify] counts match.")


# ------------------------------------------------------------------ main
def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--steps", default="all",
                    help="comma list of: schema,job,queries,load,verify (default: all)")
    ap.add_argument("--data-dir", type=Path, default=REPO / "data" / "HHGOA_IEEE")
    ap.add_argument("--map", action="append", default=[],
                    help="TAG=file.csv inside --data-dir (repeatable)")
    ap.add_argument("--chunk-mb", type=int, default=64)
    ap.add_argument("--rechunk", action="store_true")
    ap.add_argument("--timeout-ms", type=int, default=0)
    args = ap.parse_args()

    steps = [s.strip() for s in args.steps.split(",")]
    if steps == ["all"]:
        steps = list(STEP_ORDER)
    for s in steps:
        if s not in STEP_ORDER:
            sys.exit(f"unknown step '{s}' (want: {', '.join(STEP_ORDER)})")

    conn, graph = connect(load_env())
    job = tags = None
    if "job" in steps or "load" in steps:
        job, tags = parse_job((GRAPH / "loading_job.gsql").read_text())
        print(f"[job] '{job}' defines tags: {', '.join(tags)}")
    try:
        if "schema" in steps:
            step_schema(conn)
        if "job" in steps:
            step_job(conn)
        if "queries" in steps:
            step_queries(conn, graph)
        if "load" in steps:
            assert job and tags
            step_load(conn, args, job, tags)
        if "verify" in steps:
            step_verify(conn)
    except RuntimeError as e:
        sys.exit(str(e))
    print("\nDone.")


if __name__ == "__main__":
    main()