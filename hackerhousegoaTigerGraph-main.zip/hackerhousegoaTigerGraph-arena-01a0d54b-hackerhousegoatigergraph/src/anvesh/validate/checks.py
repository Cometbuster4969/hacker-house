"""The 15 answer-file checks — docs/ANSWER_SCHEMA.md §7.

Errors block the freeze. Warnings are reported but do not block.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from ..config import (
    NARRATIVE_MAX_SENTENCES,
    NARRATIVE_MIN_SENTENCES,
    SUMMARY_MAX_SENTENCES,
    SUMMARY_MIN_SENTENCES,
)
from ..domain.enums import Action, Route
from ..policy.actions import route_for
from ..util.ids import IdRegistry, count_sentences

TOP_LEVEL = {"case_id", "case", "evidence_requests", "next_best_actions",
             "sar", "stop_reason", "tool_calls", "tokens", "latency_s"}

CASE_FIELDS = {
    "status", "verdict", "fraud_probability", "pattern", "pattern_description",
    "affected_txn_ids", "first_suspicious_txn_id", "connected_card_ids",
    "connected_device_profiles", "exposure_usd", "evidence", "similar_prior_cases",
    "summary", "written_to_graph", "graph_case_id",
}

STATUSES = {"open", "closed_fraud", "closed_legitimate", "escalated"}
VERDICTS = {"fraud", "legitimate", "uncertain"}
PATTERNS = {"card_testing", "card_not_present_fraud", "card_not_present_new_device",
            "out_of_region_use", "account_takeover", "undocumented", "none"}
REQUEST_TYPES = {"customer_validation", "step_up_auth", "analyst_info"}


@dataclass
class Report:
    case_id: str = ""
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return not self.errors


def validate(answer: dict, registry: IdRegistry) -> Report:
    rep = Report(case_id=str(answer.get("case_id", "<unknown>")))

    # 1 — schema -----------------------------------------------------------
    missing_top = TOP_LEVEL - set(answer)
    if missing_top:
        rep.errors.append(f"[1] missing top-level fields: {sorted(missing_top)}")
    case = answer.get("case") or {}
    if not isinstance(case, dict):
        rep.errors.append("[1] `case` is not an object")
        return rep
    missing_case = CASE_FIELDS - set(case)
    if missing_case:
        rep.errors.append(f"[1] missing case fields: {sorted(missing_case)}")

    if case.get("status") not in STATUSES:
        rep.errors.append(f"[1] bad status: {case.get('status')!r}")
    if case.get("verdict") not in VERDICTS:
        rep.errors.append(f"[1] bad verdict: {case.get('verdict')!r}")
    if case.get("pattern") not in PATTERNS:
        rep.errors.append(f"[1] bad pattern: {case.get('pattern')!r}")

    p = case.get("fraud_probability")
    if not isinstance(p, (int, float)) or not (0.0 <= float(p) <= 1.0):
        rep.errors.append(f"[1] fraud_probability out of range: {p!r}")

    for r in answer.get("evidence_requests") or []:
        if r.get("type") not in REQUEST_TYPES:
            rep.errors.append(f"[1] bad evidence request type: {r.get('type')!r}")

    # 2 — every ID exists (hard fail, no repair) ---------------------------
    ids: list[str] = []
    ids += case.get("affected_txn_ids") or []
    ids += case.get("connected_card_ids") or []
    ids += case.get("connected_device_profiles") or []
    ids += case.get("similar_prior_cases") or []
    if case.get("first_suspicious_txn_id"):
        ids.append(case["first_suspicious_txn_id"])
    for e in case.get("evidence") or []:
        ids += e.get("entity_ids") or []
    for s in (answer.get("sar") or {}).get("subjects") or []:
        ids.append(s)

    unknown = registry.unknown(ids)
    if unknown:
        rep.errors.append(f"[2] IDs not present in the dataset: {unknown[:10]}"
                          f"{' …' if len(unknown) > 10 else ''}")

    # 3 — exposure arithmetic ---------------------------------------------
    exposure = case.get("exposure_usd")
    affected = case.get("affected_txn_ids") or []
    if isinstance(exposure, (int, float)) and affected is not None:
        # The answer file does not carry amounts, so compare against the
        # caller-provided expected value if present.
        expected = answer.get("_expected_exposure_usd")
        if expected is not None and abs(float(exposure) - float(expected)) > 0.01:
            rep.errors.append(
                f"[3] exposure_usd {exposure} != sum(|amount|) {expected}")
        if float(exposure) < 0:
            rep.errors.append(f"[3] negative exposure: {exposure}")

    # 4 — sar.file <=> FILE_REPORT in final --------------------------------
    sar = answer.get("sar") or {}
    nba = answer.get("next_best_actions") or {}
    final = nba.get("final") or []
    final_actions = {a.get("action") for a in final}
    if bool(sar.get("file")) != (Action.FILE_REPORT.value in final_actions):
        rep.errors.append(
            f"[4] sar.file={sar.get('file')} but FILE_REPORT in final="
            f"{Action.FILE_REPORT.value in final_actions}")

    # 5 — sar.file false => empties ----------------------------------------
    if not sar.get("file"):
        if (sar.get("narrative") or "").strip():
            rep.errors.append("[5] sar.file is false but narrative is non-empty")
        if sar.get("subjects"):
            rep.errors.append("[5] sar.file is false but subjects is non-empty")
        if float(sar.get("total_amount_usd") or 0) != 0:
            rep.errors.append("[5] sar.file is false but total_amount_usd != 0")
        if sar.get("activity_dates"):
            rep.errors.append("[5] sar.file is false but activity_dates is non-empty")

    # 6 — legitimate invariants -------------------------------------------
    if case.get("verdict") == "legitimate":
        if affected:
            rep.errors.append("[6] legitimate verdict but affected_txn_ids is non-empty")
        if float(exposure or 0) != 0:
            rep.errors.append("[6] legitimate verdict but exposure_usd != 0")
        if sar.get("file"):
            rep.errors.append("[6] legitimate verdict but sar.file is true")

    # 7 — undocumented <=> description -------------------------------------
    desc = (case.get("pattern_description") or "").strip()
    if case.get("pattern") == "undocumented" and not desc:
        rep.errors.append("[7] pattern=undocumented requires pattern_description")
    if case.get("pattern") != "undocumented" and desc:
        rep.errors.append("[7] pattern_description must be empty unless undocumented")

    # 8 — legal actions -----------------------------------------------------
    legal = {a.value for a in Action}
    for bucket in ("initial", "final"):
        for a in nba.get(bucket) or []:
            if a.get("action") not in legal:
                rep.errors.append(f"[8] illegal action in {bucket}: {a.get('action')!r}")

    # 9 — routes match the routing table -----------------------------------
    for bucket in ("initial", "final"):
        for a in nba.get(bucket) or []:
            try:
                want = route_for(Action(a["action"]), float(exposure or 0)).value
            except Exception:
                continue
            if a.get("route") != want:
                rep.errors.append(
                    f"[9] {bucket}.{a.get('action')} route={a.get('route')} "
                    f"but table says {want} at exposure {exposure}")

    # 10 — every action cites a rule ---------------------------------------
    for bucket in ("initial", "final"):
        for a in nba.get(bucket) or []:
            reason = a.get("reason") or ""
            if "R" not in reason and "§" not in reason:
                rep.errors.append(
                    f"[10] {bucket}.{a.get('action')} has no rule citation: {reason!r}")

    # 11 — summary length (warning) ----------------------------------------
    n = count_sentences(case.get("summary") or "")
    if not (SUMMARY_MIN_SENTENCES <= n <= SUMMARY_MAX_SENTENCES):
        rep.warnings.append(f"[11] summary has {n} sentences (want "
                            f"{SUMMARY_MIN_SENTENCES}-{SUMMARY_MAX_SENTENCES})")

    # 12 — narrative length (warning) --------------------------------------
    if sar.get("file"):
        n = count_sentences(sar.get("narrative") or "")
        if not (NARRATIVE_MIN_SENTENCES <= n <= NARRATIVE_MAX_SENTENCES):
            rep.warnings.append(f"[12] SAR narrative has {n} sentences (want "
                                f"{NARRATIVE_MIN_SENTENCES}-{NARRATIVE_MAX_SENTENCES})")
        if len(sar.get("activity_dates") or []) != 2:
            rep.warnings.append("[12] SAR activity_dates should have exactly 2 entries")

    # 13 — evidence has source + ref (error) --------------------------------
    for i, e in enumerate(case.get("evidence") or []):
        if not e.get("source"):
            rep.errors.append(f"[13] evidence[{i}] missing source")
        if not e.get("ref"):
            rep.errors.append(f"[13] evidence[{i}] missing ref")

    # 14 — initial/final present, what_changed non-empty --------------------
    if not isinstance(nba.get("initial"), list):
        rep.errors.append("[14] next_best_actions.initial missing")
    if not isinstance(nba.get("final"), list):
        rep.errors.append("[14] next_best_actions.final missing")
    if not (nba.get("what_changed") or "").strip():
        rep.errors.append("[14] what_changed is empty")

    # 15 — telemetry (warning) ----------------------------------------------
    for k in ("tool_calls", "tokens", "latency_s"):
        if answer.get(k) is None:
            rep.warnings.append(f"[15] {k} not populated")

    return rep


def validate_all(answers: list[dict], registry: IdRegistry) -> list[Report]:
    return [validate(a, registry) for a in answers]
