"""Domain models. Plain dataclasses — no I/O, no framework coupling."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from .enums import (
    Action,
    CaseStatus,
    Channel,
    EvidenceAxis,
    EvidenceRequestType,
    EvidenceSource,
    Pattern,
    ResponseKind,
    Route,
    TriggerType,
    Verdict,
)


# ---------------------------------------------------------------------------
# Graph entities
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Txn:
    txn_id: str
    ts: datetime
    amount: float
    card_id: str
    customer_id: str
    product_cd: str
    channel: Channel
    risk_score: float
    region: str | None = None
    country: str | None = None
    device_id: str | None = None        # None for in-person. Always.
    device_new: bool = False
    proxy: str | None = None
    p_email: str | None = None
    r_email: str | None = None
    v_anom: float = 0.0                 # model residual
    m_flags: int = 0


@dataclass(frozen=True)
class Card:
    card_id: str
    customer_id: str


@dataclass(frozen=True)
class ClosedCase:
    case_id: str
    customer_id: str
    card_id: str
    opened_at: datetime
    closed_at: datetime | None
    outcome: str                        # confirmed_fraud | cleared
    pattern: str
    first_fraud_txn_id: str | None
    txn_ids: list[str] = field(default_factory=list)
    n_txns: int = 0
    exposure_usd: float = 0.0
    connected_card_ids: list[str] = field(default_factory=list)
    actions_taken: list[str] = field(default_factory=list)
    report_filed: bool = False
    analyst_notes: str = ""


@dataclass(frozen=True)
class CasePackRow:
    case_id: str
    opened_at: datetime
    trigger_type: TriggerType
    trigger_text: str
    flagged_txn_id: str
    card_id: str
    customer_id: str
    risk_score: float | None = None


# ---------------------------------------------------------------------------
# Baseline / context
# ---------------------------------------------------------------------------

@dataclass
class Baseline:
    """Cardholder baseline over [as_of - days, as_of] only. Never the full history."""

    amount_mean: float = 0.0
    amount_std: float = 1.0
    product_hist: dict[str, int] = field(default_factory=dict)
    region_hist: dict[str, int] = field(default_factory=dict)
    device_hist: dict[str, int] = field(default_factory=dict)
    channel_hist: dict[str, int] = field(default_factory=dict)
    n_txns: int = 0

    def amount_z(self, amount: float) -> float:
        if self.amount_std <= 0:
            return 0.0
        return (amount - self.amount_mean) / self.amount_std

    def product_novelty(self, product_cd: str) -> float:
        if not self.product_hist:
            return 0.0
        return 1.0 if product_cd not in self.product_hist else 0.0

    def region_novelty(self, region: str | None) -> float:
        if region is None or not self.region_hist:
            return 0.0
        return 1.0 if region not in self.region_hist else 0.0

    def device_novelty(self, device_id: str | None) -> float:
        if device_id is None or not self.device_hist:
            return 0.0
        return 1.0 if device_id not in self.device_hist else 0.0


@dataclass
class GeoPair:
    from_txn: str
    to_txn: str
    from_region: str | None
    to_region: str | None
    minutes: float


@dataclass
class RingInfo:
    cluster_id: str
    size: int
    card_ids: list[str] = field(default_factory=list)
    shared_element: str = ""


@dataclass
class SharedOrigin:
    kind: str                            # device | region | email
    element: str
    card_ids: list[str] = field(default_factory=list)


@dataclass
class EvidenceContext:
    """Everything a detector may look at. Always as_of-bounded, never re-queried."""

    as_of: datetime
    flagged_txn_id: str
    card_id: str
    customer_id: str
    channel: Channel
    flagged: Txn | None = None
    window_txns: list[Txn] = field(default_factory=list)     # card window, ts <= as_of
    baseline: Baseline = field(default_factory=Baseline)
    geo_pairs: list[GeoPair] = field(default_factory=list)
    device_cards: list[str] = field(default_factory=list)    # other cards on this device
    device_closed_cases: list[str] = field(default_factory=list)
    region_cards: list[str] = field(default_factory=list)
    email_cards: list[str] = field(default_factory=list)
    ring: RingInfo | None = None
    customer_cards: list[str] = field(default_factory=list)
    similar_cases: list[str] = field(default_factory=list)
    doc_refs: list[str] = field(default_factory=list)

    @property
    def has_device(self) -> bool:
        """False for in-person transactions, always. Guards R5 of AGENTS.md."""
        return self.channel == Channel.ONLINE and self.flagged is not None \
            and self.flagged.device_id is not None


# ---------------------------------------------------------------------------
# Investigation artifacts
# ---------------------------------------------------------------------------

@dataclass
class Evidence:
    claim: str
    source: EvidenceSource
    ref: str
    entity_ids: list[str] = field(default_factory=list)
    axis: EvidenceAxis = EvidenceAxis.GRAPH
    weight: float = 1.0


@dataclass
class Hypothesis:
    pattern: Pattern
    rationale: str
    probes: list[str] = field(default_factory=list)   # query names this needs
    prior: float = 0.5


@dataclass
class ToolCall:
    query: str
    params: dict[str, Any]
    for_hypothesis: Pattern | None = None


@dataclass
class RejectedTool:
    query: str
    reason: str
    """Logged to the trace. The clearest evidence that the agent chooses."""


@dataclass
class EvidenceRequest:
    type: EvidenceRequestType
    asked_after_step: int
    assumed_response: str


@dataclass
class SimulatedResponse:
    request_type: EvidenceRequestType
    kind: ResponseKind
    text: str


@dataclass
class ActionRef:
    action: Action
    reason: str                            # MUST cite a rule number
    route: Route | None = None
    """Filled in by the policy engine once exposure is known — never by the rules
    and never by the LLM (docs/POLICY.md §2)."""


@dataclass
class SAR:
    file: bool = False
    reason: str = ""
    narrative: str = ""
    subjects: list[str] = field(default_factory=list)
    total_amount_usd: float = 0.0
    activity_dates: list[str] = field(default_factory=list)


@dataclass
class Episode:
    txn_ids: list[str] = field(default_factory=list)
    first_suspicious_txn_id: str = ""
    exposure_usd: float = 0.0


@dataclass
class PolicyFlags:
    """The state the policy engine reads. Nothing else."""

    channel: Channel = Channel.ONLINE
    response: ResponseKind = ResponseKind.NONE
    disputed: bool = False
    shared_origin: bool = False
    shared_element: str = ""
    in_ring: bool = False
    ring_size: int = 0
    is_recurring: bool = False
    cross_customer: bool = False
    conflicting_evidence: bool = False
    cards_confirmed_fraud: int = 0
    credentials_compromised: bool = False
    max_cleared_purchase: float = 0.0
    testing_sequence: bool = False


@dataclass
class Decision:
    actions: list[ActionRef] = field(default_factory=list)
    open_case: bool = False
    file_sar: bool = False
    stop_reason: str = ""
    verdict: Verdict = Verdict.UNCERTAIN
    suppressed: list[str] = field(default_factory=list)
    """Actions considered and withheld, with the rule that withheld them."""


@dataclass
class TraceEvent:
    seq: int
    node: str
    kind: str                              # tool_call | tool_rejected | assessment | ...
    detail: dict[str, Any] = field(default_factory=dict)
