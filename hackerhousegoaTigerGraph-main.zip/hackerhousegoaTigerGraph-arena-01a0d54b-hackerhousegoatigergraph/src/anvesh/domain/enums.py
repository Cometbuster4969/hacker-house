"""Enumerations. Every closed value set in the system lives here."""

from __future__ import annotations

from enum import Enum


class TriggerType(str, Enum):
    RISK_SCORE = "risk_score"
    CUSTOMER_REPORT = "customer_report"
    ANALYST_REQUEST = "analyst_request"


class Verdict(str, Enum):
    FRAUD = "fraud"
    LEGITIMATE = "legitimate"
    UNCERTAIN = "uncertain"


class CaseStatus(str, Enum):
    OPEN = "open"
    CLOSED_FRAUD = "closed_fraud"
    CLOSED_LEGITIMATE = "closed_legitimate"
    ESCALATED = "escalated"


class Pattern(str, Enum):
    CARD_TESTING = "card_testing"
    CARD_NOT_PRESENT_FRAUD = "card_not_present_fraud"
    CARD_NOT_PRESENT_NEW_DEVICE = "card_not_present_new_device"
    OUT_OF_REGION_USE = "out_of_region_use"
    ACCOUNT_TAKEOVER = "account_takeover"
    UNDOCUMENTED = "undocumented"
    NONE = "none"


KNOWN_PATTERNS = frozenset({
    Pattern.CARD_TESTING,
    Pattern.CARD_NOT_PRESENT_FRAUD,
    Pattern.CARD_NOT_PRESENT_NEW_DEVICE,
    Pattern.OUT_OF_REGION_USE,
    Pattern.ACCOUNT_TAKEOVER,
})


class Action(str, Enum):
    """The 14 legal actions (docs/POLICY.md §1)."""

    ALLOW_TRANSACTION = "ALLOW_TRANSACTION"
    DECLINE_TRANSACTION = "DECLINE_TRANSACTION"
    MONITOR_CARD = "MONITOR_CARD"
    MONITOR_CONNECTED_CARDS = "MONITOR_CONNECTED_CARDS"
    WARN_CUSTOMER = "WARN_CUSTOMER"
    VERIFY_WITH_CUSTOMER = "VERIFY_WITH_CUSTOMER"
    STEP_UP_AUTH = "STEP_UP_AUTH"
    BLOCK_CARD = "BLOCK_CARD"
    BLOCK_ALL_CARDS = "BLOCK_ALL_CARDS"
    GENERATE_REPORT = "GENERATE_REPORT"
    CREATE_CASE = "CREATE_CASE"
    FILE_REPORT = "FILE_REPORT"
    ESCALATE_TO_ANALYST = "ESCALATE_TO_ANALYST"
    CLOSE_NO_FRAUD = "CLOSE_NO_FRAUD"


class Route(str, Enum):
    AUTO = "auto"
    L1 = "L1"
    L2 = "L2"


class EvidenceSource(str, Enum):
    GRAPH = "graph"
    DOCUMENT = "document"
    CUSTOMER = "customer"
    EXTERNAL = "external"


class EvidenceAxis(str, Enum):
    """Independence classes. Two evidences are independent iff their axes differ."""

    VELOCITY = "velocity"
    AMOUNT = "amount"
    DEVICE = "device"
    GEOGRAPHY = "geography"
    CHANNEL = "channel"
    MODEL_RESIDUAL = "model_residual"
    GRAPH = "graph"
    MEMORY = "memory"


class EvidenceRequestType(str, Enum):
    CUSTOMER_VALIDATION = "customer_validation"
    STEP_UP_AUTH = "step_up_auth"
    ANALYST_INFO = "analyst_info"


class ResponseKind(str, Enum):
    NONE = "none"
    DENIED = "denied"
    CONFIRMED = "confirmed"
    NO_REPLY = "no_reply"


class Channel(str, Enum):
    ONLINE = "online"
    IN_PERSON = "in_person"


class Outcome(str, Enum):
    CONFIRMED_FRAUD = "confirmed_fraud"
    CLEARED = "cleared"
