"""Synthetic dataset generator.

Mirrors the HHGOA_IEEE schema exactly (docs/SETUP.md) so the full pipeline can
be built, tested and demonstrated before the real 708 MB dataset is available.

NOT a substitute for the real data. Every ID it produces is synthetic and will
fail validator check #2 against the real dataset — by design.

Planted scenarios:
  1. card_testing        2. card_not_present_fraud     3. card_not_present_new_device
  4. out_of_region_use   5. account_takeover           6. device ring (R6/R9)
  7. recurring dispute (R7)                            8. clean / legitimate
"""

from __future__ import annotations

import random
from dataclasses import dataclass
from datetime import datetime, timedelta

from ..domain.enums import Channel, Outcome, Pattern, TriggerType
from ..domain.models import CasePackRow, ClosedCase, Txn

START = datetime(2016, 7, 2)
END = datetime(2016, 12, 31)
PRODUCTS_ONLINE = ["C", "H", "R", "S"]
PRODUCTS_IN_PERSON = ["W"]
REGIONS = [str(r) for r in (101, 204, 264, 318, 350, 444, 494)]
EMAILS = ["gmail.com", "yahoo.com", "outlook.com", "hotmail.com", "icloud.com"]


def _build_devices(n: int = 140) -> list[tuple[str, str, str, str]]:
    """40 device profiles.

    Deliberately diverse: with only a handful of profiles every card shares a
    device, the shared-origin detector fires on everything and the device signal
    carries no information (exactly the failure this generator must not bake in).
    """
    base = [
        ("SAMSUNG SM-G935F Build/NRD90M", "Android 7.0", "chrome", "1440x2560"),
        ("iPhone 9,3", "iOS 11.2", "safari", "750x1334"),
        ("LG-H840 Build/NRD90U", "Android 7.1", "chrome", "1080x1920"),
        ("SM-J710F Build/NRD90M", "Android 7.0", "samsung browser", "720x1280"),
        ("Moto G (5) Plus", "Android 8.0", "chrome", "1080x1920"),
    ]
    rnd = random.Random(99)
    models = ["SM-G955N", "Pixel 2", "HUAWEI P10", "Xperia XZ", "iPhone 10,3",
              "Nexus 6P", "LG-K500", "SM-A520F", "Redmi Note 4", "HTC U11"]
    while len(base) < n:
        base.append((
            f"{rnd.choice(models)} Build/{rnd.choice(['NRD90M', 'NRD90U', 'OPR6'])}",
            rnd.choice(["Android 7.0", "Android 8.0", "iOS 11.2", "iOS 12.0"]),
            rnd.choice(["chrome", "safari", "samsung browser", "firefox"]),
            rnd.choice(["1440x2560", "750x1334", "1080x1920", "720x1280", "1080x2340"]),
        ))
    return base


DEVICES = _build_devices(140)
N_CUSTOMER_SLOTS = 70          # 0..69 primary, 70..139 secondary ('new device')
RING_DEVICE_IDX = len(DEVICES) - 1          # reserved: the only truly shared device


def _other_device(idx: int) -> int:
    """A device this customer has never used — for new-device scenarios.

    Offset by N_CUSTOMER_SLOTS so it is unique per customer. A collision here
    puts unrelated cards in one connected component and destroys the ring signal.
    """
    return idx + N_CUSTOMER_SLOTS


def _device_id(idx: int) -> str:
    return f"D{idx:06d}"


@dataclass
class SynthData:
    txns: list[Txn]
    closed_cases: list[ClosedCase]
    case_pack: list[CasePackRow]
    scenario_of: dict[str, str]          # case_id -> scenario name (test labels)


def _mk_txn(rng: random.Random, txn_id: str, ts: datetime, card_id: str,
            customer_id: str, amount: float, channel: Channel,
            product: str, region: str, device_id: str | None = None,
            device_new: bool = False, proxy: str | None = None,
            risk: float | None = None, v_anom: float | None = None,
            m_flags: int = 0) -> Txn:
    return Txn(
        txn_id=txn_id,
        ts=ts,
        amount=round(float(amount), 2),
        card_id=card_id,
        customer_id=customer_id,
        product_cd=product,
        channel=channel,
        risk_score=round(risk if risk is not None else rng.betavariate(1.5, 6) * 0.9, 3),
        region=region,
        country="87",
        device_id=device_id if channel is Channel.ONLINE else None,   # CHANNEL GUARD
        device_new=device_new,
        proxy=proxy,
        p_email=rng.choice(EMAILS) if channel is Channel.ONLINE else None,
        r_email=rng.choice(EMAILS) if (channel is Channel.ONLINE and rng.random() < 0.24) else None,
        v_anom=round(v_anom if v_anom is not None else min(1.0, abs(rng.gauss(0.25, 0.2))), 4),
        m_flags=m_flags,
    )


class _Gen:
    def __init__(self, seed: int = 20260924):
        self.rng = random.Random(seed)
        self.txns: list[Txn] = []
        self.n = 0

    def _next_id(self) -> str:
        self.n += 1
        return f"T{3_400_000 + self.n}"

    def add(self, **kw) -> Txn:
        t = _mk_txn(self.rng, txn_id=self._next_id(), **kw)
        self.txns.append(t)
        return t

    # ---- background activity -------------------------------------------
    def background(self, card_id: str, customer_id: str, home_region: str,
                   device_idx: int, days: int = 180, rate: float = 0.35) -> None:
        ts = START + timedelta(days=self.rng.uniform(0, 30))
        while ts < END:
            online = self.rng.random() < 0.45
            self.add(
                ts=ts, card_id=card_id, customer_id=customer_id,
                amount=round(abs(self.rng.gauss(60, 40)) + 3, 2),
                channel=Channel.ONLINE if online else Channel.IN_PERSON,
                product=self.rng.choice(PRODUCTS_ONLINE) if online else "W",
                region=home_region,
                device_id=_device_id(device_idx) if online else None,
                v_anom=round(min(1.0, abs(self.rng.gauss(0.2, 0.15))), 4),
            )
            ts += timedelta(days=max(0.4, self.rng.expovariate(rate)))

    # ---- planted scenarios ---------------------------------------------
    def card_testing(self, card_id: str, customer_id: str, region: str,
                     device_idx: int, at: datetime) -> list[str]:
        """3-4 sub-$5 online auths within an hour, then a larger purchase."""
        ids = []
        for i in range(4):
            ids.append(self.add(
                ts=at + timedelta(minutes=5 + i * 9), card_id=card_id,
                customer_id=customer_id, amount=round(self.rng.uniform(0.5, 4.5), 2),
                channel=Channel.ONLINE, product=self.rng.choice(PRODUCTS_ONLINE),
                region=region, device_id=_device_id(device_idx), device_new=True,
                risk=round(self.rng.uniform(0.45, 0.7), 3),
                v_anom=round(self.rng.uniform(0.4, 0.7), 4)).txn_id)
        big = self.add(
            ts=at + timedelta(minutes=52), card_id=card_id, customer_id=customer_id,
            amount=round(self.rng.uniform(180, 320), 2), channel=Channel.ONLINE,
            product=self.rng.choice(PRODUCTS_ONLINE), region=region,
            device_id=_device_id(device_idx), device_new=True,
            risk=round(self.rng.uniform(0.6, 0.85), 3),
            v_anom=round(self.rng.uniform(0.6, 0.9), 4))
        ids.append(big.txn_id)
        return ids

    def cnp(self, card_id: str, customer_id: str, region: str, device_idx: int,
            at: datetime, new_device: bool = False, proxy: str | None = None) -> list[str]:
        ids = []
        for i in range(self.rng.randint(2, 4)):
            ids.append(self.add(
                ts=at + timedelta(hours=i * 9), card_id=card_id, customer_id=customer_id,
                amount=round(self.rng.uniform(150, 650), 2), channel=Channel.ONLINE,
                product=self.rng.choice(PRODUCTS_ONLINE), region=region,
                device_id=_device_id(device_idx), device_new=new_device, proxy=proxy,
                risk=round(self.rng.uniform(0.55, 0.9), 3),
                v_anom=round(self.rng.uniform(0.5, 0.95), 4)).txn_id)
        return ids

    def out_of_region(self, card_id: str, customer_id: str, home_region: str,
                      away_region: str, at: datetime) -> list[str]:
        """Clone: 1-2 days in a new region while home activity continues."""
        ids = []
        for i in range(3):
            ids.append(self.add(
                ts=at + timedelta(hours=i * 6), card_id=card_id, customer_id=customer_id,
                amount=round(self.rng.uniform(80, 400), 2), channel=Channel.IN_PERSON,
                product="W", region=away_region,
                risk=round(self.rng.uniform(0.6, 0.9), 3),
                v_anom=round(self.rng.uniform(0.5, 0.9), 4)).txn_id)
        # home activity continues -> the "trip or clone" discriminator
        self.add(ts=at + timedelta(hours=20), card_id=card_id, customer_id=customer_id,
                 amount=round(self.rng.uniform(30, 90), 2), channel=Channel.IN_PERSON,
                 product="W", region=home_region, risk=0.2, v_anom=0.15)
        return ids

    def ato(self, card_id: str, customer_id: str, region: str, device_idx: int,
            at: datetime) -> list[str]:
        ids = []
        ids.append(self.add(
            ts=at, card_id=card_id, customer_id=customer_id,
            amount=round(self.rng.uniform(200, 700), 2), channel=Channel.ONLINE,
            product=self.rng.choice(PRODUCTS_ONLINE), region=region,
            device_id=_device_id(device_idx), device_new=True, proxy="anonymous",
            risk=round(self.rng.uniform(0.7, 0.95), 3),
            v_anom=round(self.rng.uniform(0.7, 0.98), 4), m_flags=3).txn_id)
        ids.append(self.add(
            ts=at + timedelta(hours=7), card_id=card_id, customer_id=customer_id,
            amount=round(self.rng.uniform(150, 500), 2), channel=Channel.IN_PERSON,
            product="W", region=region,
            risk=round(self.rng.uniform(0.6, 0.9), 3),
            v_anom=round(self.rng.uniform(0.5, 0.9), 4), m_flags=2).txn_id)
        return ids

    def recurring(self, card_id: str, customer_id: str, region: str,
                  device_idx: int = 0) -> list[str]:
        """A monthly subscription the customer will later dispute (R7)."""
        ids, amount = [], 49.00
        for m in range(6):
            ids.append(self.add(
                ts=START + timedelta(days=15 + m * 30), card_id=card_id,
                customer_id=customer_id, amount=amount, channel=Channel.ONLINE,
                product="S", region=region, device_id=_device_id(0),
                risk=round(self.rng.uniform(0.05, 0.2), 3), v_anom=0.1).txn_id)
        return ids


def generate(n_customers: int = 60, seed: int = 20260924) -> SynthData:
    """Build a small, fully-labelled dataset with planted scenarios."""
    g = _Gen(seed)
    rng = g.rng
    scenario_of: dict[str, str] = {}
    closed_cases: list[ClosedCase] = []
    case_pack: list[CasePackRow] = []

    # ---------------------------------------------------------------- customers
    customers = [f"C{i:05d}" for i in range(1, n_customers + 1)]
    cards: dict[str, list[str]] = {}
    home_region: dict[str, str] = {}
    device_idx: dict[str, int] = {}
    for i, c in enumerate(customers):
        cards[c] = [f"{c}-K1"] + ([f"{c}-K2"] if rng.random() < 0.35 else [])
        home_region[c] = REGIONS[i % len(REGIONS)]
        # Every non-ring customer gets their own device profile.
        device_idx[c] = i

    for c in customers:
        for card in cards[c]:
            g.background(card, c, home_region[c], device_idx[c])

    # ---------------------------------------------------- closed cases (Jul-Oct)
    closed_start = datetime(2016, 7, 10)
    closed_end = datetime(2016, 10, 25)
    for i in range(120):
        c = rng.choice(customers)
        card = cards[c][0]
        at = closed_start + timedelta(days=rng.uniform(0, (closed_end - closed_start).days))
        fraud = rng.random() < 0.80
        if fraud:
            kind = rng.choice(["card_testing", "cnp", "cnp_new_device",
                               "out_of_region", "ato"])
            if kind == "card_testing":
                ids = g.card_testing(card, c, home_region[c], device_idx[c], at)
            elif kind == "cnp":
                ids = g.cnp(card, c, home_region[c], device_idx[c], at)
            elif kind == "cnp_new_device":
                ids = g.cnp(card, c, home_region[c], _other_device(device_idx[c]), at, new_device=True)
            elif kind == "out_of_region":
                away = rng.choice([r for r in REGIONS if r != home_region[c]])
                ids = g.out_of_region(card, c, home_region[c], away, at)
            else:
                ids = g.ato(card, c, home_region[c], _other_device(device_idx[c]), at)
        else:
            kind = "none"
            ids = [g.add(ts=at, card_id=card, customer_id=c,
                         amount=round(rng.uniform(20, 200), 2),
                         channel=Channel.ONLINE if rng.random() < 0.5 else Channel.IN_PERSON,
                         product=rng.choice(PRODUCTS_ONLINE + PRODUCTS_IN_PERSON),
                         region=home_region[c],
                         device_id=_device_id(device_idx[c]) if rng.random() < 0.5 else None,
                         risk=round(rng.uniform(0.4, 0.95), 3), v_anom=0.3).txn_id]

        exposure = round(sum(abs(t.amount) for t in g.txns if t.txn_id in set(ids)), 2)
        closed_cases.append(ClosedCase(
            case_id=f"CC-{i:04d}",
            customer_id=c, card_id=card,
            opened_at=at + timedelta(hours=2), closed_at=at + timedelta(days=2),
            outcome=Outcome.CONFIRMED_FRAUD.value if fraud else Outcome.CLEARED.value,
            pattern=kind if fraud else "none",
            first_fraud_txn_id=ids[0] if fraud else None,
            txn_ids=ids, n_txns=len(ids), exposure_usd=exposure,
            connected_card_ids=[], actions_taken=[], report_filed=fraud and exposure > 1000,
            analyst_notes=("Customer denied the transactions." if fraud
                           else "Customer confirmed the charge; false alarm."),
        ))

    # --------------------------------------- device ring across 5 customers (R6)
    ring_customers = customers[:5]
    ring_device = RING_DEVICE_IDX
    ring_at = datetime(2016, 11, 20, 12, 0)
    ring_cards = [cards[c][0] for c in ring_customers]
    ring_txns: list[str] = []
    for c in ring_customers:
        ring_txns += g.cnp(cards[c][0], c, home_region[c], ring_device,
                           ring_at + timedelta(hours=rng.uniform(0, 8)), new_device=True)

    # ------------------------------- recurring-dispute series (one per case, R7)
    # Each gets its own customer, card and device so the cases are genuinely
    # ------------------------------------------------------ the 20 benchmark cases
    plan: list[tuple[str, str]] = [
        ("card_testing", "risk_score"), ("cnp_new_device", "risk_score"),
        ("recurring", "customer_report"), ("cnp", "customer_report"),
        ("card_testing", "risk_score"), ("recurring", "customer_report"),
        ("out_of_region", "risk_score"), ("recurring", "customer_report"),
        ("recurring", "customer_report"), ("ato", "risk_score"),
        ("cnp", "customer_report"), ("out_of_region", "risk_score"),
        ("card_testing", "risk_score"), ("ring", "analyst_request"),
        ("cnp_new_device", "risk_score"), ("recurring", "customer_report"),
        ("card_testing", "risk_score"), ("recurring", "customer_report"),
        ("cnp_new_device", "risk_score"), ("cnp", "risk_score"),
    ]

    # independent rather than six identical pointers at one transaction.
    n_recurring = sum(1 for k, _ in plan if k == "recurring")
    recurring_series: list[tuple[str, str, str]] = []
    for j in range(n_recurring):
        c = customers[6 + j]
        card = cards[c][0]
        ids = g.recurring(card, c, home_region[c], device_idx[c])
        recurring_series.append((c, card, ids[-1]))
    rec_i = 0


    open_start = datetime(2016, 11, 5)
    open_end = datetime(2016, 12, 28)
    for i, (kind, trigger) in enumerate(plan, start=1):
        case_id = f"HHG-{i:03d}"
        at = open_start + timedelta(days=rng.uniform(0, (open_end - open_start).days))

        if kind == "ring":
            c = ring_customers[0]
            card = ring_cards[0]
            flagged = ring_txns[0]
        elif kind == "recurring":
            c, card, flagged = recurring_series[rec_i]
            rec_i += 1
        else:
            c = rng.choice(customers[6:])
            card = cards[c][0]
            if kind == "card_testing":
                flagged = g.card_testing(card, c, home_region[c], device_idx[c], at)[-1]
            elif kind == "cnp":
                flagged = g.cnp(card, c, home_region[c], device_idx[c], at)[-1]
            elif kind == "cnp_new_device":
                flagged = g.cnp(card, c, home_region[c], _other_device(device_idx[c]), at,
                                new_device=True, proxy="anonymous")[-1]
            elif kind == "out_of_region":
                away = rng.choice([r for r in REGIONS if r != home_region[c]])
                flagged = g.out_of_region(card, c, home_region[c], away, at)[1]
            else:  # ato
                flagged = g.ato(card, c, home_region[c], _other_device(device_idx[c]), at)[0]

        risk = round(rng.uniform(0.5, 0.95), 3) if trigger == "risk_score" else None
        opened_at = g.by_id_ts(flagged) + timedelta(minutes=rng.randint(20, 300))

        if trigger == "customer_report":
            amt = next((t.amount for t in g.txns if t.txn_id == flagged), 0.0)
            text = (f"Customer {c} message: 'I never made this ${amt:,.2f} purchase. "
                    f"Please check my card.' Refers to {flagged}.")
        elif trigger == "analyst_request":
            text = (f"Analyst request: several cards this month show purchases from the "
                    f"same unusual device profile. Review transaction {flagged} on card "
                    f"{card} and look for related activity.")
        else:
            text = (f"Real-time model scored transaction {flagged} at {risk}. "
                    f"Review and decide.")

        case_pack.append(CasePackRow(
            case_id=case_id, opened_at=opened_at,
            trigger_type=TriggerType(trigger), trigger_text=text,
            flagged_txn_id=flagged, card_id=card, customer_id=c, risk_score=risk,
        ))
        scenario_of[case_id] = kind

    # set the risk score on flagged transactions for risk_score triggers
    by_id = {t.txn_id: t for t in g.txns}
    for row in case_pack:
        if row.risk_score is not None and row.flagged_txn_id in by_id:
            object.__setattr__(by_id[row.flagged_txn_id], "risk_score", row.risk_score)

    return SynthData(txns=g.txns, closed_cases=closed_cases,
                     case_pack=case_pack, scenario_of=scenario_of)


def _patch_gen() -> None:
    """Give _Gen a timestamp lookup helper without touching the dataclass."""
    def by_id_ts(self, txn_id: str) -> datetime:
        for t in reversed(self.txns):
            if t.txn_id == txn_id:
                return t.ts
        return END

    _Gen.by_id_ts = by_id_ts


_patch_gen()
