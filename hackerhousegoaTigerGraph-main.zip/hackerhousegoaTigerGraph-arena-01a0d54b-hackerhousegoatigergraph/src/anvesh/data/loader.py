"""Load the real HHGOA_IEEE CSVs into domain objects.

Two modes:
  - full load  -> MemoryAdapter over real transactions (needs ~4 GB RAM;
                  the honest fallback when no TigerGraph is available)
  - id scan    -> IdRegistry only, chunked, for validator check #2 in
                  tigergraph mode (reads go to the graph; the registry just
                  needs to know which IDs exist)

Column handling is tolerant (many aliases, case-insensitive) but LOUD:
a missing required logical column raises LoaderError naming the column and
listing the headers actually found. Card/customer identity is configurable
via CARD_ID_FROM / CUSTOMER_ID_FROM (comma-separated header lists) because
the derivation lives in data/README.md, not in the code.

Validator fail-fast: case_pack card/customer/txn IDs must all exist in the
scanned registry, or the load stops with the mapping hint. A wrong card-ID
derivation must never silently produce zero-match investigations.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Iterator

import numpy as np
import pandas as pd

from ..domain.enums import Channel, TriggerType
from ..domain.models import CasePackRow, ClosedCase, Txn
from ..util.ids import IdRegistry

CHUNK = 100_000
TIME_ORIGIN = datetime(2016, 7, 1)   # numeric TransactionDT is seconds after this
V_ANOM_SAMPLE = 50_000
V_ANOM_SEED = 7


class LoaderError(RuntimeError):
    pass


# ------------------------------------------------------------------ columns

ALIASES: dict[str, list[str]] = {
    "txn_id": ["transnum", "transactionid", "transaction_id", "txn_id", "id"],
    "dt": ["transdatetranshour", "transdate", "transactiondt", "transaction_dt",
           "timestamp", "ts", "datetime", "date"],
    "amount": ["amount", "transactionamt", "transaction_amt"],
    "product": ["productcd", "product_cd", "product"],
    "card": ["card_id", "cardid", "card"],
    "customer": ["customer_id", "customerid", "customer", "cust_id"],
    "addr1": ["addr1", "region", "billing_region"],
    "addr2": ["addr2", "country", "billing_country"],
    "p_email": ["p_emaildomain", "purchaser_email", "email_p"],
    "r_email": ["r_emaildomain", "recipient_email", "email_r"],
    "risk": ["risk_score", "riskscore", "score", "model_score"],
    "channel": ["channel", "txn_channel"],
}

DEVICE_COLS = ["device_id", "deviceinfo", "device_info", "os", "browser",
               "screen", "devicetype", "device_type",
               "id_30", "id_31", "id_33"]
M_COLS = [f"m{i}" for i in range(1, 10)]
TRUTHY_M = {"t", "true", "1", "y", "yes"}


def _norm(h: str) -> str:
    return re.sub(r"[\s_\-]+", "", str(h).lower())


def resolve(headers: list[str], logical: str) -> str | None:
    """Find the actual header for a logical column, or None."""
    normed = {_norm(h): h for h in headers}
    for alias in ALIASES[logical]:
        if _norm(alias) in normed:
            return normed[_norm(alias)]
    return None


def require(headers: list[str], *logical: str) -> dict[str, str]:
    out, missing = {}, []
    for name in logical:
        found = resolve(headers, name)
        if found is None:
            missing.append(name)
        else:
            out[name] = found
    if missing:
        raise LoaderError(
            f"missing required columns {missing} (aliases tried: "
            f"{[(m, ALIASES[m]) for m in missing]}). "
            f"Headers found: {headers[:40]}")
    return out


def _present_v_cols(headers: list[str]) -> list[str]:
    return [h for h in headers if re.fullmatch(r"v\d+", _norm(h))]


def _present_m_cols(headers: list[str]) -> list[str]:
    normed = {_norm(h): h for h in headers}
    return [normed[m] for m in M_COLS if m in normed]


# --------------------------------------------------------------------- time

def _parse_times(raw: pd.Series, origin: datetime) -> pd.Series:
    """Parse a timestamp column that may be datetimes, offsets, or epoch."""
    sample = raw.dropna().head(50)
    if len(sample) == 0:
        raise LoaderError("timestamp column is entirely empty")
    probe = str(sample.iloc[0])
    try:
        float(probe)
        numeric = True
    except ValueError:
        numeric = False
    if not numeric:
        out = pd.to_datetime(raw, errors="coerce")
        if out.isna().all():
            raise LoaderError(f"could not parse datetimes like {probe!r}")
        return out
    vals = pd.to_numeric(raw, errors="coerce")
    lo = float(vals.min())
    if lo > 1e9:                                        # unix epoch seconds
        return pd.to_datetime(vals, unit="s", errors="coerce")
    return origin + pd.to_timedelta(vals, unit="s")     # offsets from origin


def _check_range(ts: pd.Series) -> None:
    lo, hi = ts.min(), ts.max()
    if not (datetime(2015, 1, 1) <= lo <= hi <= datetime(2017, 6, 1)):
        raise LoaderError(
            f"parsed timestamps span {lo} .. {hi}, outside the expected "
            f"2016 window — the time origin or format is wrong. Override with "
            f"ANVESH_TIME_ORIGIN=YYYY-MM-DD.")


# ------------------------------------------------------------------- config

@dataclass
class LoadConfig:
    data_dir: Path
    card_id_from: list[str] | None = None     # None = auto (card col, else card1..6)
    customer_id_from: list[str] | None = None
    time_origin: datetime = TIME_ORIGIN
    fit_v_anom: bool = True
    chunksize: int = CHUNK

    @classmethod
    def from_env(cls, data_dir: str | Path) -> "LoadConfig":
        def cols(key: str) -> list[str] | None:
            v = os.getenv(key, "").strip()
            return [c.strip() for c in v.split(",") if c.strip()] or None

        origin = TIME_ORIGIN
        if os.getenv("ANVESH_TIME_ORIGIN"):
            origin = datetime.strptime(os.getenv("ANVESH_TIME_ORIGIN"), "%Y-%m-%d")
        return cls(data_dir=Path(data_dir),
                   card_id_from=cols("CARD_ID_FROM"),
                   customer_id_from=cols("CUSTOMER_ID_FROM"),
                   time_origin=origin)


def _id_series(df: pd.DataFrame, headers: list[str], explicit: list[str] | None,
               logical: str, n_cols_prefix: str, n: int) -> pd.Series:
    """Resolve a card/customer identity series: explicit cols, else the
    dedicated column, else a composite of card1..cardN / addr cols."""
    if explicit:
        missing = [c for c in explicit if c not in df.columns]
        if missing:
            raise LoaderError(f"ID columns {missing} not in headers "
                              f"(from CARD_ID_FROM/CUSTOMER_ID_FROM)")
        return df[explicit].astype(str).agg("-".join, axis=1)
    direct = resolve(headers, logical)
    if direct is not None:
        return df[direct].astype(str)
    comp = [c for c in
            ([f"{n_cols_prefix}{i}" for i in range(1, n + 1)]
             if logical == "card" else ["addr1", "addr2"])
            if c in df.columns]
    if not comp:
        raise LoaderError(
            f"cannot derive {logical} identity: no {logical} column and no "
            f"fallback columns found. Set CARD_ID_FROM/CUSTOMER_ID_FROM — "
            f"see data/README.md for the mapping.")
    return df[comp].astype(str).agg("-".join, axis=1)


def _challenge_cols_present(headers: list[str]) -> bool:
    """True when the challenge card-grouping columns exist."""
    norm = {_norm(h) for h in headers}
    return _norm("customer_id") in norm and all(
        _norm(c) in norm for c in CARD_TUPLE_COLS)

# ------------------------------------------------- card identity (challenge)
_CARD_MAP_CACHE: dict[str, dict[str, str]] = {}

CARD_TUPLE_COLS = ["card1", "card2", "card3", "card4", "card5", "card6"]


def build_card_map(data_dir: Path) -> dict[str, str]:
    """TransactionID -> card_id under the challenge scheme.

    Groups transactions by (customer_id + full card1..6 tuple); K-numbers go
    by first-seen order within each customer; anchored groups take their true
    pack/closed C-ID. Raises LOUDLY on any contradiction — a wrong grouping
    must never silently mislabel cards.
    """
    key = str(data_dir)
    if key in _CARD_MAP_CACHE:
        return _CARD_MAP_CACHE[key]
    txn_path = Path(data_dir) / "transactions.csv"
    headers = list(pd.read_csv(txn_path, nrows=0).columns)
    norm = {_norm(h): h for h in headers}

    def need(logical: str) -> str:
        if _norm(logical) not in norm:
            raise LoaderError(
                f"card grouping needs column {logical}; headers include: "
                f"{headers[:12]}...")
        return norm[_norm(logical)]

    tid_c = need("TransactionID")
    cust_c = need("customer_id")
    tup_c = [need(c) for c in CARD_TUPLE_COLS]
    use = [tid_c, cust_c, *tup_c]
    cust_seen: dict[str, int] = {}
    group_cid: dict[str, str] = {}
    tid_group: dict[str, str] = {}
    for chunk in pd.read_csv(txn_path, usecols=use, chunksize=200_000,
                             dtype=str):
        chunk = chunk.fillna("")
        cols = [chunk[c].astype(str) for c in use]
        for vals in zip(*cols):
            tid, cust = str(vals[0]), str(vals[1])
            g = cust + "||" + "|".join(str(x) for x in vals[2:])
            if g not in group_cid:
                cust_seen[cust] = cust_seen.get(cust, 0) + 1
                group_cid[g] = f"{cust}-K{cust_seen[cust]}"
            tid_group[tid] = g
    anchors: dict[str, str] = {}
    for r in load_pack(Path(data_dir) / "case_pack.csv"):
        anchors[str(r.flagged_txn_id)] = str(r.card_id)
    for c in load_closed_cases(Path(data_dir) / "closed_cases_history.csv"):
        ids = [str(x) for x in c.txn_ids]
        if c.first_fraud_txn_id:
            ids.append(str(c.first_fraud_txn_id))
        for t in ids:
            if t in anchors and anchors[t] != str(c.card_id):
                raise LoaderError(
                    f"anchor txn {t} claimed by two cards: {anchors[t]} and "
                    f"{c.card_id} — data contradiction, report it")
            anchors[t] = str(c.card_id)
    alias: dict[str, str] = {}
    for tid, cid in anchors.items():
        g = tid_group.get(tid)
        if g is None:
            raise LoaderError(f"anchor txn {tid} (card {cid}) not in "
                              f"transactions.csv")
        if g in alias and alias[g] != cid:
            raise LoaderError(
                f"card grouping collision: one card-tuple claimed by {alias[g]} "
                f"and {cid} — the (customer + card-tuple) grouping is wrong")
        alias[g] = cid
    out = {tid: alias.get(g, group_cid[g]) for tid, g in tid_group.items()}
    _CARD_MAP_CACHE[key] = out
    return out


# ------------------------------------------------------------------ v_anom

class AnomalyScorer:
    """IsolationForest over the Vesta V-columns, fitted once on a sample.

    Deterministic (fixed seed). Scores are min-max normalised using the
    sample's own range, so chunked scoring stays consistent. v_anom is a
    STATIC per-transaction attribute — same status as risk_score: computed
    once at load, never recomputed per case, so it cannot leak case outcomes.
    """

    def __init__(self) -> None:
        self.model = None
        self.v_cols: list[str] = []
        self.lo = 0.0
        self.hi = 1.0

    def fit(self, frame: pd.DataFrame, v_cols: list[str]) -> None:
        from sklearn.ensemble import IsolationForest

        self.v_cols = v_cols
        X = frame[v_cols].apply(pd.to_numeric, errors="coerce").fillna(0.0).to_numpy()
        if len(X) < 10 or X.shape[1] == 0:
            return
        self.model = IsolationForest(n_estimators=200, contamination=0.05,
                                     random_state=V_ANOM_SEED, n_jobs=-1)
        self.model.fit(X)
        s = -self.model.score_samples(X)
        self.lo, self.hi = float(s.min()), float(s.max())
        if self.hi <= self.lo:
            self.hi = self.lo + 1.0

    def score(self, frame: pd.DataFrame) -> np.ndarray:
        if self.model is None or not self.v_cols:
            return np.zeros(len(frame))
        X = frame[self.v_cols].apply(pd.to_numeric, errors="coerce").fillna(0.0).to_numpy()
        s = -self.model.score_samples(X)
        return np.clip((s - self.lo) / (self.hi - self.lo), 0.0, 1.0)


def _fit_scorer(path: Path, v_cols: list[str], id_col: str) -> AnomalyScorer:
    scorer = AnomalyScorer()
    if not v_cols:
        return scorer
    sample_parts = []
    taken = 0
    for chunk in pd.read_csv(path, usecols=[id_col, *v_cols], chunksize=CHUNK):
        if taken >= V_ANOM_SAMPLE:
            break
        need = V_ANOM_SAMPLE - taken
        sample_parts.append(chunk.head(need))
        taken += len(chunk)
    sample = pd.concat(sample_parts, ignore_index=True) if sample_parts else pd.DataFrame()
    scorer.fit(sample, v_cols)
    return scorer


# ------------------------------------------------------------------ loading

def _read_identity(path: Path | None) -> dict[str, dict[str, str]]:
    """identity.csv keyed by transaction id -> {device cols present}."""
    if path is None or not path.exists():
        return {}
    df = pd.read_csv(path, dtype=str).fillna("")
    key = resolve(list(df.columns), "txn_id")
    if key is None:
        raise LoaderError(f"identity file has no transaction-id column; "
                          f"headers: {list(df.columns)[:20]}")
    normed = {_norm(h): h for h in df.columns}
    use, _seen = [], set()          # NOTE: DEVICE_COLS must match normalized
    for c in DEVICE_COLS:           # ("id_30" never equals normalized "id30")
        if _norm(c) in normed and normed[_norm(c)] not in _seen:
            _seen.add(normed[_norm(c)])
            use.append(normed[_norm(c)])
    out: dict[str, dict[str, str]] = {}
    for _, row in df.iterrows():
        dev = {c: str(row[c]).strip() for c in use if str(row[c]).strip()}
        out[str(row[key])] = dev
    return out


def _device_id(dev: dict[str, str]) -> str | None:
    if not dev:
        return None
    parts = [dev[c] for c in
             ("DeviceInfo", "deviceinfo", "os", "browser", "screen",
              "DeviceType", "devicetype", "device_id", "id_30", "id_31", "id_33")
             if dev.get(c)]
    if not parts:
        parts = sorted(dev.values())
    return " | ".join(parts) if parts else None


def _m_flags(row: pd.Series, m_cols: list[str]) -> int:
    n = 0
    for c in m_cols:
        v = row[c]
        if pd.isna(v):
            continue
        if str(v).strip().lower() not in TRUTHY_M:
            n += 1
    return n


def load_transactions(cfg: LoadConfig,
                      progress: bool = False) -> Iterator[list[Txn]]:
    """Yield Txn batches from transactions.csv (+ identity.csv join)."""
    txn_path = cfg.data_dir / "transactions.csv"
    if not txn_path.exists():
        raise LoaderError(f"{txn_path} not found — see docs/SETUP.md §1")
    id_path = cfg.data_dir / "identity.csv"
    identity = _read_identity(id_path if id_path.exists() else None)
    if progress:
        print(f"[load] identity rows: {len(identity):,}")

    headers = list(pd.read_csv(txn_path, nrows=0).columns)
    cols = require(headers, "txn_id", "dt", "amount", "product")
    opt = {k: resolve(headers, k) for k in
           ("addr1", "addr2", "p_email", "r_email", "risk", "channel")}
    m_cols = _present_m_cols(headers)
    v_cols = _present_v_cols(headers)

    scorer = _fit_scorer(txn_path, v_cols, cols["txn_id"]) if cfg.fit_v_anom else AnomalyScorer()
    if progress:
        print(f"[load] V columns: {len(v_cols)}, M columns: {len(m_cols)}, "
              f"v_anom fitted: {scorer.model is not None}")

    for chunk in pd.read_csv(txn_path, chunksize=cfg.chunksize, low_memory=False):
        ts = _parse_times(chunk[cols["dt"]], cfg.time_origin)
        _check_range(ts.dropna())
        if cfg.card_id_from or resolve(headers, "card") or \
                not _challenge_cols_present(headers):
            # explicit cols, a direct card column, or a generic CSV without
            # the challenge grouping columns -> legacy composite derivation
            card_ids = _id_series(chunk, headers, cfg.card_id_from, "card",
                                  "card", 6)
        else:
            card_ids = chunk[cols["txn_id"]].astype(str).map(
                build_card_map(cfg.data_dir))
            if card_ids.isna().any():
                raise LoaderError("card map missed transactions — report it")
            card_ids = card_ids.astype(str)
        cust_ids = _id_series(chunk, headers, cfg.customer_id_from,
                              "customer", "", 0)
        scores = scorer.score(chunk)
        batch: list[Txn] = []
        for i, (_, row) in enumerate(chunk.iterrows()):
            tid = str(row[cols["txn_id"]])
            product = str(row[cols["product"]])
            if opt["channel"]:
                online = str(row[opt["channel"]]).strip().lower() == "online"
            else:
                online = product != "W"      # ProductCD W = in-person
            dev = identity.get(tid, {})
            t = row[cols["dt"]]
            batch.append(Txn(
                txn_id=tid,
                ts=ts.iloc[i].to_pydatetime()
                if hasattr(ts.iloc[i], "to_pydatetime") else ts.iloc[i],
                amount=float(row[cols["amount"]]),
                card_id=str(card_ids.iloc[i]),
                customer_id=str(cust_ids.iloc[i]),
                product_cd=product,
                channel=Channel.ONLINE if online else Channel.IN_PERSON,
                risk_score=float(row[opt["risk"]]) if opt["risk"] else 0.0,
                region=str(row[opt["addr1"]]) if opt["addr1"] else None,
                country=str(row[opt["addr2"]]) if opt["addr2"] else None,
                device_id=_device_id(dev) if online else None,
                device_new=False,            # novelty comes from the baseline
                proxy=None,
                p_email=str(row[opt["p_email"]]) if opt["p_email"] else None,
                r_email=str(row[opt["r_email"]]) if opt["r_email"] else None,
                v_anom=round(float(scores[i]), 4),
                m_flags=_m_flags(row, m_cols),
            ))
        yield batch


def scan_ids(cfg: LoadConfig) -> IdRegistry:
    """Build an IdRegistry from CSVs without holding transactions."""
    reg = IdRegistry()
    txn_path = cfg.data_dir / "transactions.csv"
    headers = list(pd.read_csv(txn_path, nrows=0).columns)
    cols = require(headers, "txn_id")
    use = [cols["txn_id"]]
    card_col = resolve(headers, "card")
    cust_col = resolve(headers, "customer")
    for c in (card_col, cust_col):
        if c and c not in use:
            use.append(c)
    card_map = None
    if not card_col and not cfg.card_id_from and _challenge_cols_present(
            headers):
        card_map = build_card_map(cfg.data_dir)
    for chunk in pd.read_csv(txn_path, usecols=use, chunksize=CHUNK,
                             dtype=str):
        reg.add_txn(*chunk[cols["txn_id"]].astype(str).tolist())
        if card_col:
            reg.add_card(*chunk[card_col].astype(str).tolist())
        elif card_map is not None:
            reg.add_card(*chunk[cols["txn_id"]].astype(str).map(card_map)
                         .dropna().astype(str).tolist())
        if cust_col:
            reg.add_customer(*chunk[cust_col].astype(str).tolist())
    id_path = cfg.data_dir / "identity.csv"
    if id_path.exists():
        for tid, dev in _read_identity(id_path).items():
            d = _device_id(dev)
            if d:
                reg.add_device(d)
    for case in load_closed_cases(cfg.data_dir / "closed_cases_history.csv"):
        reg.add_case(case.case_id)
        reg.add_card(case.card_id)
        reg.add_customer(case.customer_id)
    return reg


# ------------------------------------------------------------- closed cases

def _split_ids(raw: str) -> list[str]:
    return [p.strip() for p in re.split(r"[;|,]", str(raw or "")) if p.strip()]


def load_closed_cases(path: Path) -> list[ClosedCase]:
    if not path.exists():
        return []
    df = pd.read_csv(path, dtype=str).fillna("")
    headers = list(df.columns)
    normed = {_norm(h): h for h in headers}

    def col(*names: str) -> str | None:
        for n in names:
            if _norm(n) in normed:
                return normed[_norm(n)]
        return None

    c_case = col("case_id", "caseid")
    c_cust = col("customer_id", "customerid", "customer")
    c_card = col("card_id", "cardid", "card")
    c_open = col("opened_at", "openedat", "opened")
    if not (c_case and c_cust and c_card and c_open):
        raise LoaderError(f"closed-cases file needs case/customer/card/opened_at "
                          f"columns (opened_at anchors the as_of for fitting); "
                          f"headers: {headers[:20]}")
    c_close = col("closed_at", "closedat", "closed")
    c_out = col("outcome")
    c_pat = col("pattern")
    c_first = col("first_fraud_txn_id", "first_fraud_txn")
    c_txns = col("txn_ids", "txns", "transaction_ids")
    c_n = col("n_txns", "n")
    c_exp = col("exposure_usd", "exposure")
    c_conn = col("connected_card_ids", "connected_cards")
    c_act = col("actions_taken", "actions")
    c_rep = col("report_filed", "report")
    c_notes = col("analyst_notes", "notes")

    def dt(v: str) -> datetime | None:
        v = (v or "").strip()
        if not v:
            return None
        try:
            return datetime.fromisoformat(v.replace("Z", ""))
        except ValueError:
            return pd.to_datetime(v).to_pydatetime()

    out = []
    for _, r in df.iterrows():
        out.append(ClosedCase(
            case_id=str(r[c_case]), customer_id=str(r[c_cust]),
            card_id=str(r[c_card]),
            opened_at=dt(r[c_open]),
            closed_at=dt(r[c_close]) if c_close else None,
            outcome=str(r[c_out]) if c_out else "",
            pattern=str(r[c_pat]) if c_pat else "",
            first_fraud_txn_id=str(r[c_first]) if c_first and r[c_first] else None,
            txn_ids=_split_ids(r[c_txns]) if c_txns else [],
            n_txns=int(float(r[c_n])) if c_n and r[c_n] else 0,
            exposure_usd=float(r[c_exp]) if c_exp and r[c_exp] else 0.0,
            connected_card_ids=_split_ids(r[c_conn]) if c_conn else [],
            actions_taken=_split_ids(r[c_act]) if c_act else [],
            report_filed=str(r[c_rep]).strip().lower() in
            ("1", "true", "t", "yes", "y") if c_rep else False,
            analyst_notes=str(r[c_notes]) if c_notes else "",
        ))
    out = [c for c in out if c.case_id]
    bad = [c.case_id for c in out if c.opened_at is None]
    if bad:
        raise LoaderError(f"closed cases with unparseable opened_at: {bad[:5]}")
    return out


# ---------------------------------------------------------------- case pack

def load_pack(path: Path) -> list[CasePackRow]:
    if not path.exists():
        raise LoaderError(f"{path} not found — see docs/SETUP.md §1")
    df = pd.read_csv(path, dtype=str).fillna("")
    headers = list(df.columns)
    normed = {_norm(h): h for h in headers}

    def col(*names: str) -> str | None:
        for n in names:
            if _norm(n) in normed:
                return normed[_norm(n)]
        return None

    c_case = col("case_id", "caseid")
    c_open = col("opened_at", "openedat", "opened", "as_of")
    c_trig = col("trigger_type", "trigger")
    c_text = col("trigger_text", "text", "description")
    c_flag = col("flagged_txn_id", "flagged_txn", "txn_id")
    c_card = col("card_id", "cardid", "card")
    c_cust = col("customer_id", "customerid", "customer")
    c_risk = col("risk_score", "riskscore", "score")
    missing = [n for n, c in (("case_id", c_case), ("opened_at", c_open),
                              ("flagged_txn_id", c_flag), ("card_id", c_card),
                              ("customer_id", c_cust)) if c is None]
    if missing:
        raise LoaderError(f"case_pack needs columns {missing}; "
                          f"headers: {headers[:20]}")

    out = []
    for _, r in df.iterrows():
        trig = str(r[c_trig]).strip().lower() if c_trig else "risk_score"
        try:
            trig_e = TriggerType(trig)
        except ValueError:
            trig_e = TriggerType.RISK_SCORE
        risk = None
        if c_risk and str(r[c_risk]).strip():
            try:
                risk = float(r[c_risk])
            except ValueError:
                risk = None
        out.append(CasePackRow(
            case_id=str(r[c_case]),
            opened_at=pd.to_datetime(r[c_open]).to_pydatetime(),
            trigger_type=trig_e,
            trigger_text=str(r[c_text]) if c_text else "",
            flagged_txn_id=str(r[c_flag]),
            card_id=str(r[c_card]),
            customer_id=str(r[c_cust]),
            risk_score=risk,
        ))
    return [c for c in out if c.case_id]


def validate_pack(pack: list[CasePackRow], reg: IdRegistry) -> None:
    """Fail fast when pack IDs don't resolve — usually a wrong card/customer
    derivation. Never silently investigate zero-match cases."""
    problems = []
    for row in pack:
        for label, vid in (("txn", row.flagged_txn_id), ("card", row.card_id),
                           ("customer", row.customer_id)):
            if vid and not reg.knows(vid):
                problems.append(f"{row.case_id}: {label} {vid} not in dataset")
    if problems:
        raise LoaderError(
            f"{len(problems)} case-pack IDs do not resolve to dataset IDs "
            f"(first 5: {problems[:5]}). The card/customer derivation is "
            f"probably wrong — check data/README.md and set CARD_ID_FROM / "
            f"CUSTOMER_ID_FROM.")
