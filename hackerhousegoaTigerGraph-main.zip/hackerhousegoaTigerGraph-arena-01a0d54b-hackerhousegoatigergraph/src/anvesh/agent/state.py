"""Investigation state — docs/STATE.md §1.

A plain dataclass. LangGraph-compatible in shape but with no LangGraph
dependency, so a hand-rolled state machine is a drop-in replacement
(docs/ARCHITECTURE.md §6).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from ..domain.enums import (
    EvidenceRequestType,
    EvidenceSource,
    Pattern,
    ResponseKind,
    TriggerType,
)
from ..domain.models import (
    ActionRef,
    Evidence,
    EvidenceContext,
    EvidenceRequest,
    Episode,
    Hypothesis,
    PolicyFlags,
    RejectedTool,
    SAR,
    SimulatedResponse,
    TraceEvent,
)


@dataclass
class Investigation:
    # identity — immutable after intake
    case_id: str = ""
    trigger_type: TriggerType = TriggerType.RISK_SCORE
    trigger_text: str = ""
    flagged_txn_id: str = ""
    card_id: str = ""
    customer_id: str = ""
    risk_score: float | None = None
    as_of: datetime | None = None

    # episode
    ctx: EvidenceContext | None = None
    episode: Episode = field(default_factory=Episode)
    candidate_txn_ids: list[str] = field(default_factory=list)

    # hypotheses and plan
    hypotheses: list[Hypothesis] = field(default_factory=list)
    rejected_tools: list[RejectedTool] = field(default_factory=list)

    # evidence
    evidence: list[Evidence] = field(default_factory=list)

    # memory
    similar_prior_cases: list[str] = field(default_factory=list)
    retrieved_docs: list[str] = field(default_factory=list)

    # assessment
    features: dict[str, float] = field(default_factory=dict)
    per_axis: dict[str, float] = field(default_factory=dict)
    prior: float = 0.4
    p_det: float = 0.4
    p_llm: float | None = None
    fraud_probability: float = 0.4
    verdict: str = "uncertain"
    pattern: Pattern = Pattern.NONE
    pattern_description: str = ""
    n_independent_signals: int = 0
    signal_axes: list[str] = field(default_factory=list)
    sensitivity: str = ""

    # policy flags
    flags: PolicyFlags = field(default_factory=PolicyFlags)

    # evidence requests
    evidence_requests: list[EvidenceRequest] = field(default_factory=list)
    responses: list[SimulatedResponse] = field(default_factory=list)

    # decision
    initial_actions: list[ActionRef] = field(default_factory=list)
    final_actions: list[ActionRef] = field(default_factory=list)
    what_changed: str = ""
    sar: SAR = field(default_factory=SAR)
    stop_reason: str = ""

    # control
    step: int = 0
    tool_calls: int = 0
    tokens: int = 0
    latency_s: float = 0.0
    round: int = 0
    status: str = "open"
    graph_case_id: str = ""
    written_to_graph: bool = False
    errors: list[str] = field(default_factory=list)
    trace: list[TraceEvent] = field(default_factory=list)

    # ------------------------------------------------------------------ trace
    def _seq(self) -> int:
        return len(self.trace) + 1

    def log(self, node: str, kind: str, **detail) -> None:
        self.trace.append(TraceEvent(seq=self._seq(), node=node, kind=kind, detail=detail))

    def add_evidence(self, claim: str, source: EvidenceSource, ref: str,
                     entity_ids: list[str], axis) -> None:
        self.evidence.append(Evidence(claim=claim, source=source, ref=ref,
                                      entity_ids=entity_ids, axis=axis))

    def reject_tool(self, query: str, reason: str) -> None:
        """The clearest evidence of agency in the whole trace."""
        self.rejected_tools.append(RejectedTool(query=query, reason=reason))
        self.log("gather_evidence", "tool_rejected", query=query, reason=reason)

    @property
    def has_device(self) -> bool:
        return bool(self.ctx and self.ctx.has_device)

    def to_rule_input(self):
        from ..policy.rules import RuleInput
        return RuleInput(
            fraud_probability=self.fraud_probability,
            exposure_usd=self.episode.exposure_usd,
            verdict=self.verdict_enum,
            pattern=self.pattern,
            n_independent_signals=self.n_independent_signals,
            flags=self.flags,
            evidence_requested=bool(self.evidence_requests),
        )

    @property
    def verdict_enum(self):
        from ..domain.enums import Verdict
        return Verdict(self.verdict)


def response_kind_of(s: SimulatedResponse) -> ResponseKind:
    return s.kind


__all__ = ["Investigation", "EvidenceRequestType", "Pattern", "ResponseKind"]
