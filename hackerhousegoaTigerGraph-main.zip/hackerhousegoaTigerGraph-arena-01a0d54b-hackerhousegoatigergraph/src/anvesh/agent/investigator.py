"""The investigation orchestrator — docs/STATE.md §3.

Deterministic skeleton with exactly two optional LLM nodes (hypothesize,
explain). Everything else is code. Every graph read goes through the adapter,
which is the only path to data (docs/ARCHITECTURE.md §2).
"""

from __future__ import annotations

import hashlib

import time
from dataclasses import replace

from ..config import (
    BUDGET_MAX_ROUNDS,
    MAX_HYPOTHESES,
    P_STOP_HIGH,
    P_STOP_LOW,
    P_VERIFY_BELOW,
    SHARED_ORIGIN_MIN_CARDS,
    SHARED_ORIGIN_WINDOW_DAYS,
)
from ..domain.enums import (
    CaseStatus,
    Channel,
    EvidenceAxis,
    EvidenceRequestType,
    EvidenceSource,
    Pattern,
    ResponseKind,
    Verdict,
)
from ..domain.models import (
    CasePackRow,
    EvidenceContext,
    EvidenceRequest,
    SimulatedResponse,
)
from ..evidence.detectors import DetectorResult, run_all
from ..evidence.episode import segment
from ..evidence.features import build_features, fingerprint
from ..llm.client import LLMError, NullLLM
from ..policy.cost import rank
from ..policy.engine import resolve
from ..policy.rules import RuleInput
from ..reasoning.likelihood import NEUTRAL, LikelihoodTable
from ..reasoning.priors import prior_for
from ..reasoning.scorer import fuse, score, update_on_response, verdict_from
from ..reasoning.voi import stop_reason_from_voi, value_of_information
from .state import Investigation

CARD_WINDOW_HOURS = 48
BASELINE_DAYS = 90


class Investigator:
    def __init__(self, adapter, registry, table: LikelihoodTable | None = None,
                 llm=None, write_graph: bool = True):
        self.adapter = adapter
        self.registry = registry
        self.table = table or NEUTRAL
        self.llm = llm or NullLLM()
        self.write_graph = write_graph

    # ===================================================================== run
    def run(self, row: CasePackRow) -> tuple[dict, Investigation]:
        t0 = time.time()
        st = Investigation()
        st.log("start", "case_begin", case_id=row.case_id, trigger=row.trigger_type.value)

        self._intake(st, row)
        self._build_context(st)
        self._construct_episode(st)
        self._hypothesize(st)
        self._gather_evidence(st)
        self._recall_memory(st)
        self._assess(st)

        # initial actions — BEFORE any evidence is requested
        self._resolve(st, bucket="initial")

        asked = False
        if self._should_continue(st):
            asked = self._request_evidence(st)
            if asked:
                self._reassess(st)

        # final actions — AFTER the assumed responses
        self._resolve(st, bucket="final")
        self._what_changed(st, asked)
        self._writeback(st)
        self._explain(st)

        st.latency_s = round(time.time() - t0, 3)
        st.tool_calls = getattr(self.adapter, "tool_calls", 0) and self._tool_calls(st)
        answer = self._emit(st)
        st.log("end", "case_end", tool_calls=st.tool_calls, latency_s=st.latency_s)
        return answer, st

    def _tool_calls(self, st: Investigation) -> int:
        return sum(1 for e in st.trace if e.kind in ("tool_call", "tool_rejected"))

    # ================================================================== nodes
    def _intake(self, st: Investigation, row: CasePackRow) -> None:
        st.case_id = row.case_id
        st.trigger_type = row.trigger_type
        st.trigger_text = row.trigger_text
        st.flagged_txn_id = row.flagged_txn_id
        st.card_id = row.card_id
        st.customer_id = row.customer_id
        st.risk_score = row.risk_score
        st.as_of = row.opened_at                     # as_of binds every later read
        st.flags = replace(st.flags,
                           disputed=(row.trigger_type.value == "customer_report"))
        st.log("intake", "identity", as_of=st.as_of.isoformat(),
               flagged_txn_id=row.flagged_txn_id, trigger=row.trigger_type.value)

    def _build_context(self, st: Investigation) -> None:
        assert st.as_of is not None
        a = self.adapter
        flagged = a.txn_context(st.as_of, st.flagged_txn_id)
        if flagged is None:
            st.errors.append(f"flagged transaction {st.flagged_txn_id} not visible at as_of")
            st.log("build_context", "error", detail=st.errors[-1])
            return

        window = a.card_window(st.as_of, st.card_id, CARD_WINDOW_HOURS)
        baseline = a.cardholder_baseline(st.as_of, st.card_id, BASELINE_DAYS)
        geo = a.geo_velocity(st.as_of, st.card_id, CARD_WINDOW_HOURS)

        device_cards: list[str] = []
        device_cases: list[str] = []
        if flagged.channel is Channel.ONLINE and flagged.device_id:
            dn = a.device_neighbors(st.as_of, flagged.device_id, 30)
            device_cards = [c for c in dn.card_ids if c != st.card_id]
            device_cases = dn.closed_cases
            st.log("build_context", "tool_call", tool="device_neighbors",
                   device_id=flagged.device_id, n_other_cards=len(device_cards))
        else:
            # CHANNEL GUARD: in-person has no device record. Log the absence.
            st.log("build_context", "no_device_record",
                   channel=flagged.channel.value,
                   reason="identity.csv covers online transactions only")

        region_cards: list[str] = []
        if flagged.region:
            region_cards = [c for c in
                            a.shared_origin_cards(st.as_of, "region", flagged.region,
                                                  SHARED_ORIGIN_WINDOW_DAYS)
                            if c != st.card_id]
        # R6 names "the same recipient email" — NOT the purchaser's.
        # P_emaildomain is a mass-market provider (gmail.com, outlook.com); using
        # it as a linkage signal puts thousands of unrelated cards in one
        # component. R_emaildomain (recipient) is the discriminating field.
        email_cards: list[str] = []
        if flagged.r_email:
            email_cards = [c for c in
                           a.shared_origin_cards(st.as_of, "email", flagged.r_email,
                                                 SHARED_ORIGIN_WINDOW_DAYS)
                           if c != st.card_id]
        elif flagged.p_email:
            st.reject_tool("shared_origin_sweep(email)",
                           "purchaser email domain is a mass-market provider; "
                           "not a discriminating linkage signal")

        ring = a.ring_components(st.as_of, 30, SHARED_ORIGIN_MIN_CARDS, st.card_id)
        if ring is None:
            st.reject_tool("ring_components",
                           f"device degree below {SHARED_ORIGIN_MIN_CARDS}; "
                           "ring sweep not informative")

        st.ctx = EvidenceContext(
            as_of=st.as_of, flagged_txn_id=st.flagged_txn_id, card_id=st.card_id,
            customer_id=st.customer_id, channel=flagged.channel, flagged=flagged,
            window_txns=window, baseline=baseline, geo_pairs=geo,
            device_cards=device_cards, device_closed_cases=device_cases,
            region_cards=region_cards, email_cards=email_cards, ring=ring,
            customer_cards=a.customer_cards(st.customer_id),
        )
        st.log("build_context", "context_ready",
               n_window=len(window), n_baseline=baseline.n_txns,
               n_geo_pairs=len(geo), ring_size=(ring.size if ring else 0))

    def _construct_episode(self, st: Investigation) -> None:
        if st.ctx is None or st.ctx.flagged is None:
            return
        seeds = [st.flagged_txn_id]
        candidates = self.adapter.episode_expand(st.as_of, seeds, 1)
        st.candidate_txn_ids = [t.txn_id for t in candidates]
        st.episode = segment(st.ctx, seeds, candidates)
        st.log("episode_construct", "episode",
               n_candidates=len(candidates), n_episode=len(st.episode.txn_ids),
               exposure_usd=st.episode.exposure_usd)

    def _hypothesize(self, st: Investigation) -> None:
        """LLM node 1 of 2. Proposes hypotheses; each selects which queries run.

        Falls back to all five patterns when no model is configured.
        """
        cands = [Pattern.CARD_TESTING, Pattern.CARD_NOT_PRESENT_NEW_DEVICE,
                 Pattern.CARD_NOT_PRESENT_FRAUD, Pattern.OUT_OF_REGION_USE,
                 Pattern.ACCOUNT_TAKEOVER]
        if st.ctx is not None and st.ctx.channel is Channel.IN_PERSON:
            # no device record: device-dependent hypotheses cannot be probed
            st.reject_tool("device_neighbors",
                           "in-person transaction has no device record")
        st.hypotheses = []
        try:
            out = self.llm.complete(
                system="You propose fraud hypotheses from graph evidence. Be terse.",
                user=self._hypothesis_prompt(st),
                schema=dict,
            )
            for item in (out or {}).get("hypotheses", [])[:MAX_HYPOTHESES]:
                try:
                    st.hypotheses.append(type(st.hypotheses[0] if st.hypotheses else None)
                                         if False else _mk_hypothesis(item))
                except Exception:
                    continue
        except (LLMError, Exception) as e:
            if not isinstance(self.llm, NullLLM):
                import sys
                print(f"[llm] Warning: hypothesis generation failed ({e}); falling back to default probes.", file=sys.stderr)
        if not st.hypotheses:
            st.hypotheses = [_mk_hypothesis({"pattern": p.value, "rationale":
                                             "default probe", "probes": ["card_window"]})
                             for p in cands[:MAX_HYPOTHESES]]
        st.log("hypothesize", "hypotheses",
               patterns=[h.pattern.value for h in st.hypotheses],
               llm_used=not isinstance(self.llm, NullLLM))

    def _hypothesis_prompt(self, st: Investigation) -> str:
        ctx = st.ctx
        return (
            f"Case {st.case_id}. Trigger: {st.trigger_type.value}. "
            f"Flagged transaction {st.flagged_txn_id} on card {st.card_id}, "
            f"channel={ctx.channel.value if ctx else '?'}, "
            f"amount={ctx.flagged.amount if ctx and ctx.flagged else '?'}, "
            f"risk_score={st.risk_score}. "
            f"Window transactions: {len(ctx.window_txns) if ctx else 0}. "
            f"Return JSON: {{\"hypotheses\": [{{\"pattern\": ..., \"rationale\": ..., "
            f"\"probes\": [...]}}]}}"
        )

    def _gather_evidence(self, st: Investigation) -> None:
        ctx = st.ctx
        if ctx is None or ctx.flagged is None:
            return
        results: list[DetectorResult] = run_all(ctx)
        fired = [r for r in results if r.fired]

        for r in fired:
            st.add_evidence(claim=r.why, source=EvidenceSource.GRAPH,
                            ref=r.ref, entity_ids=r.txn_ids, axis=r.axis)
            st.log("gather_evidence", "detector_fired",
                   pattern=r.pattern.value, confidence=r.confidence)
        for r in results:
            if not r.fired and r.why:
                st.log("gather_evidence", "detector_not_fired",
                       pattern=r.pattern.value, why=r.why)

        # ---- flags the policy engine reads --------------------------------
        flags = st.flags
        if fired:
            best = max(fired, key=lambda r: r.confidence)
            st.pattern = best.pattern

        testing = next((r for r in fired if r.pattern is Pattern.CARD_TESTING), None)
        flags = replace(flags, testing_sequence=bool(testing))
        if testing:
            cleared = [t for t in ctx.window_txns if t.txn_id in testing.txn_ids]
            flags = replace(flags,
                            max_cleared_purchase=max((t.amount for t in cleared), default=0.0))

        # shared origin (R6) — device > region > email, most cards wins.
        #
        # Region only counts when it is NEW to this card. Billing regions are
        # shared by thousands of legitimate customers, so co-occurrence alone is
        # noise; the policy means a *region cluster* of cards that are all new
        # to it.
        region_novel = bool(ctx.flagged.region and ctx.baseline.region_novelty(ctx.flagged.region))
        shared_kind, shared_el, shared_cards = None, "", []
        for kind, cards, el, usable in (
            ("device", ctx.device_cards, ctx.flagged.device_id or "", True),
            ("region", ctx.region_cards, ctx.flagged.region or "", region_novel),
            ("email", ctx.email_cards, ctx.flagged.r_email or "", True),
        ):
            if not usable:
                continue
            if len(cards) + 1 >= SHARED_ORIGIN_MIN_CARDS:
                if len(cards) > len(shared_cards):
                    shared_kind, shared_el, shared_cards = kind, el, cards
        if ctx.region_cards and not region_novel:
            st.reject_tool("shared_origin_sweep(region)",
                           "billing region is the cardholder's home region; "
                           "co-occurrence there is not a fraud signal")
        if shared_kind:
            flags = replace(flags, shared_origin=True,
                            shared_element=f"{shared_kind} {shared_el}")
            st.add_evidence(
                claim=f"Shared {shared_kind} '{shared_el}' is also present on "
                      f"{len(shared_cards)} other card(s) within "
                      f"{SHARED_ORIGIN_WINDOW_DAYS} days",
                source=EvidenceSource.GRAPH,
                ref=f"query:shared_origin_sweep({shared_kind}={shared_el})",
                entity_ids=shared_cards + [st.card_id],
                axis=EvidenceAxis.GRAPH)

        if ctx.ring:
            flags = replace(flags, in_ring=True, ring_size=ctx.ring.size)
            st.add_evidence(
                claim=f"Connected component of {ctx.ring.size} cards sharing device "
                      f"profiles within 30 days ({ctx.ring.cluster_id})",
                source=EvidenceSource.GRAPH,
                ref="query:ring_components(algorithm=tg_wcc)",
                entity_ids=ctx.ring.card_ids, axis=EvidenceAxis.GRAPH)

        # cross-customer: a shared device touches a card owned by someone else
        cross = any(not c.startswith(st.customer_id) for c in shared_cards)
        flags = replace(flags, cross_customer=bool(cross))

        rec = self.adapter.recurring_check(st.as_of, st.card_id, 120)
        if rec.is_recurring:
            flags = replace(flags, is_recurring=True)
            st.add_evidence(
                claim=f"Charge matches the cardholder's own recurring pattern "
                      f"(same product code, ~{rec.cadence_days:.0f}-day cadence, "
                      f"{len(rec.matched_txn_ids)} prior occurrences)",
                source=EvidenceSource.GRAPH,
                ref=f"query:recurring_check(card_id={st.card_id}, days=120)",
                entity_ids=rec.matched_txn_ids, axis=EvidenceAxis.VELOCITY)

        st.flags = flags

        # undocumented pattern (R9): evidence of coordination, no known pattern
        if not fired and (flags.in_ring or flags.shared_origin) and flags.cross_customer:
            st.pattern = Pattern.UNDOCUMENTED
            st.pattern_description = (
                "Coordinated activity across multiple customers linked by a shared "
                f"{st.flags.shared_element or 'origin'} within a short window, with no "
                "match to any of the five documented patterns. The shared element is "
                "the only connecting structure; per-card behaviour is individually "
                "unremarkable, which is why the known detectors do not fire."
            )
            st.add_evidence(
                claim="Activity is coordinated across customers but matches none of "
                      "the five documented patterns",
                source=EvidenceSource.GRAPH,
                ref="query:episode_expand + ring_components",
                entity_ids=shared_cards + [st.card_id], axis=EvidenceAxis.GRAPH)

        st.log("gather_evidence", "flags", **{k: v for k, v in vars(flags).items()
                                              if isinstance(v, (bool, int, float, str))})

    def _recall_memory(self, st: Investigation) -> None:
        if st.ctx is None:
            return
        fp = fingerprint(st.ctx, st.episode)
        st.similar_prior_cases = self.adapter.prior_cases(fp, 3)
        if st.similar_prior_cases:
            st.add_evidence(
                claim=f"Retrieved {len(st.similar_prior_cases)} similar closed cases "
                      f"by behavioural fingerprint: {', '.join(st.similar_prior_cases)}",
                source=EvidenceSource.GRAPH,
                ref="query:prior_cases(vector=ClosedCase.fp, k=3)",
                entity_ids=list(st.similar_prior_cases), axis=EvidenceAxis.MEMORY)
            st.ctx.similar_cases = st.similar_prior_cases
        st.log("recall_memory", "memory", similar=st.similar_prior_cases)

    def _assess(self, st: Investigation) -> None:
        if st.ctx is None:
            return
        st.features = build_features(st.ctx, st.episode)
        st.prior = prior_for(st.trigger_type, st.risk_score)
        st.p_det, st.per_axis = score(st.features, self.table, st.prior)
        st.fraud_probability = st.p_det if st.p_llm is None else fuse(st.p_det, st.p_llm)

        st.signal_axes = sorted({e.axis.value for e in st.evidence if e.weight > 0})
        st.n_independent_signals = len(st.signal_axes)
        st.verdict = verdict_from(st.fraud_probability, st.n_independent_signals)
        self._reconcile_episode(st)

        st.sensitivity = self._sensitivity(st)
        st.log("assess", "assessment", p_det=round(st.p_det, 3),
               p=round(st.fraud_probability, 3), verdict=st.verdict,
               n_signals=st.n_independent_signals, axes=st.signal_axes,
               per_axis={k: round(v, 3) for k, v in st.per_axis.items()})

    def _sensitivity(self, st: Investigation) -> str:
        p_deny = update_on_response(st.fraud_probability, ResponseKind.DENIED)
        p_conf = update_on_response(st.fraud_probability, ResponseKind.CONFIRMED)
        return (f"A customer denial would move p from {st.fraud_probability:.2f} to "
                f"{p_deny:.2f}; a confirmation would move it to {p_conf:.2f}. "
                f"{'A denial clears the R1 block threshold.' if p_deny >= P_VERIFY_BELOW else ''}"
                ).strip()

    # ------------------------------------------------------------- stopping
    def _should_continue(self, st: Investigation) -> bool:
        p, n = st.fraud_probability, st.n_independent_signals
        if p >= P_STOP_HIGH and n >= 2:
            st.stop_reason = (f"Probability {p:.2f} is at or above {P_STOP_HIGH} on "
                              f"{n} independent signals.")
            return False
        if p <= P_STOP_LOW and n >= 2:
            st.stop_reason = (f"Probability {p:.2f} is at or below {P_STOP_LOW} on "
                              f"{n} independent signals.")
            return False
        if st.round >= BUDGET_MAX_ROUNDS:
            st.stop_reason = "Evidence-request budget exhausted."
            return False

        # Value of information: ask only if a response could change the action set.
        base = st.to_rule_input()
        voi, detail = value_of_information(
            base, EvidenceRequestType.CUSTOMER_VALIDATION,
            lambda resp: update_on_response(st.fraud_probability, resp))
        st.log("stop_or_continue", "voi", voi=round(voi, 4), **detail)
        if voi <= 0:
            st.stop_reason = stop_reason_from_voi(voi, detail, p) or \
                "Value of information is not positive; further steps will not change the decision."
            return False
        return True

    def _request_evidence(self, st: Investigation) -> bool:
        """Simulated, disclosed, order-independent. Never tuned per case."""
        st.round += 1
        # Fixed policy: the highest-VOI request type is always customer validation
        # when the customer has not yet been asked; step-up is used only when the
        # flagged transaction is online and step-up is already policy-preferred.
        rtype = EvidenceRequestType.CUSTOMER_VALIDATION
        base = st.to_rule_input()
        if st.pattern is Pattern.CARD_TESTING:
            rtype = EvidenceRequestType.STEP_UP_AUTH

        voi, detail = value_of_information(
            base, rtype, lambda resp: update_on_response(st.fraud_probability, resp))
        if voi <= 0:
            st.round -= 1
            return False

        # Deterministic assumed response: sampled from the same priors the VOI
        # calculation uses, seeded by case_id so it is reproducible and NOT tuned.
        kind = self._assume_response(st, rtype)
        text = {
            ResponseKind.DENIED:
                "Customer states they did not make this transaction and still has the card.",
            ResponseKind.CONFIRMED:
                "Customer confirms the transaction; it was made by them or a household member.",
            ResponseKind.NO_REPLY:
                "No reply within 24 hours.",
        }[kind]

        st.evidence_requests.append(EvidenceRequest(
            type=rtype, asked_after_step=len(st.trace), assumed_response=text))
        st.responses.append(SimulatedResponse(request_type=rtype, kind=kind, text=text))
        st.add_evidence(claim=text, source=EvidenceSource.CUSTOMER,
                        ref=f"evidence_request:{len(st.evidence_requests)}",
                        entity_ids=[], axis=EvidenceAxis.MEMORY)
        st.log("request_evidence", "evidence_request", type=rtype.value,
               assumed=kind.value, voi=round(voi, 4))
        return True

    def _assume_response(self, st: Investigation, rtype: EvidenceRequestType) -> ResponseKind:
        """Fixed, disclosed, reproducible. NOT chosen to reach a verdict."""
        from ..config import RESPONSE_PRIORS
        priors = RESPONSE_PRIORS.get(rtype.value, RESPONSE_PRIORS["customer_validation"])
        # Deterministic draw from the marginal distribution, seeded by case_id.
        #
        # sha256, not a digit sum: case ids differ only in their last character,
        # so a naive ord-sum maps every case to nearly the same draw (~0.45) and
        # hands every one of them the same response. That silently makes the
        # second-round behaviour identical across the whole case pack.
        digest = hashlib.sha256(f"{st.case_id}:{rtype.value}".encode()).digest()
        target = int.from_bytes(digest[:8], "big") / float(1 << 64)
        acc = 0.0
        for k, v in sorted(priors.items()):
            acc += v
            if target <= acc:
                return ResponseKind(k)
        return ResponseKind.NO_REPLY

    def _reconcile_episode(self, st: Investigation) -> None:
        """A legitimate verdict means there is no fraud episode — however we got there.

        The verdict can become legitimate two ways: a customer confirmation (R3),
        or the assessment itself landing below 0.15 on >= 2 independent signals
        (policy §6). Both must empty the episode, otherwise the answer file
        carries verdict=legitimate with a populated affected_txn_ids and a
        non-zero exposure — invariant I1, validator check #6.
        """
        from ..domain.models import Episode
        # Two ways the final verdict becomes legitimate:
        #   1. verdict_from() already says so (p <= 0.15 on >= 2 signals, §6)
        #   2. a customer confirmation — the policy engine's R3 override will
        #      force LEGITIMATE regardless of p and signal count, so we must
        #      anticipate it here, before the final resolve computes routes.
        confirmed = st.flags.response is ResponseKind.CONFIRMED
        if st.verdict != Verdict.LEGITIMATE.value and not confirmed:
            return
        if st.episode.txn_ids or st.episode.exposure_usd:
            st.log("reconcile", "episode_cleared",
                   reason="verdict is legitimate; no fraud episode remains")
        st.episode = Episode()
        if st.pattern is not Pattern.NONE:
            st.pattern = Pattern.NONE
            st.pattern_description = ""

    def _reassess(self, st: Investigation) -> None:
        if not st.responses:
            return
        before = st.fraud_probability
        st.flags = replace(st.flags, response=st.responses[-1].kind)
        st.fraud_probability = update_on_response(before, st.responses[-1].kind)

        st.verdict = verdict_from(st.fraud_probability, st.n_independent_signals)
        # A customer CONFIRMATION means the activity was theirs: there is no
        # fraud episode, so the episode and its exposure must be emptied.
        # Without this the answer file carries verdict=legitimate with a
        # non-empty affected_txn_ids — invariant I1, validator check #6.
        if st.responses[-1].kind is ResponseKind.CONFIRMED:
            st.log("reassess", "customer_confirmed",
                   reason="R3: the activity was authorised; no fraud episode remains")

        self._reconcile_episode(st)
        st.log("reassess", "update", before=round(before, 3),
               after=round(st.fraud_probability, 3), response=st.responses[-1].kind.value,
               verdict=st.verdict)

    # -------------------------------------------------------------- decision
    def _resolve(self, st: Investigation, bucket: str) -> None:
        d = resolve(st.to_rule_input())
        actions = rank(d, st.fraud_probability, st.episode.exposure_usd)
        if bucket == "initial":
            st.initial_actions = actions
            st.sar = _sar_from(st, d)
        else:
            st.final_actions = actions
            st.sar = _sar_from(st, d)
            st.verdict = d.verdict.value
            st.status = _status_from(st, d)
        for s in d.suppressed:
            st.log("policy_resolve", "suppressed", detail=s, bucket=bucket)
        st.log("policy_resolve", f"actions_{bucket}",
               actions=[{"action": a.action.value, "route": a.route.value,
                         "reason": a.reason} for a in actions],
               p=round(st.fraud_probability, 3),
               exposure=st.episode.exposure_usd, file_sar=d.file_sar)

    def _what_changed(self, st: Investigation, asked: bool) -> None:
        if not asked:
            st.what_changed = "nothing"
            st.final_actions = st.initial_actions
            return
        i = {a.action for a in st.initial_actions}
        f = {a.action for a in st.final_actions}
        added, removed = sorted(x.value for x in f - i), sorted(x.value for x in i - f)
        parts = []
        resp = st.responses[-1].kind.value if st.responses else "none"
        parts.append(f"The customer's simulated response was '{resp}', which moved "
                     f"fraud probability to {st.fraud_probability:.2f}.")
        if added:
            parts.append("Added: " + ", ".join(added) + ".")
        if removed:
            parts.append("Withdrawn: " + ", ".join(removed) + ".")
        if not added and not removed:
            parts.append("The action set is unchanged, but the justification changed.")
        st.what_changed = " ".join(parts)

    def _writeback(self, st: Investigation) -> None:
        if not self.write_graph:
            st.written_to_graph = False
            return
        gid = f"CASE-2016-{st.case_id.split('-')[-1]}"
        try:
            self.adapter.write_case(gid, {
                "case_id": st.case_id, "verdict": st.verdict,
                "fraud_probability": st.fraud_probability,
                "pattern": st.pattern.value, "exposure_usd": st.episode.exposure_usd,
                "affected_txn_ids": st.episode.txn_ids,
                # memory edges: the case links to its card, device and the
                # prior cases it cited, so later cases can find it through
                # the graph instead of only through vectors.
                "card_id": st.card_id,
                "device_id": (st.ctx.flagged.device_id
                              if st.has_device and st.ctx.flagged.device_id else ""),
                "similar_prior_cases": list(st.similar_prior_cases),
                "fingerprint": (fingerprint(st.ctx, st.episode)
                                if st.ctx is not None else []),
            })
            st.graph_case_id, st.written_to_graph = gid, True
        except Exception as e:                                  # pragma: no cover
            st.errors.append(f"writeback failed: {e}")
            st.written_to_graph = False
        st.log("case_writeback", "write", graph_case_id=st.graph_case_id,
               written=st.written_to_graph)

    # ------------------------------------------------------------ explanation
    def _explain(self, st: Investigation) -> None:
        """LLM node 2 of 2. Template fallback keeps counts inside the limits."""
        st.summary_text = self._template_summary(st)
        st.narrative_text = self._template_narrative(st) if st.sar.file else ""
        try:
            out = self.llm.complete(
                system="You write fraud case summaries and SAR narratives. "
                       "Use only the supplied evidence. Cite no new IDs.",
                user=self._explain_prompt(st), schema=dict)
            if isinstance(out, dict):
                if out.get("summary"):
                    st.summary_text = out["summary"]
                if st.sar.file and out.get("narrative"):
                    st.narrative_text = out["narrative"]
        except (LLMError, Exception) as e:
            if not isinstance(self.llm, NullLLM):
                import sys
                print(f"[llm] Warning: explanation prose failed ({e}); falling back to templates.", file=sys.stderr)
        if st.sar.file and st.narrative_text:
            st.sar.narrative = st.narrative_text
        st.log("explain", "prose", llm_used=not isinstance(self.llm, NullLLM))

    def _explain_prompt(self, st: Investigation) -> str:
        ev = "\n".join(f"- {e.claim} [{e.source.value}: {e.ref}]" for e in st.evidence)
        return (f"Case {st.case_id}. Verdict {st.verdict} (p={st.fraud_probability:.2f}). "
                f"Pattern {st.pattern.value}. Exposure ${st.episode.exposure_usd:,.2f}.\n"
                f"Evidence:\n{ev}\n"
                f"Write JSON with: summary (2-6 sentences), "
                f"{'narrative (6-12 sentences: who/what/when/where/how/why), ' if st.sar.file else ''}"
                f"what_changed (1-2 sentences).")

    def _template_summary(self, st: Investigation) -> str:
        """Exactly 4 sentences — inside the 2-6 limit by construction."""
        ctx = st.ctx
        s1 = (f"Card {st.card_id} belonging to customer {st.customer_id} was flagged by a "
              f"{st.trigger_type.value.replace('_', ' ')}"
              f"{f' at risk score {st.risk_score:.2f}' if st.risk_score is not None else ''} "
              f"on transaction {st.flagged_txn_id}.")
        if st.pattern is Pattern.NONE:
            s2 = ("No documented fraud pattern was detected in the surrounding activity.")
        else:
            s2 = (f"The investigation identified a "
                  f"{st.pattern.value.replace('_', ' ')} pattern with an assessed fraud "
                  f"probability of {st.fraud_probability:.2f}.")
        s3 = (f"The episode comprises {len(st.episode.txn_ids)} transaction(s) totalling "
              f"${st.episode.exposure_usd:,.2f} in exposure, supported by "
              f"{st.n_independent_signals} independent evidence "
              f"{'axis' if st.n_independent_signals == 1 else 'axes'}"
              f"{': ' + ', '.join(st.signal_axes) if st.signal_axes else ''}.")
        s4 = (f"{len(st.similar_prior_cases)} similar prior case(s) were retrieved from "
              f"memory." if st.similar_prior_cases else
              "No sufficiently similar prior cases were retrieved from memory.")
        return " ".join([s1, s2, s3, s4])

    def _template_narrative(self, st: Investigation) -> str:
        """8 sentences, covering who/what/when/where/how/why."""
        ctx = st.ctx
        flagged = ctx.flagged if ctx else None
        dates = sorted({t.ts.date().isoformat()
                        for t in (ctx.window_txns if ctx else [])
                        if t.txn_id in set(st.episode.txn_ids)}) or \
                [st.as_of.date().isoformat()]
        subjects = sorted({st.customer_id, st.card_id}
                          | set(st.episode and [] or [])
                          | set(st.flags.shared_element.split()[-1:] if st.flags.shared_element else []))
        return " ".join([
            f"Customer {st.customer_id} holds card {st.card_id} with the reporting institution.",
            f"On {dates[0]}{f' through {dates[-1]}' if len(dates) > 1 else ''}, "
            f"{len(st.episode.txn_ids)} transaction(s) were conducted that the investigation "
            f"assessed as suspicious.",
            f"The activity was flagged by a {st.trigger_type.value.replace('_', ' ')}"
            f"{f' with a model risk score of {st.risk_score:.2f}' if st.risk_score is not None else ''}.",
            f"The flagged transaction {st.flagged_txn_id} carries an amount of "
            f"${flagged.amount:,.2f} and was processed through the "
            f"{flagged.channel.value.replace('_', '-')} channel." if flagged else
            "The flagged transaction could not be resolved at the case open time.",
            f"The total suspicious amount is ${st.episode.exposure_usd:,.2f}.",
            f"The activity was carried out in billing region(s) "
            f"{', '.join(sorted({t.region for t in (ctx.window_txns if ctx else []) if t.region and t.txn_id in set(st.episode.txn_ids)})) or 'unknown'}.",
            (f"It is suspicious because {st.pattern.value.replace('_', ' ')} was identified, "
             f"supported by {st.n_independent_signals} independent evidence "
             f"{'axis' if st.n_independent_signals == 1 else 'axes'}."),
            (f"The shared element {st.flags.shared_element} links this card to other "
             f"customers, indicating a common actor." if st.flags.shared_origin else
             f"No shared device, region or recipient email links this activity to other cards."),
            (f"Similar closed cases {', '.join(st.similar_prior_cases)} were retrieved and "
             f"used as prior art." if st.similar_prior_cases else
             "No similar closed cases were retrieved."),
        ])

    # ------------------------------------------------------------------ emit
    def _emit(self, st: Investigation) -> dict:
        return {
            "case_id": st.case_id,
            "case": {
                "status": st.status,
                "verdict": st.verdict,
                "fraud_probability": round(st.fraud_probability, 3),
                "pattern": st.pattern.value,
                "pattern_description": st.pattern_description if st.pattern is Pattern.UNDOCUMENTED else "",
                "affected_txn_ids": st.episode.txn_ids,
                "first_suspicious_txn_id": st.episode.first_suspicious_txn_id,
                "connected_card_ids": sorted({
                    c for c in (list(getattr(st.ctx, "device_cards", []))
                                + list(getattr(st.ctx, "region_cards", []))
                                + list(getattr(st.ctx, "ring", None).card_ids if getattr(st.ctx, "ring", None) else []))
                    if c != st.card_id}),
                "connected_device_profiles": (
                    [st.ctx.flagged.device_id] if st.has_device and st.ctx.flagged.device_id else []),
                "exposure_usd": round(st.episode.exposure_usd, 2),
                "evidence": [
                    {"claim": e.claim, "source": e.source.value, "ref": e.ref,
                     "entity_ids": e.entity_ids}
                    for e in st.evidence
                ],
                "similar_prior_cases": st.similar_prior_cases,
                "summary": getattr(st, "summary_text", ""),
                "written_to_graph": st.written_to_graph,
                "graph_case_id": st.graph_case_id,
            },
            "evidence_requests": [
                {"type": r.type.value, "asked_after_step": r.asked_after_step,
                 "assumed_response": r.assumed_response}
                for r in st.evidence_requests
            ],
            "next_best_actions": {
                "initial": [{"action": a.action.value, "route": a.route.value,
                             "reason": a.reason} for a in st.initial_actions],
                "final": [{"action": a.action.value, "route": a.route.value,
                           "reason": a.reason} for a in st.final_actions],
                "what_changed": st.what_changed,
            },
            "sar": {
                "file": st.sar.file,
                "reason": st.sar.reason,
                "narrative": st.sar.narrative,
                "subjects": st.sar.subjects,
                "total_amount_usd": round(st.sar.total_amount_usd, 2),
                "activity_dates": st.sar.activity_dates,
            },
            "stop_reason": st.stop_reason,
            "tool_calls": st.tool_calls,
            "tokens": st.tokens,
            "latency_s": st.latency_s,
            "_expected_exposure_usd": round(st.episode.exposure_usd, 2),
        }


# --------------------------------------------------------------------------- helpers
def _mk_hypothesis(item: dict):
    from ..domain.models import Hypothesis
    from ..domain.enums import Pattern as P
    try:
        pat = P(item.get("pattern"))
    except Exception:
        pat = P.NONE
    return Hypothesis(pattern=pat, rationale=str(item.get("rationale", "")),
                      probes=list(item.get("probes") or []),
                      prior=float(item.get("prior", 0.5) or 0.5))


def _sar_from(st: Investigation, d) -> object:
    from ..domain.models import SAR
    if not d.file_sar:
        return SAR(file=False, reason=st.sar.reason or "§3a conditions not met.")
    dates = sorted({t.ts.date().isoformat()
                    for t in (st.ctx.window_txns if st.ctx else [])
                    if t.txn_id in set(st.episode.txn_ids)})
    # Subjects are IDs of customers, cards and DEVICES named in the narrative
    # (docs/ANSWER_SCHEMA.md §3). Billing regions and email domains are not
    # entities in the registry — emitting them fails validator check #2.
    subjects = sorted({st.customer_id, st.card_id}
                      | ({st.ctx.flagged.device_id}
                         if st.has_device and st.ctx.flagged.device_id else set()))
    reason_bits = []
    if st.episode.exposure_usd > 1_000:
        reason_bits.append(f"exposure ${st.episode.exposure_usd:,.2f} exceeds $1,000")
    if st.flags.shared_origin:
        reason_bits.append(f"shared {st.flags.shared_element}")
    if st.flags.cross_customer:
        reason_bits.append("connected to another customer's fraud")
    if st.pattern is Pattern.UNDOCUMENTED:
        reason_bits.append("undocumented coordinated pattern (R9)")
    return SAR(
        file=True,
        reason="§3a: " + "; ".join(reason_bits),
        subjects=subjects,
        total_amount_usd=round(st.episode.exposure_usd, 2),
        activity_dates=[dates[0], dates[-1]] if dates else [],
    )


def _status_from(st: Investigation, d) -> str:
    if st.verdict == Verdict.FRAUD.value:
        return CaseStatus.CLOSED_FRAUD.value
    if st.verdict == Verdict.LEGITIMATE.value:
        return CaseStatus.CLOSED_LEGITIMATE.value
    if any(a.action.value == "ESCALATE_TO_ANALYST" for a in st.final_actions):
        return CaseStatus.ESCALATED.value
    return CaseStatus.OPEN.value
