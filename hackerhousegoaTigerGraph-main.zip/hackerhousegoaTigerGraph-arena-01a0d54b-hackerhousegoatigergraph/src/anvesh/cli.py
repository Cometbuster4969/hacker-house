"""Command line entry point.

    anvesh demo-build                 # generate a synthetic dataset
    anvesh run --all                  # investigate every case
    anvesh validate                   # the 15 answer-file checks
    anvesh backtest                   # honest accuracy/calibration numbers
    anvesh gsql-out                   # write graph/*.gsql for TigerGraph
    anvesh serve                      # analyst workstation (replay only)
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
CASES = ROOT / "cases"
TRACES = ROOT / "traces"
BENCH = ROOT / "benchmark"


def _write_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, default=str))


def cmd_demo_build(args) -> int:
    from .data.synthetic import generate
    from .graph.memory_adapter import MemoryAdapter
    from .util.ids import IdRegistry

    data = generate(n_customers=args.customers, seed=args.seed)
    adapter = MemoryAdapter(data.txns, data.closed_cases)
    registry = IdRegistry.from_adapter(adapter)

    out = ROOT / "data" / "synthetic"
    out.mkdir(parents=True, exist_ok=True)
    _write_json(out / "meta.json", {
        "n_txns": len(data.txns),
        "n_closed_cases": len(data.closed_cases),
        "n_cases": len(data.case_pack),
        "scenario_of": data.scenario_of,
        "note": "SYNTHETIC. Real dataset goes in data/ per docs/SETUP.md.",
    })
    print(f"transactions : {len(data.txns):,}")
    print(f"closed cases : {len(data.closed_cases):,}")
    print(f"case pack    : {len(data.case_pack)}")
    print(f"registry ids : {len(registry._all):,}")
    print(f"written to   : {out}")
    return 0


def _load_real(data_dir: str):
    """Real CSVs -> SimpleNamespace(case_pack, closed_cases, txns|None later).

    Returns (data_without_txns, cfg). Transaction loading is the caller's
    choice: full load for memory mode, id-scan only for tigergraph mode.
    """
    from types import SimpleNamespace

    from .data.loader import LoadConfig, load_closed_cases, load_pack

    cfg = LoadConfig.from_env(data_dir)
    pack = load_pack(cfg.data_dir / "case_pack.csv")
    closed = load_closed_cases(cfg.data_dir / "closed_cases_history.csv")
    print(f"[data] {cfg.data_dir}: pack={len(pack)} closed={len(closed)}")
    return SimpleNamespace(case_pack=pack, closed_cases=closed, txns=[]), cfg


def _build(args):
    """Build (data, adapter, registry, table, closer) for the chosen mode.

    - memory + synthetic (default): offline dev/demo
    - memory + --data-dir: real CSVs fully loaded (~4 GB RAM)
    - tigergraph + --data-dir: graph reads via MCP; CSVs give pack/closed/ids
    """
    from .reasoning.fit import fit_table
    from .util.ids import IdRegistry

    adapter_name = getattr(args, "adapter", "memory")
    data_dir = getattr(args, "data_dir", None)
    closer = None

    if data_dir:
        from .data.loader import load_transactions, scan_ids, validate_pack

        data, cfg = _load_real(data_dir)
        if adapter_name == "tigergraph":
            from .graph.tigergraph_adapter import connect

            client, adapter = connect(
                graph_name=os.getenv("TG_GRAPHNAME") or None)
            closer = client.close
            print("[graph] connected via tigergraph-mcp "
                  f"(graph={os.getenv('TG_GRAPHNAME')})")
            registry = scan_ids(cfg)
            validate_pack(data.case_pack, registry)
        else:
            from .graph.memory_adapter import MemoryAdapter

            txns: list = []
            for batch in load_transactions(cfg, progress=True):
                txns.extend(batch)
            print(f"[data] {len(txns):,} transactions in memory")
            data.txns = txns
            adapter = MemoryAdapter(data.txns, data.closed_cases)
            registry = IdRegistry.from_adapter(adapter)
            validate_pack(data.case_pack, registry)
    else:
        if adapter_name == "tigergraph":
            raise SystemExit("--adapter tigergraph requires --data-dir "
                             "(case_pack + closed cases come from CSVs)")
        from .data.synthetic import generate
        from .graph.memory_adapter import MemoryAdapter

        data = generate(n_customers=args.customers, seed=args.seed)
        adapter = MemoryAdapter(data.txns, data.closed_cases)
        registry = IdRegistry.from_adapter(adapter)

    table, n = fit_table(adapter, data.closed_cases, limit=args.fit_limit)
    print(f"[fit] likelihood table fitted on {n} closed cases "
          f"({'fitted' if table.is_fitted() else 'NEUTRAL - not enough labels'})")
    return data, adapter, registry, table, closer


def cmd_run(args) -> int:
    data, adapter, registry, table, closer = _build(args)
    try:
        return _cmd_run_inner(args, data, adapter, registry, table)
    finally:
        if closer is not None:
            closer()


def _cmd_run_inner(args, data, adapter, registry, table) -> int:
    from .agent.investigator import Investigator
    from .llm.client import get_llm

    llm = get_llm()
    inv = Investigator(adapter, registry, table=table, llm=llm)

    rows = data.case_pack
    if args.case:
        rows = [r for r in rows if r.case_id == args.case]
        if not rows:
            print(f"no such case: {args.case}", file=sys.stderr)
            return 1

    ok = 0
    for row in rows:
        answer, st = inv.run(row)
        # strip the internal field used only by validator check #3
        answer.pop("_expected_exposure_usd", None)
        _write_json(CASES / f"{row.case_id}.json", answer)
        _write_json(TRACES / f"{row.case_id}.json", {
            "case_id": st.case_id,
            "as_of": st.as_of.isoformat() if st.as_of else None,
            "events": [{"seq": e.seq, "node": e.node, "kind": e.kind, **e.detail}
                       for e in st.trace],
        })
        rep = _validate_one(answer, registry)
        ok += int(rep.passed)
        flag = "PASS" if rep.passed else "FAIL"
        print(f"  {flag}  {row.case_id}  p={answer['case']['fraud_probability']:.2f}  "
              f"verdict={answer['case']['verdict']:<10} pattern={answer['case']['pattern']:<28} "
              f"exposure=${answer['case']['exposure_usd']:>9,.2f}  "
              f"actions={len(answer['next_best_actions']['final'])}")
        for e in rep.errors:
            print(f"        ERROR {e}")
    print(f"\n{ok}/{len(rows)} cases passed validation")
    return 0 if ok == len(rows) else 1


def _validate_one(answer, registry):
    from .validate.checks import validate
    return validate(answer, registry)


def cmd_validate(args) -> int:
    from .util.ids import IdRegistry

    data, adapter, registry, table, closer = _build(args)
    try:
        files = sorted(CASES.glob("HHG-*.json"))
        if not files:
            print("no answer files in cases/ — run `anvesh run --all` first",
                  file=sys.stderr)
            return 1
        from .validate.checks import validate
        n_ok = 0
        for f in files:
            answer = json.loads(f.read_text())
            rep = validate(answer, registry)
            n_ok += int(rep.passed)
            print(f"  {'PASS' if rep.passed else 'FAIL'}  {f.name}")
            for e in rep.errors:
                print(f"        ERROR {e}")
            for w in rep.warnings:
                print(f"        warn  {w}")
        print(f"\n{n_ok}/{len(files)} files passed")
        return 0 if n_ok == len(files) else 1
    finally:
        if closer is not None:
            closer()


def cmd_backtest(args) -> int:
    """Honest measurement on held-out closed cases (docs/BACKTEST.md)."""
    from .data.synthetic import generate
    from .graph.memory_adapter import MemoryAdapter
    from .reasoning.fit import context_for_closed_case, episode_from_closed_case
    from .reasoning.priors import prior_for
    from .reasoning.scorer import score
    from .evidence.features import build_features
    from .util.ids import IdRegistry
    from .domain.enums import TriggerType
    import random

    if getattr(args, "adapter", "memory") == "tigergraph":
        raise SystemExit("backtest is memory-only — it measures the model, not "
                         "the transport. Use --data-dir with the memory adapter.")
    if getattr(args, "data_dir", None):
        from .data.loader import load_transactions

        data, cfg = _load_real(args.data_dir)
        txns: list = []
        for batch in load_transactions(cfg, progress=True):
            txns.extend(batch)
        data.txns = txns
        print(f"[data] {len(txns):,} transactions in memory")
    else:
        data = generate(n_customers=args.customers, seed=args.seed)
    adapter = MemoryAdapter(data.txns, data.closed_cases)

    rng = random.Random(7)
    cases = list(data.closed_cases)
    rng.shuffle(cases)
    cut = int(len(cases) * 0.6)
    cut2 = int(len(cases) * 0.8)
    train, cal, ev = cases[:cut], cases[cut:cut2], cases[cut2:]

    from .reasoning.fit import fit_table
    table, n = fit_table(adapter, train)
    print(f"[split] train={len(train)} cal={len(cal)} eval={len(ev)} "
          f"(fitted on {n} rows, table={'fitted' if table.is_fitted() else 'NEUTRAL'})")

    def evaluate(subset, trigger: str) -> dict:
        rows, ys, ps = [], [], []
        for c in subset:
            ctx = context_for_closed_case(adapter, c)
            if ctx is None:
                continue
            if trigger == "random" and c.txn_ids:
                # honest arm: sample the flagged transaction at random
                pick = rng.choice(c.txn_ids)
                t = adapter.txn_context(c.opened_at, pick)
                if t is None:
                    continue
                ctx = type(ctx)(**{**vars(ctx), "flagged_txn_id": pick, "flagged": t})
            ep = episode_from_closed_case(adapter, c)
            f = build_features(ctx, ep)
            p, _ = score(f, table, prior_for(TriggerType.RISK_SCORE, None))
            rows.append(p >= 0.5)
            ys.append(c.outcome == "confirmed_fraud")
            ps.append(p)
        if not ys:
            return {}
        tp = sum(1 for a, b in zip(rows, ys) if a and b)
        tn = sum(1 for a, b in zip(rows, ys) if not a and not b)
        acc = (tp + tn) / len(ys)
        brier = sum((p - float(y)) ** 2 for p, y in zip(ps, ys)) / len(ys)
        try:
            from sklearn.metrics import roc_auc_score
            auc = roc_auc_score([int(y) for y in ys], ps) if len(set(ys)) > 1 else float("nan")
        except Exception:
            auc = float("nan")
        return {"n": len(ys), "accuracy": round(acc, 3),
                "brier": round(brier, 3), "auc": round(auc, 3)}

    onset = evaluate(ev, "onset")
    random_arm = evaluate(ev, "random")
    print("\n  arm              n     accuracy   brier    auc")
    for name, r in (("onset (upper)", onset), ("random (honest)", random_arm)):
        if r:
            print(f"  {name:<16} {r['n']:<5}  {r['accuracy']:<9}  {r['brier']:<7}  {r['auc']}")
    BENCH.mkdir(parents=True, exist_ok=True)
    _write_json(BENCH / "backtest.json", {"onset": onset, "random": random_arm})
    print(f"\nwritten to {BENCH/'backtest.json'}")
    return 0


def cmd_verify(args) -> int:
    """Live-instance checklist — docs/SETUP.md section 7, executable.

    Requires TG_* in the environment and --data-dir for the as_of probe
    (it needs a real card id; a probe against a nonexistent card proves
    nothing because it returns empty either way).
    """
    from datetime import datetime

    from .graph.mcp_client import ALLOWED_QUERIES, MCPError
    from .graph.tigergraph_adapter import connect

    failures = 0

    def check(name: str, ok: bool, detail: str = "") -> None:
        nonlocal failures
        failures += 0 if ok else 1
        print(f"  {'PASS' if ok else 'FAIL'}  {name}"
              + (f" — {detail}" if detail else ""))

    try:
        client, adapter = connect(graph_name=os.getenv("TG_GRAPHNAME") or None)
    except MCPError as e:
        print(f"cannot connect: {e}", file=sys.stderr)
        return 1
    try:
        try:
            data = client.call("list_graphs", {})
            want = os.getenv("TG_GRAPHNAME", "")
            check("graph reachable", (not want) or (want in str(data)),
                  f"graphs: {str(data)[:160]}")
        except Exception as e:
            check("graph reachable", False, str(e)[:160])

        for q in sorted(ALLOWED_QUERIES):
            try:
                check(f"installed: {q}", adapter.is_query_installed(q))
            except Exception as e:
                check(f"installed: {q}", False, str(e)[:120])

        for vtype, expected in (("Transaction", 590_742),
                                ("ClosedCase", 5_565)):
            try:
                n = adapter.vertex_count(vtype)
                check(f"count({vtype})", n == expected,
                      f"{n:,}" + ("" if n == expected
                                  else f" (expected {expected:,})"))
            except Exception as e:
                check(f"count({vtype})", False, str(e)[:120])

        if getattr(args, "data_dir", None):
            from .data.loader import load_pack

            pack = load_pack(Path(args.data_dir) / "case_pack.csv")
            card = pack[0].card_id if pack else ""
            try:
                rows = adapter.card_window(datetime(2016, 1, 1), card, 48)
                check("as_of isolation", rows == [],
                      f"card_window(2016-01-01, {card}) -> {len(rows)} rows")
            except Exception as e:
                check("as_of isolation", False, str(e)[:160])
        else:
            print("  SKIP  as_of isolation — needs --data-dir (a real card id)")

        print(f"\n{'all checks passed' if failures == 0 else f'{failures} check(s) FAILED'}")
        return 0 if failures == 0 else 1
    finally:
        client.close()


def cmd_gsql_out(args) -> int:
    from .graph.gsql import write_gsql
    out = write_gsql(ROOT / "graph")
    print(f"GSQL written to {out} — VERIFY SYNTAX before installing.")
    return 0


def cmd_serve(args) -> int:
    """Serve the frozen replay.

    Zero-dependency: renders demo/index.html from cases/ and traces/ and serves
    it with the stdlib. Streamlit is a nicer workstation but it is not needed
    to review an investigation, and the demo must survive a Savanna auto-stop.
    """
    import functools
    import http.server
    import socketserver

    from .ui.replay import write_html

    page = write_html(ROOT / "demo" / "index.html")
    port = int(getattr(args, "port", 8000) or 8000)

    class Handler(http.server.SimpleHTTPRequestHandler):
        def __init__(self, *a, **kw):
            super().__init__(*a, directory=str(page.parent), **kw)

        def log_message(self, *_):
            pass

    class Server(socketserver.ThreadingTCPServer):
        allow_reuse_address = True
        daemon_threads = True

    with Server(("0.0.0.0", port), Handler) as httpd:
        print(f"replay served on http://0.0.0.0:{port}/index.html")
        print(f"regenerate with: anvesh run --all && anvesh serve")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            pass
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="anvesh", description=__doc__.split("\n")[1])
    sub = p.add_subparsers(dest="cmd", required=True)

    def common(sp):
        sp.add_argument("--customers", type=int, default=60)
        sp.add_argument("--seed", type=int, default=20260924)
        sp.add_argument("--fit-limit", type=int, default=None)
        sp.add_argument("--adapter", choices=["memory", "tigergraph"],
                        default="memory")
        sp.add_argument("--data-dir", default=None,
                        help="HHGOA_IEEE folder (transactions.csv, identity.csv, "
                             "closed_cases_history.csv, case_pack.csv)")

    s = sub.add_parser("demo-build"); common(s); s.set_defaults(fn=cmd_demo_build)
    s = sub.add_parser("run"); common(s)
    s.add_argument("--case", default=None); s.add_argument("--all", action="store_true")
    s.set_defaults(fn=cmd_run)
    s = sub.add_parser("validate"); common(s); s.set_defaults(fn=cmd_validate)
    s = sub.add_parser("backtest"); common(s); s.set_defaults(fn=cmd_backtest)
    s = sub.add_parser("verify")
    s.add_argument("--data-dir", default=None)
    s.set_defaults(fn=cmd_verify)
    s = sub.add_parser("gsql-out"); s.set_defaults(fn=cmd_gsql_out)
    s = sub.add_parser("serve")
    s.add_argument("--port", type=int, default=8000)
    s.set_defaults(fn=cmd_serve)
    return p


def main() -> int:
    args = build_parser().parse_args()
    return args.fn(args)


if __name__ == "__main__":
    raise SystemExit(main())
