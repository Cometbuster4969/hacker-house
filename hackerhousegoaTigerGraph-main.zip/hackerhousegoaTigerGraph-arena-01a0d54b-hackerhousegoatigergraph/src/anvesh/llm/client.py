"""LLM access. Provider-agnostic, temperature 0, always optional.

Supports OpenRouter (recommended for high throughput/reliability), Google AI Studio,
or any OpenAI-compatible chat completions endpoint.

Two nodes use it (docs/STATE.md §2): hypothesis generation and explanation.
If no provider is configured, template fallbacks run instead — the pipeline
never hard-depends on an API (NFR: deterministic replay must be possible).
"""

from __future__ import annotations

import json
import os
from typing import Any


class LLMError(RuntimeError):
    pass


class NullLLM:
    """No model configured. Every call raises; callers fall back to templates."""

    available = False

    def complete(self, system: str, user: str, schema: type | None = None,
                 temperature: float = 0.0) -> Any:
        raise LLMError("no LLM provider configured")


def _extract_json(text: str) -> Any:
    """Extract JSON object from string, tolerating markdown fences and wrappers."""
    text = text.strip()
    # Strip markdown ```json ... ``` code fence
    if text.startswith("```"):
        lines = text.splitlines()
        if lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].startswith("```"):
            lines = lines[:-1]
        text = "\n".join(lines).strip()

    try:
        return json.loads(text)
    except Exception:
        first_brace = text.find("{")
        last_brace = text.rfind("}")
        if first_brace != -1 and last_brace != -1 and last_brace > first_brace:
            return json.loads(text[first_brace : last_brace + 1])
        raise


class OpenAICompatLLM:
    """Talks to OpenRouter or any OpenAI-compatible chat-completions endpoint."""

    available = True

    def __init__(self, model: str | None = None, base_url: str | None = None,
                 api_key: str | None = None, provider: str = "openrouter") -> None:
        self.provider = provider
        self.api_key = api_key or os.getenv("OPENROUTER_API_KEY") or os.getenv("LLM_API_KEY", "")
        self.base_url = (base_url or os.getenv("LLM_BASE_URL", "")).rstrip("/")
        if not self.base_url:
            if self.provider == "openrouter":
                self.base_url = "https://openrouter.ai/api/v1"
            else:
                self.base_url = "https://generativelanguage.googleapis.com/v1beta/openai"

        if model:
            self.model = model
        elif os.getenv("LLM_MODEL"):
            self.model = os.getenv("LLM_MODEL", "")
        elif self.provider == "openrouter":
            self.model = "meta-llama/llama-3.3-70b-instruct"
        else:
            self.model = "gemini-2.5-flash"

        self.timeout = int(os.getenv("LLM_TIMEOUT", "45"))

    def complete(self, system: str, user: str, schema: type | None = None,
                 temperature: float = 0.0) -> Any:
        import urllib.error
        import urllib.request

        payload: dict[str, Any] = {
            "model": self.model,
            "temperature": temperature,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
        }
        if schema is not None:
            payload["response_format"] = {"type": "json_object"}

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}",
            "HTTP-Referer": "https://github.com/nickkerDroid/hackerhousegoaTigerGraph",
            "X-Title": "Anvesh Fraud Agent",
        }

        url = f"{self.base_url}/chat/completions"
        data = json.dumps(payload).encode()
        req = urllib.request.Request(url, data=data, headers=headers)

        body = None
        for attempt in range(3):
            try:
                with urllib.request.urlopen(req, timeout=self.timeout) as r:
                    body = json.loads(r.read().decode())
                break
            except urllib.error.HTTPError as e:
                err_body = e.read().decode(errors="replace")
                # Retry transient server or rate-limit errors
                if e.code in (429, 500, 502, 503, 504) and attempt < 2:
                    time.sleep(2 * (attempt + 1))
                    continue
                # If response_format caused 400 on models without strict json mode, retry once without it
                if schema is not None and "response_format" in err_body:
                    payload.pop("response_format", None)
                    req_retry = urllib.request.Request(url, data=json.dumps(payload).encode(), headers=headers)
                    try:
                        with urllib.request.urlopen(req_retry, timeout=self.timeout) as r:
                            body = json.loads(r.read().decode())
                        break
                    except Exception as retry_err:
                        raise LLMError(f"HTTP {e.code} from {self.base_url}: {err_body}") from retry_err
                raise LLMError(f"HTTP {e.code} from {self.base_url}: {err_body}") from e
            except Exception as e:
                if attempt < 2:
                    time.sleep(2 * (attempt + 1))
                    continue
                raise LLMError(f"Connection to {self.base_url} failed: {e}") from e

        if not body or "choices" not in body or not body["choices"]:
            raise LLMError(f"Empty or malformed response from {self.base_url}")

        text = body["choices"][0]["message"]["content"]
        if schema is not None:
            return _extract_json(text)
        return text


def _load_env() -> None:
    """Best-effort auto-loading of .env from current working dir or repo root."""
    from pathlib import Path

    candidates = [
        Path.cwd() / ".env",
        Path(__file__).resolve().parents[3] / ".env",
    ]
    for dot in candidates:
        if dot.is_file():
            try:
                for line in dot.read_text(encoding="utf-8").splitlines():
                    line = line.strip()
                    if not line or line.startswith("#") or "=" not in line:
                        continue
                    k, v = line.split("=", 1)
                    os.environ.setdefault(k.strip(), v.strip().strip("'\""))
                break
            except Exception:
                pass


def get_llm():
    """Return configured OpenRouter or OpenAI-compatible client, or NullLLM."""
    _load_env()
    api_key = (os.getenv("OPENROUTER_API_KEY") or os.getenv("LLM_API_KEY") or "").strip()
    if not api_key:
        return NullLLM()

    raw_provider = os.getenv("LLM_PROVIDER", "").lower()
    base_url = os.getenv("LLM_BASE_URL", "").strip()

    is_openrouter = (
        raw_provider == "openrouter"
        or api_key.startswith("sk-or-")
        or "openrouter.ai" in base_url
        or "OPENROUTER_API_KEY" in os.environ
    )

    provider = "openrouter" if is_openrouter else ("gemini" if raw_provider == "gemini" else "openai")

    try:
        client = OpenAICompatLLM(api_key=api_key, provider=provider)
        print(f"[llm] Configured {provider.upper()} client (model={client.model})")
        return client
    except Exception as e:
        print(f"[llm] Failed to initialize LLM client: {e}")
        return NullLLM()
