"""Anvesh — agentic fraud investigation and next-best-action on TigerGraph."""
__version__ = "0.1.0"
