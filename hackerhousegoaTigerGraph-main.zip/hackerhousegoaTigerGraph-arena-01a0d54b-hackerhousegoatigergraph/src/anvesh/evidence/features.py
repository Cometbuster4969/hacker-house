"""The feature vector — identical construction for closed cases and benchmark cases.

docs/UNCERTAINTY.md §3. Every feature is computed as of `as_of`.
"""

from __future__ import annotations

import math
from datetime import timedelta

from ..domain.enums import EvidenceAxis
from ..domain.models import EvidenceContext, Episode

# Which axis each feature belongs to. Independence counting (docs/STATE.md §4.2)
# works on axes, so a feature must declare one.
AXIS_OF: dict[str, EvidenceAxis] = {
    "n_txns_1h": EvidenceAxis.VELOCITY,
    "n_txns_24h": EvidenceAxis.VELOCITY,
    "burst_ratio": EvidenceAxis.VELOCITY,
    "amount_z": EvidenceAxis.AMOUNT,
    "max_mean_ratio": EvidenceAxis.AMOUNT,
    "n_small_auths": EvidenceAxis.AMOUNT,
    "device_new": EvidenceAxis.DEVICE,
    "device_card_degree": EvidenceAxis.DEVICE,
    "has_proxy": EvidenceAxis.DEVICE,
    "n_regions_24h": EvidenceAxis.GEOGRAPHY,
    "geo_velocity_max": EvidenceAxis.GEOGRAPHY,
    "region_novelty": EvidenceAxis.GEOGRAPHY,
    "channel_mix_shift": EvidenceAxis.CHANNEL,
    "m_flag_anomalies": EvidenceAxis.CHANNEL,
    "v_anom": EvidenceAxis.MODEL_RESIDUAL,
    "ring_size": EvidenceAxis.GRAPH,
    "shared_origin_degree": EvidenceAxis.GRAPH,
    "similar_case_max": EvidenceAxis.MEMORY,
}

FEATURE_NAMES: tuple[str, ...] = tuple(AXIS_OF)


def _safe_div(a: float, b: float) -> float:
    return a / b if b else 0.0


def build_features(ctx: EvidenceContext, ep: Episode) -> dict[str, float]:
    txns = [t for t in ctx.window_txns if t.ts <= ctx.as_of]
    f: dict[str, float] = {k: 0.0 for k in FEATURE_NAMES}

    if not txns:
        return f

    flagged = ctx.flagged
    now = ctx.as_of

    counts_1h = sum(1 for t in txns if now - t.ts <= timedelta(hours=1))
    counts_24h = sum(1 for t in txns if now - t.ts <= timedelta(hours=24))
    baseline_rate = _safe_div(ctx.baseline.n_txns, 30.0) or 1.0

    f["n_txns_1h"] = float(counts_1h)
    f["n_txns_24h"] = float(counts_24h)
    f["burst_ratio"] = round(_safe_div(counts_24h, baseline_rate * 1.0), 3)

    amounts = [t.amount for t in txns]
    f["amount_z"] = round(ctx.baseline.amount_z(flagged.amount) if flagged else 0.0, 3)
    f["max_mean_ratio"] = round(_safe_div(max(amounts), (sum(amounts) / len(amounts)) or 1.0), 3)
    f["n_small_auths"] = float(sum(1 for a in amounts if a < 5.0))

    # Device — guarded: in-person transactions have no device record.
    if ctx.has_device and flagged is not None:
        f["device_new"] = 1.0 if flagged.device_new else 0.0
        f["device_card_degree"] = float(len(ctx.device_cards))
        f["has_proxy"] = 1.0 if flagged.proxy else 0.0

    regions = {t.region for t in txns if t.region}
    f["n_regions_24h"] = float(len({
        t.region for t in txns if t.region and now - t.ts <= timedelta(hours=24)
    }))
    f["region_novelty"] = 1.0 if (flagged and ctx.baseline.region_novelty(flagged.region)) else 0.0
    f["geo_velocity_max"] = round(
        max([p.minutes and _safe_div(1.0, max(p.minutes, 0.001)) * 60.0
             for p in ctx.geo_pairs] or [0.0]), 3)

    chan_online = sum(1 for t in txns if t.channel.value == "online")
    f["channel_mix_shift"] = round(abs(_safe_div(chan_online, len(txns)) - 0.5) * 2.0, 3)
    f["m_flag_anomalies"] = float(flagged.m_flags if flagged else 0)

    f["v_anom"] = round(flagged.v_anom if flagged else 0.0, 4)

    f["ring_size"] = float(ctx.ring.size) if ctx.ring else 0.0
    f["shared_origin_degree"] = float(max(
        len(ctx.device_cards), len(ctx.region_cards), len(ctx.email_cards)))
    f["similar_case_max"] = round(min(1.0, len(ctx.similar_cases) / 5.0), 3)

    return {k: (0.0 if (isinstance(v, float) and (math.isnan(v) or math.isinf(v))) else v)
            for k, v in f.items()}


def fingerprint(ctx: EvidenceContext, ep: Episode) -> list[float]:
    """Behavioural fingerprint for memory retrieval. NOT an embedding —
    12 hand-built, stable, interpretable floats (docs/UNCERTAINTY.md §6)."""
    f = build_features(ctx, ep)
    hour = ctx.as_of.hour / 24.0
    return [
        f["amount_z"],
        math.log1p(ep.exposure_usd),
        f["n_txns_24h"],
        f["device_new"],
        f["region_novelty"],
        f["channel_mix_shift"],
        f["geo_velocity_max"],
        math.sin(2 * math.pi * hour),
        math.cos(2 * math.pi * hour),
        f["v_anom"],
        f["ring_size"],
        f["shared_origin_degree"],
    ]
