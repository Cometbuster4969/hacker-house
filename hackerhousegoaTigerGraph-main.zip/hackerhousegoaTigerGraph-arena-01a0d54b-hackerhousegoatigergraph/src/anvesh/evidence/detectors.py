"""The five known fraud-pattern detectors.

Deterministic. They read an EvidenceContext that is already as_of-bounded and
never query the graph themselves (docs/QUERIES.md §4.3), so they are unit
testable without a database.

CHANNEL GUARD (AGENTS.md R5): identity.csv covers ONLINE transactions only.
ProductCD == "W" => in_person => no device record. Every device-using detector
must return early on in-person transactions.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from ..config import (
    AMOUNT_Z_THRESHOLD,
    BURST_MAX,
    BURST_MIN,
    BURST_WINDOW_H,
    GEO_VELOCITY_MAX_KMH,
    OUT_OF_REGION_MAX_DAYS,
    TESTING_LARGE_RATIO,
    TESTING_MIN_SMALL,
    TESTING_SMALL_MAX,
    TESTING_WINDOW_H,
)
from ..domain.enums import Channel, EvidenceAxis, Pattern
from ..domain.models import EvidenceContext


@dataclass
class DetectorResult:
    pattern: Pattern
    fired: bool = False
    confidence: float = 0.0        # 0-1. NOT a fraud probability.
    txn_ids: list[str] = field(default_factory=list)
    why: str = ""
    ref: str = ""
    axis: EvidenceAxis = EvidenceAxis.VELOCITY


def _fmt(ids: list[str], n: int = 6) -> str:
    return ", ".join(ids[:n]) + ("…" if len(ids) > n else "")


# ---------------------------------------------------------------------------
# 1. Card testing — >= 3 small online auths within an hour, then a larger purchase
# ---------------------------------------------------------------------------
def detect_card_testing(ctx: EvidenceContext) -> DetectorResult:
    r = DetectorResult(pattern=Pattern.CARD_TESTING,
                       ref=f"query:testing_sequence(card_id={ctx.card_id}, hours=1)",
                       axis=EvidenceAxis.VELOCITY)
    if ctx.channel is Channel.IN_PERSON:
        r.why = "in-person transaction: no online authorization sequence"
        return r

    smalls = [t for t in ctx.window_txns
              if t.amount < TESTING_SMALL_MAX and t.channel is Channel.ONLINE]
    if len(smalls) < TESTING_MIN_SMALL:
        return r

    # the smalls must cluster inside the testing window
    smalls_sorted = sorted(smalls, key=lambda t: t.ts)
    span_h = (smalls_sorted[-1].ts - smalls_sorted[0].ts).total_seconds() / 3600.0
    if span_h > TESTING_WINDOW_H * (len(smalls_sorted) - 1):
        return r

    small_mean = sum(t.amount for t in smalls_sorted) / len(smalls_sorted)
    later = [t for t in ctx.window_txns if t.ts > smalls_sorted[-1].ts]
    big = [t for t in later if t.amount >= max(small_mean * TESTING_LARGE_RATIO, 25.0)]
    if not big:
        return r

    target = big[0]
    r.fired = True
    r.txn_ids = [t.txn_id for t in smalls_sorted] + [target.txn_id]
    r.confidence = min(0.95, 0.55 + 0.08 * len(smalls_sorted))
    r.why = (f"{len(smalls_sorted)} online authorizations under ${TESTING_SMALL_MAX:.0f} "
             f"within {span_h:.1f}h, followed by a ${target.amount:,.2f} purchase "
             f"({target.amount / max(small_mean, 0.01):.0f}x the small amounts)")
    return r


# ---------------------------------------------------------------------------
# 2. Card-not-present fraud — a burst of 2-4 online txns that don't fit the card
# ---------------------------------------------------------------------------
def detect_cnp(ctx: EvidenceContext) -> DetectorResult:
    r = DetectorResult(pattern=Pattern.CARD_NOT_PRESENT_FRAUD,
                       ref=f"query:card_window(card_id={ctx.card_id}, hours=48)",
                       axis=EvidenceAxis.VELOCITY)
    if ctx.channel is Channel.IN_PERSON:
        return r

    recent = [t for t in ctx.window_txns if t.channel is Channel.ONLINE]
    if not (BURST_MIN <= len(recent) <= BURST_MAX):
        return r

    novel = [t for t in recent
             if ctx.baseline.product_novelty(t.product_cd) > 0
             or ctx.baseline.amount_z(t.amount) > AMOUNT_Z_THRESHOLD]
    if not novel:
        return r

    r.fired = True
    r.txn_ids = [t.txn_id for t in recent]
    r.confidence = min(0.75, 0.35 + 0.10 * len(novel))
    r.why = (f"{len(recent)} online transactions within {BURST_WINDOW_H}h; "
             f"{len(novel)} outside the cardholder's baseline "
             f"(novel product code or amount z > {AMOUNT_Z_THRESHOLD})")
    return r


# ---------------------------------------------------------------------------
# 3. CNP from a new device — as above, with the device marked New
# ---------------------------------------------------------------------------
def detect_cnp_new_device(ctx: EvidenceContext) -> DetectorResult:
    r = DetectorResult(pattern=Pattern.CARD_NOT_PRESENT_NEW_DEVICE,
                       ref=f"query:device_neighbors(device_id={ctx.flagged.device_id if ctx.flagged else '?'})",
                       axis=EvidenceAxis.DEVICE)
    if not ctx.has_device:
        r.why = "no device record (in-person transaction)"
        return r

    base = detect_cnp(ctx)
    if not base.fired:
        return r

    novelty = ctx.baseline.device_novelty(ctx.flagged.device_id)
    if not (ctx.flagged.device_new or novelty > 0):
        return r

    r.fired = True
    r.txn_ids = base.txn_ids
    r.confidence = min(0.90, base.confidence + 0.20 + (0.05 if ctx.flagged.proxy else 0.0))
    r.why = (base.why + f"; device {ctx.flagged.device_id} is new for this account"
             + (f" behind a {ctx.flagged.proxy} proxy" if ctx.flagged.proxy else ""))
    return r


# ---------------------------------------------------------------------------
# 4. Out-of-region use — clone, not a trip
# ---------------------------------------------------------------------------
def detect_out_of_region(ctx: EvidenceContext) -> DetectorResult:
    r = DetectorResult(pattern=Pattern.OUT_OF_REGION_USE,
                       ref=f"query:geo_velocity(card_id={ctx.card_id}, hours=48)",
                       axis=EvidenceAxis.GEOGRAPHY)
    if not ctx.geo_pairs:
        return r

    impossible = [p for p in ctx.geo_pairs
                  if p.from_region and p.to_region and p.from_region != p.to_region]
    if not impossible:
        return r

    novel = [t for t in ctx.window_txns
             if ctx.baseline.region_novelty(t.region) > 0]
    if not novel:
        return r

    # "Several days of purchases in one new region is a trip, not a clone."
    if novel:
        days = {(t.ts.date()) for t in novel}
        if len(days) > OUT_OF_REGION_MAX_DAYS:
            r.why = (f"{len(days)} separate days in a new region — consistent with travel, "
                     "not a cloned card")
            return r

    r.fired = True
    r.txn_ids = [t.txn_id for t in novel]
    r.confidence = min(0.80, 0.40 + 0.12 * len(novel))
    r.why = (f"{len(novel)} transactions in billing region(s) new to this card "
             f"({_fmt([t.region for t in novel if t.region], 3)}) over "
             f"{len({t.ts.date() for t in novel})} day(s), with normal activity continuing at home")
    return r


# ---------------------------------------------------------------------------
# 5. Account takeover — mixed channel + device/match anomalies
# ---------------------------------------------------------------------------
def detect_ato(ctx: EvidenceContext) -> DetectorResult:
    r = DetectorResult(pattern=Pattern.ACCOUNT_TAKEOVER,
                       ref=f"query:card_window(card_id={ctx.card_id}, hours=48)",
                       axis=EvidenceAxis.CHANNEL)

    channels = {t.channel for t in ctx.window_txns}
    if len(channels) < 2:
        return r

    anomalies = []
    if ctx.flagged and ctx.flagged.m_flags >= 2:
        anomalies.append(f"{ctx.flagged.m_flags} identity match-flag anomalies")
    if ctx.has_device and (ctx.flagged.device_new
                           or ctx.baseline.device_novelty(ctx.flagged.device_id) > 0):
        anomalies.append("new device")
    if ctx.flagged and ctx.flagged.proxy:
        anomalies.append(f"{ctx.flagged.proxy} proxy")
    if ctx.flagged and ctx.baseline.amount_z(ctx.flagged.amount) > AMOUNT_Z_THRESHOLD:
        anomalies.append(f"amount z={ctx.baseline.amount_z(ctx.flagged.amount):.1f}")

    if len(anomalies) < 2:
        return r

    r.fired = True
    r.txn_ids = [t.txn_id for t in ctx.window_txns if t.channel is not (ctx.flagged.channel if ctx.flagged else Channel.ONLINE)]
    r.confidence = min(0.85, 0.35 + 0.13 * len(anomalies))
    r.why = "mixed-channel activity inconsistent with the cardholder: " + "; ".join(anomalies)
    return r


DETECTORS = {
    Pattern.CARD_TESTING: detect_card_testing,
    Pattern.CARD_NOT_PRESENT_FRAUD: detect_cnp,
    Pattern.CARD_NOT_PRESENT_NEW_DEVICE: detect_cnp_new_device,
    Pattern.OUT_OF_REGION_USE: detect_out_of_region,
    Pattern.ACCOUNT_TAKEOVER: detect_ato,
}


def run_all(ctx: EvidenceContext) -> list[DetectorResult]:
    return [d(ctx) for d in DETECTORS.values()]
