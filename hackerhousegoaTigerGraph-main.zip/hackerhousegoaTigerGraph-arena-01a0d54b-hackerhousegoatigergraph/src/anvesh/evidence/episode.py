"""Episode segmentation — deciding where the fraud episode starts and stops.

This is the highest-blast-radius unsupervised step in the pipeline: exposure
feeds BLOCK_CARD routing ($2,500) and the SAR threshold ($1,000), so a boundary
error propagates straight into the action score (docs/ROADMAP.md G8).

Tuned on IoU against closed-case `txn_ids`, which are 5,565 free labelled
episodes (docs/BACKTEST.md §5).
"""

from __future__ import annotations

from datetime import timedelta

from ..config import (
    EPISODE_LAMBDA,
    EPISODE_MAX_SPAN_HOURS,
    EPISODE_SCORE_THRESHOLD,
)
from ..domain.models import Episode, EvidenceContext, Txn

# Weights for the per-transaction fraud score.
W_MODEL_RESIDUAL = 0.20
W_AMOUNT_Z = 0.20
W_DEVICE_NOVELTY = 0.20
W_REGION_NOVELTY = 0.15
W_PRODUCT_NOVELTY = 0.10
W_TIME_PROXIMITY = 0.15


def _sigmoid(x: float) -> float:
    if x >= 0:
        return 1.0 / (1.0 + pow(2.718281828459045, -x))
    e = pow(2.718281828459045, x)
    return e / (1.0 + e)


def score_txn(t: Txn, ctx: EvidenceContext) -> float:
    """How plausibly this transaction belongs to the fraud episode. 0..1."""
    s = W_MODEL_RESIDUAL * min(1.0, t.v_anom)
    s += W_AMOUNT_Z * min(1.0, abs(ctx.baseline.amount_z(t.amount)) / 4.0)
    s += W_DEVICE_NOVELTY * ctx.baseline.device_novelty(t.device_id)
    s += W_REGION_NOVELTY * ctx.baseline.region_novelty(t.region)
    s += W_PRODUCT_NOVELTY * ctx.baseline.product_novelty(t.product_cd)
    s += W_TIME_PROXIMITY * (0.5 if t.risk_score >= 0.7 else 0.0)
    return max(0.0, min(1.0, s))


def segment(
    ctx: EvidenceContext,
    seed_txn_ids: list[str],
    candidate_txns: list[Txn],
    max_span_hours: int = EPISODE_MAX_SPAN_HOURS,
    lam: float = EPISODE_LAMBDA,
    threshold: float = EPISODE_SCORE_THRESHOLD,
) -> Episode:
    """Grow an episode from seeds, then pick the contiguous window that maximises
    total score minus a sprawl penalty.

    Hard cap: no transaction with ts > as_of may ever enter the episode.
    """
    by_id = {t.txn_id: t for t in candidate_txns if t.ts <= ctx.as_of}
    seeds = [s for s in seed_txn_ids if s in by_id]
    if not seeds:
        # Fall back to the flagged transaction alone.
        if ctx.flagged is not None and ctx.flagged.ts <= ctx.as_of:
            seeds = [ctx.flagged.txn_id]
            by_id.setdefault(ctx.flagged.txn_id, ctx.flagged)
        else:
            return Episode()

    seed_times = [by_id[s].ts for s in seeds]
    anchor = min(seed_times)

    pool = sorted(
        (t for t in by_id.values()
         if anchor - timedelta(hours=max_span_hours) <= t.ts <= ctx.as_of),
        key=lambda t: t.ts,
    )
    if not pool:
        return Episode(txn_ids=sorted(seeds))

    scored = [(t, score_txn(t, ctx)) for t in pool]

    # Best contiguous window containing every seed: maximise sum(score) - lam*span_hours
    seed_set = set(seeds)
    best = None
    n = len(scored)
    for i in range(n):
        if scored[i][0].txn_id not in seed_set:
            continue
        for j in range(i, n):
            window = scored[i:j + 1]
            if not seed_set.issubset({t.txn_id for t, _ in window}):
                continue
            span_h = (window[-1][0].ts - window[0][0].ts).total_seconds() / 3600.0
            val = sum(s for _, s in window) - lam * span_h
            if best is None or val > best[0]:
                best = (val, window)

    if best is None:
        return Episode(txn_ids=sorted(seeds))

    window = best[1]
    # Include a transaction only if it earns its place, unless it is a seed.
    kept = [t for t, s in window if s >= threshold or t.txn_id in seed_set]

    ids = [t.txn_id for t in kept]
    exposure = round(sum(abs(t.amount) for t in kept), 2)
    first = kept[0].txn_id if kept else (sorted(seeds)[0] if seeds else "")

    return Episode(txn_ids=ids, first_suspicious_txn_id=first, exposure_usd=exposure)


def iou(predicted: list[str], actual: list[str]) -> float:
    p, a = set(predicted), set(actual)
    if not p and not a:
        return 1.0
    if not p or not a:
        return 0.0
    return len(p & a) / len(p | a)
