"""ID registry.

Every ID in an answer file must exist in the provided dataset.
"Made-up IDs score zero" — and a composed ID looks exactly like a real one,
so this is the only defence (AGENTS.md R4).
"""

from __future__ import annotations

import re


class IdRegistry:
    def __init__(self) -> None:
        self.txn: set[str] = set()
        self.card: set[str] = set()
        self.customer: set[str] = set()
        self.device: set[str] = set()
        self.case: set[str] = set()
        self._all: set[str] = set()

    def add_txn(self, *ids: str) -> None:
        self.txn.update(ids)
        self._all.update(ids)

    def add_card(self, *ids: str) -> None:
        self.card.update(ids)
        self._all.update(ids)

    def add_customer(self, *ids: str) -> None:
        self.customer.update(ids)
        self._all.update(ids)

    def add_device(self, *ids: str) -> None:
        self.device.update(ids)
        self._all.update(ids)

    def add_case(self, *ids: str) -> None:
        self.case.update(ids)
        self._all.update(ids)

    def knows(self, value: str) -> bool:
        return value in self._all

    def unknown(self, values) -> list[str]:
        return [v for v in values if v and v not in self._all]

    @classmethod
    def from_adapter(cls, adapter) -> "IdRegistry":
        r = cls()
        for t in getattr(adapter, "txns", []):
            r.add_txn(t.txn_id)
            r.add_card(t.card_id)
            r.add_customer(t.customer_id)
            if t.device_id:
                r.add_device(t.device_id)
        for cid in adapter.closed_case_ids():
            r.add_case(cid)
        for c in getattr(adapter, "closed_cases", {}).values():
            r.add_card(c.card_id)
            r.add_customer(c.customer_id)
        return r


_ABBREV = re.compile(
    r"\b(?:Mr|Mrs|Ms|Dr|Sr|Jr|St|Ave|Blvd|Co|Corp|Inc|Ltd|Natl|vs|etc|e\.g|i\.e)\.",
    re.IGNORECASE,
)
_DECIMAL = re.compile(r"(\d)\.(\d)")          # 3.14, $526.42, 2016.11
_INITIAL = re.compile(r"(?:^|(?<=\s))([A-Z])\.(?=[A-Z]\.)")  # U.S.
_SENT_SPLIT = re.compile(r"[.!?]+(?:\s+|$)")


def count_sentences(text: str) -> int:
    """Count sentences without splitting inside numbers or abbreviations.

    The naive regex counted every period, so a summary like "...exposure of
    $526.42, supported by..." scored 7 sentences for 4 written. This version
    protects decimals, initials and common abbreviations before splitting.
    """
    if not text or not text.strip():
        return 0
    masked = _ABBREV.sub(lambda m: m.group(0).replace(".", "<DOT>"), text)
    masked = _DECIMAL.sub(r"\1<DOT>\2", masked)
    masked = _INITIAL.sub(r"\1<DOT>", masked)
    parts = [p for p in (s.strip() for s in _SENT_SPLIT.split(masked)) if p]
    return len(parts)
