"""Replay — render frozen traces as if live.

docs/UI.md §1 contract:
  1. Inputs are ONLY traces/<case_id>.json and cases/<case_id>.json.
  2. A trace is complete — no recomputation at render time.
  3. Rendering is deterministic — same inputs, same output, every time.

No network, no graph, no LLM. This is what makes the demo recordable when
Savanna's free tier has auto-stopped the database.
"""

from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]   # src/anvesh/ui/ -> repo root
TRACES = ROOT / "traces"
CASES = ROOT / "cases"


def load(case_id: str, traces_dir: Path = TRACES,
         cases_dir: Path = CASES) -> dict | None:
    """Read one frozen case. Returns None if either artifact is missing."""
    tp, ap = traces_dir / f"{case_id}.json", cases_dir / f"{case_id}.json"
    if not (tp.exists() and ap.exists()):
        return None
    return {"answer": json.loads(ap.read_text()), "trace": json.loads(tp.read_text())}


def available(cases_dir: Path = CASES) -> list[str]:
    return sorted(p.stem for p in cases_dir.glob("HHG-*.json"))


# ---------------------------------------------------------------------------
# Static HTML. Zero dependencies, so it renders anywhere — including the
# submission repo and an offline screen recording.
# ---------------------------------------------------------------------------

_CSS = """
:root{--bg:#0e1117;--panel:#161b22;--line:#30363d;--fg:#e6edf3;--dim:#8b949e;
--fraud:#f85149;--legit:#3fb950;--unc:#d29922;--accent:#58a6ff;--rej:#a371f7}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--fg);
font:14px/1.55 ui-monospace,SFMono-Regular,Menlo,monospace}
header{padding:18px 24px;border-bottom:1px solid var(--line);display:flex;
gap:18px;align-items:baseline;flex-wrap:wrap}
header h1{margin:0;font-size:17px;letter-spacing:.4px}
header .sub{color:var(--dim);font-size:12px}
#wrap{display:flex;min-height:calc(100vh - 61px)}
#queue{width:250px;border-right:1px solid var(--line);overflow-y:auto;
max-height:calc(100vh - 61px);flex:0 0 auto}
.qitem{padding:9px 14px;border-bottom:1px solid var(--line);cursor:pointer;
display:flex;justify-content:space-between;gap:8px;align-items:center}
.qitem:hover{background:#1c2128}
.qitem.on{background:#1f2b3d;border-left:3px solid var(--accent)}
.qitem .p{color:var(--dim);font-size:11px}
.dot{width:8px;height:8px;border-radius:50%;flex:0 0 auto}
main{flex:1;padding:22px 26px;overflow-y:auto;max-height:calc(100vh - 61px)}
h2{font-size:13px;text-transform:uppercase;letter-spacing:1.2px;color:var(--dim);
margin:26px 0 10px;border-bottom:1px solid var(--line);padding-bottom:6px}
h2:first-child{margin-top:0}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px}
.cell{background:var(--panel);border:1px solid var(--line);border-radius:6px;padding:10px 12px}
.cell .k{color:var(--dim);font-size:11px;text-transform:uppercase;letter-spacing:.7px}
.cell .v{font-size:16px;margin-top:3px}
.verdict-fraud{color:var(--fraud)}.verdict-legitimate{color:var(--legit)}
.verdict-uncertain{color:var(--unc)}
table{border-collapse:collapse;width:100%;background:var(--panel)}
th,td{border:1px solid var(--line);padding:7px 10px;text-align:left;vertical-align:top}
th{color:var(--dim);font-weight:500;font-size:11px;text-transform:uppercase;
letter-spacing:.7px;background:#12171f}
ol.timeline{list-style:none;padding:0;margin:0}
ol.timeline li{display:grid;grid-template-columns:34px 150px 1fr;gap:10px;
padding:6px 0;border-bottom:1px solid #21262d;font-size:12.5px}
ol.timeline .seq{color:var(--dim);text-align:right}
ol.timeline .node{color:var(--accent)}
ol.timeline li.rejected .node,ol.timeline li.rejected .detail{color:var(--rej)}
ol.timeline li.suppressed .detail{color:var(--unc)}
ol.timeline li.fired .detail{color:var(--fraud)}
.chip{display:inline-block;background:#21262d;border:1px solid var(--line);
border-radius:10px;padding:1px 8px;font-size:11px;color:var(--dim);margin-right:4px}
.ev{border:1px solid var(--line);border-radius:6px;padding:8px 11px;margin-bottom:7px;
background:var(--panel)}
.ev .ref{color:var(--dim);font-size:11px;margin-top:4px;word-break:break-all}
.act{border:1px solid var(--line);border-left:3px solid var(--accent);border-radius:4px;
padding:7px 11px;margin-bottom:6px;background:var(--panel)}
.act .r{color:var(--dim);font-size:11.5px;margin-top:3px}
.route{border:1px solid var(--line);border-radius:3px;padding:0 5px;font-size:10.5px;
color:var(--dim);margin-left:6px}
.narrative{background:var(--panel);border:1px solid var(--line);border-radius:6px;
padding:14px 16px;white-space:pre-wrap}
.changed{background:#1a2233;border-left:3px solid var(--accent);padding:10px 14px;
border-radius:4px}
.empty{color:var(--dim);font-style:italic}
"""

_JS = """
function show(id){
  document.querySelectorAll('.case').forEach(function(c){
    c.style.display = (c.id === id) ? 'block' : 'none';});
  document.querySelectorAll('.qitem').forEach(function(q){
    q.classList.toggle('on', q.dataset.id === id);});
  window.scrollTo(0,0);
}
window.addEventListener('DOMContentLoaded', function(){
  var first = document.querySelector('.qitem');
  if (first) show(first.dataset.id);
});
"""

_DOT = {"fraud": "var(--fraud)", "legitimate": "var(--legit)", "uncertain": "var(--unc)"}


def _esc(s: str) -> str:
    return (str(s).replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;"))


def _detail(ev: dict) -> str:
    """One line summarising a trace event, whatever its kind."""
    skip = {"seq", "node", "kind"}
    parts = [f"{k}={_esc(v)}" for k, v in ev.items()
             if k not in skip and not isinstance(v, (list, dict))]
    if ev.get("detail"):
        return _esc(ev["detail"])
    if ev.get("reason"):
        return _esc(ev["reason"])
    if ev.get("claim"):
        return _esc(ev["claim"])
    if ev.get("query") and ev.get("reason"):
        return f"{_esc(ev['query'])} — {_esc(ev['reason'])}"
    if ev.get("query"):
        return f"{_esc(ev['query'])}"
    if ev.get("tool"):
        return f"{_esc(ev['tool'])}({', '.join(parts)})"
    return " · ".join(parts[:6])


def _timeline(trace: dict) -> str:
    rows = []
    for ev in trace.get("events", []):
        kind = ev.get("kind", "")
        cls = ("rejected" if kind == "tool_rejected"
               else "suppressed" if kind == "suppressed"
               else "fired" if kind == "detector_fired" else "")
        rows.append(
            f'<li class="{cls}"><span class="seq">{ev.get("seq","")}</span>'
            f'<span class="node">{_esc(ev.get("node",""))}</span>'
            f'<span class="detail">{_detail(ev)}</span></li>')
    return f'<ol class="timeline">{"".join(rows)}</ol>' if rows \
        else '<p class="empty">no trace recorded</p>'


def _actions(actions: list[dict]) -> str:
    if not actions:
        return '<p class="empty">none</p>'
    out = []
    for a in actions:
        out.append(
            f'<div class="act"><b>{_esc(a["action"])}</b>'
            f'<span class="route">{_esc(a.get("route","auto"))}</span>'
            f'<div class="r">{_esc(a.get("reason",""))}</div></div>')
    return "".join(out)


def render_case(model: dict) -> str:
    a, t = model["answer"], model["trace"]
    c = a["case"]
    v = c["verdict"]
    nba = a["next_best_actions"]

    ev_html = "".join(
        f'<div class="ev">{_esc(e["claim"])}'
        f'<div><span class="chip">{_esc(e["source"])}</span>'
        f'{"".join(f"<span class=chip>{_esc(i)}</span>" for i in e.get("entity_ids", [])[:8])}</div>'
        f'<div class="ref">{_esc(e.get("ref",""))}</div></div>'
        for e in c.get("evidence", []))

    sar = a.get("sar", {})
    sar_html = ""
    if sar.get("file"):
        sar_html = (f'<h2>SAR — filed</h2><div class="narrative">{_esc(sar.get("narrative",""))}</div>'
                    f'<p><b>Subjects:</b> {_esc(", ".join(sar.get("subjects", [])))}</p>'
                    f'<p><b>Reason:</b> {_esc(sar.get("reason",""))}</p>')
    else:
        sar_html = ('<h2>SAR</h2><p class="empty">not filed — the §3a conditions '
                    'were not met (verdict, probability and exposure thresholds)</p>')

    req = a.get("evidence_requests", [])
    req_html = "".join(
        f'<div class="act"><b>{_esc(r["type"])}</b><div class="r">'
        f'assumed: {_esc(r.get("assumed_response",""))}</div></div>' for r in req) \
        or '<p class="empty">none — the VOI gate said the answer would not change</p>'

    return f"""
<section class="case" id="{_esc(a['case_id'])}" style="display:none">
  <h2>Case {_esc(a['case_id'])}</h2>
  <div class="grid">
    <div class="cell"><div class="k">Verdict</div>
      <div class="v verdict-{_esc(v)}">{_esc(v)}</div></div>
    <div class="cell"><div class="k">Fraud probability</div>
      <div class="v">{c['fraud_probability']}</div></div>
    <div class="cell"><div class="k">Pattern</div>
      <div class="v">{_esc(c['pattern'])}</div></div>
    <div class="cell"><div class="k">Exposure</div>
      <div class="v">${c['exposure_usd']:,.2f}</div></div>
    <div class="cell"><div class="k">Transactions</div>
      <div class="v">{len(c['affected_txn_ids'])}</div></div>
    <div class="cell"><div class="k">Actions (final)</div>
      <div class="v">{len(nba['final'])}</div></div>
  </div>

  <h2>Summary</h2>
  <div class="narrative">{_esc(c.get('summary',''))}</div>

  <h2>Investigation timeline</h2>
  {_timeline(t)}

  <h2>Evidence ({len(c.get('evidence',[]))})</h2>
  {ev_html or '<p class="empty">none</p>'}

  <h2>Evidence requests ({len(req)} of 2 rounds)</h2>
  {req_html}

  <h2>Recommended actions — initial</h2>
  {_actions(nba['initial'])}

  <h2>Recommended actions — final</h2>
  {_actions(nba['final'])}

  <h2>What changed</h2>
  <div class="changed">{_esc(nba.get('what_changed','')) or 'unchanged'}</div>

  {sar_html}

  <h2>Similar prior cases</h2>
  <p>{_esc(', '.join(c.get('similar_prior_cases', []))) or '<span class="empty">none</span>'}</p>

  <h2>Writeback</h2>
  <p>written_to_graph: <b>{c.get('written_to_graph')}</b> ·
     graph_case_id: <b>{_esc(c.get('graph_case_id','')) or '—'}</b></p>
</section>"""


def render_all(traces_dir: Path = TRACES, cases_dir: Path = CASES) -> str:
    """One self-contained HTML page for the whole case pack."""
    ids = available(cases_dir)
    models = [(i, load(i, traces_dir, cases_dir)) for i in ids]
    models = [(i, m) for i, m in models if m]
    if not models:
        raise SystemExit("no frozen cases found — run `anvesh run --all` first")

    queue = "".join(
        f'<div class="qitem" data-id="{_esc(i)}" onclick="show(\'{i}\')">'
        f'<span>{_esc(i)}</span>'
        f'<span class="p">{m["answer"]["case"]["fraud_probability"]:.2f}</span>'
        f'<span class="dot" style="background:{_DOT.get(m["answer"]["case"]["verdict"], "var(--dim)")}"></span>'
        f"</div>" for i, m in models)

    body = "".join(render_case(m) for _, m in models)
    n_fraud = sum(1 for _, m in models if m["answer"]["case"]["verdict"] == "fraud")

    return f"""<!doctype html>
<html><head><meta charset="utf-8">
<title>Anvesh — fraud investigation replay</title>
<style>{_CSS}</style></head><body>
<header>
  <h1>ANVESH</h1>
  <span class="sub">agentic fraud investigation · replay of {len(models)} frozen cases
  · {n_fraud} fraud · no live database required</span>
</header>
<div id="wrap">
  <nav id="queue">{queue}</nav>
  <main>{body}</main>
</div>
<script>{_JS}</script>
</body></html>"""


def write_html(out: Path, traces_dir: Path = TRACES, cases_dir: Path = CASES) -> Path:
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(render_all(traces_dir, cases_dir))
    return out


if __name__ == "__main__":
    print(write_html(ROOT / "demo" / "index.html"))
