"""Single source of truth for every threshold, weight and budget.

No magic numbers anywhere else in the codebase. Each constant carries the
policy wording it implements, so a change here is a policy change, not a tuning change.
"""

from __future__ import annotations

# --------------------------------------------------------------------------
# Budgets (docs/STATE.md §5)
# --------------------------------------------------------------------------
BUDGET_TOOL_CALLS = 30
BUDGET_WALL_S = 60
BUDGET_MAX_ROUNDS = 2          # evidence-request rounds
MAX_HYPOTHESES = 4
MAX_EVIDENCE_ITEMS = 25

# --------------------------------------------------------------------------
# Probability thresholds
# --------------------------------------------------------------------------
P_CASE_OPEN = 0.30             # §3a "fraud probability reaches 0.30"
P_VERIFY_BELOW = 0.70          # R1  "your assessed fraud probability is below 0.70"
P_STOP_HIGH = 0.85             # §6  "at or above 0.85"
P_STOP_LOW = 0.15              # §6  "at or below 0.15"
P_STRONGLY_SUSPECTED = 0.70    # §3a "fraud is confirmed or strongly suspected" (INTERPRETATION)
P_CLAMP_MIN = 0.01
P_CLAMP_MAX = 0.99
MIN_INDEPENDENT_SIGNALS = 2    # §6  "at least two independent pieces of evidence"

# --------------------------------------------------------------------------
# Exposure thresholds (USD) — comparison operators are exact
# --------------------------------------------------------------------------
EXPOSURE_SAR = 1_000           # R2 / §3a "exposure exceeds $1,000"            -> >
EXPOSURE_ESCALATE = 500        # R4 / R8 "exposure exceeds $500"               -> >
PURCHASE_BLOCK = 100           # R5  "a purchase over $100 has already cleared" -> >
BLOCK_ROUTE_L1_MAX = 2_500     # "exposure ≤ $2,500" -> L1 ; "> $2,500" -> L2   -> <=

# --------------------------------------------------------------------------
# Detector parameters (docs/UNCERTAINTY.md §8 — interpretive gaps)
# --------------------------------------------------------------------------
TESTING_SMALL_MAX = 5.00       # R5 "small" authorizations
TESTING_MIN_SMALL = 3          # R5 "three or more"
TESTING_WINDOW_H = 1           # R5 "within an hour"
TESTING_LARGE_RATIO = 5.0      # "materially larger" = >= 5x mean of the small ones
BURST_MIN = 2                  # pattern 2 "burst of two to four"
BURST_MAX = 4
BURST_WINDOW_H = 48            # "within 48 hours"
SHARED_ORIGIN_MIN_CARDS = 2    # R6 "several cards"
SHARED_ORIGIN_WINDOW_DAYS = 7  # R6 "in one window"
RECURRING_CADENCE_MIN_D = 25   # R7 "monthly"
RECURRING_CADENCE_MAX_D = 35
RECURRING_AMOUNT_TOL = 0.02    # R7 "same amount" (+/- 2%)
OUT_OF_REGION_MIN_DAYS = 3     # "several days in one new region is a trip, not a clone"
OUT_OF_REGION_MAX_DAYS = 2     # a *clone* shows few days in the new region
UNKNOWN_PATTERN_MIN_CLUSTER = 3  # R9 "coordinated" = >= 3 clustered episodes
AMOUNT_Z_THRESHOLD = 2.0       # amount z-score vs cardholder baseline
GEO_VELOCITY_MAX_KMH = 800.0   # impossible travel

# --------------------------------------------------------------------------
# Episode segmentation (docs/ARCHITECTURE.md §4.3)
# --------------------------------------------------------------------------
EPISODE_MAX_SPAN_HOURS = 72
EPISODE_LAMBDA = 0.15          # sprawl penalty per hour of span
EPISODE_SCORE_THRESHOLD = 0.35 # inclusion threshold (tuned on closed-case IoU)

# --------------------------------------------------------------------------
# Priors (docs/UNCERTAINTY.md §2) — ASSUMPTIONS, not measurements
# --------------------------------------------------------------------------
PI_TRAIN = 4_665 / 5_565       # 0.8383 — closed-case base rate (selection-biased)

PRIOR_RISK_BANDS = [           # (upper_bound, pi0) — upper bound is exclusive
    (0.50, 0.20),
    (0.70, 0.30),
    (0.90, 0.40),
    (1.01, 0.45),
]
PRIOR_CUSTOMER_REPORT = 0.50
PRIOR_ANALYST_REQUEST = 0.50

# --------------------------------------------------------------------------
# Likelihood ratios for simulated responses (docs/UNCERTAINTY.md §5)
# Learned from closed-case analyst_notes where available; these are the
# starting values used when no notes exist. Odds multipliers.
# --------------------------------------------------------------------------
LR_RESPONSE = {
    "denied": 5.5,      # a denial strongly supports fraud
    "confirmed": 0.06,  # a confirmation strongly supports legitimacy
    "no_reply": 1.6,    # silence is mildly incriminating
}

# Marginal probability of each response, used by the VOI calculation.
RESPONSE_PRIORS = {
    "customer_validation": {"denied": 0.45, "confirmed": 0.40, "no_reply": 0.15},
    "step_up_auth": {"denied": 0.30, "confirmed": 0.55, "no_reply": 0.15},
    "analyst_info": {"denied": 0.35, "confirmed": 0.35, "no_reply": 0.30},
}

# --------------------------------------------------------------------------
# Expected-cost model (docs/POLICY.md §7)
# --------------------------------------------------------------------------
COST_OF_ASKING = {             # friction + latency cost of requesting evidence
    "customer_validation": 0.04,
    "step_up_auth": 0.02,
    "analyst_info": 0.06,
}
COST_MISSING_SAR = 40.0        # regulatory cost of not filing when §3a required it
COST_LAMBDA_OPS = 0.01         # operational cost weight

# --------------------------------------------------------------------------
# Fusion / shrinkage (fitted on the held-out closed-case split)
# --------------------------------------------------------------------------
FUSION_ALPHA = 0.65            # weight on p_det vs p_llm
LR_SHRINKAGE_GAMMA = 0.6       # evidence axes are not independent

# --------------------------------------------------------------------------
# Prose limits (docs/ANSWER_SCHEMA.md)
# --------------------------------------------------------------------------
SUMMARY_MIN_SENTENCES = 2
SUMMARY_MAX_SENTENCES = 6
NARRATIVE_MIN_SENTENCES = 6
NARRATIVE_MAX_SENTENCES = 12
