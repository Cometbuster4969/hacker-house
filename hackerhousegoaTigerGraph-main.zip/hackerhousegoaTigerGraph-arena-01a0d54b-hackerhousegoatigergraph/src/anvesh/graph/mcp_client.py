"""MCP client: the ONLY path from the agent to TigerGraph.

Spawns `tigergraph-mcp` as a stdio subprocess and holds ONE session for the
whole run (the server README measures ~4x speedup vs a session per call).

Safety is enforced in THREE places, deliberately redundant:
  1. The subprocess is started with an explicit `--allowed-tools` list, so the
     server itself refuses to serve anything else. An unrecognised selector
     stops the server at startup rather than silently serving a short list.
  2. This client refuses to call any tool outside ALLOWED_TOOLS.
  3. `run_installed_query` is further restricted to ALLOWED_QUERIES — the
     installed, as_of-bounded queries this repo ships. The agent can never
     run arbitrary query text (no `gsql`, no `run_query`, no `generate_*`).

Tool names and signatures verified against tigergraph-mcp's own source
(see commit history); the envelope shape {success, data, error} comes from
its README ("Structured Responses").
"""

from __future__ import annotations

import asyncio
import json
import os
import threading
from dataclasses import dataclass, field
from typing import Any

TOOL_PREFIX = "tigergraph__"

# Read + append-only. No drops, deletes, clears, or raw GSQL — ever.
ALLOWED_TOOLS = frozenset({
    "run_installed_query",      # restricted further to ALLOWED_QUERIES below
    "is_query_installed",
    "list_graphs",
    "get_vertex_count",
    "get_node",
    "get_nodes",
    "get_neighbors",
    "add_node",
    "add_nodes",
    "add_edge",
    "add_edges",
    "search_top_k_similarity",
    "upsert_vectors",
})

# The only installed queries the agent may run. Every one takes `as_of` first.
ALLOWED_QUERIES = frozenset({
    "txn_context",
    "card_window",
    "cardholder_baseline",
    "device_neighbors",
    "geo_velocity",
    "testing_sequence",
    "recurring_check",
    "episode_expand",
    "ring_components",
    "shared_origin",
})

# Forwarded to the subprocess. stdio_client does NOT inherit our environment,
# so credentials must be passed explicitly (server README: "the subprocess
# does not inherit your shell environment").
TG_ENV_KEYS = (
    "TG_HOST", "TG_GRAPHNAME", "TG_USERNAME", "TG_PASSWORD", "TG_SECRET",
    "TG_API_TOKEN", "TG_JWT_TOKEN", "TG_RESTPP_PORT", "TG_GS_PORT",
    "TG_SSL_PORT", "TG_TGCLOUD", "TG_CERT_PATH", "TG_LOG_TOOL_CALLS",
)


class MCPError(RuntimeError):
    """A tool call failed, or a safety rule refused it."""

    def __init__(self, message: str, suggestions: list[str] | None = None):
        super().__init__(message)
        self.suggestions = suggestions or []


@dataclass
class MCPConfig:
    command: str = "tigergraph-mcp"
    extra_args: list[str] = field(default_factory=list)
    timeout_s: float = 180.0        # Savanna cold starts are slow
    log_calls: bool = False


class MCPClient:
    """Synchronous facade over one MCP stdio session.

    The asyncio session lives on a dedicated thread; callers use plain
    blocking `call()`. Use as a context manager so the subprocess is reaped.
    """

    def __init__(self, config: MCPConfig | None = None) -> None:
        self.config = config or MCPConfig()
        self._thread: threading.Thread | None = None
        self._loop: asyncio.AbstractEventLoop | None = None
        self._ready = threading.Event()
        self._session = None
        self._stack = None
        self.calls = 0

    # ------------------------------------------------------------- lifecycle
    def __enter__(self) -> "MCPClient":
        self.connect()
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    def connect(self) -> None:
        if self._thread is not None:
            return
        self._thread = threading.Thread(target=self._run_loop, daemon=True,
                                        name="anvesh-mcp")
        self._thread.start()
        if not self._ready.wait(timeout=120):
            raise MCPError("MCP session thread did not start")
        if isinstance(self._session, Exception):
            raise self._session

    def close(self) -> None:
        if self._loop is None:
            return
        try:
            fut = asyncio.run_coroutine_threadsafe(self._ashutdown(), self._loop)
            fut.result(timeout=30)
        except Exception:
            pass
        finally:
            self._loop.call_soon_threadsafe(self._loop.stop)
            self._thread.join(timeout=30)
            self._thread, self._loop, self._session = None, None, None

    # ------------------------------------------------------------------ call
    def call(self, tool: str, args: dict[str, Any] | None = None) -> Any:
        """Call one tool. Returns the envelope's `data` on success."""
        short = tool[len(TOOL_PREFIX):] if tool.startswith(TOOL_PREFIX) else tool
        if short not in ALLOWED_TOOLS:
            raise MCPError(
                f"refused: tool '{tool}' is outside the read/append-only profile")
        if short == "run_installed_query":
            q = (args or {}).get("query_name")
            if q not in ALLOWED_QUERIES:
                raise MCPError(
                    f"refused: query '{q}' is not one of the shipped installed queries")
        if self._loop is None:
            raise MCPError("MCP client is not connected")

        if self.config.log_calls or os.getenv("TG_LOG_TOOL_CALLS") == "true":
            print(f"[mcp] {short} {(args or {}).get('query_name', '')}")

        fut = asyncio.run_coroutine_threadsafe(
            self._acall(TOOL_PREFIX + short, dict(args or {})), self._loop)
        try:
            return fut.result(timeout=self.config.timeout_s)
        except TimeoutError as e:
            raise MCPError(f"tool '{short}' timed out after "
                           f"{self.config.timeout_s}s") from e

    # --------------------------------------------------------------- internals
    def _run_loop(self) -> None:
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        try:
            self._loop.run_until_complete(self._aconnect())
        except Exception as e:                      # surfaced via connect()
            self._session = e
        finally:
            self._ready.set()
            if not isinstance(self._session, Exception):
                self._loop.run_forever()
            pending = asyncio.all_tasks(self._loop)
            for t in pending:
                t.cancel()
            try:
                self._loop.run_until_complete(
                    asyncio.gather(*pending, return_exceptions=True))
            except Exception:
                pass
            self._loop.close()

    async def _aconnect(self) -> None:
        from contextlib import AsyncExitStack

        from mcp import ClientSession, StdioServerParameters
        from mcp.client.stdio import get_default_environment, stdio_client

        env = {k: v for k, v in os.environ.items()
               if k in TG_ENV_KEYS and v}
        if not env.get("TG_HOST"):
            raise MCPError(
                "TG_HOST is not set — copy .env.example to .env and fill in "
                "your TigerGraph connection (docs/SETUP.md §2)")

        params = StdioServerParameters(
            command=self.config.command,
            args=["--allowed-tools", ",".join(sorted(ALLOWED_TOOLS)),
                  *self.config.extra_args],
            env={**get_default_environment(), **env},
        )
        self._stack = AsyncExitStack()
        read, write = await self._stack.enter_async_context(stdio_client(params))
        self._session = await self._stack.enter_async_context(ClientSession(read, write))
        await self._session.initialize()

    async def _ashutdown(self) -> None:
        if self._stack is not None:
            await self._stack.aclose()
            self._stack = None

    async def _acall(self, tool: str, args: dict[str, Any]) -> Any:
        self.calls += 1
        result = await self._session.call_tool(tool, args)
        text = "\n".join(getattr(c, "text", "") for c in result.content or [])
        try:
            envelope = json.loads(text)
        except json.JSONDecodeError as e:
            raise MCPError(f"tool '{tool}' returned non-JSON: {text[:200]}") from e
        if not envelope.get("success", False):
            raise MCPError(
                f"tool '{tool}' failed: {envelope.get('error', 'unknown error')}",
                suggestions=envelope.get("suggestions") or [])
        return envelope.get("data")
