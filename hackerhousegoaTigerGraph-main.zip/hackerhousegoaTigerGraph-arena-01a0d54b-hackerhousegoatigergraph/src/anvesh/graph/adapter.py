"""The graph adapter interface.

ONE interface, two implementations:
  * MemoryAdapter        — pandas-backed, fully functional offline (tests, dev, demo)
  * TigerGraphAdapter    — MCP-backed, the real submission path

Every method takes `as_of` first (docs/QUERIES.md §0). A transaction is visible
iff ts <= as_of. No implementation may return future data.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime

from ..domain.models import Baseline, GeoPair, Txn


@dataclass
class DeviceNeighbors:
    device_id: str
    card_ids: list[str] = field(default_factory=list)
    txn_ids: list[str] = field(default_factory=list)
    closed_cases: list[str] = field(default_factory=list)


@dataclass
class TestingSequence:
    fired: bool = False
    small_txn_ids: list[str] = field(default_factory=list)
    large_txn_id: str = ""
    large_amount: float = 0.0


@dataclass
class RecurringResult:
    is_recurring: bool = False
    matched_txn_ids: list[str] = field(default_factory=list)
    cadence_days: float = 0.0


@dataclass
class RingResult:
    cluster_id: str = ""
    size: int = 0
    card_ids: list[str] = field(default_factory=list)


class GraphAdapter(ABC):
    """The only way the agent sees data. Implementations must be as_of-correct."""

    # ---- core reads (docs/QUERIES.md §1) ---------------------------------
    @abstractmethod
    def txn_context(self, as_of: datetime, txn_id: str) -> Txn | None: ...

    @abstractmethod
    def card_window(self, as_of: datetime, card_id: str, hours: int) -> list[Txn]: ...

    @abstractmethod
    def cardholder_baseline(self, as_of: datetime, card_id: str, days: int) -> Baseline: ...

    @abstractmethod
    def device_neighbors(self, as_of: datetime, device_id: str, days: int) -> DeviceNeighbors: ...

    @abstractmethod
    def geo_velocity(self, as_of: datetime, card_id: str, hours: int) -> list[GeoPair]: ...

    @abstractmethod
    def testing_sequence(self, as_of: datetime, card_id: str, hours: int) -> TestingSequence: ...

    @abstractmethod
    def recurring_check(self, as_of: datetime, card_id: str, days: int) -> RecurringResult: ...

    @abstractmethod
    def episode_expand(self, as_of: datetime, seed_txn_ids: list[str],
                       hops: int) -> list[Txn]: ...

    # ---- graph algorithms / memory ---------------------------------------
    @abstractmethod
    def ring_components(self, as_of: datetime, days: int, min_cards: int,
                        card_id: str) -> RingResult | None: ...

    @abstractmethod
    def shared_origin_cards(self, as_of: datetime, kind: str, element: str,
                            days: int) -> list[str]: ...

    @abstractmethod
    def prior_cases(self, fingerprint: list[float], k: int) -> list[str]: ...

    @abstractmethod
    def customer_cards(self, customer_id: str) -> list[str]: ...

    @abstractmethod
    def closed_case_ids(self) -> list[str]: ...

    # ---- append-only writes ----------------------------------------------
    @abstractmethod
    def write_case(self, case_id: str, payload: dict) -> str: ...

    # ---- integrity --------------------------------------------------------
    @abstractmethod
    def has_txn(self, txn_id: str) -> bool: ...

    def assert_as_of(self, as_of: datetime, txns: list[Txn]) -> None:
        """Guard rail: no implementation may leak the future."""
        bad = [t.txn_id for t in txns if t.ts > as_of]
        if bad:
            raise AssertionError(f"as_of leak: {bad[:5]} returned for as_of={as_of}")
