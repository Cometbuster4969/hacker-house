"""TigerGraph-backed adapter. The real submission path.

Every read is one `run_installed_query` call against the queries in graph/
(every one `as_of`-bounded); writes are `add_node`/`add_edges` only. All
traffic goes through MCPClient, which enforces the read/append-only tool
profile — this module cannot reach a destructive tool even by accident.

Result parsing is deliberately tolerant: pyTigerGraph shapes differ slightly
between versions, so every parser looks for several plausible shapes and
raises a clear MCPError naming the query and the shape seen when nothing
matches. A parse failure must be LOUD, never a silent empty result.

Requires: pip install -e ".[tigergraph]" + a live instance + installed queries.
Untested against a live database — see docs/SETUP.md §7 verification order.
"""

from __future__ import annotations

import re
from datetime import datetime
from typing import Any

from ..domain.enums import Channel
from ..domain.models import Baseline, GeoPair, Txn
from .adapter import (
    DeviceNeighbors,
    GraphAdapter,
    RecurringResult,
    RingResult,
    TestingSequence,
)
from .mcp_client import MCPClient, MCPError

VECTOR_ATTRIBUTE = "fp"          # ClosedCase.fp / InvestigationCase.fp (TigerVector)
VECTOR_DIM = 12


def gsql_datetime(dt: datetime) -> str:
    """Format a datetime as a GSQL DATETIME parameter."""
    return dt.strftime("%Y-%m-%d %H:%M:%S")


def parse_ts(value: Any) -> datetime:
    if isinstance(value, datetime):
        return value
    if isinstance(value, (int, float)):
        return datetime.fromtimestamp(float(value))
    s = str(value).strip().replace("T", " ")
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M:%S.%f",
                "%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try:
            return datetime.strptime(s[:len(fmt.format())] if False else s, fmt)
        except ValueError:
            continue
    raise MCPError(f"cannot parse timestamp {value!r}")


def _aliases(result: Any, query: str) -> dict[str, Any]:
    """Merge installed-query PRINT outputs into one alias dict.

    pyTigerGraph returns a list with one dict per PRINT statement, each
    mapping alias -> value. Later statements win on collision.
    """
    if isinstance(result, dict):
        return dict(result)
    if not isinstance(result, list):
        raise MCPError(f"query '{query}' returned unexpected shape: "
                       f"{type(result).__name__}: {str(result)[:200]}")
    merged: dict[str, Any] = {}
    for item in result:
        if isinstance(item, dict):
            merged.update(item)
    return merged


def _vertices(value: Any) -> list[dict[str, Any]]:
    if not value:
        return []
    if isinstance(value, dict):
        value = [value]
    return [v for v in value if isinstance(v, dict)]


def _vid(v: dict[str, Any]) -> str:
    for k in ("v_id", "id", "vertex_id"):
        if v.get(k) is not None:
            return str(v[k])
    raise MCPError(f"vertex has no id: {str(v)[:200]}")


def _attrs(v: dict[str, Any]) -> dict[str, Any]:
    a = v.get("attributes")
    return dict(a) if isinstance(a, dict) else {}


def _ids(value: Any) -> list[str]:
    """Collect id strings from whatever shape a tool returned."""
    out: list[str] = []
    if value is None:
        return out
    items = value if isinstance(value, list) else [value]
    for it in items:
        if isinstance(it, str):
            out.append(it)
        elif isinstance(it, dict):
            try:
                out.append(_vid(it))
            except MCPError:
                continue
    # dedupe, preserving order
    return list(dict.fromkeys(out))


def _channel(value: Any) -> Channel:
    s = str(value or "").strip().lower()
    if s == "online":
        return Channel.ONLINE
    if s in ("in_person", "in-person", "offline", "card_present", "card-present"):
        return Channel.IN_PERSON
    raise MCPError(f"unknown channel value {value!r} — expected 'online' or 'in_person'")


class TigerGraphAdapter(GraphAdapter):
    """GraphAdapter over tigergraph-mcp. Owns nothing; the MCPClient owns the
    session. Pass a fake client with the same .call() shape for offline tests."""

    def __init__(self, client, graph_name: str | None = None) -> None:
        self.client = client
        self.graph_name = graph_name
        self.tool_calls = 0

    # ------------------------------------------------------------- plumbing
    def _q(self, name: str, params: dict[str, Any]) -> dict[str, Any]:
        args: dict[str, Any] = {"query_name": name, "params": params}
        if self.graph_name:
            args["graph_name"] = self.graph_name
        data = self.client.call("run_installed_query", args)
        self.tool_calls += 1
        if not isinstance(data, dict) or "result" not in data:
            raise MCPError(f"query '{name}' returned no result envelope: "
                           f"{str(data)[:200]}")
        return _aliases(data["result"], name)

    def _txn_from(self, v: dict[str, Any], card_id: str, customer_id: str,
                  side: dict[str, dict[str, str]]) -> Txn:
        a = _attrs(v)
        tid = _vid(v)
        ts = parse_ts(a.get("ts"))
        return Txn(
            txn_id=tid,
            ts=ts,
            amount=float(a.get("amount", 0.0) or 0.0),
            card_id=side.get("txn_card", {}).get(tid, card_id),
            customer_id=side.get("txn_customer", {}).get(tid, customer_id),
            product_cd=str(a.get("product_cd", "") or ""),
            channel=_channel(a.get("channel")),
            risk_score=float(a.get("risk_score", 0.0) or 0.0),
            region=side.get("txn_region", {}).get(tid),
            country=str(a.get("addr2") or "") or None,
            device_id=side.get("txn_device", {}).get(tid),
            # device_new is intentionally always False here: on real data,
            # novelty is computed from the cardholder baseline (device_hist),
            # which is the same signal the detectors actually use.
            device_new=False,
            proxy=None,                        # no proxy column in the dataset
            p_email=side.get("txn_pemail", {}).get(tid),
            r_email=side.get("txn_remail", {}).get(tid),
            v_anom=float(a.get("v_anom", 0.0) or 0.0),
            m_flags=int(a.get("m_flags", 0) or 0),
        )

    # ------------------------------------------------------------ core reads
    def txn_context(self, as_of: datetime, txn_id: str) -> Txn | None:
        out = self._q("txn_context", {"as_of": gsql_datetime(as_of),
                                      "txn_id": txn_id})
        t = _vertices(out.get("T"))
        if not t:
            return None
        card = _vertices(out.get("C"))
        cust = _vertices(out.get("Cu"))
        dev = _vertices(out.get("D"))
        reg = _vertices(out.get("R"))
        co = _vertices(out.get("Co"))
        prod = _vertices(out.get("P"))
        pe = _vertices(out.get("Pe"))
        re_ = _vertices(out.get("Re"))
        a = _attrs(t[0])
        txn = Txn(
            txn_id=txn_id, ts=parse_ts(a.get("ts")),
            amount=float(a.get("amount", 0.0) or 0.0),
            card_id=_vid(card[0]) if card else "",
            customer_id=_vid(cust[0]) if cust else "",
            product_cd=_vid(prod[0]) if prod else str(a.get("product_cd", "") or ""),
            channel=_channel(a.get("channel")),
            risk_score=float(a.get("risk_score", 0.0) or 0.0),
            region=_vid(reg[0]) if reg else None,
            country=_vid(co[0]) if co else (str(a.get("addr2") or "") or None),
            device_id=_vid(dev[0]) if dev else None,
            device_new=False, proxy=None,
            p_email=_vid(pe[0]) if pe else None,
            r_email=_vid(re_[0]) if re_ else None,
            v_anom=float(a.get("v_anom", 0.0) or 0.0),
            m_flags=int(a.get("m_flags", 0) or 0),
        )
        self.assert_as_of(as_of, [txn])
        return txn

    def card_window(self, as_of: datetime, card_id: str, hours: int) -> list[Txn]:
        out = self._q("card_window", {"as_of": gsql_datetime(as_of),
                                      "card_id": card_id, "hours": hours})
        cust = _vertices(out.get("Cus"))
        customer_id = _vid(cust[0]) if cust else ""
        side = {k: (out.get(k) or {}) for k in
                ("txn_device", "txn_region", "txn_pemail", "txn_remail")}
        txns = sorted(
            (self._txn_from(v, card_id, customer_id, side)
             for v in _vertices(out.get("W"))),
            key=lambda t: t.ts)
        self.assert_as_of(as_of, txns)
        return txns

    def cardholder_baseline(self, as_of: datetime, card_id: str, days: int) -> Baseline:
        out = self._q("cardholder_baseline", {"as_of": gsql_datetime(as_of),
                                              "card_id": card_id, "days": days})

        def hist(key: str) -> dict[str, int]:
            h = out.get(key) or {}
            return {str(k): int(v) for k, v in h.items()} if isinstance(h, dict) else {}

        b = Baseline(
            amount_mean=float(out.get("amount_mean", 0.0) or 0.0),
            amount_std=float(out.get("amount_std", 1.0) or 1.0),
            product_hist=hist("product_hist"),
            region_hist=hist("region_hist"),
            device_hist=hist("device_hist"),
            channel_hist=hist("channel_hist"),
            n_txns=int(out.get("n_txns", 0) or 0),
        )
        if b.amount_std <= 0:
            b.amount_std = max(b.amount_mean * 0.3, 1.0)
        return b

    def device_neighbors(self, as_of: datetime, device_id: str, days: int) -> DeviceNeighbors:
        if not device_id:
            return DeviceNeighbors(device_id=device_id or "")
        out = self._q("device_neighbors", {"as_of": gsql_datetime(as_of),
                                           "device_id": device_id, "days": days})
        return DeviceNeighbors(
            device_id=device_id,
            card_ids=_ids(out.get("cards")),
            txn_ids=[],
            closed_cases=_ids(out.get("cases")),
        )

    def geo_velocity(self, as_of: datetime, card_id: str, hours: int) -> list[GeoPair]:
        out = self._q("geo_velocity", {"as_of": gsql_datetime(as_of),
                                       "card_id": card_id, "hours": hours})
        pairs = out.get("pairs") or []
        # NEXT is undirected, so each unordered pair appears in both directions;
        # keep the forward one (non-negative elapsed time), deduped.
        seen: set[tuple[str, str]] = set()
        result: list[GeoPair] = []
        for p in pairs:
            if not isinstance(p, dict):
                continue
            minutes = float(p.get("minutes_elapsed", 0) or 0)
            if minutes < 0:
                continue
            key = (str(p.get("from_txn", "")), str(p.get("to_txn", "")))
            if key in seen:
                continue
            seen.add(key)
            result.append(GeoPair(from_txn=key[0], to_txn=key[1],
                                  from_region=p.get("from_region"),
                                  to_region=p.get("to_region"), minutes=minutes))
        return result

    def testing_sequence(self, as_of: datetime, card_id: str, hours: int) -> TestingSequence:
        out = self._q("testing_sequence", {"as_of": gsql_datetime(as_of),
                                           "card_id": card_id, "hours": hours})
        return TestingSequence(
            fired=bool(out.get("fired", False)),
            small_txn_ids=_ids(out.get("small_ids")),
            large_txn_id=str(out.get("large_id") or ""),
            large_amount=float(out.get("large_amount", 0.0) or 0.0),
        )

    def recurring_check(self, as_of: datetime, card_id: str, days: int) -> RecurringResult:
        out = self._q("recurring_check", {"as_of": gsql_datetime(as_of),
                                          "card_id": card_id, "days": days})
        return RecurringResult(
            is_recurring=bool(out.get("is_recurring", False)),
            matched_txn_ids=_ids(out.get("matched")),
            cadence_days=float(out.get("cadence", 0.0) or 0.0),
        )

    def episode_expand(self, as_of: datetime, seed_txn_ids: list[str],
                       hops: int) -> list[Txn]:
        out = self._q("episode_expand", {"as_of": gsql_datetime(as_of),
                                         "seed_txn_ids": sorted(set(seed_txn_ids)),
                                         "hops": hops})
        side = {k: (out.get(k) or {}) for k in
                ("txn_device", "txn_region", "txn_pemail", "txn_remail",
                 "txn_card", "txn_customer")}
        txns = sorted(
            (self._txn_from(v, "", "", side)
             for v in _vertices(out.get("Frontier"))),
            key=lambda t: t.ts)
        self.assert_as_of(as_of, txns)
        return txns

    # ------------------------------------------------------------- algorithms
    def ring_components(self, as_of: datetime, days: int, min_cards: int,
                        card_id: str) -> RingResult | None:
        out = self._q("ring_components", {"as_of": gsql_datetime(as_of),
                                          "card_id": card_id, "days": days,
                                          "min_cards": min_cards})
        cards = _ids(out.get("cards"))
        if len(cards) < min_cards:                # enforced client-side too
            return None
        return RingResult(cluster_id=str(out.get("cluster_id") or ""),
                          size=int(out.get("size", len(cards)) or len(cards)),
                          card_ids=cards)

    def shared_origin_cards(self, as_of: datetime, kind: str, element: str,
                            days: int) -> list[str]:
        if kind not in ("device", "region", "email") or not element:
            return []
        out = self._q("shared_origin", {"as_of": gsql_datetime(as_of),
                                        "kind": kind, "element": element,
                                        "days": days})
        return _ids(out.get("cards"))

    def prior_cases(self, fingerprint: list[float], k: int) -> list[str]:
        """TigerVector kNN over ClosedCase.fp. Degrades to [] when vector
        search is unavailable (pre-4.2, or the attribute was never created) —
        memory is an enhancement, never a dependency."""
        if not fingerprint:
            return []
        try:
            data = self.client.call("search_top_k_similarity", {
                "vertex_type": "ClosedCase",
                "vector_attribute": VECTOR_ATTRIBUTE,
                "query_vector": [float(x) for x in fingerprint],
                "top_k": k,
            })
            self.tool_calls += 1
        except MCPError:
            return []
        if not isinstance(data, dict):
            return []
        for key in ("results", "vertices", "neighbors", "ids", "cases"):
            if key in data:
                return _ids(data[key])[:k]
        return []

    # --------------------------------------------------------------- lookups
    def customer_cards(self, customer_id: str) -> list[str]:
        data = self.client.call("get_neighbors", {
            "vertex_type": "Customer", "vertex_id": customer_id,
            "edge_type": "OWNS", "target_vertex_type": "Card", "limit": 100,
        })
        self.tool_calls += 1
        if not isinstance(data, dict):
            return []
        return _ids(data.get("neighbors"))

    def closed_case_ids(self) -> list[str]:
        data = self.client.call("get_nodes", {
            "vertex_type": "ClosedCase", "limit": 10000,
        })
        self.tool_calls += 1
        if not isinstance(data, dict):
            return []
        if data.get("has_more"):
            raise MCPError("more than 10000 ClosedCase vertices — raise the limit")
        return _ids(data.get("vertices"))

    def has_txn(self, txn_id: str) -> bool:
        try:
            data = self.client.call("get_node", {
                "vertex_type": "Transaction", "vertex_id": txn_id,
            })
            self.tool_calls += 1
        except MCPError as e:
            # "not found" means no; anything else (auth, timeout, 500) is real.
            if "not found" in str(e).lower() or "does not exist" in str(e).lower():
                return False
            raise
        return bool(data)

    # ----------------------------------------------------------------- writes
    def write_case(self, case_id: str, payload: dict) -> str:
        self.client.call("add_node", {
            "vertex_type": "InvestigationCase",
            "vertex_id": case_id,
            "attributes": {
                "opened_at": gsql_datetime(datetime.now()),
                "verdict": str(payload.get("verdict", "")),
                "fraud_probability": float(payload.get("fraud_probability", 0.0)),
                "pattern": str(payload.get("pattern", "")),
                "exposure_usd": float(payload.get("exposure_usd", 0.0)),
            },
        })
        self.tool_calls += 1

        batches: dict[str, tuple[str, str, list[dict[str, str]]]] = {}

        def edge(edge_type: str, target_type: str, target_id: str) -> None:
            if not target_id:
                return
            key = (edge_type, target_type)
            batches.setdefault(key, ("InvestigationCase", target_type, []))[2].append(
                {"source_type": "InvestigationCase", "source_id": case_id,
                 "target_type": target_type, "target_id": target_id})

        for tid in payload.get("affected_txn_ids") or []:
            edge("CASE_TXN", "Transaction", tid)
        edge("CASE_CARD", "Card", payload.get("card_id", ""))
        edge("CASE_DEVICE", "DeviceProfile", payload.get("device_id", ""))
        for cc in payload.get("similar_prior_cases") or []:
            edge("CASE_CITES", "ClosedCase", cc)

        for (edge_type, _), (_, _, edges) in batches.items():
            self.client.call("add_edges", {"edge_type": edge_type, "edges": edges})
            self.tool_calls += 1

        fp = payload.get("fingerprint") or []
        if len(fp) == VECTOR_DIM:
            try:                                    # best-effort; see prior_cases
                self.client.call("upsert_vectors", {
                    "vertex_type": "InvestigationCase",
                    "vector_attribute": VECTOR_ATTRIBUTE,
                    "vectors": [{"vertex_id": case_id,
                                 "vector": [float(x) for x in fp]}],
                })
                self.tool_calls += 1
            except MCPError:
                pass
        return case_id

    # ------------------------------------------------------------ verification
    def vertex_count(self, vertex_type: str) -> int:
        """Used by `anvesh verify` (docs/SETUP.md §7). Not part of GraphAdapter."""
        data = self.client.call("get_vertex_count", {"vertex_type": vertex_type})
        self.tool_calls += 1
        if isinstance(data, dict):
            for key in ("count", "vertex_count", "total"):
                if isinstance(data.get(key), int):
                    return data[key]
        raise MCPError(f"get_vertex_count returned unexpected shape: {str(data)[:200]}")

    def is_query_installed(self, query_name: str) -> bool:
        try:
            data = self.client.call("is_query_installed", {"query_name": query_name})
            self.tool_calls += 1
        except MCPError:
            return False
        if isinstance(data, dict):
            return bool(data.get("installed", data.get("exists", True)))
        return bool(data)


def connect(graph_name: str | None = None,
            timeout_s: float = 180.0) -> tuple[MCPClient, "TigerGraphAdapter"]:
    """Open a session and return (client, adapter). Keep the client alive for
    the whole run; close it at the end (`with` block preferred)."""
    from .mcp_client import MCPConfig
    client = MCPClient(MCPConfig(timeout_s=timeout_s))
    client.connect()
    return client, TigerGraphAdapter(client, graph_name=graph_name)
