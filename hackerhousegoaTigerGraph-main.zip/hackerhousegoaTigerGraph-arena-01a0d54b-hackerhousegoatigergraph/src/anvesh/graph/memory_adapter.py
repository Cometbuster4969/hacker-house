"""Pandas-backed adapter. Fully functional offline.

Used for tests, development, and the replay demo. Not a submission artifact —
but it shares the exact interface with TigerGraphAdapter, so everything built
against it ports directly.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from datetime import datetime, timedelta

import numpy as np

from ..config import (
    RECURRING_AMOUNT_TOL,
    RECURRING_CADENCE_MAX_D,
    RECURRING_CADENCE_MIN_D,
    SHARED_ORIGIN_WINDOW_DAYS,
    TESTING_LARGE_RATIO,
    TESTING_MIN_SMALL,
    TESTING_SMALL_MAX,
    TESTING_WINDOW_H,
)
from ..domain.models import (
    Baseline,
    ClosedCase,
    GeoPair,
    Txn,
)
from .adapter import (
    DeviceNeighbors,
    GraphAdapter,
    RecurringResult,
    RingResult,
    TestingSequence,
)


class MemoryAdapter(GraphAdapter):
    def __init__(self, txns: list[Txn], closed_cases: list[ClosedCase] | None = None) -> None:
        self.txns = sorted(txns, key=lambda t: (t.card_id, t.ts))
        self.by_id: dict[str, Txn] = {t.txn_id: t for t in self.txns}
        self.by_card: dict[str, list[Txn]] = defaultdict(list)
        for t in self.txns:
            self.by_card[t.card_id].append(t)
        self.by_customer: dict[str, list[str]] = defaultdict(list)
        for t in self.txns:
            if t.customer_id not in self.by_customer or t.card_id not in self.by_customer[t.customer_id]:
                self.by_customer[t.customer_id].append(t.card_id)

        self.closed_cases = {c.case_id: c for c in (closed_cases or [])}
        self._case_txns: dict[str, set[str]] = {c.case_id: set(c.txn_ids)
                                                for c in (closed_cases or [])}
        self.written: dict[str, dict] = {}
        self.tool_calls: int = 0

    # ------------------------------------------------------------------ util
    def _visible(self, card_id: str, as_of: datetime) -> list[Txn]:
        return [t for t in self.by_card.get(card_id, []) if t.ts <= as_of]

    def _count(self) -> None:
        self.tool_calls += 1

    # ------------------------------------------------------------ core reads
    def txn_context(self, as_of: datetime, txn_id: str) -> Txn | None:
        self._count()
        t = self.by_id.get(txn_id)
        if t is None or t.ts > as_of:
            return None
        return t

    def card_window(self, as_of: datetime, card_id: str, hours: int) -> list[Txn]:
        self._count()
        lo = as_of - timedelta(hours=hours)
        out = [t for t in self._visible(card_id, as_of) if t.ts >= lo]
        self.assert_as_of(as_of, out)
        return sorted(out, key=lambda t: t.ts)

    def cardholder_baseline(self, as_of: datetime, card_id: str, days: int) -> Baseline:
        """Baseline over [as_of - days, as_of] only. Never the full history."""
        self._count()
        lo = as_of - timedelta(days=days)
        win = [t for t in self._visible(card_id, as_of) if t.ts >= lo]
        if not win:
            return Baseline()
        amounts = np.array([t.amount for t in win], dtype=float)
        b = Baseline(
            amount_mean=float(amounts.mean()),
            amount_std=float(amounts.std()) if len(amounts) > 1 else max(float(amounts.mean()) * 0.3, 1.0),
            product_hist=dict(Counter(t.product_cd for t in win)),
            region_hist=dict(Counter(t.region for t in win if t.region)),
            device_hist=dict(Counter(t.device_id for t in win if t.device_id)),
            channel_hist=dict(Counter(t.channel.value for t in win)),
            n_txns=len(win),
        )
        if b.amount_std <= 0:
            b.amount_std = max(b.amount_mean * 0.3, 1.0)
        return b

    def device_neighbors(self, as_of: datetime, device_id: str, days: int) -> DeviceNeighbors:
        self._count()
        if not device_id:
            return DeviceNeighbors(device_id="")
        lo = as_of - timedelta(days=days)
        cards, txns = [], []
        for t in self.txns:
            if t.ts > as_of or t.ts < lo or t.device_id != device_id:
                continue
            txns.append(t.txn_id)
            if t.card_id not in cards:
                cards.append(t.card_id)
        cases = [cid for cid, tset in self._case_txns.items()
                 if any(self.by_id.get(x) and self.by_id[x].device_id == device_id
                        for x in tset)]
        return DeviceNeighbors(device_id=device_id, card_ids=cards,
                               txn_ids=txns, closed_cases=cases)

    def geo_velocity(self, as_of: datetime, card_id: str, hours: int) -> list[GeoPair]:
        self._count()
        lo = as_of - timedelta(hours=hours)
        win = [t for t in self._visible(card_id, as_of) if t.ts >= lo]
        out = []
        for a, b in zip(win, win[1:]):
            if a.region and b.region and a.region != b.region:
                out.append(GeoPair(from_txn=a.txn_id, to_txn=b.txn_id,
                                   from_region=a.region, to_region=b.region,
                                   minutes=(b.ts - a.ts).total_seconds() / 60.0))
        return out

    def testing_sequence(self, as_of: datetime, card_id: str, hours: int) -> TestingSequence:
        self._count()
        lo = as_of - timedelta(hours=max(hours, TESTING_WINDOW_H))
        win = [t for t in self._visible(card_id, as_of) if t.ts >= lo and t.channel.value == "online"]
        smalls = [t for t in win if t.amount < TESTING_SMALL_MAX]
        if len(smalls) < TESTING_MIN_SMALL:
            return TestingSequence()
        smalls = sorted(smalls, key=lambda t: t.ts)
        mean_small = sum(t.amount for t in smalls) / len(smalls)
        later = [t for t in win if t.ts > smalls[-1].ts
                 and t.amount >= max(mean_small * TESTING_LARGE_RATIO, 25.0)]
        if not later:
            return TestingSequence()
        big = later[0]
        return TestingSequence(fired=True,
                               small_txn_ids=[t.txn_id for t in smalls],
                               large_txn_id=big.txn_id, large_amount=big.amount)

    def recurring_check(self, as_of: datetime, card_id: str, days: int) -> RecurringResult:
        self._count()
        lo = as_of - timedelta(days=days)
        win = sorted([t for t in self._visible(card_id, as_of) if t.ts >= lo],
                     key=lambda t: t.ts)
        flagged = next((t for t in reversed(win) if t.txn_id in self.by_id), None)
        if flagged is None:
            return RecurringResult()
        matches = [t for t in win
                   if t.product_cd == flagged.product_cd
                   and abs(t.amount - flagged.amount) <= flagged.amount * RECURRING_AMOUNT_TOL]
        if len(matches) < 3:
            return RecurringResult()
        deltas = [(b.ts - a.ts).days for a, b in zip(matches, matches[1:])]
        cadence = sum(deltas) / len(deltas)
        if RECURRING_CADENCE_MIN_D <= cadence <= RECURRING_CADENCE_MAX_D:
            return RecurringResult(is_recurring=True,
                                   matched_txn_ids=[t.txn_id for t in matches],
                                   cadence_days=float(cadence))
        return RecurringResult()

    def episode_expand(self, as_of: datetime, seed_txn_ids: list[str],
                       hops: int) -> list[Txn]:
        self._count()
        seeds = [self.by_id[s] for s in seed_txn_ids if s in self.by_id and self.by_id[s].ts <= as_of]
        if not seeds:
            return []
        anchors = {t.card_id for t in seeds}
        devices = {t.device_id for t in seeds if t.device_id}
        regions = {t.region for t in seeds if t.region}
        emails = {t.p_email for t in seeds if t.p_email}

        out: dict[str, Txn] = {t.txn_id: t for t in seeds}
        for _ in range(max(1, hops)):
            added = []
            for t in self.txns:
                if t.ts > as_of or t.txn_id in out:
                    continue
                if t.card_id in anchors:
                    added.append(t)
                elif t.device_id and t.device_id in devices:
                    added.append(t)
                elif t.region and t.region in regions:
                    added.append(t)
                elif t.p_email and t.p_email in emails:
                    added.append(t)
            for t in added:
                out[t.txn_id] = t
            if not added:
                break
        res = list(out.values())
        self.assert_as_of(as_of, res)
        return sorted(res, key=lambda t: t.ts)

    # ------------------------------------------------------------- algorithms
    def ring_components(self, as_of: datetime, days: int, min_cards: int,
                        card_id: str) -> RingResult | None:
        """Connected component of cards sharing a device within the window.

        Mirrors the installed `ring_components` query (docs/QUERIES.md §3):
        single-source walk, deterministic ids. Union-find here must attach
        larger roots to smaller ones and iterate in sorted order, or the
        RING-* id depends on hash seed and answer files stop being byte-stable.
        """
        self._count()
        lo = as_of - timedelta(days=days)
        dev_cards: dict[str, set[str]] = defaultdict(set)
        for t in self.txns:
            if t.ts > as_of or t.ts < lo or not t.device_id:
                continue
            dev_cards[t.device_id].add(t.card_id)

        # union-find over cards sharing a device
        parent: dict[str, str] = {}

        def find(x: str) -> str:
            parent.setdefault(x, x)
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x

        def union(a: str, b: str) -> None:
            ra, rb = find(a), find(b)
            if ra != rb:
                parent[max(ra, rb)] = min(ra, rb)

        for device, cards in sorted(dev_cards.items()):
            cl = sorted(cards)
            for other in cl[1:]:
                union(cl[0], other)

        if card_id not in parent:
            return None
        root = find(card_id)
        comp = sorted(c for c in parent if find(c) == root)
        if len(comp) < min_cards:
            return None
        shared = max(((d, len(c)) for d, c in dev_cards.items() if c & set(comp)),
                     key=lambda x: (x[1], x[0]), default=("", 0))
        return RingResult(cluster_id=f"RING-{root}", size=len(comp), card_ids=comp)

    def shared_origin_cards(self, as_of: datetime, kind: str, element: str,
                            days: int) -> list[str]:
        self._count()
        lo = as_of - timedelta(days=days or SHARED_ORIGIN_WINDOW_DAYS)
        cards = set()
        for t in self.txns:
            if t.ts > as_of or t.ts < lo:
                continue
            v = {"device": t.device_id, "region": t.region, "email": t.p_email}.get(kind)
            if v and v == element:
                cards.add(t.card_id)
        return sorted(cards)

    def prior_cases(self, fingerprint: list[float], k: int) -> list[str]:
        """Nearest closed cases by behavioural fingerprint.

        In TigerGraph this is TigerVector over ClosedCase.fp
        (docs/UNCERTAINTY.md §6). Here it is exact cosine kNN.
        """
        self._count()
        if not self.closed_cases or not fingerprint:
            return []
        q = np.asarray(fingerprint, dtype=float)
        scored = []
        for cid, case in self.closed_cases.items():
            fp = self._fp_of(case)
            if fp is None:
                continue
            v = np.asarray(fp, dtype=float)
            denom = (np.linalg.norm(q) * np.linalg.norm(v)) or 1.0
            scored.append((float(np.dot(q, v) / denom), cid))
        scored.sort(reverse=True)
        return [cid for _, cid in scored[:k]]

    def _fp_of(self, case: ClosedCase) -> list[float] | None:
        txns = [self.by_id[t] for t in case.txn_ids if t in self.by_id]
        if not txns:
            return None
        amounts = [t.amount for t in txns]
        return [
            0.0,                                   # amount_z unknown for historical cases
            float(np.log1p(case.exposure_usd)),
            float(len(txns)),
            1.0 if case.pattern not in ("none", "") else 0.0,
            1.0 if case.pattern == "out_of_region_use" else 0.0,
            0.5,
            0.0,
            0.0, 0.0,
            float(np.mean([t.v_anom for t in txns])) if txns else 0.0,
            float(len(case.connected_card_ids)),
            float(len(case.connected_card_ids)),
        ]

    # --------------------------------------------------------------- lookups
    def customer_cards(self, customer_id: str) -> list[str]:
        return sorted(self.by_customer.get(customer_id, []))

    def closed_case_ids(self) -> list[str]:
        return sorted(self.closed_cases)

    def has_txn(self, txn_id: str) -> bool:
        return txn_id in self.by_id

    # ---------------------------------------------------------------- writes
    def write_case(self, case_id: str, payload: dict) -> str:
        self._count()
        self.written[case_id] = payload
        return case_id
