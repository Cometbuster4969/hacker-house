"""The policy engine — the ONLY writer of next_best_actions.

`resolve()` is pure: same input, same output, no I/O, no LLM, no network.
That is what makes a quarter of the score unit-testable.

docs/POLICY.md is the specification.
"""

from __future__ import annotations

import re

from ..config import (
    EXPOSURE_SAR,
    P_CASE_OPEN,
    P_STRONGLY_SUSPECTED,
)
from ..domain.enums import Action, Pattern, ResponseKind, Verdict
from ..domain.models import Decision
from .actions import route_for
from .rules import ActionBuilder, RuleInput, RULES, apply_r10

_CITATION = re.compile(r"\bR\d+\b|§\d")


def resolve(inp: RuleInput) -> Decision:
    """Resolve a case state into a policy-legal, correctly-routed action set.

    Never returns an empty action list. Every action carries a rule citation.
    """
    b = ActionBuilder()

    # R1-R9 plus the default action.
    for rule in RULES:
        rule(inp, b)

    # R10 is a veto, evaluated last. Nothing overrides it.
    apply_r10(inp, b)

    # A customer confirmation settles the verdict (R3).
    verdict = inp.verdict
    if inp.flags.response is ResponseKind.CONFIRMED:
        verdict = Verdict.LEGITIMATE

    closing = b.has(Action.CLOSE_NO_FRAUD)

    # ---- §3a: a case is not a report -------------------------------------
    open_case = (
        (inp.fraud_probability >= P_CASE_OPEN)
        or inp.evidence_requested
        or inp.flags.disputed
    ) and not closing

    if open_case and not b.has(Action.CREATE_CASE):
        b.emit(
            Action.CREATE_CASE,
            f"§3a: open a case — probability {inp.fraud_probability:.2f} "
            f"{'reaches' if inp.fraud_probability >= P_CASE_OPEN else ''}"
            f"{' / evidence requested' if inp.evidence_requested else ''}"
            f"{' / customer disputed' if inp.flags.disputed else ''}".replace("  ", " ").strip(),
        )

    # ---- §3a: the SAR decision -------------------------------------------
    # File when fraud is confirmed or strongly suspected AND at least one of:
    #   exposure > $1,000 ; shared device/region/other customer's fraud ;
    #   coordinated or undocumented pattern (R9).
    strongly = (verdict is Verdict.FRAUD) or (inp.fraud_probability >= P_STRONGLY_SUSPECTED)
    if verdict is Verdict.LEGITIMATE:
        strongly = False

    reasons = []
    if inp.exposure_usd > EXPOSURE_SAR:
        reasons.append(f"exposure ${inp.exposure_usd:,.2f} exceeds ${EXPOSURE_SAR:,}")
    if inp.flags.shared_origin:
        reasons.append(f"shared {inp.flags.shared_element or 'origin'}")
    if inp.flags.cross_customer:
        reasons.append("connected to another customer's fraud")
    if inp.pattern is Pattern.UNDOCUMENTED and inp.flags.cross_customer:
        reasons.append("undocumented coordinated pattern (R9)")

    file_sar = bool(strongly and reasons) and not closing

    if file_sar and not b.has(Action.FILE_REPORT):
        b.emit(Action.FILE_REPORT, "§3a: report required — " + "; ".join(reasons))
    if file_sar and not b.has(Action.CREATE_CASE):
        b.emit(Action.CREATE_CASE, "§3a: a report always has a case behind it")

    # ---- reconcile: the SAR decision is the engine's and is authoritative ----
    # A rule may *propose* FILE_REPORT (R6 presumes fraud). If §3a is not met —
    # e.g. the verdict came back legitimate — the proposal is withdrawn. This
    # is what makes `sar.file <=> FILE_REPORT in final` true by construction
    # (validator check #4).
    if not file_sar and b.has(Action.FILE_REPORT):
        b.remove(Action.FILE_REPORT)
        b._note("FILE_REPORT withdrawn — §3a conditions not met "
                f"(verdict={verdict.value}, p={inp.fraud_probability:.2f}, "
                f"exposure=${inp.exposure_usd:,.2f})")

    # ---- routes are computed, never generated ----------------------------
    for a in b.actions:
        a.route = route_for(a.action, inp.exposure_usd)

    # ---- §7: every recommendation must cite the rule ---------------------
    for a in b.actions:
        if not _CITATION.search(a.reason or ""):
            raise ValueError(
                f"action {a.action.value} emitted without a rule citation: {a.reason!r}"
            )

    if not b.actions:                       # defensive: a case with no actions is invalid
        raise AssertionError("policy engine produced an empty action set")

    return Decision(
        actions=b.actions,
        open_case=bool(open_case) or b.has(Action.CREATE_CASE),
        file_sar=file_sar,
        verdict=verdict,
        suppressed=b.suppressed,
    )


def resolve_evidence_requested(inp: RuleInput) -> bool:
    """Whether any emitted action is an evidence request (drives §3a case opening)."""
    d = resolve(inp)
    return any(
        a.action in (Action.VERIFY_WITH_CUSTOMER, Action.STEP_UP_AUTH)
        for a in d.actions
    )
