"""Fraud Policy v1.0 rules R1-R10 as code.

Each rule is a pure function over RuleInput that mutates an ActionBuilder.
Rules run in order; later rules may suppress or un-suppress earlier ones.
docs/POLICY.md §4 is the specification.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

from ..config import (
    EXPOSURE_ESCALATE,
    EXPOSURE_SAR,
    P_VERIFY_BELOW,
    PURCHASE_BLOCK,
)
from ..domain.enums import Action, Pattern, ResponseKind, Verdict
from ..domain.models import ActionRef, PolicyFlags


@dataclass
class RuleInput:
    fraud_probability: float
    exposure_usd: float
    verdict: Verdict
    pattern: Pattern
    n_independent_signals: int
    flags: PolicyFlags
    evidence_requested: bool = False


class ActionBuilder:
    """Accumulates actions, honouring suppression. Every emit carries a rule citation."""

    def __init__(self) -> None:
        self.actions: list[ActionRef] = []
        self.suppressed: list[str] = []
        self._blocked: set[Action] = set()

    def emit(self, action: Action, reason: str) -> None:
        """Route is left None here; engine._finalise assigns it from exposure."""
        if action in self._blocked:
            self._note(f"{action.value} withheld — {reason}")
            return
        if any(a.action is action for a in self.actions):
            return                                        # idempotent
        self.actions.append(ActionRef(action=action, reason=reason))

    def suppress(self, actions: tuple[Action, ...], by: str) -> None:
        for a in actions:
            self._blocked.add(a)
            removed = [x for x in self.actions if x.action is a]
            self.actions = [x for x in self.actions if x.action is not a]
            self._note(f"{a.value} withheld — {by}" if removed
                       else f"{a.value} blocked — {by}")

    def unsuppress(self, note: str = "") -> None:
        self._blocked.clear()
        if note:
            self._note(note)

    def has(self, action: Action) -> bool:
        return any(a.action is action for a in self.actions)

    def remove(self, action: Action) -> None:
        self.actions = [a for a in self.actions if a.action is not action]

    def _note(self, text: str) -> None:
        if text not in self.suppressed:                   # dedupe
            self.suppressed.append(text)


# ---------------------------------------------------------------------------
# R1 — Verify before you block on a weak signal
# ---------------------------------------------------------------------------
def r1(i: RuleInput, b: ActionBuilder) -> None:
    if i.n_independent_signals == 1 and i.fraud_probability < P_VERIFY_BELOW:
        b.emit(
            Action.VERIFY_WITH_CUSTOMER,
            f"R1: single signal ({i.n_independent_signals}) and probability "
            f"{i.fraud_probability:.2f} is below {P_VERIFY_BELOW}",
        )
        b.suppress(
            (Action.BLOCK_CARD, Action.BLOCK_ALL_CARDS, Action.DECLINE_TRANSACTION),
            by=f"R1: blocking a legitimate customer on one signal is a policy breach "
               f"(p={i.fraud_probability:.2f} < {P_VERIFY_BELOW})",
        )


# ---------------------------------------------------------------------------
# R2 — Customer denies the transaction
# ---------------------------------------------------------------------------
def r2(i: RuleInput, b: ActionBuilder) -> None:
    if i.flags.response is not ResponseKind.DENIED:
        return
    b.emit(Action.BLOCK_CARD, "R2: customer denied the transaction")
    b.emit(Action.CREATE_CASE, "R2: customer denial opens an internal case")

    # Escalation to a customer-wide block is *proposed* here and *permitted* by R10.
    # Defence in depth: the proposal and the guard are deliberately separate.
    if i.flags.cards_confirmed_fraud >= 2 or i.flags.credentials_compromised:
        b.emit(Action.BLOCK_ALL_CARDS, "R2: compromise spans multiple cards of this customer")

    if (i.exposure_usd > EXPOSURE_SAR
            or i.flags.shared_origin
            or i.flags.cross_customer):
        b.emit(
            Action.FILE_REPORT,
            "R2: exposure exceeds $1,000 / shared device / another card's fraud",
        )


# ---------------------------------------------------------------------------
# R3 — Customer confirms the transaction
# ---------------------------------------------------------------------------
def r3(i: RuleInput, b: ActionBuilder) -> None:
    if i.flags.response is ResponseKind.CONFIRMED:
        b.emit(Action.CLOSE_NO_FRAUD, "R3: customer confirmed the transaction")
        b.suppress(
            (Action.BLOCK_CARD, Action.BLOCK_ALL_CARDS, Action.DECLINE_TRANSACTION),
            by="R3: customer confirmed the transaction",
        )


# ---------------------------------------------------------------------------
# R4 — No reply within 24 hours
# ---------------------------------------------------------------------------
def r4(i: RuleInput, b: ActionBuilder) -> None:
    if i.flags.response is not ResponseKind.NO_REPLY:
        return
    b.emit(Action.MONITOR_CARD, "R4: no reply within 24 hours")
    b.emit(Action.DECLINE_TRANSACTION, "R4: decline pending authorizations")
    if i.exposure_usd > EXPOSURE_ESCALATE:
        b.emit(
            Action.ESCALATE_TO_ANALYST,
            f"R4: exposure ${i.exposure_usd:,.2f} exceeds ${EXPOSURE_ESCALATE}",
        )


# ---------------------------------------------------------------------------
# R5 — Card testing. OVERRIDES R1: the sequence is itself multiple signals.
# ---------------------------------------------------------------------------
def r5(i: RuleInput, b: ActionBuilder) -> None:
    if i.pattern is not Pattern.CARD_TESTING:
        return
    b.unsuppress("R5: testing sequence overrides the R1 suppression")
    b.emit(Action.DECLINE_TRANSACTION, "R5: card-testing sequence observed")
    b.emit(Action.STEP_UP_AUTH, "R5: step-up before further activity")
    if i.flags.max_cleared_purchase > PURCHASE_BLOCK:
        b.emit(
            Action.BLOCK_CARD,
            f"R5: a purchase over ${PURCHASE_BLOCK} "
            f"(${i.flags.max_cleared_purchase:,.2f}) has already cleared",
        )


# ---------------------------------------------------------------------------
# R6 — Shared origin
# ---------------------------------------------------------------------------
def r6(i: RuleInput, b: ActionBuilder) -> None:
    if not i.flags.shared_origin:
        return
    b.emit(Action.CREATE_CASE, "R6: shared origin across multiple cards")
    b.emit(Action.FILE_REPORT, "R6: shared origin requires a report")
    b.emit(
        Action.MONITOR_CONNECTED_CARDS,
        f"R6: monitor every card sharing {i.flags.shared_element or 'the shared element'}",
    )


# ---------------------------------------------------------------------------
# R7 — Disputed but legitimate (recurring charge). Do not block.
# ---------------------------------------------------------------------------
def r7(i: RuleInput, b: ActionBuilder) -> None:
    if not (i.flags.disputed and i.flags.is_recurring):
        return
    b.emit(Action.CREATE_CASE, "R7: disputed charge matches the cardholder's recurring pattern")
    b.emit(Action.VERIFY_WITH_CUSTOMER, "R7: confirm before acting")
    b.emit(Action.WARN_CUSTOMER, "R7: informational message to the customer")
    b.suppress(
        (Action.BLOCK_CARD, Action.BLOCK_ALL_CARDS, Action.DECLINE_TRANSACTION),
        by="R7: disputed charge matches a recurring pattern — do not block",
    )


# ---------------------------------------------------------------------------
# R8 — Escalate when uncertain and exposed, or when evidence conflicts
# ---------------------------------------------------------------------------
def r8(i: RuleInput, b: ActionBuilder) -> None:
    if (i.verdict is Verdict.UNCERTAIN and i.exposure_usd > EXPOSURE_ESCALATE) \
            or i.flags.conflicting_evidence:
        b.emit(Action.ESCALATE_TO_ANALYST, "R8: uncertain and exposed, or evidence conflicts")


# ---------------------------------------------------------------------------
# R9 — Undocumented patterns
# ---------------------------------------------------------------------------
def r9(i: RuleInput, b: ActionBuilder) -> None:
    if i.pattern is Pattern.UNDOCUMENTED and i.flags.cross_customer:
        b.emit(Action.CREATE_CASE, "R9: undocumented coordinated pattern")
        b.emit(Action.FILE_REPORT, "R9: coordinated or undocumented pattern")
        b.emit(Action.ESCALATE_TO_ANALYST, "R9: pattern fits no known category")


# ---------------------------------------------------------------------------
# Default — a case with no actions is invalid
# ---------------------------------------------------------------------------
def default_action(i: RuleInput, b: ActionBuilder) -> None:
    if b.actions:
        return
    # §7 requires every recommendation to cite the rule it follows from. The
    # default action follows from §1, which defines the legal action space.
    if i.verdict is Verdict.LEGITIMATE:
        b.emit(Action.ALLOW_TRANSACTION, "§1: no rule fired; activity assessed as legitimate")
    else:
        b.emit(Action.MONITOR_CARD, "§1: no rule fired; default to monitoring")


RULES: tuple[Callable[[RuleInput, ActionBuilder], None], ...] = (
    r1, r2, r3, r4, r5, r6, r7, r8, r9, default_action,
)


# ---------------------------------------------------------------------------
# R10 — BLOCK_ALL_CARDS guard. A VETO, evaluated last. Nothing overrides it.
# ---------------------------------------------------------------------------
def apply_r10(i: RuleInput, b: ActionBuilder) -> None:
    if not b.has(Action.BLOCK_ALL_CARDS):
        return
    if not (i.flags.cards_confirmed_fraud >= 2 or i.flags.credentials_compromised):
        b.remove(Action.BLOCK_ALL_CARDS)
        b.suppressed.append(
            "BLOCK_ALL_CARDS withheld — R10: fewer than two of the customer's cards "
            "show confirmed fraud and credentials are not confirmed compromised"
        )
