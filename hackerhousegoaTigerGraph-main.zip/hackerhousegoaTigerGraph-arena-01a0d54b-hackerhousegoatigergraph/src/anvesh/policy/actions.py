"""The 14 legal actions and the approval routing table.

Source: Fraud Policy v1.0 §1-§2. Every comparison operator here is quoted from
the policy text. docs/POLICY.md is the specification.
"""

from __future__ import annotations

from ..config import BLOCK_ROUTE_L1_MAX
from ..domain.enums import Action, Route

# ---------------------------------------------------------------------------
# Customer-impact friction weights (docs/POLICY.md §1)
# Used by the expected-cost model. Taken from the policy's own impact column.
# ---------------------------------------------------------------------------
FRICTION: dict[Action, float] = {
    Action.ALLOW_TRANSACTION: 0.0,
    Action.MONITOR_CARD: 0.0,
    Action.MONITOR_CONNECTED_CARDS: 0.0,
    Action.WARN_CUSTOMER: 0.0,
    Action.GENERATE_REPORT: 0.0,
    Action.CREATE_CASE: 0.0,
    Action.FILE_REPORT: 0.0,
    Action.ESCALATE_TO_ANALYST: 0.0,
    Action.CLOSE_NO_FRAUD: 0.0,
    Action.DECLINE_TRANSACTION: 1.0,        # Low
    Action.VERIFY_WITH_CUSTOMER: 1.0,       # Low
    Action.STEP_UP_AUTH: 2.0,               # Low
    Action.BLOCK_CARD: 6.0,                 # High
    Action.BLOCK_ALL_CARDS: 15.0,           # Very high
}

AUTO_ROUTE: frozenset[Action] = frozenset({
    Action.ALLOW_TRANSACTION,
    Action.MONITOR_CARD,
    Action.MONITOR_CONNECTED_CARDS,
    Action.WARN_CUSTOMER,
    Action.VERIFY_WITH_CUSTOMER,
    Action.STEP_UP_AUTH,
    Action.GENERATE_REPORT,
    Action.CREATE_CASE,
    Action.ESCALATE_TO_ANALYST,
    Action.CLOSE_NO_FRAUD,
})

BLOCK_ACTIONS: frozenset[Action] = frozenset({
    Action.BLOCK_CARD,
    Action.BLOCK_ALL_CARDS,
    Action.DECLINE_TRANSACTION,
})

ALL_ACTIONS: tuple[Action, ...] = tuple(Action)


def route_for(action: Action, exposure_usd: float) -> Route:
    """Compute the approval route. The route is never generated, always computed.

    Policy §2:
      auto : ALLOW_TRANSACTION, MONITOR_CARD, MONITOR_CONNECTED_CARDS, WARN_CUSTOMER,
             VERIFY_WITH_CUSTOMER, STEP_UP_AUTH, GENERATE_REPORT, CREATE_CASE,
             ESCALATE_TO_ANALYST, CLOSE_NO_FRAUD
      L1   : DECLINE_TRANSACTION ; BLOCK_CARD when exposure <= $2,500
      L2   : BLOCK_CARD when exposure > $2,500 ; BLOCK_ALL_CARDS always ; FILE_REPORT always
    """
    if action is Action.BLOCK_CARD:
        # "exposure ≤ $2,500" -> L1 ; "exposure > $2,500" -> L2
        return Route.L1 if exposure_usd <= BLOCK_ROUTE_L1_MAX else Route.L2
    if action in (Action.BLOCK_ALL_CARDS, Action.FILE_REPORT):
        return Route.L2                      # "always"
    if action is Action.DECLINE_TRANSACTION:
        return Route.L1
    if action in AUTO_ROUTE:
        return Route.AUTO
    raise ValueError(f"unknown action: {action}")


def is_executable(action: Action) -> bool:
    """Only `auto` actions may be executed by the agent. L1/L2 wait for a human."""
    return action in AUTO_ROUTE
