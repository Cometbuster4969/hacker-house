"""Expected-cost action ranking (docs/POLICY.md §7).

Within the policy-legal set, order actions by expected cost. This is why the
system recommends MONITOR_CARD over BLOCK_CARD at p = 0.4 — the arithmetic says
so, and R1 agrees. The rule citation is still required.
"""

from __future__ import annotations

from ..config import COST_LAMBDA_OPS, COST_MISSING_SAR
from ..domain.enums import Action
from ..domain.models import ActionRef, Decision
from .actions import FRICTION

# Fraction of the exposure each action prevents, if the activity really is fraud.
LOSS_PREVENTED: dict[Action, float] = {
    Action.ALLOW_TRANSACTION: 0.0,
    Action.CLOSE_NO_FRAUD: 0.0,
    Action.WARN_CUSTOMER: 0.05,
    Action.GENERATE_REPORT: 0.0,
    Action.CREATE_CASE: 0.05,
    Action.ESCALATE_TO_ANALYST: 0.20,
    Action.MONITOR_CARD: 0.30,
    Action.MONITOR_CONNECTED_CARDS: 0.15,
    Action.VERIFY_WITH_CUSTOMER: 0.35,
    Action.STEP_UP_AUTH: 0.60,
    Action.DECLINE_TRANSACTION: 0.85,
    Action.BLOCK_CARD: 0.95,
    Action.BLOCK_ALL_CARDS: 1.0,
    Action.FILE_REPORT: 0.10,
}

# Fraction of a case's operational burden each action adds.
OPS_COST: dict[Action, float] = {
    Action.ALLOW_TRANSACTION: 0.0,
    Action.CLOSE_NO_FRAUD: 0.5,
    Action.WARN_CUSTOMER: 0.5,
    Action.MONITOR_CARD: 1.0,
    Action.MONITOR_CONNECTED_CARDS: 1.5,
    Action.VERIFY_WITH_CUSTOMER: 2.0,
    Action.STEP_UP_AUTH: 2.5,
    Action.DECLINE_TRANSACTION: 1.5,
    Action.CREATE_CASE: 2.0,
    Action.ESCALATE_TO_ANALYST: 3.0,
    Action.BLOCK_CARD: 3.0,
    Action.BLOCK_ALL_CARDS: 4.0,
    Action.FILE_REPORT: 4.0,
    Action.GENERATE_REPORT: 1.0,
}


def expected_cost(actions: list[ActionRef], p: float, exposure_usd: float,
                  sar_required: bool = False) -> float:
    """Cost of an action set. Lower is better."""
    prevented = min(1.0, sum(LOSS_PREVENTED.get(a.action, 0.0) for a in actions))
    friction = sum(FRICTION.get(a.action, 0.0) for a in actions)
    ops = sum(OPS_COST.get(a.action, 0.0) for a in actions)

    cost = p * exposure_usd * (1.0 - prevented)     # fraud loss we failed to stop
    cost += (1.0 - p) * friction * 25.0             # customer friction, scaled to dollars
    cost += COST_LAMBDA_OPS * ops * 10.0            # operational
    if sar_required and not any(a.action is Action.FILE_REPORT for a in actions):
        cost += COST_MISSING_SAR                    # regulatory cost of not filing
    return cost


def rank(decision: Decision, p: float, exposure_usd: float) -> list[ActionRef]:
    """Order the legal set by marginal value: cheapest first is NOT the goal —
    we order by what happens first, then break ties by expected cost.

    Policy §1: "Order them by what happens first."
    """
    order = {
        Action.VERIFY_WITH_CUSTOMER: 10,
        Action.STEP_UP_AUTH: 10,
        Action.DECLINE_TRANSACTION: 20,
        Action.BLOCK_CARD: 30,
        Action.BLOCK_ALL_CARDS: 35,
        Action.MONITOR_CARD: 40,
        Action.MONITOR_CONNECTED_CARDS: 45,
        Action.WARN_CUSTOMER: 50,
        Action.ESCALATE_TO_ANALYST: 60,
        Action.CREATE_CASE: 70,
        Action.FILE_REPORT: 75,
        Action.GENERATE_REPORT: 80,
        Action.ALLOW_TRANSACTION: 90,
        Action.CLOSE_NO_FRAUD: 95,
    }
    return sorted(
        decision.actions,
        key=lambda a: (order.get(a.action, 99),
                       expected_cost([a], p, exposure_usd, decision.file_sar)),
    )
