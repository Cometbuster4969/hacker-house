"""Fit the likelihood table from the closed-case corpus.

docs/BACKTEST.md §5 — closed-case `txn_ids` are 5,565 free labelled episodes.
This module turns them into training rows for the LR table and for episode
segmentation tuning.

Fit on TRAIN only. Never touch EVAL (docs/BACKTEST.md §4).
"""

from __future__ import annotations

import json
from datetime import timedelta
from pathlib import Path

import numpy as np

from ..domain.enums import Channel
from ..domain.models import Baseline, ClosedCase, Episode, EvidenceContext
from ..evidence.features import build_features
from .likelihood import LikelihoodTable

BASELINE_DAYS = 90
CACHE_PATH = Path(__file__).resolve().parents[3] / "benchmark" / "fitted_likelihood_table.json"


def context_for_closed_case(adapter, case: ClosedCase) -> EvidenceContext | None:
    """Rebuild the context an analyst would have seen at case open time."""
    flagged_id = case.first_fraud_txn_id or (case.txn_ids[0] if case.txn_ids else None)
    if not flagged_id:
        return None
    flagged = adapter.txn_context(case.opened_at, flagged_id)
    if flagged is None:
        return None

    window = adapter.card_window(case.opened_at, case.card_id, 48)
    baseline = adapter.cardholder_baseline(case.opened_at, case.card_id, BASELINE_DAYS)
    geo = adapter.geo_velocity(case.opened_at, case.card_id, 48)

    device_cards, device_cases = [], []
    if flagged.channel is Channel.ONLINE and flagged.device_id:
        dn = adapter.device_neighbors(case.opened_at, flagged.device_id, 30)
        device_cards = [c for c in dn.card_ids if c != case.card_id]
        device_cases = dn.closed_cases

    return EvidenceContext(
        as_of=case.opened_at,
        flagged_txn_id=flagged_id,
        card_id=case.card_id,
        customer_id=case.customer_id,
        channel=flagged.channel,
        flagged=flagged,
        window_txns=window,
        baseline=baseline,
        geo_pairs=geo,
        device_cards=device_cards,
        device_closed_cases=device_cases,
        customer_cards=adapter.customer_cards(case.customer_id),
    )


def episode_from_closed_case(adapter, case: ClosedCase) -> Episode:
    amounts = []
    for tid in case.txn_ids:
        t = adapter.txn_context(case.opened_at, tid)
        if t is not None:
            amounts.append(abs(t.amount))
    return Episode(
        txn_ids=list(case.txn_ids),
        first_suspicious_txn_id=case.first_fraud_txn_id or (case.txn_ids[0] if case.txn_ids else ""),
        exposure_usd=round(sum(amounts), 2),
    )


def _load_cached_table() -> tuple[LikelihoodTable, int] | None:
    if not CACHE_PATH.is_file():
        return None
    try:
        data = json.loads(CACHE_PATH.read_text(encoding="utf-8"))
        edges = {k: np.array(v, dtype=float) for k, v in data.get("edges", {}).items()}
        lr = {k: np.array(v, dtype=float) for k, v in data.get("lr", {}).items()}
        n = data.get("n_cases", len(edges))
        tbl = LikelihoodTable(edges=edges, lr=lr)
        return tbl, n
    except Exception:
        return None


def _save_cached_table(table: LikelihoodTable, n_cases: int) -> None:
    try:
        CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
        data = {
            "n_cases": n_cases,
            "edges": {k: v.tolist() for k, v in table.edges.items()},
            "lr": {k: v.tolist() for k, v in table.lr.items()},
        }
        CACHE_PATH.write_text(json.dumps(data, indent=2), encoding="utf-8")
    except Exception:
        pass


def fit_table(adapter, closed_cases: list[ClosedCase],
              limit: int | None = None) -> tuple[LikelihoodTable, int]:
    """Estimate per-feature log-likelihood-ratios from labelled closed cases."""
    # Fast path: if no limit is specified, check disk cache
    if limit is None:
        cached = _load_cached_table()
        if cached is not None and cached[0].is_fitted():
            return cached

    rows: list[dict[str, float]] = []
    outcomes: list[bool] = []

    cases = closed_cases[:limit] if limit else closed_cases
    total = len(cases)
    show_progress = total > 100

    for i, case in enumerate(cases):
        if show_progress and (i % 250 == 0 or i == total - 1):
            pct = int((i + 1) / total * 100)
            print(f"  [fit] processing training cases: {i+1}/{total} ({pct}%)...", end="\r", flush=True)

        ctx = context_for_closed_case(adapter, case)
        if ctx is None:
            continue
        ep = episode_from_closed_case(adapter, case)
        rows.append(build_features(ctx, ep))
        outcomes.append(case.outcome == "confirmed_fraud")

    if show_progress:
        print()  # newline after carriage return

    table = LikelihoodTable().fit(rows, outcomes)
    if limit is None and table.is_fitted():
        _save_cached_table(table, len(rows))

    return table, len(rows)
