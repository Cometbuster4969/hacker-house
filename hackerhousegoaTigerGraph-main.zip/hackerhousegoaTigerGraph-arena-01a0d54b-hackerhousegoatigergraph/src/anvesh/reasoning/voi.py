"""Value of information — the stopping rule.

docs/POLICY.md §6 and docs/STATE.md §4.3.

Policy §6 permits stopping when "further steps are unlikely to change the
decision". That is a decision-theoretic claim, so we test it as one: ask for
evidence only if a plausible response could actually change the action set.

This is the single most direct hit on the 25% next-best-action criterion, and
it prevents the most common agentic failure in this task — asking a question
whose answer changes nothing.
"""

from __future__ import annotations

from dataclasses import replace
from dataclasses import replace as dc_replace
from typing import Callable

from ..config import COST_OF_ASKING, RESPONSE_PRIORS
from ..domain.enums import EvidenceRequestType, ResponseKind
from ..domain.models import PolicyFlags
from ..policy.cost import expected_cost
from ..policy.engine import resolve
from ..policy.rules import RuleInput


def with_response(base: RuleInput, kind: ResponseKind, p: float) -> RuleInput:
    return dc_replace(
        base,
        fraud_probability=p,
        flags=replace(base.flags, response=kind),
    )


def value_of_information(
    base: RuleInput,
    request_type: EvidenceRequestType | str,
    p_updater: Callable[[str], float],
) -> tuple[float, dict]:
    """Expected benefit of asking, minus the cost of asking.

    Returns (voi, detail). Ask only if voi > 0.
    """
    key = request_type.value if isinstance(request_type, EvidenceRequestType) else str(request_type)
    priors = RESPONSE_PRIORS.get(key, RESPONSE_PRIORS["customer_validation"])

    d0 = resolve(base)
    c0 = expected_cost(d0.actions, base.fraud_probability, base.exposure_usd, d0.file_sar)
    a0 = {a.action for a in d0.actions}

    benefit = 0.0
    flip = 0.0
    per: dict[str, dict] = {}

    for resp, pr in priors.items():
        p2 = p_updater(resp)
        i2 = with_response(base, ResponseKind(resp), p2)
        d2 = resolve(i2)
        c2 = expected_cost(d2.actions, p2, i2.exposure_usd, d2.file_sar)
        a2 = {a.action for a in d2.actions}
        changed = a2 != a0
        per[resp] = {
            "p": round(p2, 3),
            "changed": changed,
            "cost_before": round(c0, 2),
            "cost_after": round(c2, 2),
            "actions": sorted(a.value for a in a2),
        }
        benefit += pr * max(0.0, c0 - c2)
        flip += pr if changed else 0.0

    cost = COST_OF_ASKING.get(key, 0.05)
    voi = benefit - cost

    return voi, {
        "request_type": key,
        "flip_probability": round(flip, 3),
        "gross_benefit": round(benefit, 3),
        "cost_of_asking": cost,
        "cost_now": round(c0, 2),
        "per_response": per,
    }


def stop_reason_from_voi(voi: float, detail: dict, p: float) -> str:
    flip = detail.get("flip_probability", 0.0)
    if flip <= 0.0:
        return (f"No response can change the action set (VOI={voi:.2f}). At p={p:.2f} the "
                f"policy-legal actions are the same whether the customer confirms, denies "
                f"or does not reply.")
    if voi <= 0:
        return (f"A response could change the action set (P(change)={flip:.2f}) but the "
                f"expected benefit ({detail.get('gross_benefit', 0):.2f}) does not exceed "
                f"the cost of asking ({detail.get('cost_of_asking', 0):.2f}). VOI={voi:.2f}.")
    return ""
