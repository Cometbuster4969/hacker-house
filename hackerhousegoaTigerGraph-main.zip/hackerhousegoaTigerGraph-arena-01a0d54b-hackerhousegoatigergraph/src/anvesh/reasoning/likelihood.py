"""Likelihood ratios estimated from the closed-case corpus.

docs/UNCERTAINTY.md §4. P(feature | confirmed_fraud) / P(feature | cleared).

The ORDERING of an LR survives outcome-dependent selection even though the
LEVEL does not — which is exactly why we fit LRs here but assume the prior
(docs/UNCERTAINTY.md §2).
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from ..evidence.features import FEATURE_NAMES


@dataclass
class LikelihoodTable:
    edges: dict[str, np.ndarray] = None      # feature -> bin edges
    lr: dict[str, np.ndarray] = None         # feature -> per-bin log-LR

    def __post_init__(self) -> None:
        self.edges = self.edges or {}
        self.lr = self.lr or {}

    # ---------------------------------------------------------------- fit
    def fit(self, rows: list[dict[str, float]], outcomes: list[bool],
            n_bins: int = 5, smoothing: float = 1.0) -> "LikelihoodTable":
        """Fit per-feature binned log-likelihood-ratios.

        Bins are quantiles of the training distribution per feature. Features
        that are constant are dropped (they carry no information).
        """
        y = np.asarray(outcomes, dtype=bool)
        if len(rows) < 20 or y.sum() == 0 or (~y).sum() == 0:
            return self                                   # not enough signal; stay neutral

        for name in FEATURE_NAMES:
            col = np.asarray([float(r.get(name, 0.0)) for r in rows], dtype=float)
            if np.nanstd(col) == 0:
                continue                                   # constant -> uninformative
            qs = np.unique(np.nanquantile(col, np.linspace(0, 1, n_bins + 1)))
            if len(qs) < 2:
                continue
            idx = np.clip(np.digitize(col, qs[1:-1], right=False), 0, len(qs) - 2)

            pos = np.zeros(len(qs) - 1) + smoothing
            neg = np.zeros(len(qs) - 1) + smoothing
            np.add.at(pos, idx[y], 1.0)
            np.add.at(neg, idx[~y], 1.0)

            pos_rate = pos / pos.sum()
            neg_rate = neg / neg.sum()
            self.edges[name] = qs
            self.lr[name] = np.log(np.clip(pos_rate, 1e-6, None)
                                   / np.clip(neg_rate, 1e-6, None))
        return self

    # -------------------------------------------------------------- apply
    def bin_of(self, name: str, value: float) -> int:
        qs = self.edges[name]
        return int(np.clip(np.digitize(float(value), qs[1:-1], right=False),
                           0, len(qs) - 2))

    def log_lr(self, features: dict[str, float]) -> dict[str, float]:
        out: dict[str, float] = {}
        for name in FEATURE_NAMES:
            if name not in self.lr:
                continue
            v = features.get(name, 0.0)
            if v is None or (isinstance(v, float) and (math.isnan(v) or math.isinf(v))):
                v = 0.0
            out[name] = float(self.lr[name][self.bin_of(name, v)])
        return out

    def is_fitted(self) -> bool:
        return bool(self.lr)


NEUTRAL = LikelihoodTable()
"""A table that contributes nothing — the safe default before fitting."""
