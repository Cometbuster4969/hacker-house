"""The fraud-probability model.

docs/UNCERTAINTY.md §1:

    logit(p) = logit(pi0) + gamma * sum_i w_i * log LR_i        [then prior-corrected]
    p        = alpha * p_det + (1 - alpha) * p_llm

Never returns 0.0 or 1.0.
"""

from __future__ import annotations

from ..config import (
    FUSION_ALPHA,
    LR_RESPONSE,
    LR_SHRINKAGE_GAMMA,
    P_CLAMP_MAX,
    P_CLAMP_MIN,
    PI_TRAIN,
)
from ..domain.enums import ResponseKind
from ..evidence.features import AXIS_OF, FEATURE_NAMES
from .likelihood import LikelihoodTable
from .priors import correct_prior, logit, sigmoid


def clamp(p: float) -> float:
    return max(P_CLAMP_MIN, min(P_CLAMP_MAX, float(p)))


def score_det(features: dict[str, float],
              table: LikelihoodTable,
              prior: float = PI_TRAIN,
              gamma: float = LR_SHRINKAGE_GAMMA) -> tuple[float, dict[str, float]]:
    """Deterministic episode score, in the TRAINING population's scale.

    The LRs were estimated on the closed-case corpus, whose base rate is
    PI_TRAIN. So the logit base must be PI_TRAIN — not the target prior. The
    target prior enters afterwards, via correct_prior() (see `score`).

    Evidence axes are NOT independent, so log-LRs are averaged within an axis
    and shrunk by gamma, rather than naively summed.
    """
    lrs = table.log_lr(features)

    by_axis: dict[str, list[float]] = {}
    for name, val in lrs.items():
        by_axis.setdefault(AXIS_OF.get(name, "graph").value, []).append(val)

    per_axis = {axis: (sum(vals) / len(vals)) for axis, vals in by_axis.items()}
    total = gamma * sum(per_axis.values())

    p = sigmoid(logit(prior) + total)
    return clamp(p), per_axis


def score(features: dict[str, float],
          table: LikelihoodTable,
          pi_target: float,
          gamma: float = LR_SHRINKAGE_GAMMA) -> tuple[float, dict[str, float]]:
    """Score, then correct from the training base rate to the target prior.

    Two distinct steps, deliberately:
      1. evidence shifts belief *within* the closed-case population (PI_TRAIN)
      2. the level is re-based to the alert population (pi_target)
    Mixing them —using pi_target as the logit base— would silently undo the
    correction. docs/UNCERTAINTY.md §2.
    """
    p_raw, per_axis = score_det(features, table, PI_TRAIN, gamma)
    return clamp(correct_prior(p_raw, pi_target)), per_axis


def fuse(p_det: float, p_llm: float | None, alpha: float = FUSION_ALPHA) -> float:
    """Fuse the deterministic score with the LLM's independent read.

    If the LLM did not run, or returned nothing usable, p_det stands alone.
    """
    if p_llm is None:
        return clamp(p_det)
    return clamp(alpha * p_det + (1.0 - alpha) * p_llm)


def update_on_response(p: float, response: ResponseKind | str) -> float:
    """Bayesian update using the response likelihood ratio.

    docs/UNCERTAINTY.md §5. LR values are odds multipliers learned from
    closed-case analyst_notes (config.LR_RESPONSE).
    """
    key = response.value if isinstance(response, ResponseKind) else str(response)
    lr = LR_RESPONSE.get(key, 1.0)
    if lr == 1.0:
        return clamp(p)
    return clamp(sigmoid(logit(p) + _log(lr)))


def _log(x: float) -> float:
    import math
    return math.log(max(x, 1e-9))


def verdict_from(p: float, n_signals: int,
                 low: float = 0.15, high: float = 0.85) -> str:
    """Map a probability to a verdict.

    Stops only when the probability is extreme AND supported by >= 2 independent
    signals (policy §6). Otherwise the verdict stays `uncertain`, which is a
    valid and scored answer for genuinely ambiguous cases.
    """
    if p >= high and n_signals >= 2:
        return "fraud"
    if p <= low and n_signals >= 2:
        return "legitimate"
    return "uncertain"
