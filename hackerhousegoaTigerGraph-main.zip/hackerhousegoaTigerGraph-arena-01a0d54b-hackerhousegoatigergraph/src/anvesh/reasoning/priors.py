"""Priors and the selection-bias correction.

docs/UNCERTAINTY.md §2. THE PRIOR IS AN ASSUMPTION, NOT A MEASUREMENT — the
closed-case corpus is 84% fraud while the alert population is ~50%.
"""

from __future__ import annotations

import math

from ..config import (
    PI_TRAIN,
    PRIOR_ANALYST_REQUEST,
    PRIOR_CUSTOMER_REPORT,
    PRIOR_RISK_BANDS,
)
from ..domain.enums import TriggerType


def logit(p: float) -> float:
    p = min(max(p, 1e-9), 1 - 1e-9)
    return math.log(p / (1.0 - p))


def sigmoid(x: float) -> float:
    if x < -700:
        return 0.0
    if x > 700:
        return 1.0
    return 1.0 / (1.0 + math.exp(-x))


def prior_for(trigger_type: TriggerType, risk_score: float | None) -> float:
    """Base rate before evidence. Documented assumption, not a fitted quantity."""
    if trigger_type is TriggerType.CUSTOMER_REPORT:
        return PRIOR_CUSTOMER_REPORT
    if trigger_type is TriggerType.ANALYST_REQUEST:
        return PRIOR_ANALYST_REQUEST
    if risk_score is None:
        return PRIOR_RISK_BANDS[1][1]
    for upper, pi0 in PRIOR_RISK_BANDS:
        if risk_score < upper:
            return pi0
    return PRIOR_RISK_BANDS[-1][1]


def correct_prior(p_model: float, pi_target: float,
                  pi_train: float = PI_TRAIN) -> float:
    """Shift a model trained under outcome-dependent selection to the target
    base rate.

        logit(p') = logit(p) + logit(pi_target) - logit(pi_train)

    Directionally correct; magnitude approximate, because the closed cases were
    selected by an upstream triage rule that correlates with the outcome, not
    by the outcome itself. Say so when reporting (docs/UNCERTAINTY.md §2).
    """
    return sigmoid(logit(p_model) + logit(pi_target) - logit(pi_train))
