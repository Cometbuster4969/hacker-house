"""Real-CSV loader: tolerant columns, loud failures, deterministic v_anom.

Fixtures use Vesta-style headers (TransactionID, TransactionDT, ProductCD...)
to prove the alias resolution works on the shapes the real files plausibly
have. If the real headers differ, the loader's error message — not a silent
wrong load — is what the user sees.
"""

from __future__ import annotations

from datetime import datetime

import pytest

from anvesh.data.loader import (
    LoadConfig,
    LoaderError,
    load_closed_cases,
    load_pack,
    load_transactions,
    scan_ids,
    validate_pack,
)
from anvesh.domain.enums import Channel

TXN_CSV = """TransactionID,TransactionDT,TransactionAmt,ProductCD,card1,card2,addr1,addr2,P_emaildomain,R_emaildomain,M1,M2,V1,V2,V3,V4,V5
T1,1000,500.00,C,1111,2222,444,87,gmail.com,shop.com,T,F,0.1,0.2,0.3,0.4,0.5
T2,2000,20.00,W,1111,2222,444,87,,,T,T,0.0,0.1,0.0,0.1,0.0
T3,3000,49.00,S,3333,4444,101,87,yahoo.com,,T,T,0.2,0.1,0.2,0.1,0.2
T4,4000,49.00,S,3333,4444,101,87,yahoo.com,,F,F,0.1,0.3,0.1,0.3,0.1
T5,5000,49.00,S,3333,4444,101,87,yahoo.com,,T,T,0.3,0.2,0.3,0.2,0.3
T6,6000,49.00,S,3333,4444,101,87,yahoo.com,,T,T,0.2,0.2,0.2,0.2,0.2
T7,7000,49.00,S,3333,4444,101,87,yahoo.com,,T,T,0.1,0.1,0.1,0.1,0.1
T8,8000,49.00,S,3333,4444,101,87,yahoo.com,,T,T,0.0,0.0,0.0,0.0,0.0
T9,9000,49.00,S,3333,4444,101,87,yahoo.com,,T,T,0.5,0.5,0.5,0.5,0.5
T10,10000,49.00,S,3333,4444,101,87,yahoo.com,,T,T,0.4,0.4,0.4,0.4,0.4
T11,11000,49.00,S,3333,4444,101,87,yahoo.com,,T,T,0.6,0.1,0.6,0.1,0.6
T12,12000,49.00,S,3333,4444,101,87,yahoo.com,,T,T,0.1,0.6,0.1,0.6,0.1
"""

IDENT_CSV = """TransactionID,DeviceInfo,os,browser,screen
T1,SAMSUNG SM-G935F,Android 7.0,chrome,1440x2560
T3,"iPhone 9,3",iOS 11.2,safari,750x1334
"""

CLOSED_CSV = """case_id,customer_id,card_id,opened_at,closed_at,outcome,pattern,first_fraud_txn_id,txn_ids,n_txns,exposure_usd,connected_card_ids,actions_taken,report_filed,analyst_notes
CC-1,444-87,1111-2222,2016-08-01 10:00:00,2016-08-03 10:00:00,confirmed_fraud,card_testing,T1,T1,1,500.0,,BLOCK_CARD,true,Customer denied.
"""

PACK_CSV = """case_id,opened_at,trigger_type,trigger_text,flagged_txn_id,card_id,customer_id,risk_score
HHG-001,2016-11-05 10:00:00,risk_score,scored 0.9,T1,1111-2222,444-87,0.9
"""


@pytest.fixture
def datadir(tmp_path):
    (tmp_path / "transactions.csv").write_text(TXN_CSV)
    (tmp_path / "identity.csv").write_text(IDENT_CSV)
    (tmp_path / "closed_cases_history.csv").write_text(CLOSED_CSV)
    (tmp_path / "case_pack.csv").write_text(PACK_CSV)
    return tmp_path


def _all(cfg):
    out = []
    for batch in load_transactions(cfg):
        out.extend(batch)
    return out


def test_full_load_derives_channels_devices_and_flags(datadir):
    txns = _all(LoadConfig(datadir))
    assert len(txns) == 12
    by_id = {t.txn_id: t for t in txns}
    assert by_id["T1"].channel is Channel.ONLINE
    assert by_id["T2"].channel is Channel.IN_PERSON   # ProductCD W
    assert by_id["T2"].device_id is None
    assert by_id["T1"].device_id == "SAMSUNG SM-G935F | Android 7.0 | chrome | 1440x2560"
    assert by_id["T1"].m_flags == 1                   # M2=F
    assert by_id["T4"].m_flags == 2
    assert by_id["T1"].card_id == "1111-2222"         # card1+card2 composite
    assert by_id["T1"].customer_id == "444-87"        # addr1+addr2 fallback
    assert by_id["T1"].ts == datetime(2016, 7, 1, 0, 16, 40)  # origin + 1000s
    assert all(0.0 <= t.v_anom <= 1.0 for t in txns)


def test_v_anom_is_deterministic(datadir):
    a = [t.v_anom for t in _all(LoadConfig(datadir))]
    b = [t.v_anom for t in _all(LoadConfig(datadir))]
    assert a == b


def test_explicit_id_columns_win(datadir, tmp_path):
    cfg = LoadConfig(datadir, card_id_from=["card1"],
                     customer_id_from=["addr1"])
    txns = _all(cfg)
    assert {t.card_id for t in txns} == {"1111", "3333"}
    assert {t.customer_id for t in txns} == {"444", "101"}


def test_missing_required_column_is_loud(tmp_path):
    (tmp_path / "transactions.csv").write_text("foo,bar\n1,2\n")
    with pytest.raises(LoaderError, match="txn_id"):
        _all(LoadConfig(tmp_path))


def test_closed_cases_and_pack_parse(datadir):
    closed = load_closed_cases(datadir / "closed_cases_history.csv")
    assert len(closed) == 1
    assert closed[0].txn_ids == ["T1"] and closed[0].report_filed is True
    pack = load_pack(datadir / "case_pack.csv")
    assert len(pack) == 1 and pack[0].risk_score == 0.9


def test_pack_validation_passes_and_fails(datadir):
    reg = scan_ids(LoadConfig(datadir))
    assert reg.knows("T1") and reg.knows("1111-2222") and reg.knows("CC-1")
    validate_pack(load_pack(datadir / "case_pack.csv"), reg)   # must not raise

    bad = load_pack(datadir / "case_pack.csv")
    object.__setattr__(bad[0], "card_id", "WRONG")
    with pytest.raises(LoaderError, match="CARD_ID_FROM"):
        validate_pack(bad, reg)


def test_scan_ids_does_not_hold_transactions(datadir):
    reg = scan_ids(LoadConfig(datadir))
    assert not reg.knows("T999")
