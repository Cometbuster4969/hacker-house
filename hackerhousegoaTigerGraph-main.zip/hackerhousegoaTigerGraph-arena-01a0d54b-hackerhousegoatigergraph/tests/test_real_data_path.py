"""The real-data path, offline: synthetic -> CSVs -> loader -> pipeline.

This is the closest the sandbox gets to the submission run. It proves the
loader's output plugs into the investigator: three cases load from CSV,
investigate, and validate. v_anom is recomputed by the loader's own
IsolationForest (it cannot survive a CSV round-trip, and shouldn't need to).
"""

from __future__ import annotations

from datetime import datetime

import pandas as pd

from anvesh.agent.investigator import Investigator
from anvesh.data.loader import (
    TIME_ORIGIN,
    LoadConfig,
    load_closed_cases,
    load_pack,
    load_transactions,
    scan_ids,
    validate_pack,
)
from anvesh.data.synthetic import generate
from anvesh.graph.memory_adapter import MemoryAdapter
from anvesh.reasoning.fit import fit_table
from anvesh.util.ids import IdRegistry
from anvesh.validate.checks import validate


def _export_csvs(data, path) -> None:
    txns = [{
        "TransactionID": t.txn_id,
        "TransactionDT": int((t.ts - TIME_ORIGIN).total_seconds()),
        "TransactionAmt": t.amount,
        "ProductCD": t.product_cd,
        "card_id": t.card_id,
        "customer_id": t.customer_id,
        "addr1": t.region or "",
        "addr2": t.country or "",
        "P_emaildomain": t.p_email or "",
        "R_emaildomain": t.r_email or "",
        "risk_score": t.risk_score,
        "M1": "F" if t.m_flags >= 1 else "T",
        "M2": "F" if t.m_flags >= 2 else "T",
        "M3": "F" if t.m_flags >= 3 else "T",
        "V1": t.v_anom, "V2": 0.0, "V3": 0.0, "V4": 0.0, "V5": 0.0,
    } for t in data.txns]
    pd.DataFrame(txns).to_csv(path / "transactions.csv", index=False)

    ident = [{"TransactionID": t.txn_id, "DeviceInfo": t.device_id or ""}
             for t in data.txns if t.device_id]
    pd.DataFrame(ident).to_csv(path / "identity.csv", index=False)

    closed = [{
        "case_id": c.case_id, "customer_id": c.customer_id, "card_id": c.card_id,
        "opened_at": c.opened_at.isoformat(), "closed_at": c.closed_at.isoformat(),
        "outcome": c.outcome, "pattern": c.pattern,
        "first_fraud_txn_id": c.first_fraud_txn_id or "",
        "txn_ids": ";".join(c.txn_ids), "n_txns": c.n_txns,
        "exposure_usd": c.exposure_usd,
        "connected_card_ids": ";".join(c.connected_card_ids),
        "actions_taken": ";".join(c.actions_taken),
        "report_filed": str(c.report_filed),
        "analyst_notes": c.analyst_notes,
    } for c in data.closed_cases]
    pd.DataFrame(closed).to_csv(path / "closed_cases_history.csv", index=False)

    pack = [{
        "case_id": r.case_id, "opened_at": r.opened_at.isoformat(),
        "trigger_type": r.trigger_type.value, "trigger_text": r.trigger_text,
        "flagged_txn_id": r.flagged_txn_id, "card_id": r.card_id,
        "customer_id": r.customer_id, "risk_score": r.risk_score or "",
    } for r in data.case_pack]
    pd.DataFrame(pack).to_csv(path / "case_pack.csv", index=False)


def test_csv_round_trip_investigates_and_validates(tmp_path):
    data = generate(n_customers=40, seed=20260924)
    _export_csvs(data, tmp_path)

    cfg = LoadConfig(tmp_path)
    pack = load_pack(tmp_path / "case_pack.csv")
    closed = load_closed_cases(tmp_path / "closed_cases_history.csv")
    assert len(pack) == 20 and len(closed) == len(data.closed_cases)

    txns = []
    for batch in load_transactions(cfg):
        txns.extend(batch)
    assert len(txns) == len(data.txns)

    adapter = MemoryAdapter(txns, closed)
    registry = IdRegistry.from_adapter(adapter)
    validate_pack(pack, registry)                       # must not raise

    table, n = fit_table(adapter, closed)
    assert table.is_fitted() and n > 0

    inv = Investigator(adapter, registry, table=table)
    for row in pack[:3]:
        answer, _st = inv.run(row)
        rep = validate(answer, registry)
        assert rep.passed, f"{row.case_id}: {rep.errors}"


def test_scan_ids_matches_full_load(tmp_path):
    data = generate(n_customers=40, seed=20260924)
    _export_csvs(data, tmp_path)
    cfg = LoadConfig(tmp_path)
    reg = scan_ids(cfg)
    pack = load_pack(tmp_path / "case_pack.csv")
    validate_pack(pack, reg)                            # must not raise
    assert reg.knows(data.case_pack[0].flagged_txn_id)
