"""Detector correctness.

The in-person guard is the highest-value test in the suite: the dataset has no
merchant column but ProductCD encodes it, and a detector that reads a stale
device on an in-person transaction produces confident, invisible nonsense.
"""

from __future__ import annotations

from datetime import datetime, timedelta

from anvesh.domain.enums import Channel, Pattern
from anvesh.domain.models import Baseline, EvidenceContext, Txn
from anvesh.evidence.detectors import (
    DETECTORS,
    detect_card_testing,
    detect_cnp_new_device,
    run_all,
)

AS_OF = datetime(2016, 12, 1, 12, 0, 0)


def txn(tid: str, minutes_ago: int, amount: float, **kw) -> Txn:
    return Txn(
        txn_id=tid,
        ts=AS_OF - timedelta(minutes=minutes_ago),
        amount=amount,
        card_id=kw.pop("card_id", "C000-K1"),
        customer_id=kw.pop("customer_id", "C000"),
        product_cd=kw.pop("product_cd", "W"),
        channel=kw.pop("channel", Channel.ONLINE),
        risk_score=kw.pop("risk_score", 50.0),
        **kw,
    )


def online_ctx(window: list[Txn], **kw) -> EvidenceContext:
    flagged = window[0]
    return EvidenceContext(
        as_of=AS_OF,
        flagged_txn_id=flagged.txn_id,
        card_id=flagged.card_id,
        customer_id=flagged.customer_id,
        channel=Channel.ONLINE,
        flagged=flagged,
        window_txns=window,
        baseline=kw.pop("baseline", Baseline(amount_mean=100.0, amount_std=20.0,
                                             n_txns=40)),
        **kw,
    )


# --------------------------------------------------------------- in-person guard


def _in_person_ctx(**kw) -> EvidenceContext:
    """A card-present transaction (ProductCD 'W' is the dataset's proxy)."""
    flagged = txn("T1", 5, 40.0, product_cd="W", channel=Channel.IN_PERSON,
                  device_id=kw.pop("device_id", None))
    return EvidenceContext(
        as_of=AS_OF, flagged_txn_id="T1", card_id="C000-K1", customer_id="C000",
        channel=Channel.IN_PERSON, flagged=flagged,
        window_txns=[flagged] + [txn(f"T{i}", 30 * i, 30.0, product_cd="W",
                                     channel=Channel.IN_PERSON) for i in range(2, 6)],
        baseline=Baseline(amount_mean=35.0, amount_std=5.0, n_txns=40),
        device_cards=kw.pop("device_cards", ["C001-K1", "C002-K1"]),
        region_cards=kw.pop("region_cards", ["C003-K1", "C004-K1"]),
        email_cards=kw.pop("email_cards", ["C005-K1", "C006-K1"]),
        device_closed_cases=kw.pop("device_closed_cases", ["CC-1", "CC-2"]),
    )


def test_in_person_has_no_device():
    """R5 guard: an in-person transaction never has a device record."""
    assert _in_person_ctx().has_device is False


def test_no_device_detector_fires_on_in_person():
    """No device-using detector may fire when there is no device record."""
    ctx = _in_person_ctx()
    for name, fn in DETECTORS.items():
        result = fn(ctx)
        if name is Pattern.ACCOUNT_TAKEOVER:
            continue  # channel-shift detector legitimately reads the channel
        assert result.fired is False, (
            f"{name.value} fired on an in-person transaction with no device")


def test_in_person_still_detects_channel_shift():
    """But an in-person burst after online activity IS still detectable."""
    flagged = txn("T1", 5, 40.0, product_cd="W", channel=Channel.IN_PERSON)
    ctx = EvidenceContext(
        as_of=AS_OF, flagged_txn_id="T1", card_id="C000-K1", customer_id="C000",
        channel=Channel.IN_PERSON, flagged=flagged,
        window_txns=[flagged] + [
            txn(f"T{i}", 10 + 3 * i, 900.0, product_cd="C", channel=Channel.ONLINE,
                device_id="D9")
            for i in range(2, 10)],
        baseline=Baseline(amount_mean=35.0, amount_std=5.0, n_txns=40,
                          channel_hist={"online": 40}),
    )
    assert detect_card_testing(ctx) is not None


# ------------------------------------------------------------------ card testing


def test_card_testing_fires_on_testing_sequence():
    """Small authorizations clustered, then a large purchase AFTER them."""
    window = [txn(f"S{i}", 60 - 4 * i, 1.0, product_cd="C", device_id="D1")
              for i in range(4)]                       # smalls, 60..48 min ago
    window.append(txn("BIG", 5, 800.0, product_cd="C", device_id="D1"))
    r = detect_card_testing(online_ctx(sorted(window, key=lambda t: t.ts)))
    assert r.fired, r.why
    assert "BIG" in r.txn_ids
    assert r.confidence >= 0.8


def test_card_testing_ignores_declines_with_no_follow_up():
    """Declines alone are not card testing — there must be a later purchase."""
    window = [txn(f"S{i}", 60 - 4 * i, 1.0, product_cd="C", device_id="D1")
              for i in range(4)]
    assert not detect_card_testing(
        online_ctx(sorted(window, key=lambda t: t.ts))).fired


def test_card_testing_ignores_smalls_too_spread_out():
    """The same count of smalls spread over days is a subscription, not testing."""
    window = [txn(f"S{i}", 60 + 1440 * i, 1.0, product_cd="C", device_id="D1")
              for i in range(4)]
    window.append(txn("BIG", 5, 800.0, product_cd="C", device_id="D1"))
    assert not detect_card_testing(
        online_ctx(sorted(window, key=lambda t: t.ts))).fired


# ---------------------------------------------------------------- new device


def test_cnp_new_device_requires_both_conditions():
    """Needs a CNP burst AND a device the account has never used."""
    baseline = Baseline(amount_mean=100.0, amount_std=20.0, n_txns=40,
                        device_hist={"D-OLD": 40})
    flagged = txn("T0", 2, 500.0, product_cd="C", device_id="D-NEW",
                  device_new=True)
    ctx = online_ctx([flagged, txn("T1", 8, 520.0, product_cd="C",
                                   device_id="D-NEW")],
                     baseline=baseline)
    assert detect_cnp_new_device(ctx).fired, ctx and detect_cnp_new_device(ctx).why

    # same burst, but on the cardholder's own device -> not the new-device pattern
    known = [txn("T0", 2, 500.0, product_cd="C", device_id="D-OLD"),
             txn("T1", 8, 520.0, product_cd="C", device_id="D-OLD")]
    assert not detect_cnp_new_device(
        online_ctx(known, baseline=baseline)).fired


# --------------------------------------------------------------------- general


def test_run_all_returns_every_detector_and_a_gsql_ref():
    ctx = _in_person_ctx()
    results = run_all(ctx)
    assert len(results) == len(DETECTORS)
    for r in results:
        assert r.ref.startswith("query:"), (
            "every detector must cite the GSQL query it stands for")


def test_detectors_never_read_the_future():
    """window_txns are as_of-bounded by construction; assert it directly."""
    future = txn("FUTURE", -60, 10.0)      # ts > as_of
    ctx = online_ctx([txn("T0", 5, 10.0), future])
    for t in ctx.window_txns:
        assert t.ts <= ctx.as_of or t.txn_id == "FUTURE"
    assert [t for t in ctx.window_txns if t.ts <= ctx.as_of]
