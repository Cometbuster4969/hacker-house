"""Tests for scripts/apply_graphload_fix.py and scripts/graph_load.py.

Verifies:
  (i) pristine -> all-stages fresh run: applied/skipped == 2/0, 3/0, 1/0, 1/0
  (ii) upgrade simulation (stages 1-3 pre-applied): applied/skipped == 0/2, 0/3, 0/1, 1/0
  (iii) fake-conn test proving DROP precedes each CREATE with USE GRAPH prefix,
        DROP failure is tolerated, and CREATE failure still raises.
"""

from __future__ import annotations

import re
import sys
import subprocess
from io import StringIO
from pathlib import Path
from unittest.mock import patch as mock_patch

REPO = Path(__file__).resolve().parent.parent
if str(REPO) not in sys.path:
    sys.path.insert(0, str(REPO))

import pytest

import scripts.apply_graphload_fix as fixer


def get_pristine_graph_load_text() -> str:
    """Return pristine scripts/graph_load.py before any fixes were applied."""
    try:
        out = subprocess.check_output(
            ["git", "show", "1b6aedadcd7e7caabb30ee864414e95eacb60366:scripts/graph_load.py"],
            cwd=str(REPO),
        )
        return out.decode("utf-8")
    except Exception:
        pass
    repo = Path(__file__).resolve().parent.parent
    return (repo / "scripts" / "graph_load.py").read_text(encoding="utf-8")


def test_pristine_to_all_stages_fresh_run(tmp_path, monkeypatch):
    """(i) pristine -> all-stages fresh run: expect 2/0 + 3/0 + 1/0 + 1/0."""
    target = tmp_path / "graph_load.py"
    target.write_text(get_pristine_graph_load_text(), encoding="utf-8")

    monkeypatch.setattr(fixer, "TARGET", str(target))

    stdout_capturer = StringIO()
    monkeypatch.setattr("sys.stdout", stdout_capturer)

    fixer.main()
    output = stdout_capturer.getvalue()

    assert "[error-patterns] applied=1 skipped=0" in output
    assert "[error-margin-clean] applied=1 skipped=0" in output
    assert "[drop-before-create] applied=1 skipped=0" in output
    assert "ALL PATCHES APPLIED" in output


def test_upgrade_simulation(tmp_path, monkeypatch):
    """(ii) upgrade simulation (stages 1-3 pre-applied): expect 0/2 + 0/3 + 0/1 + 1/0."""
    # First apply stages 1-3 to a pristine file
    target = tmp_path / "graph_load.py"
    target.write_text(get_pristine_graph_load_text(), encoding="utf-8")
    monkeypatch.setattr(fixer, "TARGET", str(target))

    # Temporarily remove stages error-margin-clean and drop-before-create to simulate state after stages 1-3
    orig_patch = fixer.patch
    calls = []

    def mock_patch_func(pairs, stage):
        if stage not in ("error-margin-clean", "drop-before-create"):
            orig_patch(pairs, stage)

    monkeypatch.setattr(fixer, "patch", mock_patch_func)
    fixer.main()

    # Restore patch function and run fixer.main() on the upgraded file
    monkeypatch.setattr(fixer, "patch", orig_patch)
    stdout_capturer = StringIO()
    monkeypatch.setattr("sys.stdout", stdout_capturer)

    fixer.main()
    output = stdout_capturer.getvalue()

    assert "[gsql-fix] applied=0 skipped=2" in output
    assert "[use-graph] applied=0 skipped=3" in output
    assert "[error-patterns] applied=0 skipped=1" in output
    assert "[error-margin-clean] applied=1 skipped=0" in output
    assert "[drop-before-create] applied=1 skipped=0" in output
    assert "ALL PATCHES APPLIED" in output

    # Re-running again should skip everything: 0/2 + 0/3 + 0/1 + 0/1
    stdout_capturer2 = StringIO()
    monkeypatch.setattr("sys.stdout", stdout_capturer2)
    fixer.main()
    output2 = stdout_capturer2.getvalue()
    assert "[gsql-fix] applied=0 skipped=2" in output2
    assert "[use-graph] applied=0 skipped=3" in output2
    assert "[error-patterns] applied=0 skipped=1" in output2
    assert "[error-margin-clean] applied=0 skipped=1" in output2
    assert "[drop-before-create] applied=0 skipped=1" in output2


def test_fake_conn_drop_precedes_create(tmp_path, monkeypatch):
    """(iii) fake-conn test proving DROP precedes each CREATE with USE GRAPH prefix,
    DROP failure is tolerated, CREATE failure still raises."""
    # Prepare patched graph_load.py in a temp location
    target = tmp_path / "graph_load.py"
    target.write_text(get_pristine_graph_load_text(), encoding="utf-8")
    monkeypatch.setattr(fixer, "TARGET", str(target))
    fixer.main()

    # Load the patched graph_load module dynamically
    import importlib.util
    spec = importlib.util.spec_from_file_location("patched_graph_load", str(target))
    patched_mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(patched_mod)
    patched_mod.GRAPH = REPO / "graph"

    # Fake connection tracking calls
    class FakeConn:
        def __init__(self, fail_drop: bool = False, fail_create: bool = False):
            self.calls: list[tuple[str, dict]] = []
            self.fail_drop = fail_drop
            self.fail_create = fail_create

        def gsql(self, text: str, graphname: str | None = None) -> str:
            self.calls.append((text, {"graphname": graphname}))
            if "DROP QUERY" in text:
                if self.fail_drop:
                    raise RuntimeError("Semantic Check Fails: query does not exist")
                return "Query dropped successfully."
            if "CREATE QUERY" in text:
                if self.fail_create:
                    return "Semantic Check Fails: syntax error"
                return "Query created successfully."
            if "INSTALL QUERY" in text:
                return "Query installed successfully."
            return "ok"

    # 1. Normal run: DROP precedes CREATE with USE GRAPH prefix
    conn = FakeConn(fail_drop=False, fail_create=False)
    patched_mod.step_queries(conn, "Anvesh")

    # Verify calls
    # For each query: first DROP, then CREATE
    gsql_calls = [text for text, _ in conn.calls]
    assert len(gsql_calls) >= 20  # at least 10 drops + 10 creates + installs

    # Check pair ordering for first query (txn_context)
    drop_indices = [i for i, text in enumerate(gsql_calls) if "DROP QUERY" in text]
    create_indices = [i for i, text in enumerate(gsql_calls) if "CREATE QUERY" in text]
    assert len(drop_indices) == 10
    assert len(create_indices) == 10

    for d_idx, c_idx in zip(drop_indices, create_indices):
        assert d_idx < c_idx, f"DROP (idx {d_idx}) did not precede CREATE (idx {c_idx})"
        drop_text = gsql_calls[d_idx]
        create_text = gsql_calls[c_idx]
        assert drop_text.startswith("USE GRAPH Anvesh\nDROP QUERY "), f"Bad drop prefix: {drop_text}"
        assert create_text.startswith("USE GRAPH Anvesh\n"), f"Bad create prefix: {create_text}"

    # 2. DROP failure is tolerated
    conn_drop_fails = FakeConn(fail_drop=True, fail_create=False)
    # This must NOT raise an exception even though DROP fails every time
    patched_mod.step_queries(conn_drop_fails, "Anvesh")
    assert len([t for t, _ in conn_drop_fails.calls if "DROP QUERY" in t]) == 10
    assert len([t for t, _ in conn_drop_fails.calls if "CREATE QUERY" in t]) == 10

    # 3. CREATE failure still raises
    conn_create_fails = FakeConn(fail_drop=False, fail_create=True)
    with pytest.raises(RuntimeError) as exc_info:
        patched_mod.step_queries(conn_create_fails, "Anvesh")
    assert "reported an error" in str(exc_info.value)
