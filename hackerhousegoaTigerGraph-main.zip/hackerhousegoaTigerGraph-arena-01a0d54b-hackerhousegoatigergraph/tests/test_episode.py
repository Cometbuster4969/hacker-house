"""Episode construction: boundaries, the as_of cap, and IoU scoring."""

from __future__ import annotations

from datetime import datetime, timedelta

from anvesh.domain.enums import Channel
from anvesh.domain.models import Baseline, EvidenceContext, Txn
from anvesh.evidence.episode import iou, segment

AS_OF = datetime(2016, 12, 1, 12, 0, 0)


def txn(tid: str, minutes_ago: int, amount: float, **kw) -> Txn:
    return Txn(
        txn_id=tid,
        ts=AS_OF - timedelta(minutes=minutes_ago),
        amount=amount,
        card_id="C000-K1",
        customer_id="C000",
        product_cd=kw.pop("product_cd", "C"),
        channel=Channel.ONLINE,
        risk_score=kw.pop("risk_score", 60.0),
        **kw,
    )


def _ctx(window: list[Txn]) -> EvidenceContext:
    flagged = window[0]
    return EvidenceContext(
        as_of=AS_OF, flagged_txn_id=flagged.txn_id, card_id=flagged.card_id,
        customer_id=flagged.customer_id, channel=Channel.ONLINE, flagged=flagged,
        window_txns=window,
        baseline=Baseline(amount_mean=100.0, amount_std=20.0, n_txns=40),
    )


def test_segment_contains_every_seed():
    seeds = [txn("A", 10, 5.0), txn("B", 120, 900.0)]
    window = sorted(seeds + [txn(f"X{i}", 30 + i, 20.0) for i in range(6)],
                    key=lambda t: t.ts)
    ep = segment(_ctx(window), [t.txn_id for t in seeds], window)
    for s in seeds:
        assert s.txn_id in set(ep.txn_ids)


def test_segment_excludes_transactions_after_as_of():
    """The hard cap: no transaction with ts > as_of may enter an episode."""
    seed = txn("A", 10, 5.0)
    future = txn("FUTURE", -30, 5.0)          # ts > as_of
    window = sorted([seed, future] + [txn(f"X{i}", 40 + i, 20.0) for i in range(4)],
                    key=lambda t: t.ts)
    ep = segment(_ctx(window), [seed.txn_id, future.txn_id], window)
    assert "FUTURE" not in set(ep.txn_ids)
    for t in window:
        if t.txn_id in set(ep.txn_ids):
            assert t.ts <= AS_OF


def test_segment_always_keeps_seeds_and_exposure_matches_what_was_kept():
    """Seeds always survive; exposure is the sum of the transactions kept."""
    seeds = [txn("A", 10, 5.0), txn("B", 90, 900.0)]
    filler = [txn(f"X{i}", 20 + 10 * i, 20.0) for i in range(6)]
    window = sorted(seeds + filler, key=lambda t: t.ts)
    ep = segment(_ctx(window), [t.txn_id for t in seeds], window)
    kept = set(ep.txn_ids)
    assert {"A", "B"} <= kept, "seeds must always be kept"
    assert kept <= {t.txn_id for t in window}
    expected = round(sum(abs(t.amount) for t in window if t.txn_id in kept), 2)
    assert abs(ep.exposure_usd - expected) < 0.01, (
        f"exposure {ep.exposure_usd} != sum of kept transactions {expected}")


def test_segment_respects_max_span():
    """A transaction far outside the max span must not be dragged in."""
    seeds = [txn("A", 10, 5.0)]
    ancient = txn("OLD", 60 * 24 * 40, 5.0)      # 40 days back
    window = sorted(seeds + [ancient, txn("M", 60, 5.0)], key=lambda t: t.ts)
    ep = segment(_ctx(window), ["A"], window)
    assert "OLD" not in set(ep.txn_ids)


def test_segment_trades_span_against_score():
    """A faraway seed should pull in more transactions, not fewer."""
    near = [txn("A", 10, 5.0), txn("B", 20, 5.0)]
    far = [txn("A", 10, 5.0), txn("F", 2000, 5.0)]
    window = near + far + [txn(f"X{i}", 500 + 20 * i, 5.0) for i in range(10)]
    window = sorted(set(near + far + [txn(f"X{i}", 500 + 20 * i, 5.0)
                                      for i in range(10)]), key=lambda t: t.ts)
    seg_near = segment(_ctx(window), [t.txn_id for t in near], window)
    seg_far = segment(_ctx(window), [t.txn_id for t in far], window)
    assert len(seg_far.txn_ids) >= len(seg_near.txn_ids)


def test_iou_identical_and_disjoint():
    a = ["t1", "t2", "t3"]
    assert iou(a, a) == 1.0
    assert iou(a, ["t4", "t5"]) == 0.0
    assert iou([], []) == 1.0


def test_iou_partial():
    assert abs(iou(["t1", "t2", "t3"], ["t2", "t3", "t4"]) - 2 / 4) < 1e-9
