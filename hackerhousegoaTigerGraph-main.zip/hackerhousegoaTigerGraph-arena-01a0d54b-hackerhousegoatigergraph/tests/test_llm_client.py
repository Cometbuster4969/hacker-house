import json
import os
import pytest
from anvesh.llm.client import _extract_json, get_llm, OpenAICompatLLM, NullLLM


def test_extract_json_plain():
    d = {"a": 1, "b": "text"}
    assert _extract_json(json.dumps(d)) == d


def test_extract_json_markdown():
    d = {"hypotheses": [{"pattern": "card_testing", "rationale": "test"}]}
    wrapped = f"```json\n{json.dumps(d)}\n```"
    assert _extract_json(wrapped) == d


def test_extract_json_with_chatter():
    d = {"summary": "Fraud suspected"}
    wrapped = f"Here is the JSON summary:\n```json\n{json.dumps(d)}\n```\nHope this helps!"
    assert _extract_json(wrapped) == d


def test_openrouter_auto_detection(monkeypatch):
    monkeypatch.setenv("OPENROUTER_API_KEY", "sk-or-v1-testkey123")
    monkeypatch.delenv("LLM_API_KEY", raising=False)
    monkeypatch.delenv("LLM_PROVIDER", raising=False)
    client = get_llm()
    assert isinstance(client, OpenAICompatLLM)
    assert client.provider == "openrouter"
    assert client.base_url == "https://openrouter.ai/api/v1"
    assert "llama" in client.model or client.model != ""


def test_null_llm_when_empty(monkeypatch):
    monkeypatch.delenv("OPENROUTER_API_KEY", raising=False)
    monkeypatch.delenv("LLM_API_KEY", raising=False)
    client = get_llm()
    assert isinstance(client, NullLLM)
