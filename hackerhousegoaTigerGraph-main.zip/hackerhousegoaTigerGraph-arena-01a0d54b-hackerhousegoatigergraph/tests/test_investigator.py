"""End-to-end: 20 planted cases through the full agent.

These tests exist to catch the failure mode that costs the most points and is
the hardest to see: an answer file that is internally inconsistent but looks
fine. Each test below corresponds to a bug that was actually found and fixed.
"""

from __future__ import annotations

import json
from dataclasses import dataclass

import pytest

from anvesh.agent.investigator import Investigator
from anvesh.data.synthetic import generate
from anvesh.graph.memory_adapter import MemoryAdapter
from anvesh.reasoning.fit import fit_table
from anvesh.util.ids import IdRegistry
from anvesh.validate.checks import validate

# Policy constants — duplicated deliberately so a config edit cannot silently
# move a threshold without a test noticing.
BUDGET_MAX_TOOL_CALLS = 30
BUDGET_MAX_ROUNDS = 2


@dataclass
class _Args:
    customers: int = 40
    seed: int = 20260924
    fit_limit: int | None = None


@pytest.fixture(scope="module")
def pipeline():
    args = _Args()
    data = generate(n_customers=args.customers, seed=args.seed)
    adapter = MemoryAdapter(data.txns, data.closed_cases)
    registry = IdRegistry.from_adapter(adapter)
    table, _ = fit_table(adapter, data.closed_cases, limit=args.fit_limit)
    return data, adapter, registry, table


@pytest.fixture(scope="module")
def results(pipeline):
    data, adapter, registry, table = pipeline
    inv = Investigator(adapter, registry, table=table)
    return [(row, *inv.run(row)) for row in data.case_pack]


def test_every_case_passes_all_fifteen_checks(results, pipeline):
    _, _, registry, _ = pipeline
    failures = []
    for row, answer, _st in results:
        rep = validate(answer, registry)
        if not rep.passed:
            failures.append((row.case_id, rep.errors))
    assert not failures, f"validation failures: {failures}"


def test_twenty_cases_produced(results):
    assert len(results) == 20
    assert [r[0].case_id for r in results] == [f"HHG-{i:03d}" for i in range(1, 21)]


def test_no_invented_ids(results, pipeline):
    """Check #2. Regions and email domains are not entities — emitting them
    as IDs fails this. They belong in the narrative, not in an id list."""
    _, _, registry, _ = pipeline
    for row, answer, _ in results:
        for txn_id in answer["case"]["affected_txn_ids"]:
            assert registry.knows(txn_id), f"{row.case_id}: unknown txn {txn_id}"
        for card in answer["case"]["connected_card_ids"]:
            assert registry.knows(card), f"{row.case_id}: unknown card {card}"
        for subj in answer["sar"]["subjects"]:
            assert registry.knows(subj), f"{row.case_id}: unknown subject {subj}"


def test_legitimate_verdicts_carry_no_episode(results):
    """Invariant I1. A legitimate verdict with a populated affected_txn_ids
    is the answer-file contradiction this suite was written to catch."""
    for row, answer, _ in results:
        if answer["case"]["verdict"] == "legitimate":
            assert answer["case"]["affected_txn_ids"] == [], (
                f"{row.case_id}: legitimate but has an episode")
            assert answer["case"]["exposure_usd"] == 0.0, (
                f"{row.case_id}: legitimate but exposure ${answer['case']['exposure_usd']}")
            assert answer["case"]["pattern"] == "none", (
                f"{row.case_id}: legitimate but named pattern "
                f"{answer['case']['pattern']}")


def test_sar_iff_the_file_report_action_is_present(results):
    """Check #4 — the file <-> action equivalence must hold by construction."""
    for row, answer, _ in results:
        actions = {a["action"] for a in answer["next_best_actions"]["final"]}
        assert answer["sar"]["file"] == ("FILE_REPORT" in actions), (
            f"{row.case_id}: sar.file={answer['sar']['file']} but actions={actions}")
        if answer["sar"]["file"]:
            assert answer["sar"]["narrative"].strip(), f"{row.case_id}: empty SAR"


def test_every_action_cites_a_rule(results):
    """Every recommendation must name the rule that produced it (§7)."""
    for row, answer, _ in results:
        for bucket in ("initial", "final"):
            for a in answer["next_best_actions"][bucket]:
                assert a["reason"].strip(), f"{row.case_id}: {a['action']} has no reason"
                assert a["route"] in ("auto", "L1", "L2"), (
                    f"{row.case_id}: bad route {a['route']}")


def test_action_sets_are_non_empty(results):
    for row, answer, _ in results:
        assert answer["next_best_actions"]["initial"], f"{row.case_id}: no initial actions"
        assert answer["next_best_actions"]["final"], f"{row.case_id}: no final actions"


def test_budgets_are_respected(results):
    for row, _answer, st in results:
        assert st.tool_calls <= BUDGET_MAX_TOOL_CALLS, f"{row.case_id}: {st.tool_calls} calls"
        assert len(st.evidence_requests) <= BUDGET_MAX_ROUNDS, (
            f"{row.case_id}: {len(st.evidence_requests)} rounds")
        assert len(st.hypotheses) <= 4, f"{row.case_id}: {len(st.hypotheses)} hypotheses"
        assert len(st.evidence) <= 25, f"{row.case_id}: {len(st.evidence)} evidence items"


def test_probabilities_are_never_certain(results):
    """A 0.00 or 1.00 probability means a log-LR was applied outside a clamp."""
    for row, answer, _ in results:
        p = answer["case"]["fraud_probability"]
        assert 0.0 < p < 1.0, f"{row.case_id}: p={p}"


def test_run_is_deterministic():
    """Same inputs -> byte-identical answers. A demo replay depends on this.

    Each run gets a FRESH graph. The adapter accumulates written cases as
    memory on purpose, so a shared adapter is not a fair determinism test —
    the second pass would legitimately see the first pass's writebacks.
    """
    def once() -> list[str]:
        data = generate(n_customers=40, seed=20260924)
        adapter = MemoryAdapter(data.txns, data.closed_cases)
        registry = IdRegistry.from_adapter(adapter)
        table, _ = fit_table(adapter, data.closed_cases)
        inv = Investigator(adapter, registry, table=table)
        out = []
        for r in data.case_pack:
            answer = inv.run(r)[0]
            # wall-clock latency is not part of the decision
            answer.pop("latency_s", None)
            answer.get("telemetry", {}).pop("latency_s", None)
            out.append(json.dumps(answer, sort_keys=True, default=str))
        return out

    assert once() == once(), "the agent is not deterministic"


def test_writeback_lands_in_graph_memory(pipeline):
    """Cases the agent closes become retrievable memory for later cases."""
    data, adapter, registry, table = pipeline
    inv = Investigator(adapter, registry, table=table)
    row = data.case_pack[0]
    _answer, st = inv.run(row)
    assert st.written_to_graph is True
    assert st.graph_case_id
    assert st.graph_case_id in adapter.written, "case was not persisted"


def test_answers_are_json_serialisable(results):
    for row, answer, _ in results:
        json.dumps(answer, default=str)      # raises if any value is not JSON-safe


# -------------------------------------------------------- planted-case recovery


def _pattern_of(results, case_id: str) -> str:
    for row, answer, _ in results:
        if row.case_id == case_id:
            return answer["case"]["pattern"]
    raise AssertionError(case_id)


def test_card_testing_cases_are_recognised(results, pipeline):
    data, *_ = pipeline
    planted = [cid for cid, s in data.scenario_of.items() if s == "card_testing"]
    assert planted, "the generator planted no card-testing cases"
    found = [cid for cid in planted if _pattern_of(results, cid) == "card_testing"]
    assert len(found) >= max(1, len(planted) // 2), (
        f"recovered {len(found)}/{len(planted)} card-testing cases")


def test_recurring_disputes_are_not_blocked(results, pipeline):
    """R7: a disputed charge that matches the cardholder's own recurring
    pattern must not produce a block."""
    data, *_ = pipeline
    planted = [cid for cid, s in data.scenario_of.items() if s == "recurring"]
    assert planted, "the generator planted no recurring-dispute cases"
    for _row, answer, _st in results:
        if _row.case_id not in planted:
            continue
        actions = {a["action"] for a in answer["next_best_actions"]["final"]}
        assert "BLOCK_CARD" not in actions, (
            f"{_row.case_id}: R7 violated — blocked a recurring disputed charge")
        assert "VERIFY_WITH_CUSTOMER" in actions, (
            f"{_row.case_id}: R7 requires verifying a disputed recurring charge")
