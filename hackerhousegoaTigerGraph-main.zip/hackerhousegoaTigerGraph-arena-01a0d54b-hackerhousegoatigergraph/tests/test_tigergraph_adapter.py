"""TigerGraphAdapter against a fake MCP transport. No live database.

These tests pin the contract the adapter promises:
  - every read passes `as_of` (GSQL DATETIME, never the future)
  - rows assemble into Txns with side maps applied
  - the as_of leak guard fires on future rows
  - writes batch edges by type and degrade vector upsert quietly
  - unknown tools/queries are refused (tested at the MCPClient level by
    importing the allowlists — the safety rule lives in one place)
"""

from __future__ import annotations

from datetime import datetime

import pytest

from anvesh.domain.enums import Channel
from anvesh.graph.mcp_client import ALLOWED_QUERIES, ALLOWED_TOOLS, MCPError
from anvesh.graph.tigergraph_adapter import (
    TigerGraphAdapter,
    gsql_datetime,
    parse_ts,
)

AS_OF = datetime(2016, 12, 1, 12, 0, 0)


def V(vid, **attrs):
    return {"v_id": vid, "v_type": "Transaction", "attributes": dict(attrs)}


TXN_ATTRS = {
    "ts": "2016-11-30 10:00:00", "amount": 500.0, "product_cd": "C",
    "channel": "online", "risk_score": 0.9, "addr2": "87",
    "v_anom": 0.7, "m_flags": 2,
}


class FakeMCP:
    """Canned tool responses. Records every call for assertion."""

    def __init__(self):
        self.calls: list[tuple[str, dict]] = []
        self.handlers: dict[str, object] = {}

    def on(self, tool, query_name, data):
        self.handlers[(tool, query_name)] = data
        return self

    def call(self, tool, args=None):
        args = dict(args or {})
        self.calls.append((tool, args))
        if tool == "run_installed_query":
            key = (tool, args.get("query_name"))
            if key not in self.handlers:
                raise MCPError(f"no canned response for {key}")
            return {"query_name": args["query_name"], "parameters": args.get("params"),
                    "result": self.handlers[key]}
        if (tool, "*") in self.handlers:
            h = self.handlers[(tool, "*")]
            if isinstance(h, Exception):
                raise h
            return h
        raise MCPError(f"no canned response for tool {tool}")

    def called(self, tool, query_name=None):
        return [a for t, a in self.calls
                if t == tool and (query_name is None or a.get("query_name") == query_name)]


@pytest.fixture
def fake():
    return FakeMCP()


@pytest.fixture
def adapter(fake):
    return TigerGraphAdapter(fake)


# ------------------------------------------------------------------ safety


def test_destructive_tools_are_not_allowlisted():
    for banned in ("drop_graph", "clear_graph_data", "delete_node",
                   "delete_nodes", "delete_edge", "delete_edges",
                   "drop_query", "gsql", "run_query", "generate_gsql"):
        assert banned not in ALLOWED_TOOLS, banned


def test_allowed_queries_match_shipped_files():
    from pathlib import Path
    shipped = {p.stem[2:] for p in
               (Path(__file__).resolve().parents[1] / "graph").glob("q_*.gsql")}
    assert set(ALLOWED_QUERIES) == shipped


# ------------------------------------------------------------------ parsing


def test_txn_context_assembles_full_row(fake, adapter):
    fake.on("run_installed_query", "txn_context", [{
        "T": [V("T1", **TXN_ATTRS)],
        "C": [{"v_id": "C1-K1"}], "Cu": [{"v_id": "C1"}],
        "D": [{"v_id": "D9"}], "R": [{"v_id": "444"}], "Co": [{"v_id": "87"}],
        "P": [{"v_id": "C"}], "Pe": [{"v_id": "gmail.com"}],
        "Re": [{"v_id": "shop.com"}],
    }])
    t = adapter.txn_context(AS_OF, "T1")
    assert t is not None
    assert (t.txn_id, t.card_id, t.customer_id) == ("T1", "C1-K1", "C1")
    assert t.device_id == "D9" and t.region == "444"
    assert t.p_email == "gmail.com" and t.r_email == "shop.com"
    assert t.channel is Channel.ONLINE and t.amount == 500.0
    assert t.v_anom == 0.7 and t.m_flags == 2
    # as_of travelled with the call, in GSQL DATETIME shape
    (call,) = fake.called("run_installed_query", "txn_context")
    assert call["params"]["as_of"] == "2016-12-01 12:00:00"


def test_txn_context_missing_returns_none(fake, adapter):
    fake.on("run_installed_query", "txn_context", [{"T": []}])
    assert adapter.txn_context(AS_OF, "NOPE") is None


def test_txn_context_in_person_has_no_device(fake, adapter):
    attrs = dict(TXN_ATTRS, channel="in_person", product_cd="W")
    fake.on("run_installed_query", "txn_context", [{
        "T": [V("T2", **attrs)], "C": [{"v_id": "C1-K1"}],
        "Cu": [{"v_id": "C1"}], "D": [], "R": [{"v_id": "444"}],
    }])
    t = adapter.txn_context(AS_OF, "T2")
    assert t.device_id is None and t.channel is Channel.IN_PERSON


def test_future_row_trips_the_leak_guard(fake, adapter):
    attrs = dict(TXN_ATTRS, ts="2016-12-05 10:00:00")   # after as_of
    fake.on("run_installed_query", "txn_context", [{
        "T": [V("T9", **attrs)], "C": [{"v_id": "C1-K1"}], "Cu": [{"v_id": "C1"}]}])
    with pytest.raises(AssertionError, match="as_of leak"):
        adapter.txn_context(AS_OF, "T9")


def test_card_window_applies_side_maps(fake, adapter):
    fake.on("run_installed_query", "card_window", [{
        "W": [V("T1", **TXN_ATTRS), V("T2", **dict(TXN_ATTRS, amount=20.0))],
        "Cus": [{"v_id": "C1"}],
        "txn_device": {"T1": "D9"}, "txn_region": {"T1": "444", "T2": "444"},
        "txn_pemail": {}, "txn_remail": {},
    }])
    rows = adapter.card_window(AS_OF, "C1-K1", 48)
    assert [t.txn_id for t in rows] == ["T1", "T2"]
    assert rows[0].device_id == "D9" and rows[1].device_id is None
    assert all(t.customer_id == "C1" for t in rows)


def test_baseline_parses_hists(fake, adapter):
    fake.on("run_installed_query", "cardholder_baseline", [{
        "amount_mean": 100.0, "amount_std": 0.0, "n_txns": 40,
        "product_hist": {"C": 30, "W": 10}, "region_hist": {"444": 40},
        "device_hist": {"D9": 40}, "channel_hist": {"online": 30},
    }])
    b = adapter.cardholder_baseline(AS_OF, "C1-K1", 90)
    assert b.amount_mean == 100.0 and b.n_txns == 40
    assert b.amount_std > 0                       # zero std is repaired
    assert b.product_hist["C"] == 30


def test_geo_velocity_keeps_forward_pairs_only(fake, adapter):
    # NEXT is undirected: each pair arrives in both directions.
    fake.on("run_installed_query", "geo_velocity", [{
        "pairs": [
            {"from_txn": "A", "to_txn": "B", "from_region": "444",
             "to_region": "101", "minutes_elapsed": 30},
            {"from_txn": "B", "to_txn": "A", "from_region": "101",
             "to_region": "444", "minutes_elapsed": -30},
        ]}])
    pairs = adapter.geo_velocity(AS_OF, "C1-K1", 48)
    assert [(p.from_txn, p.to_txn, p.minutes) for p in pairs] == [("A", "B", 30)]


def test_testing_and_recurring_and_device(fake, adapter):
    fake.on("run_installed_query", "testing_sequence", [{
        "fired": True, "small_ids": ["S1", "S2", "S3"],
        "large_id": "BIG", "large_amount": 800.0}])
    ts = adapter.testing_sequence(AS_OF, "C1-K1", 1)
    assert ts.fired and ts.large_txn_id == "BIG" and ts.small_txn_ids == ["S1", "S2", "S3"]

    fake.on("run_installed_query", "recurring_check", [{
        "is_recurring": True, "matched": ["M1", "M2"], "cadence": 30.5}])
    rc = adapter.recurring_check(AS_OF, "C1-K1", 120)
    assert rc.is_recurring and rc.cadence_days == 30.5

    fake.on("run_installed_query", "device_neighbors", [{
        "cards": ["C2-K1"], "cases": ["CC-1"], "n_txns": 5}])
    dn = adapter.device_neighbors(AS_OF, "D9", 30)
    assert dn.card_ids == ["C2-K1"] and dn.closed_cases == ["CC-1"]


def test_ring_enforces_min_cards_client_side(fake, adapter):
    fake.on("run_installed_query", "ring_components", [{
        "cards": ["C1-K1"], "size": 1, "cluster_id": "RING-C1-K1"}])
    assert adapter.ring_components(AS_OF, 30, 2, "C1-K1") is None


def test_shared_origin_rejects_bad_kind_without_calling(fake, adapter):
    assert adapter.shared_origin_cards(AS_OF, "merchant", "X", 7) == []
    assert adapter.shared_origin_cards(AS_OF, "device", "", 7) == []
    assert fake.calls == []


# ------------------------------------------------------------------- writes


def test_write_case_batches_edges_by_type(fake, adapter):
    fake.on("add_node", "*", {"ok": True})
    fake.on("add_edges", "*", {"edge_count": 1})
    fake.on("upsert_vectors", "*", MCPError("no vector attribute"))
    gid = adapter.write_case("CASE-1", {
        "verdict": "fraud", "fraud_probability": 0.9, "pattern": "cnp",
        "exposure_usd": 100.0, "affected_txn_ids": ["T1", "T2"],
        "card_id": "C1-K1", "device_id": "D9",
        "similar_prior_cases": ["CC-1"],
        "fingerprint": [0.1] * 12,
    })
    assert gid == "CASE-1"
    nodes = fake.called("add_node")
    assert len(nodes) == 1 and nodes[0]["vertex_type"] == "InvestigationCase"
    batches = fake.called("add_edges")
    # CASE_TXN x2 in one batch; CASE_CARD, CASE_DEVICE, CASE_CITES
    assert {b["edge_type"] for b in batches} == {
        "CASE_TXN", "CASE_CARD", "CASE_DEVICE", "CASE_CITES"}
    txn_batch = next(b for b in batches if b["edge_type"] == "CASE_TXN")
    assert len(txn_batch["edges"]) == 2
    # vector upsert failed quietly — the write still succeeded
    assert fake.called("upsert_vectors")


def test_prior_cases_degrade_to_empty(fake, adapter):
    fake.on("search_top_k_similarity", "*", MCPError("TigerVector unavailable"))
    assert adapter.prior_cases([0.0] * 12, 3) == []


def test_prior_cases_collect_ids(fake, adapter):
    fake.on("search_top_k_similarity", "*", {
        "results": [{"v_id": "CC-1"}, {"v_id": "CC-2"}]})
    assert adapter.prior_cases([0.0] * 12, 3) == ["CC-1", "CC-2"]


def test_has_txn_distinguishes_missing_from_broken(fake, adapter):
    fake.on("get_node", "*", {"v_id": "T1"})
    assert adapter.has_txn("T1") is True
    fake.handlers.clear()
    fake.on("get_node", "*", MCPError("Vertex not found"))
    assert adapter.has_txn("NOPE") is False
    fake.handlers.clear()
    fake.on("get_node", "*", MCPError("connection refused"))
    with pytest.raises(MCPError, match="connection refused"):
        adapter.has_txn("T1")


# ------------------------------------------------------------------ helpers


def test_datetime_helpers():
    assert gsql_datetime(AS_OF) == "2016-12-01 12:00:00"
    assert parse_ts("2016-11-30 10:00:00") == datetime(2016, 11, 30, 10, 0, 0)
    assert parse_ts("2016-11-30T10:00:00") == datetime(2016, 11, 30, 10, 0, 0)
    assert parse_ts("2016-11-30") == datetime(2016, 11, 30)
    assert parse_ts(AS_OF) is AS_OF
    with pytest.raises(MCPError):
        parse_ts("not a date")
