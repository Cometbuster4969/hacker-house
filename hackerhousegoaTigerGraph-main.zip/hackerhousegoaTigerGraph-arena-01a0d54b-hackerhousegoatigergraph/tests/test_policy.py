"""The policy scenario matrix — docs/POLICY.md §9, 22 rows.

Deterministic. No graph, no LLM, no dataset. This suite IS the 25%.
"""

from __future__ import annotations

import pytest

from anvesh.config import BLOCK_ROUTE_L1_MAX, EXPOSURE_SAR, P_CASE_OPEN
from anvesh.domain.enums import Action, Channel, Pattern, ResponseKind, Route, Verdict
from anvesh.domain.models import PolicyFlags
from anvesh.policy.actions import route_for
from anvesh.policy.engine import resolve
from anvesh.policy.rules import ActionBuilder, RuleInput, apply_r10


def inp(**kw) -> RuleInput:
    d = dict(
        fraud_probability=0.50,
        exposure_usd=0.0,
        verdict=Verdict.UNCERTAIN,
        pattern=Pattern.NONE,
        n_independent_signals=2,
        flags=PolicyFlags(),
    )
    d.update(kw)
    return RuleInput(**d)


def acts(d):
    return {a.action for a in d.actions}


def route_of(d, action):
    return next(a.route for a in d.actions if a.action is action)


# ---------------------------------------------------------------------------
# 1. R1 — verify before you block on a weak signal
# ---------------------------------------------------------------------------
def test_01_weak_single_signal_verifies_and_never_blocks():
    d = resolve(inp(fraud_probability=0.45, n_independent_signals=1, exposure_usd=200))
    assert Action.VERIFY_WITH_CUSTOMER in acts(d)
    assert acts(d).isdisjoint({Action.BLOCK_CARD, Action.BLOCK_ALL_CARDS,
                               Action.DECLINE_TRANSACTION})
    assert any("R1" in s for s in d.suppressed)


def test_01b_risk_score_alone_is_one_signal():
    # A risk-score trigger with no corroboration can never block.
    d = resolve(inp(fraud_probability=0.90, n_independent_signals=1, exposure_usd=5_000))
    assert acts(d).isdisjoint({Action.BLOCK_CARD, Action.BLOCK_ALL_CARDS})


# ---------------------------------------------------------------------------
# 2-4. R2 — customer denies
# ---------------------------------------------------------------------------
def test_02_denied_below_sar_threshold_files_no_report():
    d = resolve(inp(fraud_probability=0.80, verdict=Verdict.FRAUD, exposure_usd=900,
                    flags=PolicyFlags(response=ResponseKind.DENIED)))
    assert Action.BLOCK_CARD in acts(d)
    assert Action.CREATE_CASE in acts(d)
    assert Action.FILE_REPORT not in acts(d)
    assert d.file_sar is False


def test_03_denied_above_1000_files_report():
    d = resolve(inp(fraud_probability=0.80, verdict=Verdict.FRAUD, exposure_usd=1_200,
                    flags=PolicyFlags(response=ResponseKind.DENIED)))
    assert Action.FILE_REPORT in acts(d)
    assert route_of(d, Action.FILE_REPORT) is Route.L2
    assert d.file_sar is True


def test_04_denied_below_1000_but_shared_device_files_report():
    d = resolve(inp(fraud_probability=0.80, verdict=Verdict.FRAUD, exposure_usd=800,
                    flags=PolicyFlags(response=ResponseKind.DENIED,
                                      shared_origin=True, shared_element="device D000731")))
    assert Action.FILE_REPORT in acts(d)
    assert d.file_sar is True


# ---------------------------------------------------------------------------
# 5. R3 — customer confirms
# ---------------------------------------------------------------------------
def test_05_confirmed_closes_as_legitimate():
    d = resolve(inp(fraud_probability=0.30, exposure_usd=400,
                    flags=PolicyFlags(response=ResponseKind.CONFIRMED, disputed=True)))
    assert Action.CLOSE_NO_FRAUD in acts(d)
    assert d.verdict is Verdict.LEGITIMATE
    assert Action.CREATE_CASE not in acts(d)      # closing overrides case opening
    assert d.file_sar is False


# ---------------------------------------------------------------------------
# 6-7. R4 — no reply within 24 hours
# ---------------------------------------------------------------------------
def test_06_no_reply_low_exposure_no_escalation():
    d = resolve(inp(fraud_probability=0.60, exposure_usd=300,
                    flags=PolicyFlags(response=ResponseKind.NO_REPLY)))
    assert Action.MONITOR_CARD in acts(d)
    assert Action.DECLINE_TRANSACTION in acts(d)
    assert Action.ESCALATE_TO_ANALYST not in acts(d)


def test_07_no_reply_high_exposure_escalates():
    d = resolve(inp(fraud_probability=0.60, exposure_usd=900,
                    flags=PolicyFlags(response=ResponseKind.NO_REPLY)))
    assert Action.ESCALATE_TO_ANALYST in acts(d)


# ---------------------------------------------------------------------------
# 8-9. R5 — card testing
# ---------------------------------------------------------------------------
def test_08_testing_sequence_nothing_cleared():
    d = resolve(inp(fraud_probability=0.90, verdict=Verdict.FRAUD, exposure_usd=300,
                    pattern=Pattern.CARD_TESTING))
    assert Action.DECLINE_TRANSACTION in acts(d)
    assert Action.STEP_UP_AUTH in acts(d)
    assert Action.BLOCK_CARD not in acts(d)
    assert route_of(d, Action.DECLINE_TRANSACTION) is Route.L1


def test_09_testing_sequence_over_100_cleared_blocks():
    d = resolve(inp(fraud_probability=0.90, verdict=Verdict.FRAUD, exposure_usd=300,
                    pattern=Pattern.CARD_TESTING,
                    flags=PolicyFlags(max_cleared_purchase=150.0)))
    assert Action.BLOCK_CARD in acts(d)


def test_09b_testing_overrides_r1_suppression():
    # R1 would suppress the block; R5 overrides because the sequence is multi-signal.
    d = resolve(inp(fraud_probability=0.65, verdict=Verdict.FRAUD, exposure_usd=50,
                    pattern=Pattern.CARD_TESTING, n_independent_signals=1,
                    flags=PolicyFlags(max_cleared_purchase=150.0)))
    assert Action.BLOCK_CARD in acts(d)


# ---------------------------------------------------------------------------
# 10. R6 — shared origin
# ---------------------------------------------------------------------------
def test_10_shared_origin_creates_case_report_and_monitors():
    d = resolve(inp(fraud_probability=0.85, verdict=Verdict.FRAUD, exposure_usd=600,
                    flags=PolicyFlags(shared_origin=True, shared_element="device D000731",
                                      cross_customer=True)))
    assert {Action.CREATE_CASE, Action.FILE_REPORT, Action.MONITOR_CONNECTED_CARDS} <= acts(d)
    assert route_of(d, Action.FILE_REPORT) is Route.L2


# ---------------------------------------------------------------------------
# 11. R7 — disputed but recurring. Do not block.
# ---------------------------------------------------------------------------
def test_11_recurring_dispute_never_blocks():
    d = resolve(inp(fraud_probability=0.25, verdict=Verdict.LEGITIMATE, exposure_usd=49,
                    flags=PolicyFlags(disputed=True, is_recurring=True)))
    assert {Action.CREATE_CASE, Action.VERIFY_WITH_CUSTOMER, Action.WARN_CUSTOMER} <= acts(d)
    assert acts(d).isdisjoint({Action.BLOCK_CARD, Action.BLOCK_ALL_CARDS,
                               Action.DECLINE_TRANSACTION})


# ---------------------------------------------------------------------------
# 12. R8 — uncertain and exposed
# ---------------------------------------------------------------------------
def test_12_uncertain_and_exposed_escalates():
    d = resolve(inp(fraud_probability=0.50, verdict=Verdict.UNCERTAIN, exposure_usd=700))
    assert Action.ESCALATE_TO_ANALYST in acts(d)


def test_12b_conflicting_evidence_escalates_even_when_small():
    d = resolve(inp(fraud_probability=0.50, verdict=Verdict.FRAUD, exposure_usd=10,
                    flags=PolicyFlags(conflicting_evidence=True)))
    assert Action.ESCALATE_TO_ANALYST in acts(d)


# ---------------------------------------------------------------------------
# 13. R9 — undocumented patterns
# ---------------------------------------------------------------------------
def test_13_undocumented_coordinated():
    d = resolve(inp(fraud_probability=0.80, verdict=Verdict.FRAUD, exposure_usd=200,
                    pattern=Pattern.UNDOCUMENTED,
                    flags=PolicyFlags(cross_customer=True)))
    assert {Action.CREATE_CASE, Action.FILE_REPORT, Action.ESCALATE_TO_ANALYST} <= acts(d)


# ---------------------------------------------------------------------------
# 14-15, 22. R10 — BLOCK_ALL_CARDS guard
# ---------------------------------------------------------------------------
def test_14_r10_vetoes_block_all_cards_with_one_confirmed_card():
    b = ActionBuilder()
    b.emit(Action.BLOCK_ALL_CARDS, "R2: compromise spans multiple cards")
    i = inp(flags=PolicyFlags(cards_confirmed_fraud=1))
    apply_r10(i, b)
    assert Action.BLOCK_ALL_CARDS not in acts(b)
    assert any("R10" in s for s in b.suppressed)


def test_15_two_confirmed_cards_permit_block_all_cards():
    d = resolve(inp(fraud_probability=0.95, verdict=Verdict.FRAUD, exposure_usd=4_000,
                    flags=PolicyFlags(response=ResponseKind.DENIED,
                                      cards_confirmed_fraud=2)))
    assert Action.BLOCK_ALL_CARDS in acts(d)
    assert route_of(d, Action.BLOCK_ALL_CARDS) is Route.L2


def test_15b_credential_compromise_permits_block_all_cards():
    d = resolve(inp(fraud_probability=0.95, verdict=Verdict.FRAUD, exposure_usd=4_000,
                    flags=PolicyFlags(response=ResponseKind.DENIED,
                                      credentials_compromised=True)))
    assert Action.BLOCK_ALL_CARDS in acts(d)


# ---------------------------------------------------------------------------
# 16-17. Routing boundaries
# ---------------------------------------------------------------------------
def test_16_block_at_exactly_2500_is_L1():
    d = resolve(inp(fraud_probability=0.90, verdict=Verdict.FRAUD,
                    exposure_usd=float(BLOCK_ROUTE_L1_MAX),
                    flags=PolicyFlags(response=ResponseKind.DENIED)))
    assert route_of(d, Action.BLOCK_CARD) is Route.L1


def test_17_block_one_cent_above_2500_is_L2():
    d = resolve(inp(fraud_probability=0.90, verdict=Verdict.FRAUD,
                    exposure_usd=BLOCK_ROUTE_L1_MAX + 0.01,
                    flags=PolicyFlags(response=ResponseKind.DENIED)))
    assert route_of(d, Action.BLOCK_CARD) is Route.L2


def test_17b_route_function_boundaries():
    assert route_for(Action.BLOCK_CARD, 2_500.00) is Route.L1
    assert route_for(Action.BLOCK_CARD, 2_500.01) is Route.L2
    assert route_for(Action.FILE_REPORT, 0) is Route.L2
    assert route_for(Action.BLOCK_ALL_CARDS, 0) is Route.L2
    assert route_for(Action.MONITOR_CARD, 9_999) is Route.AUTO


# ---------------------------------------------------------------------------
# 18-19. Case-opening threshold
# ---------------------------------------------------------------------------
def test_18_p_exactly_030_opens_case():
    d = resolve(inp(fraud_probability=P_CASE_OPEN, exposure_usd=0))
    assert Action.CREATE_CASE in acts(d)


def test_19_p_just_below_030_does_not_open_case():
    d = resolve(inp(fraud_probability=0.29, exposure_usd=0))
    assert Action.CREATE_CASE not in acts(d)


def test_19b_evidence_request_opens_case_regardless_of_p():
    d = resolve(inp(fraud_probability=0.10, exposure_usd=0, evidence_requested=True))
    assert Action.CREATE_CASE in acts(d)


# ---------------------------------------------------------------------------
# 20. SAR threshold is strictly "exceeds"
# ---------------------------------------------------------------------------
def test_20_exposure_exactly_1000_does_not_trigger_sar():
    d = resolve(inp(fraud_probability=0.90, verdict=Verdict.FRAUD,
                    exposure_usd=float(EXPOSURE_SAR),
                    flags=PolicyFlags(response=ResponseKind.DENIED)))
    assert Action.FILE_REPORT not in acts(d)
    assert d.file_sar is False


def test_20b_exposure_one_cent_above_1000_triggers_sar():
    d = resolve(inp(fraud_probability=0.90, verdict=Verdict.FRAUD,
                    exposure_usd=EXPOSURE_SAR + 0.01,
                    flags=PolicyFlags(response=ResponseKind.DENIED)))
    assert d.file_sar is True


# ---------------------------------------------------------------------------
# 21. Default action
# ---------------------------------------------------------------------------
def test_21_legitimate_and_no_rule_fires_allows():
    d = resolve(inp(fraud_probability=0.05, verdict=Verdict.LEGITIMATE, exposure_usd=0))
    assert Action.ALLOW_TRANSACTION in acts(d)


def test_21b_default_is_monitor_when_not_legitimate():
    d = resolve(inp(fraud_probability=0.20, verdict=Verdict.UNCERTAIN, exposure_usd=0))
    assert Action.MONITOR_CARD in acts(d)


# ---------------------------------------------------------------------------
# 22. Cross-cutting guarantees
# ---------------------------------------------------------------------------
def test_22_every_action_carries_a_rule_citation():
    scenarios = [
        inp(fraud_probability=0.45, n_independent_signals=1),
        inp(fraud_probability=0.9, verdict=Verdict.FRAUD, exposure_usd=2_000,
            flags=PolicyFlags(response=ResponseKind.DENIED, shared_origin=True)),
        inp(fraud_probability=0.25, verdict=Verdict.LEGITIMATE,
            flags=PolicyFlags(disputed=True, is_recurring=True)),
        inp(fraud_probability=0.5, exposure_usd=700),
    ]
    for s in scenarios:
        for a in resolve(s).actions:
            assert a.reason and ("R" in a.reason or "§" in a.reason), a


def test_22b_resolve_is_pure_and_never_empty():
    i = inp(fraud_probability=0.5, exposure_usd=100)
    assert resolve(i).actions == resolve(i).actions
    for p in (0.0, 0.15, 0.29, 0.30, 0.5, 0.7, 0.85, 1.0):
        assert resolve(inp(fraud_probability=p)).actions


def test_22c_legitimate_verdict_never_files_a_sar():
    d = resolve(inp(fraud_probability=0.10, verdict=Verdict.LEGITIMATE, exposure_usd=9_999,
                    flags=PolicyFlags(shared_origin=True, cross_customer=True)))
    assert d.file_sar is False
    assert Action.FILE_REPORT not in acts(d)


def test_22d_in_person_channel_does_not_change_policy():
    # Channel is carried in flags but must not by itself alter the action set.
    a = resolve(inp(fraud_probability=0.8, verdict=Verdict.FRAUD, exposure_usd=1_500,
                    flags=PolicyFlags(channel=Channel.ONLINE,
                                      response=ResponseKind.DENIED)))
    b = resolve(inp(fraud_probability=0.8, verdict=Verdict.FRAUD, exposure_usd=1_500,
                    flags=PolicyFlags(channel=Channel.IN_PERSON,
                                      response=ResponseKind.DENIED)))
    assert acts(a) == acts(b)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
