"""Sentence counting for validator checks #11 and #12.

The naive implementation split on every period, so '$526.42' and '0.72'
each contributed a phantom sentence and well-formed summaries warned.
The counter must see what a human sees.
"""

from __future__ import annotations

from anvesh.util.ids import count_sentences


def test_empty_is_zero():
    assert count_sentences("") == 0
    assert count_sentences("   ") == 0


def test_single_sentence():
    assert count_sentences("One sentence here.") == 1


def test_decimals_are_not_breaks():
    text = ("The episode comprises 3 transactions totalling $526.42 in exposure, "
            "supported by 3 independent evidence axes. "
            "The assessed fraud probability is 0.72! Really?")
    assert count_sentences(text) == 3


def test_money_and_dates():
    text = ("On 2016-12-01, 3 transactions were conducted that the investigation "
            "assessed as suspicious. The total suspicious amount is $1,200.50.")
    assert count_sentences(text) == 2


def test_abbreviations_are_not_breaks():
    text = ("Mr. Singh holds card C1 with the reporting institution. "
            "The card was issued by First Natl. Bank Corp. in 2015. Done.")
    assert count_sentences(text) == 3


def test_marks_mix():
    assert count_sentences("Stop! Really? Yes.") == 3
