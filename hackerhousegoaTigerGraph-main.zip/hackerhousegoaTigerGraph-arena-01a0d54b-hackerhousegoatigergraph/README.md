# Anvesh

**Agentic fraud investigation and next-best-action on TigerGraph.**
Hacker House Goa 2026 — Partner Trial, TigerGraph (Task 4).

> From an uncertain signal to a defensible case.

---

## What it does

An alert fires — a risk score, a customer report, or an analyst request. Anvesh investigates it against a graph of **590,742 card transactions**, decides what kind of fraud it is (if any), works out how far it reaches, asks for evidence when the signals disagree, and recommends the next action with the approval route it needs.

For each of 20 benchmark cases it produces an answer file containing:

1. **A case** — the internal investigation record, written back into the graph as memory
2. **A SAR** — the regulatory filing, when the policy requires one
3. **The next best action** — before *and* after any evidence it requested, with approval routes

---

## The thesis

> **The graph supplies the facts. The model supplies the probability. The policy engine makes the call. The LLM writes it down.**

Four layers, hard boundaries:

| Layer | Owns | Nature |
|---|---|---|
| **L1 Evidence** | TigerGraph — GSQL, graph algorithms, TigerVector | Deterministic, citeable |
| **L2 Judgement** | Calibrated model ⊕ LLM synthesis | Probabilistic |
| **L3 Decision** | Policy engine — rules R1–R10 as code | Deterministic, auditable |
| **L4 Explanation** | LLM, constrained by the evidence list | Generative |

**The LLM never writes an action.** A quarter of the score is policy-legal, correctly-routed actions, and an action sampled from a language model cannot be unit-tested.

---

## How TigerGraph is used

| Capability | Where |
|---|---|
| Schema + loading | 15 vertex types, 26 edge types; chunked REST loading; two-tier device model (`DeviceProfile` precise, `DeviceSignature` fuzzy) |
| GSQL | 10 installed parameterised queries, **every one `as_of`-bounded** |
| Graph algorithms | single-source `ring_components` component walk — a card's ring at an hour, `as_of`-bounded |
| TigerVector | Closed-case narratives, behavioural fingerprints, policy/regulator chunks, our own cases |
| MCP | `tigergraph-mcp` over stdio — the **only** path from agent to graph; append-only write profile |
| Case memory | `InvestigationCase` + `CaseEvent` vertices with typed edges, so case 12 can find case 3 through the graph |

---

## Results

*Filled in after the backtest. Both arms reported — see [`docs/BACKTEST.md`](./docs/BACKTEST.md).*

| | Verdict accuracy | Episode IoU | AUC | Brier |
|---|---|---|---|---|
| Onset trigger (upper bound) | — | — | — | — |
| **Random trigger (honest)** | — | — | — | — |

---

## Quickstart

```bash
# 1. Get the dataset into data/ (see docs/SETUP.md) and read data/README.md first

pip install -e ".[dev]"
cp .env.example .env          # add TG_HOST, TG_SECRET, LLM_API_KEY

anvesh verify --data-dir data/HHGOA_IEEE   # live-instance checklist
anvesh run --case HHG-002 --data-dir data/HHGOA_IEEE --adapter tigergraph
anvesh run --all --data-dir data/HHGOA_IEEE --adapter tigergraph
anvesh validate               # the 15 answer-file checks
anvesh backtest --data-dir data/HHGOA_IEEE
anvesh serve                  # static replay server (no graph/LLM/network)
```

---

## Layout

```
cases/       HHG-001.json … HHG-020.json      ← submission artifact
traces/      per-case traces                  ← demo source
benchmark/   backtest output
monitor/     optional autonomous investigations
graph/       schema.gsql, loading_jobs.gsql, queries/
src/anvesh/  domain · graph · agent · evidence · reasoning · policy · retrieval · llm · validate · ui
docs/        architecture, state, schema, queries, policy, answer schema, uncertainty, backtest, UI, content, setup
```

---

## Documentation

| For | Read |
|---|---|
| Coding agents | [`AGENTS.md`](./AGENTS.md) — **read first** |
| Product & architecture | [`PRD.md`](./PRD.md) |
| Schedule & risk | [`ROADMAP.md`](./ROADMAP.md) |
| Implementation | [`docs/`](./docs/) — architecture, state machine, graph schema, queries, policy, answer schema, uncertainty, backtest, UI, content, setup |

---

## Limitations

*Completed at submission. Known and expected entries:*

- The prior is **assumed, not measured** — the closed-case corpus is 84% fraud while the alert population is ~50%. Corrected with an explicit prior shift; the correction is first-order.
- Customer and analyst responses are **simulated** under a fixed, disclosed policy. They are not ground truth.
- Vesta's `V`, `C`, `D`, `M` and numeric `id` columns are real model features with no published definitions. They are used as signals and described as such.
- There is **no merchant column**; `ProductCode` is the proxy used for policy R7.
- The dataset's own README notes that not every fraud pattern in the data is documented.
- Scope cuts from the PRD, kept honest: **10 installed queries** (the 8 reads the agent calls, plus ring detection and origin tracing — the PRD's 18-query catalogue); the replay UI is **static HTML**, not Streamlit; there is no `build-graph` or `monitor` command.

---

## Submission

Deadline **24 Sept 2026, 23:59 IST**. One submission, no resubmissions.
Contents: working agent · this repo · 20 answer files · demo video · blog post · social post tagging **@TigerGraphDB**.

Built with TigerGraph Savanna, `tigergraph-mcp` and LangGraph. The replay UI is dependency-free static HTML.
