# Anvesh — Product Requirements Document
### Agentic Fraud Investigation & Next-Best-Action on TigerGraph

> **From an uncertain signal to a defensible case.**

| | |
|---|---|
| **Product name** | Anvesh (Sanskrit *anveṣaṇa* — investigation, search) |
| **Track** | Hacker House Goa 2026 — Partner Trial, TigerGraph ("Task 4") |
| **Document status** | v1.0 — for build |
| **Author** | Team |
| **Hard deadline** | **24 Sept 2026, 23:59 IST** — single submission, no resubmissions |
| **Source of truth** | `TigerGraph Agentic Fraud Investigation HHGOA.md` + dataset `README.md` (HHGOA_IEEE) |

---

## 0. How to read this document

Sections 1–6 are the *why* and the *what*: why this product wins the selection task, what it must do, and how "done" is measured. Sections 7–10 are the *how*: the data model, the architecture, the reasoning model, and the interface. Section 11 is the submission checklist. Section 12 is the build plan with a cut list keyed to hours remaining — **read that first if you are time-poor.** Section 14 lists the decisions I assumed on your behalf; correct them and I will re-cut the plan.

Everything normative is written as `FR-x` (functional requirement) or `NFR-x` (non-functional requirement). Everything that is a guess is marked **HYPOTHESIS**.

---

## 1. Executive summary

Fraud analysts do not have a detection problem. They have a *decision-under-uncertainty* problem. The bank's model already flags transactions; the hard part is what happens in the twenty minutes after the flag: gathering evidence from six systems, deciding whether the signal is real, deciding whether you are allowed to act, and writing down why.

**Anvesh** is an agent that owns that twenty minutes.

The core design bet is a **separation of three jobs that almost every competing solution will conflate**:

| Job | Who does it | Nature | Failure mode if you get it wrong |
|---|---|---|---|
| **Evidence** | TigerGraph — GSQL traversals, windowed aggregations, graph algorithms | Deterministic, replayable, citeable | Hallucinated facts |
| **Judgement** | LLM + a calibrated statistical model over closed-case history | Probabilistic, explainable | Confident nonsense; miscalibrated probability |
| **Action** | Policy engine — Fraud Policy v1.0 rules R1–R10 as code | Deterministic, auditable, permissioned | Illegal or unapproved actions |

The LLM never decides what the bank does. It reads a structured evidence brief assembled from the graph, proposes a pattern and a probability, and writes the prose. A deterministic policy engine takes the probability and the evidence and emits the action set and its approval route. This one decision is what makes the system defensible to a fraud manager, and it is what the "next best action" quarter of the score is actually testing.

Three things make Anvesh different from an LLM-with-a-graph-tool:

1. **As-of temporal isolation.** Every graph read is bounded by the case's `opened_at`. The agent literally cannot see the future. Without this, an investigation is not defensible and every backtest is a leak.
2. **A calibrated posterior, not a vibe.** The dataset ships 5,565 *labelled* closed cases (4,665 confirmed fraud, 900 cleared). That is a training set. We compute the same feature vector over every closed case and every benchmark case, fit a calibrated episode classifier on a held-out split, and derive `fraud_probability` from it. The answer format scores that field **for calibration**, so this is worth real points.
3. **Value-of-information stopping.** The agent only asks for more evidence when a plausible response could actually change the action set. It computes P(flip) per candidate response first. This is policy §6 ("stopping") done as decision theory instead of a threshold, and it is the single most direct hit on the 25% "next best action" criterion.

Plus: bipartite **ring detection** for cross-customer compromise (HHG-014 is explicitly this), a **residual scan** to surface undocumented patterns (R9 — explicitly scored), and **case memory written back into the graph** so case 20 is smarter than case 1.

---

## 2. Context: what this has to win

### 2.1 The selection funnel

Hacker House Goa 2026 is a four-day builder residency in Goa, 28–31 Oct 2026, run by 2:47PM Studio. Selection runs in stages: **Open Trials** (August, general skill tasks) → **Partner Trials** (September, tasks set by sponsors) → waitlist → seat. This TigerGraph task is a **Partner Trial**: it is set by a sponsor, carries more weight than an Open Trial, and requires working with TigerGraph specifically. Getting selected here earns an onsite seat at the residency.

Two consequences shape this PRD:

- **Partner Trials reward depth on the partner's technology.** TigerGraph is the partner. Judges are TigerGraph mentors. Graph depth — real GSQL, real algorithms, TigerVector, MCP — is disproportionately rewarded over generic agent scaffolding.
- **The submission is a package, not a repo.** Working agent + GitHub repo + 20 answer files + demo video + technical blog + social post. A brilliant agent with a rushed blog and no video loses points that are cheap to earn.

### 2.2 The scoring rubric

| Criterion | Weight | What it really asks |
|---|---|---|
| Investigation accuracy | **25%** | Did you find the fraud, and did you find *all* of it (the right episode, not just the flagged txn)? |
| Next best action | **25%** | Are the actions policy-legal, correctly routed, and do they *change* correctly when evidence arrives? |
| Case summary & explainability | **10%** | Is the case file complete and is every claim sourced? |
| Agentic design & engineering | **15%** | Is it an agent or a script? Tool use, orchestration, memory, permissions. |
| Innovation | **15%** | Originality in graph / GraphRAG / agentic technique. |
| Demo quality & completeness | **10%** | Can a stranger follow it end to end in 4 minutes? |

Note the shape: **50% of the score is accuracy of the judgement and the action**, 15% is architecture, 15% is novelty, 20% is communication. A system that is 90% accurate and beautifully explained beats a clever system that is 60% accurate. This PRD front-loads accuracy and explainability and takes innovation from the same mechanisms rather than bolting on a gimmick.

### 2.3 Known facts about the exam

From the dataset README — these are load-bearing:

- **No `isFraud` label.** Every transaction carries a `risk_score` 0–1 instead.
- **Above 0.7, most flagged transactions turn out to be legitimate.** Half the 20 cases are legitimate. **An agent that blocks everything scores badly.** The prior must be learned, not assumed.
- IDs, times and amounts were transformed so the public Kaggle file cannot be used to look up answers. **Doing so is disqualification.**
- **Every ID in the answer must exist in the dataset. Made-up IDs score zero.**
- 5 of the patterns are documented; **some in the data are not**. Finding an undocumented pattern is scored (R9).
- Customer and analyst replies are **not provided**. Simulate them and record the assumption.
- Scored against an answer key we do not have.

---

## 3. Problem statement

**The job to be done:** when an alert fires, produce a decision a fraud manager would sign — a verdict with a calibrated probability, the full set of transactions in the episode, the other cards caught up in it, a correctly-routed action set, and a written record that explains itself — and know when you do not yet have enough to decide.

**Why it is hard here:**

1. **The signal is weak and inverted.** A 0.90 risk score is *usually* legitimate. The model's output is an input to an investigation, never a verdict.
2. **The episode is bigger than the transaction.** The flagged transaction is "where the alert fired. It is not necessarily where the fraud started." Scoring an episode means segmenting a boundary in a 590k-transaction graph, as-of a timestamp.
3. **Some cases are only solvable sideways.** "A device profile or a billing region shared across many cards in a short window is worth a look. Some cases can only be solved by asking what happened on *other* cards." Entity resolution at graph scale is not optional — it is the difference between a solved and an unsolved case.
4. **The action space is constrained and asymmetric.** Fourteen legal actions, three approval routes, exposure-dependent routing (block ≤ $2,500 is L1, > $2,500 is L2), and ten rules that say when you must or must not act. Over-blocking a legitimate customer is a *policy breach*, not a false positive.
5. **Stopping is a scored decision.** Both over-investigation and under-investigation are marked down. The agent needs an explicit, defensible criterion.

---

## 4. Goals and non-goals

### 4.1 Goals

| ID | Goal |
|---|---|
| G1 | Produce all 20 answer files, schema-valid, ID-valid, policy-legal. |
| G2 | Maximise verdict accuracy and episode completeness against the hidden answer key, using a held-out backtest on the closed-case corpus as our proxy for the truth. |
| G3 | Make `fraud_probability` genuinely calibrated — measurable as Brier score / reliability on held-out closed cases. |
| G4 | Demonstrate the two-stage action: initial recommendation → evidence request → revised recommendation, with a recorded `what_changed`. |
| G5 | Prove the graph matters: every material finding traces to a GSQL query or graph algorithm, reached through TigerGraph MCP. |
| G6 | Show real memory: case 20 retrieves case 3's findings through the graph. |
| G7 | Ship a UI an analyst would actually open, and a 4-minute demo that a judge can follow without narration. |
| G8 | Write the blog and the social post so the work is legible to a TigerGraph engineer in five minutes. |

### 4.2 Non-goals

| ID | Non-goal | Why |
|---|---|---|
| NG1 | Beat the bank's risk model at scoring transactions. | The risk score is an input. We investigate, we do not re-score. |
| NG2 | Train a large model or fine-tune anything. | No time, no need, and 5,565 labels fit a regularised linear/GBM model fine. |
| NG3 | Real integrations — real SMS, real card blocking, real regulator filing. | Simulated by design and by the brief. All execution is recorded, not performed. |
| NG4 | Sub-second latency. | An investigation that takes 20 s and is right beats one that takes 200 ms and is wrong. We still budget and report `latency_s`. |
| NG5 | Recovering ground truth from the public IEEE-CIS/Kaggle file. | Explicitly disqualifying. |
| NG6 | A general-purpose agent that writes its own GSQL at runtime. | Interesting, but `run_query` at agent runtime is slow, non-deterministic and un-auditable. Installed parameterised queries + an agent that *chooses* among them is the stronger engineering answer. (We keep `generate_gsql` as an offline authoring aid only.) |

---

## 5. Users

| Persona | Need | Anvesh surface |
|---|---|---|
| **Priya, L1 fraud analyst** (primary) | Close 40 alerts a shift without missing a ring; stop re-gathering the same evidence. | Case queue, investigation timeline, evidence board, graph explorer |
| **Rajesh, L2 fraud manager** (approver) | Sign off on blocks and SARs; needs the reasoning, not just the recommendation. | Action panel with rule citations and expected-cost comparison, approval buttons, policy trace |
| **Compliance officer** | SARs that stand alone: who/what/when/where/how/why. | SAR view with completeness checks |
| **Judge / TigerGraph engineer** (evaluator) | See that this is genuinely graph-native and genuinely agentic. | Tool-call trace, GSQL query catalogue, architecture doc, demo |

---

## 6. Success metrics

### 6.1 External (what we are graded on)

| Rubric criterion | Weight | Internal proxy target |
|---|---|---|
| Investigation accuracy | 25% | ≥ **85%** verdict accuracy on held-out closed cases; episode IoU ≥ **0.60** |
| Next best action | 25% | **100%** policy-legal action sets; ≥ **90%** agreement with a hand-written scenario suite covering R1–R10 |
| Case summary & explainability | 10% | **100%** citation coverage; 100% of required fields non-empty |
| Agentic design | 15% | Deterministic skeleton, ≤ 2 LLM decision nodes, full trace replay, budget caps enforced |
| Innovation | 15% | 5 named mechanisms shipped and demonstrated (§9.2) |
| Demo | 10% | 4-minute video hitting all 11 "what success looks like" points from the brief |

### 6.2 Internal quality gates (must pass before submission)

| ID | Gate | Threshold |
|---|---|---|
| NFR-1 | Held-out Brier score on `fraud_probability` | ≤ 0.15 |
| NFR-2 | Reliability: predicted 0.8 bucket actual fraud rate | 0.65–0.95 |
| NFR-3 | Answer files pass the JSON schema validator | 20/20 |
| NFR-4 | Every ID in every answer exists in the dataset | 100% |
| NFR-5 | Every evidence claim carries `source` + `ref` | 100% |
| NFR-6 | `sar.file == true` ⟺ `FILE_REPORT` ∈ final actions | 20/20 |
| NFR-7 | `exposure_usd` == Σ|amount| of `affected_txn_ids` | 100% (to the cent) |
| NFR-8 | Legitimate verdicts ⇒ empty `affected_txn_ids`, `exposure_usd` = 0, `sar.file` = false | 100% |
| NFR-9 | Every graph read is `as_of`-bounded | 100% of GSQL queries |
| NFR-10 | Deterministic replay: same case + same seed ⇒ identical answer file (modulo LLM prose) | 100% |
| NFR-11 | Per-case budget: ≤ 30 tool calls, ≤ 60 s wall clock | 20/20 |
| NFR-12 | Every case written to the graph (`written_to_graph` = true, `graph_case_id` present) | 20/20 |

**The backtest harness is the most important thing in this table.** Holding out 20% of the 5,565 closed cases, running the agent on them with `as_of = opened_at` and using `first_fraud_txn_id` as the trigger, gives us an honest accuracy and calibration number *before* we see the answer key. Most teams will ship on vibes. We will ship with a number, and we will put that number in the blog post.

---

## 7. Domain and data model

### 7.1 The dataset

| File | Rows | Notes |
|---|---|---|
| `transactions.csv` | 590,742 | 393 original Vesta columns + `customer_id`, `ts`, `channel`, `risk_score`. ~708 MB. |
| `identity.csv` | 144,432 | 41 columns, joined on `TransactionID`. **Online only.** |
| `closed_cases_history.csv` | 5,565 | July–Oct. 4,665 `confirmed_fraud` / 900 `cleared`. Our labelled history **and** our memory seed. |
| `case_pack.csv` | 20 | Nov–Dec. The exam. |

Time span: **2 Jul – 31 Dec 2016**. Calendar is real (`ts`), unlike the original `TransactionDT`.

**Critical:** `identity.csv` covers online transactions only. `ProductCD = W` ⇒ `channel = in_person` ⇒ no device record. Any detector that assumes a device exists will silently fire on every in-person transaction. This is a top-3 source of bugs.

### 7.2 Entity resolution decisions

These are engineering decisions, and the brief says schema design is part of the score.

| Entity | Resolution rule | Rationale |
|---|---|---|
| `Customer` | `customer_id` (e.g. `C01234`), derived upstream from the card issuer field | Given. One customer → several cards. |
| `Card` | `card_id` (e.g. `C01234-K1`) | Given. |
| `DeviceProfile` | `DeviceInfo + id_30 (OS) + id_31 (browser) + id_33 (screen)` | The README's suggested definition. Precise. |
| `DeviceSignature` | `DeviceType + id_30 + id_31` — **coarser, our addition** | DeviceInfo strings fragment across firmware builds. A ring that rotates `SAMSUNG SM-G892A Build/NRD90M` → `...Build/NRD90U` defeats exact matching. Two granularities catches both precision and recall. |
| `BillingRegion` | `addr1` | Given. `addr2` = country (87 = home). |
| `EmailDomain` | `P_emaildomain` / `R_emaildomain`, with a `kind` attribute | R6 names shared recipient email as a shared-origin signal. |
| `ProductCode` | `ProductCD` (W, C, H, R, S) | Closest thing to a merchant. Product novelty is a documented CNP signal. |
| `ClosedCase` / `InvestigationCase` | `case_id` | Both are vertices so memory is graph-retrievable, not just vector-retrievable. |

### 7.3 The five known patterns → detectors

| Pattern | Mechanical signature | Policy |
|---|---|---|
| `card_testing` | ≥ 3 online auths < $5 on one card within ~1 h, then a materially larger purchase | R5 |
| `card_not_present_fraud` | 2–4 online txns within 48 h; amount/product outside cardholder baseline | R1–R4 |
| `card_not_present_new_device` | as above + `id_15 = New` for the account, possibly proxy (`id_23`) | R1–R4 |
| `out_of_region_use` | Card-present txns in a region with no cardholder history **while** normal activity continues at home | R2, R3 |
| `account_takeover` | Mixed-channel activity inconsistent with the cardholder + device and match-flag (`M1`–`M9`) anomalies | — |

Two subtleties the README spells out and that the detector must honour:

- **Several days of purchases in one new region is a trip, not a clone.** Out-of-region needs a *duration and simultaneity* test, not a presence test.
- **One unusual online purchase alone is ambiguous.** CNP needs corroboration; the correct action is verify, not block.

### 7.4 The undocumented-pattern path (R9)

**HYPOTHESIS (design, not a finding):** episodes that score high on the calibrated model but have low cosine similarity to all five known pattern prototypes are candidates. Cluster their behavioural fingerprints; if a cluster has ≥ 3 episodes, sustained elevation, and no prototype match, emit `pattern = "undocumented"` with a generated `pattern_description` and route to R9 (`CREATE_CASE` + `FILE_REPORT` + `ESCALATE_TO_ANALYST`). The detection is cheap once the fingerprint vectors exist; the *description* is where the LLM earns its place.

---

## 8. Functional requirements

### 8.1 Ingestion and graph build

- **FR-1** Load `transactions.csv` (590,742 rows) and `identity.csv` (144,432 rows) into TigerGraph. Chunked REST loading in ≤ 16 MB parts so the same code path works on Savanna and CE.
- **FR-2** Materialise the schema in §9.4 with vector attributes where required.
- **FR-3** Build the `NEXT` ordering edge within each card, ordered by `ts`.
- **FR-4** Materialise `SHARES_DEVICE` / `SHARES_REGION` / `SHARES_EMAIL` card-to-card edges per time window, with first-seen/last-seen attributes — these make ring queries sub-second instead of multi-hop-at-read-time.
- **FR-5** Load `closed_cases_history.csv` as `ClosedCase` vertices with `INVOLVES` / `ON_CARD` / `CONNECTED_TO` / `HAS_PATTERN` edges.
- **FR-6** Chunk and embed the document corpus (Fraud Policy v1.0, the README's patterns section, "Things to know", FinCEN SAR narrative guidance, FFIEC red flags, FATF cyber-enabled fraud) into `DocChunk` vertices linked to `Pattern` vertices.
- **FR-7** One command rebuilds the entire graph from raw CSVs: `anvesh build-graph`. Idempotent.

### 8.2 Agent capabilities

- **FR-8** `Trigger` — accept all three trigger types (`risk_score`, `customer_report`, `analyst_request`) and resolve the flagged transaction, card, and customer.
- **FR-9** `AsOf` — bind every subsequent graph read to `as_of = case.opened_at`. Non-negotiable (NFR-9).
- **FR-10** `EpisodeConstruction` — grow a candidate episode from the flagged transaction: seed → candidate generation (device / region / email / velocity / product linkage, as-of bounded) → per-transaction scoring → boundary selection.
- **FR-11** `HypothesisGeneration` (LLM node 1 of 2) — given a cheap first-pass context packet, propose 2–4 candidate hypotheses. Each is a (pattern, entities-to-query) pair. **The hypothesis set determines which queries run next** — this is what makes it an agent rather than a pipeline.
- **FR-12** `EvidenceGathering` — execute the selected GSQL queries through TigerGraph MCP, bounded by NFR-11. Every result becomes an `evidence` object with `claim`, `source`, `ref`, `entity_ids`.
- **FR-13** `MemoryRecall` — hybrid retrieval over closed cases, prior agent cases, and the document corpus (§9.6). Populates `similar_prior_cases`.
- **FR-14** `Assessment` — compute the calibrated posterior, the pattern label, a confidence interval, and **decision sensitivity**: which single unresolved question would most change the action set.
- **FR-15** `StopOrContinue` — value-of-information gate (§9.9). Stop or request evidence.
- **FR-16** `EvidenceRequest` — emit `VERIFY_WITH_CUSTOMER` / `STEP_UP_AUTH` / `analyst_info` requests with a simulated `assumed_response`. The simulation must be **deterministic and disclosed**, never tuned per case to reach a preferred verdict.
- **FR-17** `Reassessment` — Bayesian update of the posterior using the response likelihood ratio.
- **FR-18** `PolicyResolution` — deterministic policy engine emits the action set and routes (§9.8). The LLM has no write access to `next_best_actions`.
- **FR-19** `ActionRanking` — order actions by expected cost (§9.8.3), constrained by the policy-legal set.
- **FR-20** `CaseWriteback` — write the case, its events, its evidence and its pattern into the graph via MCP; record `graph_case_id`.
- **FR-21** `Explanation` (LLM node 2 of 2) — produce `summary`, SAR `narrative`, and `what_changed`. **Every assertion must be traceable to an evidence object**; the generator is given the evidence list and is forbidden from introducing new entity IDs (enforced by validator).
- **FR-22** `Validation` — schema, ID existence, policy consistency, arithmetic consistency. On failure, repair and regenerate once, then fail loudly.
- **FR-23** `Trace` — emit a per-case JSON trace of every node, tool call, argument, latency, and token count. Powers `tool_calls`, `tokens`, `latency_s` and the UI timeline.

### 8.3 Optional (Innovation credit, P2)

- **FR-24** `AutonomousMonitor` — scan Nov–Dec for alerts the bank did not put in the case pack, investigate them, and write them to a separate `monitor/` folder. Explicitly counts toward Innovation, not accuracy.

---

## 9. Architecture

### 9.1 Design thesis

> **The graph supplies the facts. The model supplies the probability. The policy engine makes the call. The LLM writes it down.**

Four layers, each with exactly one job and a hard boundary:

```
┌──────────────────────────────────────────────────────────────────────┐
│  L4  EXPLANATION      LLM (temp 0, structured output)                │
│      summary · SAR narrative · what_changed · pattern_description    │
│      Constraint: may only assert claims backed by an evidence object  │
└───────────────▲──────────────────────────────────────────────────────┘
                │ evidence brief (structured, cited, as-of bounded)
┌───────────────┴──────────────────────────────────────────────────────┐
│  L3  DECISION         deterministic                                  │
│      policy engine (R1–R10 as code) · approval router · cost model    │
│      Constraint: LLM cannot write here. Ever.                         │
└───────────────▲──────────────────────────────────────────────────────┘
                │ verdict, probability, evidence set, exposure
┌───────────────┴──────────────────────────────────────────────────────┐
│  L2  JUDGEMENT        calibrated statistical model ⊕ LLM synthesis    │
│      episode scorer (fit on closed cases) · LR fusion · kNN memory    │
│      Constraint: probability must be calibrated on held-out data      │
└───────────────▲──────────────────────────────────────────────────────┘
                │ feature vector over the candidate episode
┌───────────────┴──────────────────────────────────────────────────────┐
│  L1  EVIDENCE         TigerGraph — the only path to the data          │
│      installed GSQL · graph algorithms · TigerVector                  │
│      reached exclusively through TigerGraph MCP (stdio)               │
└──────────────────────────────────────────────────────────────────────┘
```

### 9.2 The five innovation mechanisms

| # | Mechanism | Earns |
|---|---|---|
| I1 | **As-of temporal isolation** — every query takes `as_of`; future data is structurally unreachable | Correctness, defensibility, honest backtest (Accuracy, Design) |
| I2 | **Calibrated posterior from the closed-case corpus** — 5,565 labelled episodes → fitted, held-out-validated probability | Calibration scoring, Accuracy |
| I3 | **Value-of-information stopping** — request evidence only when a plausible response could flip the action set | Next best action (25%) |
| I4 | **Bipartite ring detection** — label-propagation / WCC over Card↔Device↔Region↔Email within a window | R6, R9, HHG-014, Accuracy, Innovation |
| I5 | **Residual scan for undocumented patterns** — high-probability, low-prototype-similarity episodes clustered and described | R9, Innovation |

### 9.3 System diagram

```
                       ┌──────────────────────────┐
  case_pack.csv  ─────▶│  Anvesh orchestrator     │
  (20 triggers)        │  LangGraph state machine │
                       └────────────┬─────────────┘
                                    │  MCP (stdio, JSON-RPC)
                       ┌────────────▼─────────────┐
                       │  tigergraph-mcp          │
                       │  run_installed_query     │
                       │  search_top_k_similarity │
                       │  add_nodes / add_edges   │
                       └────────────┬─────────────┘
                                    │  pyTigerGraph (async)
                       ┌────────────▼─────────────────────────────┐
                       │  TigerGraph Savanna (or CE 4.2+)         │
                       │  ┌────────────┐ ┌──────────────────────┐ │
                       │  │ Graph      │ │ TigerVector          │ │
                       │  │ ~800k V    │ │ DocChunk.emb         │ │
                       │  │ ~5M E      │ │ ClosedCase.emb / .fp │ │
                       │  │ 18 queries │ │ InvestigationCase.emb│ │
                       │  │ 4 algs     │ │                      │ │
                       │  └────────────┘ └──────────────────────┘ │
                       └────────────┬─────────────────────────────┘
                                    │  write-back
                       ┌────────────▼─────────────┐
                       │  InvestigationCase +     │
                       │  CaseEvent (memory)      │
                       └──────────────────────────┘

  ┌───────────────┐        ┌──────────────┐        ┌──────────────┐
  │ episode scorer│        │ policy engine│        │ validator    │
  │ (fitted, .pkl)│        │ (R1–R10)     │        │ (schema+IDs) │
  └───────────────┘        └──────────────┘        └──────────────┘
           ▲                                                    │
           └────────── backtest on held-out closed cases ───────┘
```

### 9.4 Graph schema

**Vertices** (extending the README's suggestion — additions marked ✚)

| Vertex | Key attributes |
|---|---|
| `Customer` | `customer_id` |
| `Card` | `card_id`, `card4` (network), `card6` (type) |
| `Transaction` | `txn_id`, `ts`, `amount`, `product_cd`, `channel`, `risk_score`, `addr1`, `addr2`, selected `V`/`C`/`D`/`M` features |
| `DeviceProfile` | `device_id`, `device_info`, `os`, `browser`, `screen`, `device_type` |
| `DeviceSignature` ✚ | `sig_id`, `device_type`, `os`, `browser` |
| `EmailDomain` | `domain`, `kind` (P/R) |
| `BillingRegion` / `BillingCountry` | `addr1` / `addr2` |
| `ProductCode` | `code` |
| `ClosedCase` | `case_id`, `opened_at`, `closed_at`, `outcome`, `pattern`, `n_txns`, `exposure_usd`, `analyst_notes`, **`emb`** (narrative), **`fp`** (behavioural fingerprint) |
| `InvestigationCase` ✚ | `case_id`, `opened_at`, `verdict`, `fraud_probability`, `pattern`, `exposure_usd`, **`emb`**, **`fp`** |
| `CaseEvent` ✚ | `event_id`, `seq`, `step`, `kind`, `payload_json`, `at` — append-only audit log |
| `Pattern` ✚ | `name`, the five known + discovered clusters |
| `DocChunk` ✚ | `chunk_id`, `source`, `section`, `text`, **`emb`** |
| `Cluster` ✚ | `cluster_id`, `window`, `kind` (device/region/email ring), `size` |

**Edges**

```
Customer        ──OWNS──▶              Card
Card            ──MADE──▶              Transaction
Transaction     ──FROM_DEVICE──▶       DeviceProfile       (online only)
Transaction     ──RESOLVES_TO──▶       DeviceSignature  ✚
Transaction     ──PURCHASER_EMAIL──▶   EmailDomain
Transaction     ──RECIPIENT_EMAIL──▶   EmailDomain      ✚
Transaction     ──BILLED_IN──▶         BillingRegion
Transaction     ──IN_COUNTRY──▶        BillingCountry   ✚
Transaction     ──OF_PRODUCT──▶        ProductCode      ✚
Transaction     ──NEXT──▶              Transaction      (per card, ordered by ts)
Card            ──SHARES_DEVICE──▶     Card  (window, first_seen, last_seen)  ✚
Card            ──SHARES_REGION──▶     Card  ✚
Card            ──SHARES_EMAIL──▶      Card  ✚
ClosedCase      ──INVOLVES──▶          Transaction
ClosedCase      ──ON_CARD──▶ / ──CONNECTED_TO──▶  Card
ClosedCase      ──HAS_PATTERN──▶       Pattern        ✚
InvestigationCase ──CASE_TXN──▶        Transaction    ✚
InvestigationCase ──CASE_CARD──▶       Card           ✚
InvestigationCase ──CASE_DEVICE──▶     DeviceProfile  ✚
InvestigationCase ──CASE_REGION──▶     BillingRegion  ✚
InvestigationCase ──CASE_PATTERN──▶    Pattern        ✚
InvestigationCase ──CASE_CITES──▶      ClosedCase | DocChunk  ✚
InvestigationCase ──HAS_EVENT──▶       CaseEvent      ✚
DocChunk        ──DESCRIBES──▶         Pattern        ✚
Cluster         ──CONTAINS──▶          Card           ✚
```

**Why `SHARES_*` materialised edges matter:** ring detection is the highest-value query in the system and the only way to solve HHG-014. Computing connected components over Card↔Device↔Region at read time on 590k transactions is a multi-second job per case. Materialising the projection per window and running label propagation on the *projection* makes it ~0.3 s and lets the agent call it speculatively.

### 9.5 GSQL query catalogue

All installed (`tigergraph__install_query`), all parameterised, **all taking `as_of`**, all invoked via `tigergraph__run_installed_query`. This catalogue is the agent's entire tool surface — a closed set of auditable primitives, not an open-ended query generator.

| # | Query | Purpose |
|---|---|---|
| Q1 | `txn_context(as_of, txn_id)` | One hop: txn + card + customer + device + region + email + product |
| Q2 | `card_window(as_of, card_id, hours)` | Ordered transaction window ending at `as_of` |
| Q3 | `cardholder_baseline(as_of, card_id, days)` | Amount / product / region / device distributions → z-scores |
| Q4 | `device_neighbors(as_of, device_id, days)` | Cards and transactions on an exact device profile |
| Q5 | `device_signature_neighbors(as_of, sig_id, days)` | Fuzzy device linkage across firmware variants |
| Q6 | `region_window(as_of, region_id, days)` | Activity in a billing region |
| Q7 | `geo_velocity(as_of, card_id, hours)` | Impossible travel via `NEXT` + `BILLED_IN` |
| Q8 | `email_cluster(as_of, domain, days)` | Cards sharing purchaser/recipient email |
| Q9 | `ring_components(as_of, days, min_cards)` | **Algorithm.** Label propagation / WCC on the `SHARES_*` projection |
| Q10 | `testing_sequence(as_of, card_id, hours)` | ≥ 3 small online auths then a larger purchase |
| Q11 | `burst_detect(as_of, card_id, hours)` | 2–4 online transactions within 48 h |
| Q12 | `recurring_check(as_of, card_id, days)` | Same amount + product monthly → R7 |
| Q13 | `prior_cases(vec, k, as_of)` | TigerVector over `ClosedCase.emb`, then graph expansion |
| Q14 | `similar_agent_cases(vec, k)` | Same over `InvestigationCase.emb` — **the memory loop** |
| Q15 | `policy_search(vec, k)` | `DocChunk` retrieval, returns linked `Pattern` vertices |
| Q16 | `shared_origin_sweep(as_of, element, id, days)` | R6: every card sharing a device / region / email |
| Q17 | `episode_expand(as_of, seed_txns, hops)` | Grow the affected set from seeds |
| Q18 | `counterfactual_exposure(as_of, card_ids, hours)` | Forward exposure if we do not act → cost model |

### 9.6 GraphRAG — two corpora, one retrieval pattern

| Corpus | Source | Vertex / vector |
|---|---|---|
| **Documents** | Fraud Policy v1.0 (chunked per rule), README patterns section, "Things to know", FinCEN SAR narrative guidance, FinCEN ATO advisory, FFIEC red flags, FATF cyber-enabled fraud | `DocChunk.emb`, linked to `Pattern` |
| **Cases** | 5,565 closed cases + every case we close ourselves | `ClosedCase.emb` (narrative) + `ClosedCase.fp` (fingerprint), `InvestigationCase.emb` / `.fp` |

**Retrieval is hybrid, not pure vector.** Pure vector RAG cannot answer "what else touched this device?" — the highest-value question in this dataset. The pattern is:

```
embed query ──▶ TigerVector top-k ──▶ expand 1–2 hops on the graph ──▶
rerank by (similarity × recency × outcome × entity-overlap) ──▶
assemble a STRUCTURED EVIDENCE BRIEF ──▶ hand to the LLM
```

The brief is the deliverable of the retrieval layer: claims with sources and refs, not rows. Passing raw rows to the LLM is explicitly what the brief warns against ("Pass the relevant context to the LLM rather than simply passing raw data").

### 9.7 The uncertainty model — how `fraud_probability` is produced

This is the single most score-dense subsystem (Accuracy 25% + Next best action 25%). It is also where most teams will hand-wave a number.

**Step 1 — Feature vector (identical for closed cases and benchmark cases).** For an episode, as-of its `opened_at`:

- *Velocity/structure:* n txns in 1 h / 24 h / 7 d; burst ratio; inter-arrival entropy
- *Amount:* z-score vs cardholder baseline; max/mean ratio; sub-$5 count
- *Novelty:* product code new to card? region new? device new (`id_15`)? email new?
- *Device:* profile age on account; distinct cards on device in window; proxy flag (`id_23`)
- *Geography:* distinct regions in 24 h; geo-velocity max; foreign-country share
- *Channel:* online/in-person mix shift (ATO signal); `M1`–`M9` anomaly count
- *Model residual:* anomaly score from an unsupervised model over `V1`–`V339` + `C`/`D` (IsolationForest or PCA reconstruction error)
- *Graph:* ring membership size; shared-origin degree; connected-card count
- *Trigger:* trigger type; risk-score band

**Step 2 — Prior.** Base rate conditioned on trigger type × risk band, learned from the closed cases. The README's warning — *above 0.7, most flagged transactions turn out to be legitimate* — means this prior is **below 0.5 even at high scores**. Encoding this correctly is worth more than any single detector.

**Step 3 — Likelihood ratios.** Each independent evidence axis contributes an LR computed as `P(evidence | confirmed_fraud) / P(evidence | cleared)` over the closed-case corpus. Axes are **not** independent, so combine in logit space with a fitted shrinkage exponent γ:

```
logit(p_det) = logit(π₀) + γ · Σᵢ wᵢ · log LRᵢ        γ ∈ (0,1], fitted
```

**Step 4 — Fusion with the LLM.** The LLM sees the evidence brief and returns an independent probability plus a pattern label. Fuse with a weight fitted on held-out closed cases:

```
p = α · p_det + (1 − α) · p_llm        α fitted on held-out split
```

Report both components in the case file. If α → 1, that is a finding worth writing about in the blog, not a failure.

**Step 5 — Bayesian update on the simulated response.** After `VERIFY_WITH_CUSTOMER`, update with the response LR (deny / confirm / no-reply each have an LR learned from closed cases where `analyst_notes` record the customer's answer). This is what makes `final` differ from `initial` *for a stated, quantified reason* — exactly what `what_changed` asks for.

**Step 6 — Calibration.** Isotonic or Platt calibration on the held-out split. Report Brier score and a reliability diagram in the README. **NFR-1/NFR-2.**

### 9.8 The policy engine (Fraud Policy v1.0 as code)

#### 9.8.1 Action legality and routing

Fourteen legal actions. Routes:

| Route | Actions |
|---|---|
| `auto` | `ALLOW_TRANSACTION`, `MONITOR_CARD`, `MONITOR_CONNECTED_CARDS`, `WARN_CUSTOMER`, `VERIFY_WITH_CUSTOMER`, `STEP_UP_AUTH`, `GENERATE_REPORT`, `CREATE_CASE`, `ESCALATE_TO_ANALYST`, `CLOSE_NO_FRAUD` |
| `L1` | `DECLINE_TRANSACTION`; `BLOCK_CARD` when exposure ≤ $2,500 |
| `L2` | `BLOCK_CARD` when exposure > $2,500; `BLOCK_ALL_CARDS` (always); `FILE_REPORT` (always) |

The engine computes routes from the (action, exposure) table. The LLM never supplies a route. Only `auto` actions may be executed; `L1`/`L2` are recommended and wait.

#### 9.8.2 Rules R1–R10

Implemented as ordered predicates over the case state, each emitting actions with a mandatory rule citation (policy §7). Coverage map:

| Rule | Trigger condition | Emits |
|---|---|---|
| R1 | Single signal, p < 0.70 | `VERIFY_WITH_CUSTOMER` / `STEP_UP_AUTH` **before** any block |
| R2 | Customer denies | `BLOCK_CARD`, `CREATE_CASE`; + `FILE_REPORT` if exposure > $1,000 or shared device / other card's fraud |
| R3 | Customer confirms | `CLOSE_NO_FRAUD` |
| R4 | No reply in 24 h | `MONITOR_CARD`, `DECLINE_TRANSACTION`; escalate if exposure > $500 |
| R5 | Card testing | `DECLINE_TRANSACTION`, `STEP_UP_AUTH`; `BLOCK_CARD` if a > $100 purchase cleared |
| R6 | Shared origin | name the element; `CREATE_CASE`, `FILE_REPORT`, `MONITOR_CONNECTED_CARDS` |
| R7 | Disputed but recurring | `CREATE_CASE`, `VERIFY_WITH_CUSTOMER`, `WARN_CUSTOMER`; **do not block** |
| R8 | Uncertain + exposure > $500, or conflicting evidence | `ESCALATE_TO_ANALYST` |
| R9 | Undocumented / coordinated | `CREATE_CASE`, `FILE_REPORT`, `ESCALATE_TO_ANALYST` + description |
| R10 | `BLOCK_ALL_CARDS` guard | only if ≥ 2 of the customer's cards show confirmed fraud or credentials confirmed compromised |

Special conditions: open a case when p ≥ **0.30**, when evidence is requested, or when a customer disputes (§3a). File a SAR only when fraud is confirmed/strongly suspected **and** (exposure > $1,000 **or** shared device/region/other customer's fraud **or** coordinated/undocumented). Most cases never need a report — **deciding correctly between "case only" and "case plus report" is itself scored.**

#### 9.8.3 Expected-cost ranking (innovation, P1)

Within the policy-legal set, rank actions by expected cost:

```
Cost(action set) = p · L_unavoided(action set)          # fraud loss we failed to stop
                 + (1−p) · F(action set)                # customer friction cost
                 + R_missing_filing(action set)         # regulatory cost of not filing when required
                 + λ · O(action set)                    # operational cost
```

Friction weights come from the policy's own "Customer impact" column (None / Low / High / Very high). This is why the system recommends `MONITOR_CARD` over `BLOCK_CARD` at p = 0.4 — not because a rule says so, but because the arithmetic does, *and* R1 agrees. The rule number is still cited, because policy §7 requires it.

### 9.9 Stopping: value of information

Policy §6 gives three stop conditions. Implement the third — "further steps are unlikely to change the decision" — as a decision-theoretic test rather than a threshold:

```
for each candidate evidence request r:
    for each plausible response s (deny / confirm / no-reply):
        p' = bayes_update(p, LR(s))
        A' = policy_engine(case | p', evidence + s)
        flip(r) = Σ_s P(s) · 1[A' ≠ A]
VOI(r) = flip(r) · |Δ expected cost|  −  cost(request r)

request r* = argmax VOI   if max VOI > 0
stop          otherwise
```

If no plausible response can change the action set, **the agent stops and says so.** This satisfies §6 measurably, produces a genuinely informative `stop_reason`, and prevents the most common agentic failure mode in this task: asking the customer a question whose answer changes nothing.

Hard stops (checked first): p ≥ 0.85 **or** p ≤ 0.15 with ≥ 2 independent evidence items; or a verification response settles the question.

### 9.10 Agent state machine

LangGraph, deterministic skeleton, **two LLM nodes** (FR-11 hypothesis generation, FR-21 explanation). Everything else is code.

```
 intake ─▶ as_of_bind ─▶ episode_construct ─▶ hypothesize(LLM)
                                                     │
                          ┌──────────────────────────┘
                          ▼
              gather_evidence ◀──┐  (MCP: run_installed_query ×N)
                          │      │   budget-capped: ≤30 calls, ≤60 s
                          ▼      │
                   recall_memory │  (MCP: search_top_k_similarity + graph expand)
                          │      │
                          ▼      │
                       assess    │  posterior · pattern · sensitivity
                          │      │
                          ▼      │
                  stop_or_continue ── need more ──▶ request_evidence
                          │                              │
                          │                              ▼
                          │                        reassess ──────┘
                          ▼
                  policy_resolve ─▶ rank_actions (cost model)
                          │
                          ▼
                   case_writeback (MCP: add_nodes / add_edges)
                          │
                          ▼
                     explain(LLM) ─▶ validate ─▶ emit cases/HHG-0NN.json
                                        │
                                        └── fail ─▶ repair once ─▶ fail loudly
```

**Controls:** tool-call and token budgets; wall-clock cap; idempotent case IDs; full trace to `traces/<case_id>.json`; `--no-llm` fallback path with template prose so the pipeline never hard-depends on an API.

**Permissions:** the agent's MCP client is configured with a **read + append-only** tool profile for the investigation phase. `add_nodes`/`add_edges` are available; `drop_*`, `clear_graph_data`, `delete_*` are not exposed at all. Demonstrable in the demo: try to make the agent delete a case, watch the tool not exist.

### 9.11 Case memory

Memory is a **graph**, not a vector store with a case log bolted on. When a case closes:

1. `InvestigationCase` vertex: verdict, probability, pattern, exposure, `emb` (narrative), `fp` (behavioural fingerprint).
2. `CASE_TXN` / `CASE_CARD` / `CASE_DEVICE` / `CASE_REGION` / `CASE_PATTERN` edges to everything it touched.
3. `CASE_CITES` edges to the closed cases and doc chunks it relied on.
4. `CaseEvent` vertices in sequence — the append-only audit log.

Retrieval for the next case: `similar_agent_cases(vec, k)` seeds on the fingerprint, then expands one hop — *"what else touched the device this case named?"* That question is unanswerable with vectors alone, and it is what makes case 20 smarter than case 1. It is also what the brief means by "Identify recurring fraud patterns, entities, and relationships across cases."

**Order matters:** run the 20 cases in `case_pack` order and each subsequent case can cite earlier ones. Run them in a shuffled order and the memory effect disappears. Run them in pack order, and note it in the blog.

### 9.12 Guardrails

| Guardrail | Enforcement |
|---|---|
| **No invented IDs** | Validator rejects any ID not present in the dataset. Made-up IDs score zero. |
| **No uncited claims** | Every `summary` sentence and every SAR claim maps to an evidence object; the LLM prompt is given the evidence list and forbidden new IDs. |
| **No LLM-written actions** | `next_best_actions` is written only by the policy engine. |
| **No future information** | `as_of` is a required parameter of every GSQL query. |
| **No fabricated customer replies** | Simulated responses come from a fixed, disclosed policy — never tuned to reach a preferred verdict. Recorded in `evidence_requests.assumed_response`. |
| **No destruction** | Write-only MCP tool profile. No drop/delete/clear tools exposed. |
| **No runaway** | Budgets on tool calls, tokens, wall clock. |

---

## 10. User interface — the Anvesh Analyst Workstation

FastAPI backend + React (Vite, TypeScript) SPA. Streamlit is the fallback if time collapses (§12 cut list).

| Screen | Shows | Earns |
|---|---|---|
| **1. Case queue** | 20 cases: trigger type, risk score, status, verdict, probability, exposure | Demo entry point |
| **2. Investigation timeline** | Every agent step: node, tool call, arguments, result digest, conclusion | Agentic design (15%) |
| **3. Evidence board** | Claims grouped by hypothesis, each with source chip (`graph`/`document`/`customer`/`external`), `ref`, and entity chips | Explainability (10%) |
| **4. Graph explorer** | The episode subgraph — customer → cards → transactions → device/region/email. Affected set highlighted; ring components in a distinct colour | TigerGraph depth, Innovation |
| **5. Uncertainty panel** | Prior → posterior gauge; per-evidence log-LR waterfall; confidence band; **"what would change my mind"** | Next best action (25%) |
| **6. Action panel** | `initial` vs `final` side by side, routes, rule citations, expected-cost comparison, **Approve (L1/L2)** buttons | Next best action, permissions |
| **7. Case file & SAR** | Rendered answer JSON + SAR narrative with a completeness checklist (who/what/when/where/how/why) | Explainability |
| **8. Memory** | Similar prior cases retrieved + this case's contribution to memory | Case memory requirement |
| **9. Policy trace** | Which rules fired, on what predicate, in what order | Explainability, controls |

Screen 6 carries the human-in-the-loop requirement: clicking **Approve** records the approval against the action and executes it in the simulator. The agent recommends; a human disposes. That is the demo's closing beat.

---

## 11. Deliverables and submission checklist

Submission form: `https://forms.gle/yxXzqSULGgZ9VUF56` — one per team, by the team lead, by **24 Sept 2026 23:59 IST**. No resubmissions.

| # | Deliverable | Owner | Gate |
|---|---|---|---|
| D1 | Working agent (`anvesh run --case HHG-001`, `anvesh run --all`) | Eng | NFR-3/4/10 |
| D2 | Public GitHub repo, clean tree, README with run instructions | Eng | — |
| D3 | `cases/HHG-001.json` … `HHG-020.json` — 20 files | Eng | NFR-3 |
| D4 | Every case written to the graph (`written_to_graph`, `graph_case_id`) | Eng | NFR-12 |
| D5 | SAR included wherever policy requires; `sar.file` ⟺ `FILE_REPORT` | Eng | NFR-6 |
| D6 | `initial` **and** `final` action sets with routes, plus `what_changed` | Eng | — |
| D7 | 3–5 minute demo video | Demo | All 11 success criteria visible |
| D8 | Technical blog post | Writing | §11.1 |
| D9 | X or LinkedIn post tagging **@TigerGraphDB**, linking blog or demo | Writing | — |
| D10 | Optional: `monitor/` folder with autonomous investigations | Eng | Innovation |

### 11.1 Blog post outline (required by the brief)

1. What we built — one paragraph, one sentence of thesis.
2. The architecture — the four-layer diagram from §9.1 and *why the LLM is not allowed to choose actions*.
3. How TigerGraph is used — schema, the 18 installed queries, the ring algorithm, TigerVector, MCP as the only path to the graph, case write-back.
4. The agentic capabilities — hypothesis-driven evidence gathering, VOI stopping, graph memory, permissioned tools.
5. **The numbers** — held-out backtest: accuracy, Brier score, reliability diagram, calibration before/after. *This is the section nobody else will have.*
6. What we learned — what surprised us about the risk score, the device-identity gap, the in-person channel hole.
7. What we would improve with more time — honest, specific, three items.

### 11.2 Demo video storyboard (4 minutes)

| Time | Beat |
|---|---|
| 0:00 | An alert fires. Real-time model scored txn 3506725 at 0.90. Watch. |
| 0:20 | Agent binds `as_of`, builds the episode, forms three hypotheses |
| 0:50 | Evidence streams in from the graph — device, region, velocity, ring sweep |
| 1:20 | Uncertainty panel: prior 0.31 → posterior 0.44. "Not enough. What would change my mind?" |
| 1:45 | VOI says: ask the customer. Request issued, response simulated and disclosed |
| 2:10 | Customer denies. Posterior → 0.91. **Actions change on screen**, with routes and rule citations |
| 2:40 | SAR generated; ring found; connected cards monitored |
| 3:10 | Case written to the graph. Memory view: run case 12, watch it cite case 3 |
| 3:35 | Human approves the L1 block. Agent could not execute it alone. |

---

## 12. Build plan and cut list

### 12.1 Assumed position

I do not know how far you have got. The plan is therefore written as **gates, not days** — find the last gate you have passed, and read forward. If you are starting from zero with under 24 hours, go straight to §12.3.

### 12.2 Gate sequence

| Gate | Content | Exit test |
|---|---|---|
| **G0 — Graph up** | Savanna or CE running; schema created; `transactions.csv` + `identity.csv` loaded; `NEXT` edges built; `closed_cases_history.csv` loaded | `get_vertex_count` ≈ 800k; Q1 returns a real transaction |
| **G1 — MCP green** | `tigergraph-mcp` over stdio; agent can call `run_installed_query`; tool-call logging on | Agent answers "what device made txn X?" via MCP only |
| **G2 — Queries installed** | Q1–Q12, Q16–Q18 installed and unit-tested, all `as_of`-bounded | Correct results on 5 hand-checked transactions |
| **G3 — Investigate one case by hand** | **Do this before writing agent code.** Pick HHG-002. Look up history, device, region, closed cases. Decide what *you* would do. | A hand-written `HHG-002.json` |
| **G4 — Episode + detectors** | `episode_expand`, testing/burst/recurring/geo-velocity detectors, cardholder baseline | Episode boundary sane on 5 closed cases you check manually |
| **G5 — Scorer + calibration** | Feature vectors over all 5,565 closed cases; train/held-out split; fitted scorer; isotonic calibration; **backtest report** | NFR-1 Brier ≤ 0.15 on held-out |
| **G6 — Policy engine** | R1–R10, routing table, cost model; scenario test suite | 100% pass on the R1–R10 scenario suite |
| **G7 — Orchestrator** | LangGraph skeleton, hypothesis node, VOI stopping, evidence simulation, reassessment | End-to-end run on 3 cases with a trace |
| **G8 — Memory + GraphRAG** | Doc corpus embedded; `prior_cases` / `similar_agent_cases`; case write-back; `CASE_CITES` | Case 12 cites case 3 |
| **G9 — Validator** | Schema, ID existence, policy consistency, arithmetic | 20/20 clean |
| **G10 — All 20 cases** | Run in pack order; human review of every file; fix | 20 valid files, all IDs real |
| **G11 — UI** | Screens 1–9 | Analyst can follow a case unaided |
| **G12 — Package** | Blog, demo video, social post, README, form | Submitted before 23:59 IST |

### 12.3 Cut list (MoSCoW) — if you have hours, not days

**Must have — ship nothing without these:**

- Graph loaded; MCP as the only path to it (required by the brief — without MCP you fail a required component)
- Q1–Q12, Q16, Q17 installed and `as_of`-bounded
- The five pattern detectors
- Policy engine with R1–R10 and the routing table — **this is 25% of the score and it is pure deterministic code; it is the highest value-per-hour item in the whole build**
- Orchestrator producing the two-stage action (`initial` → `final`) with `what_changed`
- All 20 answer files, validated
- SARs where policy requires
- Case write-back to the graph
- A UI of some kind (Streamlit is acceptable under time pressure)
- Demo video, blog, social post

**Should have:**

- Calibrated scorer + backtest report (G5) — worth 25% indirectly and it is the blog's best section
- Ring detection (Q9 + `SHARES_*`)
- GraphRAG document retrieval
- Expected-cost ranking
- Graph explorer screen

**Could have:**

- Undocumented-pattern residual scan (I5)
- `DeviceSignature` fuzzy tier
- Uncertainty waterfall visualisation
- Autonomous `monitor/` sweep (FR-24)

**Won't have (cut first, explicitly):**

- Runtime GSQL generation, React SPA, counterfactual exposure (Q18), multi-agent debate, any fine-tuning, real integrations.

### 12.4 Hard scheduling notes

- **Savanna auto-stop/auto-start must be enabled** (the brief asks explicitly). Nothing kills a demo like a stopped workspace.
- The graph build is the long pole — 590k transactions plus 144k identity rows plus materialised `SHARES_*` edges. Start it first, in the background, and build code against a 20k-row sample while it runs.
- **Do G3 (investigate one case by hand) before writing agent code.** The dataset README insists on it; skipping it is how agents get built that answer questions nobody asked.

---

## 13. Risks and mitigations

| # | Risk | Impact | Mitigation |
|---|---|---|---|
| R1 | **Identity gap** — `identity.csv` is online-only; in-person txns have no device | Detectors fire spuriously on product code W | Branch every detector on `channel`. Assert in tests that no device claim is made for an in-person transaction. |
| R2 | **Prior inversion** — trusting `risk_score` leads to over-blocking | Catastrophic: half the cases are legitimate; over-blocking is a policy breach | Learn the prior from closed cases. Encode the README's warning (most > 0.7 are legitimate) as an explicit prior, not a hope. |
| R3 | **Temporal leakage** — queries without `as_of` see future transactions | Invalid backtest, indefensible cases, potential invalidation | `as_of` is a required parameter of every query. Test: run Q1–Q18 with `as_of` = 1 Jul and assert empty results. |
| R4 | **Graph build is slow or fails** | Blocks everything | Chunked REST loading; sample-first development; CE locally as a fallback to Savanna. |
| R5 | **MCP auth/token expiry mid-run** | Partial runs, corrupt answer files | Fresh token per run; per-case idempotency; retry with backoff; never write an answer file for a case that did not complete. |
| R6 | **LLM invents IDs or actions** | Made-up IDs score zero; illegal actions | Validator is a hard gate; evidence-constrained generation; policy engine owns actions. |
| R7 | **Calibration overfits 5,565 labels** | Confidently wrong probabilities | Held-out split, regularised models, isotonic calibration on a *separate* slice, report both. |
| R8 | **Simulated customer replies become a hidden tuning knob** | Dishonest, and fragile under scrutiny | Fixed, disclosed, order-independent response policy. Never chosen to reach a preferred verdict. |
| R9 | **Undocumented-pattern detector cries wolf** | R9 misfires, wrong SARs | Require ≥ 3 clustered episodes plus sustained elevation plus prototype-similarity below threshold. Default off if unvalidated. |
| R10 | **Time** | Everything | §12.3 cut list. Policy engine and MCP before anything clever. |
| R11 | **Disqualification risk** | Total | Never touch the public Kaggle/IEEE-CIS files. Every ID must exist in the provided dataset. |

---

## 14. Open decisions and assumptions

I made these calls. Each is cheap to reverse — correct any of them and I will re-cut §12.

| # | Decision | Chosen | Alternative |
|---|---|---|---|
| A1 | **Team size / roles** | Assumed 2–3 builders: graph+backend, agent+policy, UI+content | If solo, cut to the Must list and use Streamlit |
| A2 | **Deployment** | TigerGraph **Savanna** (free tier, auto-stop/auto-start on) | Community Edition locally if Savanna is flaky |
| A3 | **Orchestration** | **LangGraph** (TigerGraph's own docs recommend it for MCP) | Custom state machine — fewer deps, more code |
| A4 | **LLM** | Gemini 2.5 Flash or GPT-4o-mini class; temp 0; structured outputs | Any; the architecture does not depend on it |
| A5 | **Embeddings** | Local sentence-transformers (no API cost, no rate limits) | Gemini/OpenAI embeddings |
| A6 | **UI** | React + Vite + TS, FastAPI backend | Streamlit under time pressure |
| A7 | **Case ordering** | Run the 20 in `case_pack` order so memory accumulates | Shuffled (honest, but loses the memory demo) |
| A8 | **Fusion weight α** | Fitted on held-out closed cases | If p_llm is unstable, set α = 1 and say so in the blog |
| A9 | **Repo name** | `anvesh` | Keep `hackerhousegoaTigerGraph` for discoverability |
| A10 | **Autonomous monitor (FR-24)** | P2 — Innovation only, build last | — |

---

## Appendix A — Answer-schema contract

Top level: `case_id`, `case`, `evidence_requests[]`, `next_best_actions`, `sar`, `stop_reason`, `tool_calls`, `tokens`, `latency_s`.

**`case`:** `status` (`open`|`closed_fraud`|`closed_legitimate`|`escalated`), `verdict` (`fraud`|`legitimate`|`uncertain`), `fraud_probability` (0–1), `pattern` (`card_testing`|`card_not_present_fraud`|`card_not_present_new_device`|`out_of_region_use`|`account_takeover`|`undocumented`|`none`), `pattern_description` (required iff `undocumented`), `affected_txn_ids[]`, `first_suspicious_txn_id`, `connected_card_ids[]`, `connected_device_profiles[]`, `exposure_usd`, `evidence[]` (`claim`,`source`,`ref`,`entity_ids`), `similar_prior_cases[]`, `summary` (2–6 sentences), `written_to_graph` (bool), `graph_case_id`.

**`sar`:** `file` (bool), `reason` (cite the rule), `narrative` (6–12 sentences: who/what/when/where/how/why), `subjects[]`, `total_amount_usd`, `activity_dates` (2 dates).

**`next_best_actions`:** `initial[]` and `final[]`, each `{action, route, reason}`; plus `what_changed`.

**`evidence_requests[]`:** `{type, asked_after_step, assumed_response}`.

Consistency invariants: legitimate ⇒ empty `affected_txn_ids`, `exposure_usd` = 0, `sar` zeroed. `file` = false ⇒ empty narrative, empty subjects, 0 amount, empty dates. `exposure_usd` = Σ|amount| over `affected_txn_ids`.

## Appendix B — Rule-to-scenario test matrix

Build one synthetic case state per rule (and per boundary) and assert the emitted action set and route. This is the cheapest 25% in the entire rubric — it is deterministic code with no graph dependency.

| Scenario | Expected |
|---|---|
| p = 0.45, single signal | R1 → `VERIFY_WITH_CUSTOMER` / `STEP_UP_AUTH`, no block |
| Customer denies, exposure $900, no shared device | R2 → `BLOCK_CARD`(L1), `CREATE_CASE`, **no** SAR |
| Customer denies, exposure $1,200 | R2 → + `FILE_REPORT`(L2) |
| Customer denies, exposure $800, shared device | R2 → + `FILE_REPORT`(L2) |
| Customer confirms | R3 → `CLOSE_NO_FRAUD` |
| No reply 24 h, exposure $300 | R4 → `MONITOR_CARD`, `DECLINE_TRANSACTION`(L1) |
| No reply 24 h, exposure $900 | R4 → + escalate |
| Testing sequence, no cleared purchase | R5 → `DECLINE_TRANSACTION`(L1), `STEP_UP_AUTH` |
| Testing sequence, $150 cleared | R5 → `BLOCK_CARD`(L1) |
| Shared device across 4 cards | R6 → `CREATE_CASE`, `FILE_REPORT`(L2), `MONITOR_CONNECTED_CARDS` |
| Disputed charge matching monthly recurring | R7 → `CREATE_CASE`, `VERIFY_WITH_CUSTOMER`, `WARN_CUSTOMER`, **no block** |
| Verdict uncertain, exposure $700 | R8 → `ESCALATE_TO_ANALYST` |
| Undocumented coordinated activity | R9 → `CREATE_CASE`, `FILE_REPORT`(L2), `ESCALATE_TO_ANALYST` + description |
| One card confirmed fraud | **No** `BLOCK_ALL_CARDS` |
| Two cards confirmed fraud | `BLOCK_ALL_CARDS`(L2) permitted |
| Block, exposure $2,500 | `BLOCK_CARD` route **L1** |
| Block, exposure $2,500.01 | `BLOCK_CARD` route **L2** |

## Appendix C — Backtest protocol

1. Split the 5,565 closed cases 80/20, **stratified** on outcome and pattern.
2. For every case, reconstruct the trigger: `flagged_txn_id = first_fraud_txn_id` (for confirmed) or the first txn in `txn_ids` (for cleared); `opened_at = opened_at`; `as_of = opened_at`.
3. Run the full agent.
4. Score: verdict accuracy, episode IoU against `txn_ids`, Brier score on `fraud_probability`, reliability by decile, policy-legality rate.
5. **Tune only on the 80%.** Report only on the 20%.
6. Publish the numbers in the blog and the README.

This is the difference between "we think it works" and "here is the number". It costs one extra day of build and it is the most credible artefact in the submission.

## Appendix D — The 20 cases

Triggers and amounts, with the mechanical thing each one demands. **These are pointers, not conclusions.**

| Case | Trigger | Flagged txn | Card | Score | Amount | Look for |
|---|---|---|---|---|---|---|
| HHG-001 | risk_score | 3514030 | C12382-K1 | 0.61 | $77.07 | in-person, region 444 → out-of-region / geo-velocity |
| HHG-002 | risk_score | 3478782 | C11891-K1 | 0.79 | $292.36 | online → device novelty, burst, baseline z |
| HHG-003 | customer_report | 3530164 | C08623-K2 | — | $49.00 | report → R2/R3/R7 fork; check recurring |
| HHG-004 | customer_report | 3583227 | C08106-K1 | — | $128.33 | report; K1 (first card) |
| HHG-005 | risk_score | 3523199 | C02923-K1 | 0.54 | $100.07 | online; $100 is an R5 boundary — check for a testing sequence |
| HHG-006 | customer_report | 3476682 | C07297-K1 | — | $482.12 | report; exposure near the $500 R8/R4 boundary |
| HHG-007 | risk_score | 3514948 | C09933-K2 | 0.87 | $111.92 | in-person, region 264 → out-of-region |
| HHG-008 | customer_report | 3558054 | C13171-K2 | — | $55.68 | report on K2 — check the customer's other card |
| HHG-009 | customer_report | 3581141 | C08299-K1 | — | $30.02 | report, small; R7 recurring check |
| HHG-010 | risk_score | 3506725 | C10434-K1 | 0.90 | $1,000.03 | online; **$1,000 is the SAR threshold** — case-vs-report decision is the test |
| HHG-011 | customer_report | 3583368 | C11923-K2 | — | $131.30 | report |
| HHG-012 | risk_score | 3553342 | C05876-K2 | 0.55 | $30.91 | in-person, region 494 → out-of-region |
| HHG-013 | risk_score | 3526826 | C07671-K2 | 0.76 | $35.66 | online, small → possible testing precursor |
| HHG-014 | **analyst_request** | 3478561 | C13487-K1 | — | — | **the ring case.** Shared device profile across several cards → Q9 ring sweep, R6 |
| HHG-015 | risk_score | 3464869 | C03042-K1 | 0.77 | $599.94 | online; large → CNP + device |
| HHG-016 | customer_report | 3534820 | C09988-K1 | — | $59.67 | report |
| HHG-017 | risk_score | 3450629 | C04570-K1 | 0.57 | $100.09 | online; $100 R5 boundary |
| HHG-018 | customer_report | 3491361 | C02354-K2 | — | $39.08 | report |
| HHG-019 | risk_score | 3503878 | C07987-K2 | 0.90 | $99.92 | online; $99.92 just under $100 → R5 boundary discipline |
| HHG-020 | risk_score | 3509359 | C12265-K2 | 0.52 | $125.08 | online, mid score |

Boundary discipline matters more than it looks: HHG-005, HHG-017 and HHG-019 sit within cents of the $100 R5 threshold, HHG-006 sits near the $500 R8/R4 boundary, and HHG-010 sits on the $1,000 SAR threshold. These are almost certainly deliberate.

---

*End of PRD v1.0.*
