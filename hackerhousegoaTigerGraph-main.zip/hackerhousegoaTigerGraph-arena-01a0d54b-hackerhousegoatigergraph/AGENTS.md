# AGENTS.md

Rules for any coding agent (Claude Code, Cursor, Codex, Copilot, or a human) working in this repository.

**Read this file completely before writing or generating any code.**

---

## 1. What this is

`Anvesh` — an agentic fraud-investigation system built on TigerGraph, for the Hacker House Goa 2026 TigerGraph Partner Trial.

It takes one of 20 fraud alerts (`HHG-001` … `HHG-020`), investigates it against a graph of 590,742 card transactions, and emits a JSON answer file containing a case record, an optional SAR, and a next-best-action set with approval routes.

**Deadline: 24 Sept 2026, 23:59 IST. Single submission. No resubmissions.**

---

## 2. Read these first

| File | What it governs |
|---|---|
| [`PRD.md`](./PRD.md) | Why, what, architecture, success metrics |
| [`ROADMAP.md`](./ROADMAP.md) | Schedule, workstreams, freezes, kill criteria |
| [`docs/ARCHITECTURE.md`](./docs/ARCHITECTURE.md) | Module layout, interfaces, data flow |
| [`docs/STATE.md`](./docs/STATE.md) | The investigation state machine and node contracts |
| [`docs/GRAPH_SCHEMA.md`](./docs/GRAPH_SCHEMA.md) | TigerGraph schema, loading, cardinalities |
| [`docs/QUERIES.md`](./docs/QUERIES.md) | The GSQL query catalogue |
| [`docs/POLICY.md`](./docs/POLICY.md) | **The policy engine — 25% of the score. Read before touching decisions.** |
| [`docs/ANSWER_SCHEMA.md`](./docs/ANSWER_SCHEMA.md) | Answer-file contract + the 15 validator checks |
| [`docs/UNCERTAINTY.md`](./docs/UNCERTAINTY.md) | The probability model and the prior correction |
| [`docs/BACKTEST.md`](./docs/BACKTEST.md) | How we measure ourselves honestly |
| [`docs/UI.md`](./docs/UI.md) | Analyst workstation and trace replay |
| [`docs/CONTENT.md`](./docs/CONTENT.md) | Blog, demo, social |
| [`docs/SETUP.md`](./docs/SETUP.md) | Environment and commands |

Build order is **not** the file order. See §6.

---

## 3. Non-negotiable rules

Each rule has a reason and a check. **If you are about to break one, stop and ask.**

### R1 — The LLM never writes actions

`next_best_actions` is written **only** by `src/anvesh/policy/engine.py`.

The LLM may propose probabilities, patterns, hypotheses and prose. It may not emit an action or an approval route.

- *Why:* 25% of the score is policy-legal, correctly-routed actions. An LLM route is unverifiable.
- *Check:* `grep -r "next_best_actions" src/` returns exactly one writer, in `policy/engine.py`.

### R2 — Every graph read is `as_of`-bounded

Every GSQL query takes `as_of DATETIME` as its **first** parameter. A transaction is visible to a query iff `txn.ts <= as_of`.

- *Why:* The agent must not see the future. Without this, cases are indefensible and the backtest leaks.
- *Check:* `tests/test_graph_queries.py::test_no_future_leakage` — run every query with `as_of = 2016-07-01` and assert empty results.

### R3 — No invented IDs

Every transaction, card, customer, device and case ID in an answer file **must exist in the provided dataset**. Fabricated IDs score zero.

- *Why:* The dataset README is explicit.
- *Check:* validator check #2. Hard fail, no repair loop.

### R4 — Generate IDs, never compose them

IDs come from query results, never from string formatting, inference or pattern-matching.

- *Why:* The single most likely silent failure of agent-generated code. A composed ID looks perfect and scores zero.
- *Check:* validator check #2 plus eyeball any `f-string` that builds an ID.

### R5 — `channel` guards every device claim

`identity.csv` covers **online transactions only**. `ProductCD = W` ⇒ `channel = in_person` ⇒ **no device record exists**.

- *Why:* Every detector will otherwise fire spuriously on in-person transactions.
- *Check:* `tests/test_detectors.py::test_no_device_claim_for_in_person` — assert no `FROM_DEVICE` evidence is ever produced for an in-person transaction.

### R6 — Exact comparison operators

Copy the operator table from [`docs/POLICY.md` §3](./docs/POLICY.md). `>` vs `>=` is never a judgement call.

Every threshold comparison carries an inline comment quoting the policy line:

```python
if exposure > 1000:      # R2 / §3a: "exposure exceeds $1,000"
```

- *Why:* At $2,500 the operator decides L1 vs L2. At $1,000 it decides whether a SAR exists.

### R7 — Test before implementation

Write the failing pytest case **first**, then the code. No exceptions for detectors, rules or queries.

- *Why:* Generation is cheap; verification is the bottleneck. The test is the specification.

### R8 — One writer per artifact

Each output file has exactly one module that writes it. Never two code paths to the same artifact.

- *Why:* Duplicated writers drift apart and the answer files diverge from the traces.

### R9 — No silent fallbacks

If a query, tool call or LLM call fails, **record it in `state["errors"]` and let the node decide.** No bare `except: pass`, no default values standing in for missing evidence.

- *Why:* A silent fallback produces a confident answer resting on nothing.

### R10 — Never touch the public IEEE-CIS / Kaggle files

IDs, times and amounts in the provided dataset were transformed. Using the public files to recover outcomes is **disqualification**.

### R11 — Never merge a Pull Request without explicit instruction

Never merge any Pull Request (via `gh pr merge`, git merge, or GitHub API) unless the user explicitly and directly instructs you to do so. Coding agents may create PRs, update PRs, run checks, and review diffs, but MUST NEVER merge them autonomously under any circumstances.

- *Why:* Human-in-the-loop control over the main branch and submission artifacts.
- *Check:* No automated `gh pr merge` calls in any script or agent workflow.

---

## 4. Workflow rules

1. **Commit per workstream, not per file.** `feat(policy): R1-R10 + scenario suite`.
2. **Run the validator before you report a workstream done.** `anvesh validate`.
3. **Keep `data/` out of git.** It is 708 MB. See `.gitignore`.
4. **Prompts live in `src/anvesh/agent/prompts/*.md`**, versioned, never inline in Python.
5. **No workstream may edit another workstream's spec.** If `docs/POLICY.md` is wrong, say so — do not quietly code around it.
6. **Log every tool call** to the trace. The demo and the UI depend on it.
7. **When unsure, prefer the deterministic path.** A rule-based answer with thin evidence beats an LLM-generated answer with imagined evidence.

---

## 5. Definition of done

A workstream is done when all of these hold:

- [ ] Its pytest suite passes
- [ ] Its module has no `# TODO` that affects correctness
- [ ] It writes to `state` only the keys listed in [`docs/STATE.md`](./docs/STATE.md)
- [ ] Every ID it emits is validated against the dataset
- [ ] It honours the tool-call and wall-clock budgets
- [ ] `anvesh validate` is green on any answer files it produced
- [ ] Its behaviour is described in the relevant `docs/*.md` (update the doc if the code diverged)

---

## 6. Build order

From [`ROADMAP.md` Part 2](./ROADMAP.md) — ranked by points per hour, not by dependency intuition.

| # | Workstream | Needs | Blocking? |
|---|---|---|---|
| 1 | **W2 Policy engine** (`docs/POLICY.md`) | **Nothing** | **Yes** — everything calls into it |
| 2 | W1 Graph + MCP (`docs/GRAPH_SCHEMA.md`) | Dataset, Savanna | Yes — but start the download first and build W2 while it loads |
| 3 | W3 Core GSQL (`docs/QUERIES.md`, Q1–Q4, Q7, Q10, Q12, Q17) | W1 | Yes |
| 4 | W4 Detectors + episode segmentation | W3 | Yes |
| 5 | W5 Orchestrator + trace + replay (`docs/STATE.md`) | W2, W3 | Yes |
| 6 | **W7 Validator** (`docs/ANSWER_SCHEMA.md`) | Nothing | **Yes** — gates the freeze |
| 7 | W6 Uncertainty (`docs/UNCERTAINTY.md`) | W4 | No |
| 8 | W8 Memory + GraphRAG | W1 | No |
| 9 | W9 UI (`docs/UI.md`) | Frozen traces | No |
| 10 | W10/W11 Demo + content (`docs/CONTENT.md`) | Frozen artifacts | No |
| 11 | W12 Innovation extras | Everything else | No |

**W2 needs no graph, no dataset and no LLM. Build it first.**

---

## 7. Anti-patterns

| Don't | Why |
|---|---|
| Let the LLM pick the action | Rule R1; also makes the decision unauditable |
| Put policy rules in a prompt | Rules must be testable, not sampled |
| Return raw graph rows to the LLM | The brief explicitly warns against it; build an evidence brief |
| Write one big `investigate()` function | The state machine is the "agentic design" evidence |
| Skip `as_of` "just for this one query" | That is exactly how leakage enters |
| Tune the simulated customer response to reach a verdict | Dishonest and fragile; the response policy is fixed and disclosed |
| Optimise a single case's answer file before all 20 exist | Completeness beats optimality; missing fields score zero |
| Build W12 before F1 freeze | Innovation is 15%; missing files are 100% of that part |

---

## 8. If you get stuck

State the blocker, name the workstream, and propose the **deterministic fallback** from [`ROADMAP.md` Part 7](./ROADMAP.md) kill criteria. Do not silently degrade.
