# Anvesh — Roadmap & Implementation Plan
### Grilled, re-cut, and scheduled for the HH Goa 2026 TigerGraph Partner Trial

| | |
|---|---|
| **Companion to** | [`PRD.md`](./PRD.md) — architecture and requirements |
| **Deadline** | **24 Sept 2026, 23:59 IST** — single submission, no resubmissions |
| **Status** | Post-grill re-cut. Read Part 1 before writing a line of code. |

---

## Part 0 — What the grill changed

I pressure-tested the PRD against the deadline, the dataset, the platform, and the rubric. Thirteen findings. Six changed the plan materially:

| # | Finding | Consequence |
|---|---|---|
| **G1** | The PRD describes a 10–14 day build. You have roughly **36 hours**. | Plan re-cut to a Minimum Viable Shortlist; full build retained as a stretch track |
| **G2** | The answer format says **"Missing fields score zero for that part."** | **Completeness beats optimality.** 20 complete files before any file is improved |
| **G3** | My calibrated-posterior design has a **selection-bias bug** — and part of it is **not computable** from the data | Prior is now an explicit assumption; closed cases give likelihood ratios only; added a one-line prior correction |
| **G4** | My backtest protocol **leaks** — it hands the agent `first_fraud_txn_id` | Backtest re-specified |
| **G5** | I proposed hand-writing label propagation. **TigerGraph ships the GDS library.** | Use `tg_wcc` / `tg_label_prop`. Hours saved, more defensible |
| **G6** | **Savanna free tier enforces auto-stop and you cannot turn it off.** | Nothing at the deadline may depend on a live database |

Full grill in Part 1. Revised plan starts at Part 2.

---

## Part 1 — The grill

### G1 — "You wrote a two-week plan for a two-day problem."

**Challenge.** The PRD has 13 gates (G0–G12): load 590,742 transactions plus 144,432 identity rows, materialise `SHARES_*` projections, install 18 GSQL queries, engineer features over 5,565 closed cases, fit and calibrate a model, build a LangGraph orchestrator, build a 9-screen React app, produce 20 reviewed answer files, a 4-minute demo, a blog post and a social post. Against a deadline roughly 36 hours out, with no code written and a 708 MB dataset possibly not yet downloaded, that is not a plan — it is a wish list.

**Verdict. Correct. The PRD plan is not executable as written.** The PRD is still the right *architecture*; it is the wrong *schedule*.

**Fix.** Two tracks. **Track A** (Part 5) is the honest 36-hour schedule built around a Minimum Viable Shortlist. **Track B** is the full PRD build, retained for the case where the deadline is softer than I have assumed. Every workstream is now costed in points-per-hour (Part 2) and ranked, so cuts are made by arithmetic rather than panic.

---

### G2 — "You're optimising files nobody will read twice while others sit empty."

**Challenge.** The dataset README states flatly: *"Same structure for every case. Missing fields score zero for that part."* And *"IDs must be the ones in the dataset. Made-up IDs score zero."* A submission with 17 excellent answer files and 3 missing ones loses three entire parts. A submission with 20 competent files loses nothing structurally.

**Verdict. This is the single most important operational fact in the task and the PRD buried it in a table row.**

**Fix.** Promoted to Operating Principle #1. The schedule now has a hard gate at **T-16h: twenty answer files on disk, schema-valid, ID-valid.** Only after that gate does any quality work happen. If a case is not ready, ship the deterministic path — policy engine plus minimal graph evidence — rather than nothing. **A thin, policy-legal answer beats a missing file.**

---

### G3 — "Your calibrated posterior is built on a population that doesn't exist."

**Challenge.** Three separate problems:

1. **Covariate shift.** The 5,565 closed cases are cases the bank *already chose to open* — 4,665 confirmed, 900 cleared, an 84% fraud rate. The 20 benchmark cases are *alerts*, and the README says roughly half are legitimate. A model fitted on an 84%-fraud population and applied to a ~50%-fraud population will systematically over-predict fraud. The intercept is wrong by construction.
2. **Not computable as specified.** PRD §9.7 Step 2 says "base rate conditioned on trigger type × risk band, learned from the closed cases." **The closed-case file has no `trigger_type` column.** Its columns are `case_id, customer_id, card_id, opened_at, closed_at, outcome, pattern, first_fraud_txn_id, txn_ids, n_txns, exposure_usd, connected_card_ids, actions_taken, report_filed, analyst_notes`. That prior cannot be learned from that data. My PRD specified something impossible.
3. **Consequence.** `fraud_probability` drives R1 (verify below 0.70), the stop rule (0.85 / 0.15), the case-opening threshold (0.30) and the exposure thresholds. A systematically inflated probability makes the agent over-block — which the README calls a policy breach, not a false positive.

**Verdict. Real flaw. Highest-severity item in the grill.**

**Fix.** Split the problem in two, which is the statistically correct decomposition anyway:

- **Likelihood ratios are fine.** `P(feature | confirmed_fraud) / P(feature | cleared)` is a *within-population* ratio. Its **ordering** is valid even under selection on the outcome. Use the closed cases for this, and for episode segmentation labels, and for kNN similarity. All still work.
- **The prior is an explicit assumption, not a fitted quantity.** Set it from what we actually know about the alert population: the README's statement that most transactions scoring above 0.7 turn out legitimate, and that about half the 20 cases are legitimate. Suggested starting points, documented in the blog: `π₀ ≈ 0.40` for `risk_score` triggers above 0.7, `π₀ ≈ 0.50` for `customer_report` and `analyst_request`.
- **Apply the standard prior correction.** For a model trained under outcome-dependent (case-control-style) sampling, shift the intercept:

  ```
  logit(p_corrected) = logit(p_model)
                     + log(π_target / (1 − π_target))
                     − log(π_train  / (1 − π_train))
  ```

  One line of arithmetic, textbook-correct, and it converts an over-confident score into a defensible one.
- **Validate the ranking, not just the level.** Report AUC on held-out closed cases (valid) *and* Brier with the caveat that the level depends on the assumed `π_target` (honest).

This is a better answer than the PRD's, it is cheaper, and "we found and corrected a selection-bias problem in our own scoring model" is a strong blog section.

---

### G4 — "Your backtest hands the agent the answer."

**Challenge.** PRD Appendix C says: reconstruct each closed case's trigger as `first_fraud_txn_id` for confirmed cases, or the first transaction in `txn_ids` for cleared ones.

Two problems. First, **the constructs differ.** `first_fraud_txn_id` is the analyst's identified onset; "first txn in `txn_ids`" for a cleared case is just the earliest of a set that turned out benign. You are measuring two different tasks and averaging them. Second — and worse — **for confirmed cases you are handing the agent the exact transaction where the fraud began.** In the real task the flagged transaction is arbitrary: *"it is not necessarily where the fraud started, and it may not be fraud at all."* A backtest built on `first_fraud_txn_id` is strictly easier than the exam and will flatter the agent.

**Verdict. Contaminated. Would have produced a number I then put in a blog post.**

**Fix.** Re-specify:

- For confirmed cases, sample the trigger **uniformly at random from `txn_ids`**, not from the onset. This matches the real distribution.
- Report **two** numbers: onset-triggered (easy, upper bound) and random-triggered (honest, expected). The gap between them is itself an interesting finding.
- For cleared cases, use a transaction matched on risk-score band to the confirmed triggers, so the two arms are comparable.
- Tune only on the 80% split; report only on the 20%.

---

### G5 — "Why are you hand-writing label propagation?"

**Challenge.** PRD §9.5 Q9 proposes implementing WCC / label propagation over the `SHARES_*` projection, and §9.4 justifies materialising the projection to make it fast. But TigerGraph ships a **Graph Data Science library, included with the database**: `tg_wcc`, `tg_label_prop`, `tg_louvain`, `tg_pagerank`, `tg_fastRP`, `tg_closeness_cent`, `tg_betweenness_cent` and more. They install with `INSTALL QUERY tg_wcc` or auto-install through pyTigerGraph's `Featurizer.runAlgorithm()`. You are proposing to spend hours reimplementing a shipped, optimised, parallel algorithm.

**Verdict. Waste, and worse, a missed credibility beat.** A judge from TigerGraph will rate "we used the GDS library's connected-components algorithm on a device-sharing projection" higher than "we wrote our own label propagation."

**Fix.**

- Ring detection = build the projection → call `tg_wcc` (or `tg_label_prop` for fuzzy boundaries) → store components as `Cluster` vertices.
- Keep `SHARES_*` materialisation *only if* the full graph is loaded; on a subset graph, run the algorithm directly.
- Budget: **1 hour, not 4.** Target ~0.3 s per call.
- Stretch: `tg_pagerank` or `tg_fastRP` for "which entity is the hub of this ring" — cheap, and good demo material.

---

### G6 — "Savanna will stop itself and you cannot stop it stopping."

**Challenge.** TigerGraph's Savanna release notes: *"Enforce auto stop to free tier: Auto stop is enabled and cannot change for Free tier customers' workspaces."* Every plan that ends with "run the agent live for the judges" or "record the demo against the live graph" is betting on a workspace that is designed to go to sleep. Cold start plus token refresh plus a re-warm of a 590k-vertex graph is a 20-to-60-minute risk, arriving at the worst possible moment.

**Verdict. Structural. The PRD treats the database as if it were always on.**

**Fix. Four rules, all cheap:**

1. **Freeze answer JSONs to disk at T-16h.** After that, the submission never reads from TigerGraph.
2. **Demo from replay, not live** (see G11).
3. **Treat cold start as a scheduled event.** If you must re-run after T-12h, add 30 minutes to the estimate and warm the workspace *before* you need it.
4. **Keep a local escape hatch.** Community Edition in Docker, or — if that fails — a pandas/Parquet implementation of the same eight query semantics. You would still fail the "must use TigerGraph" requirement as a *submission*, but you would keep the *answer files* shippable. Do not confuse the two; the graph must be real, but the files must exist.

---

### G7 — "If the LLM can't choose actions, is this actually an agent?"

**Challenge.** The PRD's headline design rule is that the policy engine owns `next_best_actions` and the LLM only writes prose. But **Agentic design and engineering is 15% of the score** and rewards "tool use, workflow orchestration, memory, controls, permissions." A deterministic policy engine plus an LLM summariser reads, to a hostile judge, like a pipeline with a thesaurus.

**Verdict. Partly fair. The rule is right; the PRD doesn't adequately show the agency that remains.**

**Fix. The agency is in *tool selection*, and it must be unmistakable in the trace.**

- The **hypothesis node** is real: the LLM reads a cheap first-pass context packet and proposes 2–4 hypotheses; **each hypothesis selects which queries run next.** Different cases execute different tool sequences. That is agentic.
- The **budget** is real: the agent decides when it has spent enough.
- The **VOI gate** is real: the agent decides whether to ask.
- What the LLM genuinely cannot do is emit an action or a route. Say this out loud in the blog: **the policy engine constrains the output space; it does not remove the agent's discretion over what to look at.** That is exactly how a real fraud analyst is supervised.
- Instrument it: log the hypothesis set and the *queries not run* and why. "Considered ring sweep, rejected — device degree < 3" is the most agentic line in the whole trace.

---

### G8 — "Episode segmentation gets one line and it decides your routing."

**Challenge.** `affected_txn_ids` is scored. `exposure_usd` must equal the sum of their absolute amounts — and `exposure_usd` then decides: `BLOCK_CARD` routes L1 vs L2 at **$2,500**, whether a SAR is required at **$1,000**, whether R8 escalates at **$500**, and whether R5 blocks **above $100**. A segmentation error on one case can flip a route, omit a SAR, or trigger one that shouldn't be filed. PRD FR-10 gives this one sentence.

**Verdict. Under-specified relative to its blast radius.**

**Fix. Dedicated workstream (W4) with free labels:**

- **You already have ground truth for segmentation.** Every closed case carries `txn_ids` — the analyst's episode. That is 5,565 labelled episodes. Tune the segmentation threshold on IoU against them.
- Algorithm: seed (flagged txn + detector hits) → candidate generation (same card ±window, same device, same region anomaly, same email, `NEXT`-chain adjacency) → per-candidate score → boundary selection with an explicit sprawl penalty.
- **Hard cap at `as_of`.** No transaction after `opened_at` may enter the episode.
- **Route any case within 5% of a threshold to human review.** The cost of being wrong at $2,500 is a wrong approval route.

---

### G9 — "Those boundary cases you flagged — are they real, or are you seeing faces in clouds?"

**Challenge.** PRD Appendix D points out that HHG-010 is $1,000.03 (SAR threshold), HHG-005/017/019 sit near $100 (R5), and HHG-006 is $482.12 (near the $500 R4/R8 boundary). It calls these "almost certainly deliberate."

Maybe. But they are six months of real card transactions with amounts rounded to plausible retail values; $99.92 and $100.09 are what online purchases look like. Building a "boundary discipline" doctrine on a theory about the answer key is over-fitting to a guess — and if the theory is wrong, the doctrine still costs you the right answer on those cases.

**Verdict. Fair. The observation is useful; the inference was too strong.**

**Fix. Keep the cheap half, drop the speculative half.**

- **Do** implement `>` vs `≥` exactly as the policy words it. That is free, correct regardless of intent, and it is the kind of detail a grader notices.
- **Do** route near-threshold cases to human review at T-16h.
- **Do not** encode "the answer key is testing boundaries" as a system behaviour. Note it as an observation in the blog, not as a rule in the code.

Exact comparison semantics — code these literally:

| Condition | Operator | Source |
|---|---|---|
| Open a case | `p >= 0.30` | §3a "reaches 0.30" |
| R1 verify before block | `p < 0.70` | "below 0.70" |
| R2 / SAR exposure | `exposure > 1_000` | "exceeds $1,000" |
| R4 / R8 exposure | `exposure > 500` | "exceeds $500" |
| R5 block after cleared purchase | `purchase > 100` | "a purchase over $100" |
| Stop — high | `p >= 0.85` | "at or above 0.85" |
| Stop — low | `p <= 0.15` | "at or below 0.15" |
| `BLOCK_CARD` route L1 | `exposure <= 2_500` | "exposure ≤ $2,500" |
| `BLOCK_CARD` route L2 | `exposure > 2_500` | "exposure > $2,500" |

---

### G10 — "Eighteen GSQL queries, from a team that may never have written GSQL."

**Challenge.** The PRD's catalogue is 18 installed queries, plus a caution that runtime GSQL generation is a non-goal. If nobody on the team has written GSQL before, writing and installing 18 parameterised queries with accumulators and `as_of` filtering is not a six-hour task — it is a two-day task, and it sits on the critical path for everything else.

**Verdict. Wrong sequencing for an unknown skill level.**

**Fix.**

- **Eight core queries, not eighteen:** Q1 `txn_context`, Q2 `card_window`, Q3 `cardholder_baseline`, Q4 `device_neighbors`, Q7 `geo_velocity`, Q10 `testing_sequence`, Q12 `recurring_check`, Q17 `episode_expand`. Everything else is a stretch.
- **Escape hatch:** the MCP server exposes `tigergraph__run_query` (interpreted). Slower, no install step, still GSQL through MCP, still satisfies the requirement. Use it to unblock; install later if time allows.
- **Authoring aid:** MCP also exposes `tigergraph__generate_gsql` (with the `[llm]` extra). Use it offline to draft, never at agent runtime.
- **Skill check at T-33h.** If the first query takes more than 90 minutes, drop to 5 queries and lean on interpreted queries.

---

### G11 — "The demo is 10% and it's the only 10% that can be destroyed by a flaky run."

**Challenge.** The PRD schedules the demo video for the end and the storyboard implies a live run. At that point you are tired, the workspace may have auto-stopped, and one MCP token expiry ruins the take. Ten percent of the score, single point of failure.

**Verdict. Unnecessary risk. Fixable because of a decision already in the PRD.**

**Fix. Trace-replay mode.** FR-23 already requires emitting a per-case JSON trace of every node, tool call, argument, latency and token count. Build the UI to *render a stored trace* as if live. Then:

- Record the demo against frozen traces. Zero dependency on the database, the network, or the LLM.
- Re-take as many times as you like; output is identical.
- The replay doubles as the "agentic design" evidence in the UI.
- **This is the cheapest 10% in the rubric** and it is unlocked by a workstream (W5) you were building anyway.

---

### G12 — "Twenty human case reviews is five hours you haven't budgeted."

**Challenge.** The schedule has to include reading every answer file and checking verdict, episode boundary, exposure arithmetic, rule citation, SAR consistency and tone. At 15 minutes a case that is five hours, and it is not optional — automated checks cannot catch "the episode stops one transaction too early."

**Verdict. Under-budgeted.**

**Fix.** Split explicitly:

- **Automate everything checkable** (W7): schema, ID existence, arithmetic, SAR↔`FILE_REPORT` agreement, legitimate-verdict invariants, summary sentence count (2–6), SAR sentence count (6–12), citation coverage.
- **Reserve human attention for verdict and episode boundary only.**
- Budget **4 hours**, two passes, **60% of it on the six hardest cases** (HHG-014 the ring case; HHG-010 the $1,000 boundary; HHG-007 and HHG-012 out-of-region; HHG-005/017 near $100).

---

### G13 — "The blog and the social post aren't deliverables, they're gates."

**Challenge.** The submission requires: working agent, GitHub repo, 20 answer files, demo video, **technical blog post**, **social post tagging @TigerGraphDB**. The PRD lists them as D1–D10 but the MoSCoW cut list pushes content down. If a missing blog post zeroes or heavily penalises the submission regardless of agent quality, then content is not a "Should" — it is the cheapest gating item in the plan.

**Verdict. Correct, and it inverts part of the cut list.**

**Fix.** Blog, demo and social post move to **Must**. They are scheduled *after* the answer files freeze (so they can quote real numbers) but they are protected: **no feature work after T-6h, content only.** The one thing worse than a thin blog is no blog.

---

## Part 2 — Revised strategy: score arbitrage

Not all points cost the same. Ranking workstreams by points per hour, given ~36 hours and assuming the graph comes up on time:

| Rank | Workstream | Rubric | Est. points | Est. hours | **Pts/hr** |
|---|---|---|---|---|---|
| 1 | **W2 Policy engine + routing + two-stage action** | NBA 25% | ~25 | 4 | **6.3** |
| 2 | **W7 Validator + 20-file completeness gate** | all (prevents zeros) | ~15 | 3 | **5.0** |
| 3 | **W9 UI (Streamlit) from frozen traces** | Demo 10% + gating | ~8 | 3 | 2.7 |
| 4 | **W10 Demo video (replay)** | Demo 10% | ~8 | 3 | 2.7 |
| 5 | **W3 Core GSQL (8 queries)** | Accuracy 25% + TG depth | ~15 | 6 | 2.5 |
| 6 | **W5 Orchestrator + trace + replay** | Agentic 15% | ~10 | 4 | 2.5 |
| 7 | **W1 Graph up + MCP (required)** | gating | ~10 | 4 | 2.5 |
| 8 | **W4 Detectors + episode segmentation** | Accuracy 25% | ~12 | 6 | 2.0 |
| 9 | **W6 Uncertainty (corrected)** | Accuracy 25% | ~6 | 3 | 2.0 |
| 10 | **W8 Memory + GraphRAG** | Agentic 15% + Innovation | ~6 | 3 | 2.0 |
| 11 | **W11 Blog + social + README** | gating | ~7 | 4 | 1.8 |
| 12 | **W12 Ring / innovation extras** | Innovation 15% | ~5 | 4 | 1.25 |

**The counter-intuitive conclusion: build the policy engine first.**

It is 25% of the score, it is deterministic Python, it needs **no graph, no LLM and no dataset**, it is fully testable in isolation, and it is the thing every other workstream calls into. It is also the piece most teams will implement last, badly, inside their LLM prompt.

Second: **the validator**. It converts "we think the files are right" into "the files are right," and it protects every other point you earn.

Third: **content is not decoration.** It is 10% directly (demo) plus gating.

---

## Part 3 — Operating principles

1. **Completeness beats optimality.** Twenty complete answer files before any single file is improved. Missing fields score zero.
2. **Freeze early, decorate late.** After T-16h nothing in the submission depends on a running database.
3. **Replay, don't perform.** The demo is recorded from frozen traces.
4. **The policy engine is the product.** It is a quarter of the score and it is just code.
5. **Automate every check; spend human attention only on verdicts and episode boundaries.**

---

## Part 4 — Workstreams

### W1 — Graph up + MCP

**Deliverables:** schema.gsql, loading jobs, loaded graph, `tigergraph-mcp` over stdio with `TG_LOG_TOOL_CALLS=true`.

**Sequence (order matters):**
1. Download dataset (708 MB). Start immediately — it is the longest pole.
2. Create Savanna workspace. **Auto-stop is forced on the free tier; assume it will sleep.** Enable auto-start.
3. Load a **subset first**: all transactions for the 20 flagged cards + all cards of those customers + all 5,565 closed cases + identity rows for the loaded transactions + all dimension vertices. Target ~100k rows, minutes not hours.
4. Kick the **full load** off in the background (chunked REST, ≤ 16 MB parts). It is for credibility and for the ring sweep; it must not block development.
5. Smoke-test MCP: `show_graph_details`, then one `run_installed_query`.

**Acceptance:** `get_vertex_count` returns non-zero; MCP answers from the agent process; tool-call log lines appear.

**Stretch:** `DeviceSignature` fuzzy tier; `SHARES_*` materialised edges.

---

### W2 — Policy engine (build first)

Pure Python. No dependencies on any other workstream.

```python
ACTIONS = { ... 14 legal actions ... }

ROUTE = {
    # auto: ALLOW_TRANSACTION, MONITOR_CARD, MONITOR_CONNECTED_CARDS, WARN_CUSTOMER,
    #       VERIFY_WITH_CUSTOMER, STEP_UP_AUTH, GENERATE_REPORT, CREATE_CASE,
    #       ESCALATE_TO_ANALYST, CLOSE_NO_FRAUD
    "BLOCK_CARD":      lambda s: "L1" if s.exposure_usd <= 2500 else "L2",
    "BLOCK_ALL_CARDS": lambda s: "L2",
    "FILE_REPORT":     lambda s: "L2",
    "DECLINE_TRANSACTION": lambda s: "L1",
}

RULES = [R1, R2, R3, R4, R5, R6, R7, R8, R9, R10]   # ordered predicates
# each: when(state) -> (actions, [rule citations])
```

`state` = `(verdict, p, exposure_usd, pattern, channel, n_independent_signals, has_shared_origin, in_ring, is_recurring, response, cards_confirmed_fraud, credentials_compromised)`.

Additional mandatory conditions:

- **§3a case opening:** open a case when `p >= 0.30`, **or** evidence is requested, **or** the customer disputes.
- **§3a SAR:** file when fraud is confirmed/strongly suspected **and** (`exposure > 1000` **or** shared device/region/other-customer fraud **or** coordinated/undocumented).
- **R10 guard:** `BLOCK_ALL_CARDS` requires ≥ 2 confirmed-fraud cards **or** confirmed credential compromise.
- **§7:** every emitted action carries a rule citation. No citation, no action.

**Acceptance:** the Appendix B scenario matrix in `PRD.md` passes as pytest, including all four boundary rows ($2,500 / $2,500.01 / $1,000 / $500).

---

### W3 — Core GSQL (8 queries)

All installed, all parameterised, **all taking `as_of`**, all invoked via `tigergraph__run_installed_query`.

`Q1 txn_context`, `Q2 card_window`, `Q3 cardholder_baseline`, `Q4 device_neighbors`, `Q7 geo_velocity`, `Q10 testing_sequence`, `Q12 recurring_check`, `Q17 episode_expand`.

**Skill gate at T-33h:** if the first query takes > 90 min, cut to 5 and use `tigergraph__run_query` (interpreted) for the rest.

**Channel guard (build this in from the start):** `identity.csv` is **online only**. `ProductCD = W` ⇒ `in_person` ⇒ **no device record**. Every detector must branch on `channel`, and a test must assert that no in-person transaction ever produces a device claim. This is a top-3 source of bugs in this dataset.

**Acceptance:** each query returns correct results on 5 transactions checked by hand against pandas.

---

### W4 — Detectors + episode segmentation

**Detectors** (deterministic, over query output): card testing, CNP, CNP-new-device, out-of-region (with the *duration + simultaneity* test — several days in one new region is a trip, not a clone), ATO.

**Segmentation:**

```
seed        = flagged txn ∪ detector hits on the same card within window
candidates  = expand(seed) via {same card ±window, same device, same region anomaly,
                               same email, NEXT-chain adjacency}
score(c)    = w1·model_anom + w2·device_match + w3·region_novelty
            + w4·amount_z  + w5·time_proximity + w6·product_novelty
boundary    = contiguous window maximising  Σ score(c) − λ·span_hours
hard cap    = no transaction with ts > as_of
```

**Free labels:** closed-case `txn_ids` are 5,565 labelled episodes. Tune the threshold on IoU against them.

**Acceptance:** episode IoU ≥ 0.50 on 10 held-out closed cases.

---

### W5 — Orchestrator + trace + replay

LangGraph state machine, **two LLM nodes** (hypothesis generation, explanation); everything else is code.

```
intake → as_of_bind → episode_construct → hypothesize(LLM)      ← AGENCY: selects queries
   → gather_evidence (MCP, budget-capped) → recall_memory → assess
   → stop_or_continue ──need more──▶ request_evidence → reassess ─┐
   → policy_resolve → rank_actions → case_writeback → explain(LLM) → validate → emit
```

**Trace (FR-23)** is not optional — it powers the UI timeline, the demo replay, and the `tool_calls` / `tokens` / `latency_s` answer fields. Log every node, tool call, argument, latency, token count, **and the queries considered but not run, with the reason.**

**VOI gate** (PRD §9.9): request evidence only if a plausible response could change the action set. If nothing can flip it, stop and say so in `stop_reason`.

**Budgets:** ≤ 30 tool calls, ≤ 60 s per case.

**Controls:** read + append-only MCP profile. No `drop_*`, `delete_*`, `clear_graph_data` exposed.

**Acceptance:** end-to-end run on 3 cases, traces on disk, replay renders identically.

---

### W6 — Uncertainty (corrected per G3)

```
logit(p) = logit(π₀)                                  # explicit assumption, documented
         + γ · Σᵢ wᵢ · log LRᵢ                        # LRs from closed cases (ordering valid)
         + [ log(π_target/(1−π_target)) − log(π_train/(1−π_train)) ]   # G3 correction
p = α·p_det + (1−α)·p_llm                             # α fitted on held-out split
```

- `π₀ ≈ 0.40` for `risk_score` triggers > 0.7; `π₀ ≈ 0.50` for `customer_report` / `analyst_request`. **Documented, not fitted.**
- LRs from the closed cases. Report AUC (valid) and Brier **with the caveat**.
- Bayesian update on the simulated customer response using LRs learned from `analyst_notes`.
- Simulated responses come from a **fixed, disclosed, order-independent policy** — never tuned to reach a preferred verdict.

**Acceptance:** AUC ≥ 0.75 on held-out closed cases; Brier reported with the caveat stated.

---

### W7 — Validator (gates everything)

Fifteen checks, all automatable:

| # | Check |
|---|---|
| 1 | JSON parses against the answer schema |
| 2 | Every ID exists in the dataset (zero tolerance) |
| 3 | `exposure_usd` == Σ|amount| of `affected_txn_ids`, to the cent |
| 4 | `sar.file` ⟺ `FILE_REPORT` ∈ final actions |
| 5 | `sar.file == false` ⇒ empty narrative, empty subjects, 0 amount, empty dates |
| 6 | `verdict == legitimate` ⇒ empty `affected_txn_ids`, `exposure_usd` = 0, `sar.file` = false |
| 7 | `pattern == undocumented` ⇒ `pattern_description` non-empty; else empty |
| 8 | Every action ∈ the 14 legal actions |
| 9 | Every route matches the (action, exposure) routing table |
| 10 | Every action carries a rule citation |
| 11 | `summary` is 2–6 sentences |
| 12 | `narrative` is 6–12 sentences |
| 13 | Every evidence object has `source` and `ref` |
| 14 | `initial` and `final` both present; `what_changed` non-empty |
| 15 | `tool_calls` / `tokens` / `latency_s` populated |

**Acceptance:** 20/20 green. Red blocks the freeze.

---

### W8 — Memory + GraphRAG

- Embed the document corpus (Fraud Policy v1.0 per rule, the five patterns, "Things to know", FinCEN SAR narrative guidance, FFIEC red flags) into `DocChunk.emb`.
- Embed closed cases (`ClosedCase.emb` narrative + `ClosedCase.fp` behavioural fingerprint).
- Write each closed investigation back as `InvestigationCase` with `CASE_TXN / CASE_CARD / CASE_DEVICE / CASE_REGION / CASE_PATTERN / CASE_CITES` edges + `CaseEvent` audit log.
- **Retrieval is hybrid:** vector top-k → 1–2 hop graph expansion → rerank. Pure vector RAG cannot answer "what else touched this device?".
- **Run the 20 cases in `case_pack` order** so memory accumulates and case 12 can cite case 3. Note this in the blog.

---

### W9 — UI (Streamlit under time pressure)

Screens from `PRD.md` §10, all rendering **frozen traces and frozen JSON**: queue, investigation timeline, evidence board, graph explorer, uncertainty panel, action panel with L1/L2 approve buttons, case file + SAR, memory, policy trace.

**Replay mode is mandatory** (G11). If time collapses: a static HTML render of the 20 JSON files with the timeline still beats no UI.

---

### W10 — Demo video (from replay)

Storyboard in `PRD.md` §11.2. 3–5 minutes. **Record against frozen traces.** Raw screen capture with voiceover is acceptable; unedited is acceptable; missing is not.

---

### W11 — Blog + social + README

Blog outline in `PRD.md` §11.1. The honest sections — the G3 selection-bias correction and the G4 backtest gap — are the most credible thing in the submission and cost nothing extra to write.

Social post on X or LinkedIn **tagging @TigerGraphDB**, linking the blog or the demo. Required.

README: what it is, how to run it, architecture, results table with the honest numbers.

---

### W12 — Innovation extras (stretch only)

Ring detection via `tg_wcc` (now cheap — see G5), residual scan for undocumented patterns (R9), expected-cost action ranking, autonomous `monitor/` sweep. **Build only after F1 freeze.**

---

## Part 5 — The schedule

### Track A — 36 hours (the realistic case)

Assumes: no code written, dataset possibly not downloaded, 2–3 builders. Times are **hours to deadline (T-minus)**.

| Block | Window | Work | Owner | Exit test |
|---|---|---|---|---|
| **1. Long poles** | T-36 → T-34 | Download dataset · create Savanna workspace · repo skeleton · deps · **start hand-investigating HHG-002 in pandas** | P1 / P2 / P3 | Dataset on disk, workspace up, MCP answers `show_graph_details` |
| **2. Schema + subset** | T-34 → T-31 | schema.gsql · **subset load** · start full load in background · Q1–Q3 · finish hand-written HHG-002 answer file | P1 / P2 / P3 | Q1–Q3 correct on HHG-002; one hand-written answer file exists |
| **3. Policy engine** | T-31 → T-27 | **W2 in full** + Appendix B pytest suite · Q4, Q7, Q10, Q12 | P2+P3 / P1 | Scenario suite green; 7 queries live |
| **4. Detectors + episode** | T-27 → T-23 | W4 · tune IoU against closed-case `txn_ids` | P1 / P2 | IoU ≥ 0.50 on 10 closed cases |
| **5. Orchestrator** | T-23 → T-19 | W5 · wire W2 · trace + replay | P2 / P3 | End-to-end on 3 cases, traces on disk |
| **6. First batch** | T-19 → T-16 | W7 validator · run all 20 · fix | All | **FREEZE 1 — 20 valid files on disk** |
| **7. Review + polish** | T-16 → T-12 | W6 corrected · W8 memory · human review pass 1 · re-run | All | **FREEZE 2 — final answer files** |
| **8. UI** | T-12 → T-9 | W9 Streamlit from frozen artifacts | P3 | Analyst can follow a case unaided |
| **9. Demo** | T-9 → T-6 | W10 from replay · edit · upload | P3 | Video uploaded |
| **10. Content** | T-6 → T-3 | W11 blog + social + README | P2 / P3 | Blog published, post live |
| **11. Submit** | T-3 → T-1 | Form · verify repo public and clean · verify 20 files · links | P1 | Form submitted |
| **Buffer** | T-1 → T-0 | Savanna cold start, re-runs, disasters | All | — |

### Track A-compressed — 24 hours

Cut, in this order: full graph load (subset only) → ring detection → calibrated model (use heuristic LRs with a documented prior) → React (Streamlit) → 8 queries (5) → the 9-screen UI (4 screens: queue, timeline, evidence, actions). Protect W2, W7, F1, demo, blog.

### Track A-minimum — 12 hours

MVS only: subset graph · 5 queries · policy engine · inline orchestrator (no LangGraph) · 20 files via the deterministic path · 4-screen Streamlit or static HTML · 3-minute raw screen capture · 600-word blog. Expected ceiling ~55–65%. **Still a complete submission, which is the thing most likely to be missing from the pile.**

### Track B — the full PRD build

Only if the effective deadline is a week or more away. Gates G0–G12 from `PRD.md` §12.2, in order, plus: the corrected backtest (G4), the G3 prior correction, `tg_wcc` ring detection, the residual scan, expected-cost ranking, React SPA, and the autonomous `monitor/` sweep.

---

## Part 6 — Freeze discipline

| Freeze | Time | Artifact | Rule |
|---|---|---|---|
| **F1** | T-16h | **20 answer JSONs on disk, schema-valid, ID-valid** | Nothing after this may invalidate them without an explicit re-freeze. Quality work only. |
| **F2** | T-12h | Final answer JSONs | **Frozen.** Content work only after this. |
| **F3** | T-9h | Trace bundle (20 traces) | Demo records from these. Never from a live run. |
| **F4** | T-6h | Demo video uploaded | **No feature work after this. Content only.** |
| **F5** | T-3h | Blog + README + social post | — |
| **F6** | T-1h | Form submitted | — |

The rule behind the freezes: **after F1, no workstream may hold another workstream hostage.** If the graph dies at T-14h, the answer files are already on disk and the content pipeline keeps running.

---

## Part 7 — Kill criteria

Decide these in advance, at the stated time, on the stated evidence. Do not renegotiate under pressure.

| At | If | Then |
|---|---|---|
| T-33h | First GSQL query took > 90 min | Cut to 5 queries; use interpreted `run_query` |
| T-28h | Full load < 30% | Subset graph only; disclose it in the blog |
| T-24h | Policy suite not green | **Stop everything else.** It is 25% of the score. |
| T-20h | < 6 queries installed | Interpreted queries; drop to 5 |
| T-16h | **< 20 valid files** | Ship the deterministic path for the remainder — policy engine + minimal evidence. A thin policy-legal answer beats a missing file. |
| T-12h | Episode IoU < 0.40 | Freeze heuristic segmentation |
| T-12h | No UI | Streamlit minimal, or static HTML render of the JSONs |
| T-9h | Agent flaky | Demo from replay (already the plan) |
| T-6h | No video | 3-minute raw screen capture, unedited |
| T-4h | Blog unfinished | Ship the short version: architecture diagram + honest numbers + what we'd improve |
| T-2h | Anything broken | **Submit what is complete.** No resubmissions exist. |

---

## Part 8 — Parallelisation

| Role | Owns | Notes |
|---|---|---|
| **P1 — Graph** | W1, W3, W12 | Longest pole. Starts first. Never blocks anyone after the subset load. |
| **P2 — Agent** | W2, W5, W6 | **W2 needs no graph** — start it at T-31h at the latest even if the graph is late. |
| **P3 — Product** | W4, W7, W9, W10, W11 | Owns the validator and all content. P3 is the schedule's shock absorber. |
| **Solo** | All, in the Track A order | Cut to Track A-minimum. Build W2 first regardless — it is 25% and it needs nothing else. |

**Critical-path note:** the hand-investigation of HHG-002 can be done **in pandas while the graph loads.** You do not need TigerGraph to learn what a good answer looks like. Start it at T-36h.

---

## Part 9 — Updated risk register

| # | Risk | Sev | Mitigation |
|---|---|---|---|
| R1 | **Savanna auto-stop is forced on free tier** | **High** | F1/F2 freezes; demo from replay; warm the workspace before you need it |
| R2 | **Over-blocking from a mis-specified prior** | **High** | G3 correction; explicit documented `π₀`; R1 enforced in code |
| R3 | Identity gap — in-person transactions have no device | High | Branch every detector on `channel`; test asserts no device claim for `ProductCD = W` |
| R4 | Temporal leakage | High | `as_of` on every query; test: `as_of = 2016-07-01` ⇒ empty results |
| R5 | Full load too slow | High | Subset-first; disclose if subset-only |
| R6 | GSQL inexperience | Medium | 8 → 5 queries; interpreted `run_query` fallback; `generate_gsql` for authoring |
| R7 | LLM invents IDs or actions | High | Validator gate; evidence-constrained generation; policy engine owns actions |
| R8 | MCP token expiry mid-run | Medium | Fresh token per run; per-case idempotency; never write a partial answer file |
| R9 | Backtest flatters the agent | Medium | G4 re-specification; report easy and honest numbers side by side |
| R10 | Human review under-budgeted | Medium | 4 hours, two passes, 60% on the 6 hardest cases |
| R11 | Content left to the end and skipped | **High** | W11 is Must; hard stop on feature work at T-6h |
| R12 | Boundary errors cascade into routing | Medium | W4 free labels; near-threshold cases to human review |
| R13 | Disqualification | **Total** | Never touch the public Kaggle/IEEE-CIS files; every ID must exist in the provided dataset |

---

## Part 10 — Open questions

I need three facts to finalise this into a minute-by-minute plan, and one decision to start:

1. **How much time do you actually have?** The plan above assumes ~36 hours. If you have a week, Track B applies and the whole shape changes.
2. **What is already done?** Specifically: is the dataset downloaded, is the graph loaded, is there any code?
3. **How many builders?** Solo vs three changes the parallelisation entirely.
4. **Do you want me to start building now?** My recommendation is **W2 — the policy engine and its pytest scenario suite**. It is 25% of the score, it needs no graph, no dataset and no LLM, it is finished in about four hours, and every other workstream calls into it.

---

---

## Part 11 — Addendum: solo builder + agentic development

**Context:** one builder, nothing built, 24–48 hours, and the build itself will be done with coding agents. This does not change the architecture or the strategy. It changes the *shape of the constraint*, and it introduces one new risk that outweighs everything else in this document.

### 11.1 The constraint moves from typing to judging

Agentic development makes generation nearly free. So the binding constraint is no longer how fast you can write code — it is **how fast you can tell whether the code is right.** With three humans that cost was spread across reviewers; solo, it lands entirely on you.

The practical consequence: **the schedule must be built around verification, not generation.** Every workstream below is costed with generation time *plus* your verification time, and verification is the part that does not compress.

### 11.2 The central risk: silent wrongness

This is the thing to watch. A coding agent will produce code that looks correct, runs clean, and is subtly wrong — and the failure modes specific to *this* task are all silent:

| Failure mode | What it looks like | What it costs |
|---|---|---|
| A detector that fires on in-person transactions | Plausible device evidence | Wrong findings on every `ProductCD = W` case |
| `>=` where the policy says `>` | Fine | Wrong approval route at $2,500; wrong SAR at $1,000 |
| Episode boundary one transaction too wide | Fine | Wrong `exposure_usd` → wrong route, wrong SAR decision |
| Prior fitted on the 84%-fraud closed-case population | Confident probabilities | Systematic over-blocking — a policy breach |
| IDs assembled from patterns instead of read from the graph | Realistic-looking IDs | **Zero** for that part |
| `as_of` omitted from one query in twelve | Fine | Future leakage; indefensible case |

None of these throw an exception. All of them produce confident, well-formatted, wrong answer files. **Two defences only:**

1. **The validator (W7).** The 15 automated checks are the only thing standing between generated code and 20 plausible-but-broken files. It is now the highest-value workstream after W2.
2. **The hand-investigation.** Ninety minutes on HHG-002, in pandas, before any agent writes investigation code. It is the only ground truth you personally hold, and it is the only thing that lets you recognise agent-generated nonsense when you see it. **Solo, this is not optional — it is your calibration.**

### 11.3 Wall-clock dependencies that agentic dev cannot compress

No amount of throughput shortens:

- the **708 MB** dataset download
- the **590,742**-row load (chunked REST)
- GSQL `INSTALL QUERY` compile times
- **Savanna cold start** (and auto-stop is forced on the free tier)

These *are* the schedule. Everything else is elastic. **Start the download and the workspace before you write or generate a single line of code.**

A second, softer wall: `INSTALL QUERY` compiles can take minutes each. If GSQL is new to you, use interpreted `tigergraph__run_query` to stay unblocked and install later (G10).

### 11.4 Re-costed workstreams (solo, agentic)

| W | Roadmap est. | Agentic-solo est. | Note |
|---|---|---|---|
| W1 Graph up + MCP | 4h | **4h** | Wall-clock bound. Cannot compress. Start first. |
| W2 Policy engine | 4h | **2h + 1h verification** | Agent writes it fast; **you** verify the comparison operators |
| W3 Core GSQL | 6h | **3h** | Agent + `generate_gsql` + interpreted fallback |
| W4 Detectors + segmentation | 6h | **4h** | Generation is cheap; tuning against closed-case `txn_ids` is not |
| W5 Orchestrator + trace | 4h | **2h** | LangGraph boilerplate is easy for an agent |
| W6 Uncertainty | 3h | **2h** | But the G3 prior correction is *your* decision, not the agent's |
| W7 **Validator** | 3h | **3h + 1h** | Same cost. **Higher value.** Verify line by line. |
| W8 Memory + GraphRAG | 3h | **2h** | |
| W9 UI (Streamlit) | 3h | **1.5h** | Agent-generated; replay-only, so low risk |
| W10 Demo (replay) | 3h | **2h** | |
| W11 Blog + social | 4h | **2h** | |
| W12 Innovation extras | 4h | **3h** | Stretch. Only after F1. |
| **Verification overhead** | — | **+6h** | **New line item. Non-negotiable. Protect it.** |
| **Total** | ~50h | **~38h** | Fits 24–48h **only if verification is protected** |

### 11.5 Revised solo sequence (48h; if 24h, apply Part 5 Track A-compressed)

Single-threaded, with the download and full graph load running as background jobs from hour zero.

| Phase | Window | Work | Gate |
|---|---|---|---|
| **0** | T-48 → T-46 | **Start download + Savanna + CE fallback.** Hand-investigate HHG-002 in pandas *while the graph loads* | Dataset on disk; hand-written answer file begun |
| **1** | T-46 → T-44 | schema.gsql · subset load · full load in background · MCP smoke test | MCP answers from the agent process |
| **2** | T-44 → T-42 | **W2 policy engine + Appendix B scenario suite.** Verify every operator yourself | Suite green, including all four boundary rows |
| **3** | T-42 → T-38 | W3 8 GSQL queries · W4 detectors + segmentation (tune IoU on closed-case labels) | IoU ≥ 0.50 on 10 closed cases |
| **4** | T-38 → T-34 | W5 orchestrator + trace + replay | End-to-end on 3 cases, traces on disk |
| **5** | T-34 → T-30 | W6 uncertainty (**with the G3 correction**) · W8 memory | AUC ≥ 0.75; Brier reported with caveat |
| **6** | T-30 → T-27 | **W7 validator** · first full 20-case batch | **FREEZE 1 — 20 valid files on disk** |
| **7** | T-27 → T-22 | **VERIFY.** Human review pass. 60% of attention on the 6 hardest cases | **FREEZE 2 — final answer files** |
| **8** | T-22 → T-18 | W9 Streamlit from frozen artifacts (replay only) | Walk a case unaided |
| **9** | T-18 → T-14 | W10 demo video from replay · upload | Video live |
| **10** | T-14 → T-10 | W11 blog + social + README | Published |
| **11** | T-10 → T-8 | Submit · verify repo public and clean · buffer | Form submitted |

**Sleep.** Take six hours somewhere around T-30 → T-24. Phase 7 is where correctness lives, and a degraded review at hour 40 costs more points than six hours of extra build time earns. This is the one place where "time is not a constraint" is not true: *your* attention is the constraint, and it depletes.

### 11.6 Working agreement with your coding agent

Concrete rules. Give the agent `PRD.md` and this roadmap as context — that is what they are for.

1. **The agent never writes `next_best_actions`.** The policy engine owns it. Full stop.
2. **`as_of` is a required parameter of every GSQL query.** The agent will forget. Make it a template.
3. **Every threshold comparison carries a comment quoting the policy line.** `> 1000  # R2: "exposure exceeds $1,000"`.
4. **Test before detector.** Ask for the pytest case before the implementation.
5. **No "looks reasonable."** Demand that every ID be shown to exist in the dataset.
6. **`channel` guard from the start.** Every detector branches on `in_person` vs `online`; assert no device claim ever arises for `ProductCD = W`.
7. **Emit `LIMITATIONS.md` as you go.** You will need it for the blog's "what we would improve with more time," and it is far more honest written at hour 20 than at hour 46.

### 11.7 The trap that agentic dev sets specifically for you

Throughput makes over-building *more* likely, not less. When generating a feature costs fifteen minutes, every feature looks cheap, and the kill criteria in Part 7 start to feel like pessimism.

They are not. **The completeness principle still dominates:** twenty complete answer files beat eighteen brilliant ones and two missing, because missing fields score zero. And the freeze discipline matters *more* solo, not less — you are the only person who can catch an error, and you will be worse at it the longer you go.

Build W2 first. Freeze at F1. Then decorate.

---

*End of roadmap. Freeze early, decorate late, and submit something complete.*
