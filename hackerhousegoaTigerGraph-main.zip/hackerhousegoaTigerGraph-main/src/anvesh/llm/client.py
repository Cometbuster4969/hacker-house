"""LLM access. Provider-agnostic, temperature 0, always optional.

Two nodes use it (docs/STATE.md §2): hypothesis generation and explanation.
If no provider is configured, template fallbacks run instead — the pipeline
never hard-depends on an API (NFR: deterministic replay must be possible).
"""

from __future__ import annotations

import json
import os
from typing import Any


class LLMError(RuntimeError):
    pass


class NullLLM:
    """No model configured. Every call raises; callers fall back to templates."""

    available = False

    def complete(self, system: str, user: str, schema: type | None = None,
                 temperature: float = 0.0) -> Any:
        raise LLMError("no LLM provider configured")


class OpenAICompatLLM:
    """Talks to any OpenAI-compatible chat-completions endpoint."""

    available = True

    def __init__(self, model: str | None = None, base_url: str | None = None,
                 api_key: str | None = None) -> None:
        self.model = model or os.getenv("LLM_MODEL", "gemini-2.5-flash")
        self.base_url = base_url or os.getenv("LLM_BASE_URL",
                                              "https://generativelanguage.googleapis.com/v1beta/openai/")
        self.api_key = api_key or os.getenv("LLM_API_KEY", "")

    def complete(self, system: str, user: str, schema: type | None = None,
                 temperature: float = 0.0) -> Any:
        import urllib.request

        payload: dict[str, Any] = {
            "model": self.model,
            "temperature": temperature,
            "messages": [{"role": "system", "content": system},
                         {"role": "user", "content": user}],
        }
        if schema is not None:
            payload["response_format"] = {"type": "json_object"}

        req = urllib.request.Request(
            self.base_url.rstrip("/") + "/chat/completions",
            data=json.dumps(payload).encode(),
            headers={"Content-Type": "application/json",
                     "Authorization": f"Bearer {self.api_key}"},
        )
        with urllib.request.urlopen(req, timeout=60) as r:
            body = json.loads(r.read().decode())
        text = body["choices"][0]["message"]["content"]
        if schema is not None:
            return json.loads(text)
        return text


def get_llm():
    """Return a configured client, or NullLLM when no key is present."""
    if os.getenv("LLM_API_KEY"):
        try:
            return OpenAICompatLLM()
        except Exception:
            return NullLLM()
    return NullLLM()
