"""Fit the likelihood table from the closed-case corpus.

docs/BACKTEST.md §5 — closed-case `txn_ids` are 5,565 free labelled episodes.
This module turns them into training rows for the LR table and for episode
segmentation tuning.

Fit on TRAIN only. Never touch EVAL (docs/BACKTEST.md §4).
"""

from __future__ import annotations

from datetime import timedelta

from ..domain.enums import Channel
from ..domain.models import Baseline, ClosedCase, Episode, EvidenceContext
from ..evidence.features import build_features
from .likelihood import LikelihoodTable

BASELINE_DAYS = 90


def context_for_closed_case(adapter, case: ClosedCase) -> EvidenceContext | None:
    """Rebuild the context an analyst would have seen at case open time."""
    flagged_id = case.first_fraud_txn_id or (case.txn_ids[0] if case.txn_ids else None)
    if not flagged_id:
        return None
    flagged = adapter.txn_context(case.opened_at, flagged_id)
    if flagged is None:
        return None

    window = adapter.card_window(case.opened_at, case.card_id, 48)
    baseline = adapter.cardholder_baseline(case.opened_at, case.card_id, BASELINE_DAYS)
    geo = adapter.geo_velocity(case.opened_at, case.card_id, 48)

    device_cards, device_cases = [], []
    if flagged.channel is Channel.ONLINE and flagged.device_id:
        dn = adapter.device_neighbors(case.opened_at, flagged.device_id, 30)
        device_cards = [c for c in dn.card_ids if c != case.card_id]
        device_cases = dn.closed_cases

    return EvidenceContext(
        as_of=case.opened_at,
        flagged_txn_id=flagged_id,
        card_id=case.card_id,
        customer_id=case.customer_id,
        channel=flagged.channel,
        flagged=flagged,
        window_txns=window,
        baseline=baseline,
        geo_pairs=geo,
        device_cards=device_cards,
        device_closed_cases=device_cases,
        customer_cards=adapter.customer_cards(case.customer_id),
    )


def episode_from_closed_case(adapter, case: ClosedCase) -> Episode:
    amounts = []
    for tid in case.txn_ids:
        t = adapter.txn_context(case.opened_at, tid)
        if t is not None:
            amounts.append(abs(t.amount))
    return Episode(
        txn_ids=list(case.txn_ids),
        first_suspicious_txn_id=case.first_fraud_txn_id or (case.txn_ids[0] if case.txn_ids else ""),
        exposure_usd=round(sum(amounts), 2),
    )


def fit_table(adapter, closed_cases: list[ClosedCase],
              limit: int | None = None) -> tuple[LikelihoodTable, int]:
    """Estimate per-feature log-likelihood-ratios from labelled closed cases."""
    rows: list[dict[str, float]] = []
    outcomes: list[bool] = []

    cases = closed_cases[:limit] if limit else closed_cases
    for case in cases:
        ctx = context_for_closed_case(adapter, case)
        if ctx is None:
            continue
        ep = episode_from_closed_case(adapter, case)
        rows.append(build_features(ctx, ep))
        outcomes.append(case.outcome == "confirmed_fraud")

    table = LikelihoodTable().fit(rows, outcomes)
    return table, len(rows)
